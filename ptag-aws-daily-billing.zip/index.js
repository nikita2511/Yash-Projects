"use strict";
const Sequelize = require("sequelize");
const AthenaExpress = require("athena-express"),
  AWS = require("aws-sdk"),
  mysql = require("mysql");
var iam = new AWS.IAM();
const sequelize = new Sequelize(
  process.env.DATABASE,
  process.env.USER,
  process.env.PASSWORD,
  {
    host: process.env.HOST,
    dialect: process.env.DIALECT,
  }
);
let accountNumber;
let table2;
let alias;
const athenaExpressConfig = {
  aws: AWS,
  db: process.env.DB,
  getStats: true,
};
const athenaExpress = new AthenaExpress(athenaExpressConfig);
let connection = mysql.createConnection({
  host: process.env.HOST,
  user: process.env.USER,
  password: process.env.PASSWORD,
  database: process.env.DATABASE,
});
const d = new Date();
exports.handler = async (callback) => {
  try {
    let params = {};
    const list = await iam.listAccountAliases(params).promise();
    if (list.AccountAliases.length) {
      alias = list.AccountAliases[0];
    } else {
      alias = "No Alias Available";
    }
    console.log("list", list);
  } catch (e) {
    console.log("error", e);
  }
  await sequelize.authenticate();
  connection.connect(function (err) {
    if (err) {
      console.error("Database connection failed: " + err.stack);
      return;
    } else {
      console.log("Connected to database.");
    }
  });

  let currentMonth = d.getMonth() + 1 + "";
  let currentYear = d.getFullYear() + "";
  let yesterday = new Date();
  yesterday.setDate(d.getDate() - 1);

  let yesterdayDate = yesterday.toISOString().split("T")[0];
  const sqlQueryAllProduct = `SELECT line_item_product_code, max(line_item_usage_account_id) As account_id, max(line_item_usage_end_date) AS time ,Round(sum(line_item_blended_cost),3)  AS cost FROM aws_daily_billing_report WHERE line_item_usage_start_date >= to_timestamp('${yesterdayDate} 00:00:00', 'yyyy-mm-dd hh24:mi:ss') AND  line_item_usage_end_date <= to_timestamp('${yesterdayDate} 23:59:59', 'yyyy-mm-dd hh24:mi:ss')  GROUP BY  line_item_product_code, month HAVING sum(line_item_blended_cost) > 0 ORDER BY  cost desc;`;
  //const sqlQueryAllProduct=`SELECT line_item_product_code, max(line_item_usage_account_id) As account_id, max(line_item_usage_end_date) AS time ,Round(sum(line_item_blended_cost),3)  AS cost FROM aws_daily_billing_report WHERE line_item_usage_start_date >= to_timestamp('2022-09-13 00:00:00', 'yyyy-mm-dd hh24:mi:ss') AND  line_item_usage_end_date <= to_timestamp('2022-09-13 23:59:59', 'yyyy-mm-dd hh24:mi:ss')  GROUP BY  line_item_product_code, month HAVING sum(line_item_blended_cost) > 0 ORDER BY  cost desc;`;
  try {
    let timePeriodRecords = await athenaExpress.query(sqlQueryAllProduct);
    console.log("all product", timePeriodRecords);
    if (timePeriodRecords.length != 0) {
      accountNumber = timePeriodRecords.Items[0].account_id;
      table2 = `daily_billing_${accountNumber}`;
      let response =
        await sequelize.query(`CREATE TABLE IF NOT EXISTS daily_billing_${accountNumber} (
    service_name VARCHAR(100),
	cost dOUBLE(100,3),
	time TIMESTAMP(6),
	account_id VARCHAR(50)
 );`);
      const readyForDB = timePeriodRecords.Items.map((x) => {
        let name = x.line_item_product_code;
        let cost = x.cost;
        let time = x.time;
        let accountid = x.account_id;
        return [name, cost, time, accountid];
      });

      if (response) {
        //insertion of accountid and table name in master table
        let searchForAccountIdQuery = `select * from aws_billing_master_table where account_id=${accountNumber};`;
        let searchResponse = await sequelize.query(searchForAccountIdQuery);
        console.log(
          "-------search res of master table--------",
          searchResponse
        );
        if (searchResponse[0].length) {
          let tableNameInsertQuery = `UPDATE aws_billing_master_table set account_id=${accountNumber},account_name='${alias}', daily_billing_table_name='${table2}';`;
          let insertResponse = await sequelize.query(tableNameInsertQuery);
          console.log(
            "----data updated in master table successfully ",
            insertResponse
          );
        } else {
          let tableNameInsertQuery = `INSERT  INTO aws_billing_master_table(account_id,account_name,daily_billing_table_name) VALUES(${accountNumber},'${alias}','${table2}');`;
          let insertResponse = await sequelize.query(tableNameInsertQuery);
          console.log(
            "----data inserted succesfully in master table",
            insertResponse
          );
        }
        var sqlallproduct = `INSERT INTO daily_billing_${accountNumber}(service_name,cost,time,account_id) VALUES ?`;
        connection.query(sqlallproduct, [readyForDB], function (err, result) {
          if (err) throw err;
          console.log(result.affectedRows + " rows inserted");
        });
        return "Data saved to DB";
      }
    } else {
      return `sorry,data for this time period is not available`;
    }
  } catch (err) {
    console.log(err);
    return err;
  }
};
