import React, { Component } from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import { createUser } from "../../actions/userAction";

class RegisterUser extends Component {
  constructor(props) {
    super(props);
    this.state = {
      name: "",
      email: "",
      mobileNumber: "",
      empId: "",
      loading: false,
    };
    this.onChange = this.onChange.bind(this);
  }
  onChange(event) {
    this.setState({ [event.target.name]: event.target.value });
  }
  onFinish = async () => {
    let user = {
      name: this.state.name,
      email: this.state.email,
      mobileNumber: "91" + this.state.mobileNumber,
      empId: this.state.empId,
      // status: true,
    };
    this.props.createUser(user);
    this.setState({ loading: true });
    setTimeout(() => {
      this.setState({ loading: false });
    }, 1000);
  };
  render() {
    return (
      <div className="add-user">
        <div className="container-fluid">
          <div className="card mt-5">
            <div className="card-body">
              <h1>Helloo..!!</h1>

              {/* <Row gutter={[0, 20]}>
                <Col xs={8} sm={8} md={8} lg={8} xl={8}>
                  <div className="pages-header text-success">
                    Yash User Registration
                  </div>
                  <div className="img-register-page">
                    <img src={yashLogo} alt="logo" width="100" height="75" />
                  </div>
                </Col>
                <Col xs={16} sm={16} md={16} lg={16} xl={16}>
                  <Form
                    name="add-users"
                    className="add-users"
                    onFinish={this.onFinish}
                    initialValues={{ remember: true }}
                  >
                    <Row gutter={[16, 0]}>
                      <Col xs={12} sm={12} md={12} lg={12} xl={12}>
                        <Form.Item
                          name="mobileNumber"
                          rules={[
                            {
                              required: true,
                              message: "Please enter your  Mobile Number!",
                            },
                            {
                              min: 10,
                              message: "Mobile must be 10-digits!",
                            },
                            {
                              max: 10,
                              message: "Mobile must be 10-digits!",
                            },
                            ({ getFieldValue }) => ({
                              validator(_, value) {
                                var hasAlphabets = /^[0-9]+$/;
                                if (
                                  parseInt(getFieldValue("mobileNumber")) &&
                                  hasAlphabets.test(
                                    getFieldValue("mobileNumber")
                                  )
                                ) {
                                  return Promise.resolve();
                                }
                                return Promise.reject(
                                  "Should contain numbers!"
                                );
                              },
                            }),
                          ]}
                        >
                          <Input
                            type="string"
                            name="mobileNumber"
                            id="mobileNumber"
                            value={this.state.mobileNumber}
                            onChange={this.onChange}
                            placeholder="Mobile Number"
                          />
                        </Form.Item>
                      </Col>
                      <Col xs={12} sm={12} md={12} lg={12} xl={12}>
                        <Form.Item
                          name="email"
                          rules={[
                            {
                              required: true,
                              message: "Please enter your Email!",
                            },
                            {
                              type: "email",
                              message: "The input is not a valid E-mail!",
                            },
                          ]}
                        >
                          <Input
                            type="email"
                            name="email"
                            id="email"
                            value={this.state.email}
                            onChange={this.onChange}
                            placeholder="Email"
                          />
                        </Form.Item>
                      </Col>
                    </Row>
                    <Row gutter={[16, 0]}>
                      <Col xs={12} sm={12} md={12} lg={12} xl={12}>
                        <Form.Item
                          name="name"
                          rules={[
                            {
                              required: true,
                              message: "Please Enter Name !",
                            },
                          ]}
                        >
                          <Input
                            placeholder="Name"
                            name="name"
                            value={this.state.name}
                            onChange={this.onChange}
                          />
                        </Form.Item>
                      </Col>
                      <Col xs={12} sm={12} md={12} lg={12} xl={12}>
                        <Form.Item
                          name="empId"
                          rules={[
                            {
                              required: true,
                              message: "Please Enter Employee Id !",
                            },
                          ]}
                        >
                          <Input
                            placeholder="Employee Id"
                            name="empId"
                            value={this.state.empId}
                            onChange={this.onChange}
                          />
                        </Form.Item>
                      </Col>
                    </Row>
                    <Form.Item>
                      <Button
                        type="primary"
                        htmlType="submit"
                        className="ok-modal"
                        loading={loading}
                        block
                      >
                        Add User
                      </Button>
                    </Form.Item>
                  </Form>
                </Col>
              </Row> */}
            </div>
          </div>
        </div>
      </div>
    );
  }
}
RegisterUser.propTypes = {
  createUser: PropTypes.func.isRequired,
};

export default connect(null, { createUser })(RegisterUser);
