import { withAuthenticator } from "@aws-amplify/ui-react";
// import yashLogo from "../../assests/img/download-removebg-preview.png";
import RegisterUser from "./RegisterUser";
// import { Auth } from "aws-amplify";
import React from "react";
import "./SignIn.css";
import AuthHeader from "../layouts/AuthHeader";
import AdminDashboard from "../dashboard/AdminDashboard";

function SignIn(currentUser, location) {
  // Todo logic here

  return (
    <div className="header">
      {/* Add Todo JSX here  
      {console.log("user", user)}
      <Heading level={1}>Hello {user.attributes.name}</Heading> <Test />
      <Button onClick={signOut}>Sign out</Button>
      <AuthHeader />
      {console.log("###locationlocation", location)}
      <AdminDashboard user={currentUser} location={location} />*/}
      {/** <RegisterUser /> */}
    </div>
  );
}

export default withAuthenticator(SignIn);
