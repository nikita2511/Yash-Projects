import React, { Component } from "react";
import { connect } from "react-redux";
import {
  getAllUsers,
  broadCastMessage,
  getAllGroups,
} from "../../actions/userAction";
import {
  Upload,
  Col,
  Form,
  Input,
  Row,
  Modal,
  Button,
  Table,
  Switch,
  Tag,
  Spin,
  message,
} from "antd";
import { LoadingOutlined, PlusOutlined } from "@ant-design/icons";
const { TextArea } = Input;

function getBase64(file) {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    reader.readAsDataURL(file);
    reader.onload = () => resolve(reader.result);
    reader.onerror = (error) => reject(error);
  });
}
const userCol = [
  {
    title: "Name",
    dataIndex: "name",
    align: "left",
  },
  {
    title: "MobileNumber",
    dataIndex: "mobileNumber",
    align: "left",
  },
  {
    title: "Email",
    dataIndex: "email",
    align: "left",
  },
  {
    title: "Emp Id",
    dataIndex: "empId",
    align: "left",
  },
];
const groupCol = [
  {
    title: "Name",
    dataIndex: "name",
    align: "left",
  },
  {
    title: "Total Members",
    key: "operation",
    align: "left",
    render: (record) => {
      return (
        <>
          {record.members.length > 0 ? (
            <Tag color="green">{record.members.length}</Tag>
          ) : (
            <Tag color="volcano">{record.members.length}</Tag>
          )}
        </>
      );
    },
  },
];
class BroadcastComponent extends Component {
  constructor(props) {
    super(props);
    this.state = {
      message: "",
      recipients: [],
      noRecipientsSelectedError: false,
      previewVisible: false,
      previewImage: "",
      previewTitle: "",
      fileList: [],
      image: "",
      showUserTable: true,
      errors: {},
    };
    this.onChange = this.onChange.bind(this);
    this.onSubmit = this.onSubmit.bind(this);
    this.onSelectRow = this.onSelectRow.bind(this);
    this.onSelectGroupRow = this.onSelectGroupRow.bind(this);
  }

  handleCancel = async (file) => {
    this.setState({
      previewVisible: false,
    });
  };

  handlePreview = async (file) => {
    if (!file.url && !file.preview) {
      file.preview = await getBase64(file.originFileObj);
    }

    this.setState({
      previewImage: file.url || file.preview,
      previewVisible: true,
      previewTitle:
        file.name || file.url.substring(file.url.lastIndexOf("/") + 1),
    });
  };

  handleFileChange = ({ fileList }) => {
    console.log("fileChange=====>", fileList);

    this.setState({ fileList });
  };

  beforeUpload = (file) => {
    const isJpgOrPng = file.type === "image/jpeg" || file.type === "image/png";
    if (!isJpgOrPng) {
      message.error("You can only upload JPG/PNG file!");
    }
    const isLt2M = file.size / 1024 / 1024 < 5;
    if (!isLt2M) {
      message.error("Image must smaller than 5MB!");
    }
    return isJpgOrPng && isLt2M;
  };

  handleChange = (value) => {
    console.log(`selected ${value}`);
    this.setState({ recipients: value });
  };
  onSubmit = (event) => {
    if (this.state.recipients.length === 0) {
      this.setState({ noRecipientsSelectedError: true });
    } else {
      let requestObj = {};
      if (this.state.fileList.length > 0) {
        let finalUrl = "";
        let url = this.state.fileList[0].thumbUrl.split("base64,");
        console.log("c====>", url[1]);
        finalUrl = finalUrl.concat(url[1]);
        requestObj = {
          broadcastMessage: this.state.message,
          recipients: this.state.recipients,
          mimetype: this.state.fileList[0].type,
          file: finalUrl,
        };
      } else {
        requestObj = {
          broadcastMessage: this.state.message,
          recipients: this.state.recipients,
          file: null,
          mimetype: null,
        };
      }
      console.log("------------req obj", requestObj);
      this.props.broadCastMessage(requestObj, this.props.history);
    }
  };
  componentDidMount() {
    let res = this.props.getAllUsers(this.props.history);
    let gResp = this.props.getAllGroups(this.props.history);
  }
  onChange = (event) => {
    this.setState({ [event.target.name]: event.target.value });
  };
  onSelectRow(arr) {
    console.log("#arr", arr);
    this.setState({ noRecipientsSelectedError: false });
    this.setState({ recipients: arr });
  }
  onSelectGroupRow(arr) {
    console.log("#arr", arr);
    this.setState({ noRecipientsSelectedError: false });
    this.setState({ recipients: arr });
  }
  onSwitchChange = (checked) => {
    this.setState({ showUserTable: checked });
    console.log(`#switch to ${checked}`);
  };
  render() {
    const antIcon = <LoadingOutlined style={{ fontSize: 24 }} spin />;
    console.log("-----props--", this.props);
    const rowSelection = {
      onChange: (selectedRowKeys, selectedRows) => {
        console.log("selectedRows: ", selectedRows);
        this.onSelectRow(selectedRows);
      },
    };
    const rowGroupSelection = {
      onChange: (selectedRowKeys, selectedRows) => {
        let members = [];
        selectedRows.map((select) => {
          members = select.members;
        });
        console.log("#mem", members);
        this.onSelectGroupRow(members);
      },
    };
    console.log("test", this.state.recipients);
    console.log("---props-------", this.props.sendBroadcastMsg);
    const { users, groups } = this.props;
    const { previewVisible, previewImage, fileList, previewTitle } = this.state;
    const uploadButton = (
      <div>
        <PlusOutlined />
        <div style={{ marginTop: 8 }}>Upload Documents</div>
      </div>
    );
    return (
      <div className="container dashboard statistics-card">
        <Row className="title-row">
          <Col xs={24} sm={24} md={24} lg={24} xl={24}>
            <div className="d-flex flex-row">
              <div className="pages-header">Broadcast</div>
            </div>
          </Col>
        </Row>
        <div className="mt-4">
          <div className="card">
            <div className="card-body p-5">
              <Form
                name="add-users"
                className="add-users"
                onFinish={this.onSubmit}
                initialValues={{ remember: true }}
              >
                <div style={{ margin: "-15px 0 15px 0" }}>
                  <Switch
                    onChange={this.onSwitchChange}
                    checkedChildren="Users"
                    unCheckedChildren="Groups"
                    defaultChecked
                  />
                </div>
                <Row gutter={[16, 24]}>
                  {this.state.showUserTable ? (
                    <Col
                      xs={24}
                      sm={24}
                      md={24}
                      lg={17}
                      xl={17}
                      style={{ borderRight: "1px solid rgba(0, 0, 0, 0.05)" }}
                    >
                      <div
                        style={{
                          flex: 1,
                          flexDirection: "row",
                          display: "flex",
                        }}
                      >
                        <h4 style={{ color: "red" }}>*</h4>
                        <h4 style={{ fontWeight: "bold" }}>
                          &nbsp; Please Select Recipients
                        </h4>
                      </div>
                      {users.length ? (
                        <Table
                          rowSelection={{
                            ...rowSelection,
                          }}
                          columns={userCol}
                          dataSource={users}
                          rowKey="_id"
                          align="left"
                        />
                      ) : (
                        <div className="p-5" style={{ marginLeft: "34%" }}>
                          <Spin indicator={antIcon} />
                        </div>
                      )}
                    </Col>
                  ) : (
                    <Col
                      xs={24}
                      sm={24}
                      md={24}
                      lg={17}
                      xl={17}
                      style={{ borderRight: "1px solid rgba(0, 0, 0, 0.05)" }}
                    >
                      <div
                        style={{
                          flex: 1,
                          flexDirection: "row",
                          display: "flex",
                        }}
                      >
                        <h4 style={{ color: "red" }}>*</h4>
                        <h4 style={{ fontWeight: "bold" }}>
                          &nbsp; Please Select Group
                        </h4>
                      </div>
                      {groups.length ? (
                        <Table
                          rowSelection={{
                            ...rowGroupSelection,
                          }}
                          columns={groupCol}
                          dataSource={groups}
                          rowKey="_id"
                          align="left"
                        />
                      ) : (
                        <div className="p-5" style={{ marginLeft: "34%" }}>
                          <Spin indicator={antIcon} />
                        </div>
                      )}
                    </Col>
                  )}

                  <Col xs={24} sm={24} md={24} lg={6} xl={6}>
                    <Row gutter={[8, 0]}>
                      <div
                        style={{
                          flex: 1,
                          flexDirection: "row",
                          display: "flex",
                          margin: "0 0 10px 0",
                          justifyContent: "center",
                        }}
                      >
                        <h4 style={{ fontWeight: "bold", textAlign: "center" }}>
                          Broadcast Message
                        </h4>
                      </div>
                      <Col xs={24} sm={24} md={24} lg={24} xl={24}>
                        <Form.Item
                          name="upload"
                          valuePropName="fileList"
                          // getValueFromEvent={normFile}
                        >
                          <Upload
                            className="d-flex justify-content-center"
                            action="https://www.mocky.io/v2/5cc8019d300000980a055e76"
                            accept=".png, .jpg"
                            listType="picture-card"
                            fileList={fileList}
                            beforeUpload={this.beforeUpload}
                            onPreview={this.handlePreview}
                            onChange={this.handleFileChange}
                          >
                            {fileList.length === 1 ? null : uploadButton}
                          </Upload>
                          <Modal
                            visible={previewVisible}
                            title={previewTitle}
                            footer={null}
                            onCancel={this.handleCancel}
                            destroyOnClose="true"
                          >
                            <img
                              alt="example"
                              style={{ width: "100%" }}
                              src={previewImage}
                            />
                          </Modal>
                        </Form.Item>
                      </Col>
                      <Col xs={24} sm={24} md={24} lg={24} xl={24}>
                        <Form.Item
                          name="message"
                          rules={[
                            {
                              required: true,
                              message: "Please Enter Broadcast Message!",
                            },
                          ]}
                        >
                          <TextArea
                            placeholder="Type Broadcast message"
                            name="message"
                            value={this.state.message}
                            onChange={this.onChange}
                            rows={4}
                          />
                        </Form.Item>
                      </Col>
                      <Col xs={24} sm={24} md={24} lg={24} xl={24}>
                        <Form.Item>
                          <Button
                            type="primary"
                            htmlType="submit"
                            className="ok-modal"
                            disabled={
                              this.state.recipients.length &&
                              this.state.message.length
                                ? false
                                : true
                            }
                            block
                          >
                            Send Message
                          </Button>
                        </Form.Item>
                      </Col>
                    </Row>
                    {/**<div>
                      {this.state.noRecipientsSelectedError ? (
                        <span style={{ color: "#ff4d4f" }}>
                          Please Select Atleast One Recipient
                        </span>
                      ) : (
                        <span></span>
                      )}
                    </div> */}
                  </Col>
                </Row>
              </Form>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
const mapStateToProps = (state) => ({
  errors: state.errors,
  users: state.users.users,
  groups: state.users.groups,
  sendBroadcastMsg: state.users.sendBroadCastMsgResponse,
});
export default connect(mapStateToProps, {
  getAllUsers,
  getAllGroups,
  broadCastMessage,
})(BroadcastComponent);
