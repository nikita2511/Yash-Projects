import React, { Component } from "react";
import { connect } from "react-redux";
import { getAllGroups, deleteUserFromGroup } from "../../../actions/userAction";
import {
  Upload,
  Col,
  Form,
  Input,
  Row,
  Modal,
  Button,
  Table,
  Tag,
  Tooltip,
} from "antd";
import { Spin } from "antd";
import {
  DeleteOutlined,
  EditOutlined,
  LoadingOutlined,
  PlusOutlined,
} from "@ant-design/icons";
import AddGroup from "./AddGroup";
import AddMembers from "./AddMembers";

const groupCol = [
  {
    title: "Name",
    dataIndex: "name",
    align: "left",
  },
  // {
  //   title: "Total Members",
  //   key: "operation",
  //   align: "left",
  //   render: (record) => {
  //     return (
  //       <>
  //         {record.members.length > 0 ? (
  //           <Tag color="green">{record.members.length}</Tag>
  //         ) : (
  //           <Tag color="volcano">{record.members.length}</Tag>
  //         )}
  //       </>
  //     );
  //   },
  // },
];
class Groups extends Component {
  delete = (e, memberId) => {
    let deleteObj = {
      groupId: e._id,
      memberId: memberId,
    };
    this.props.deleteUserFromGroup(deleteObj);
  };
  expandedRowRender = (e, index) => {
    console.log("##eee", index, e);
    const userCol = [
      {
        title: "Name",
        dataIndex: "name",
        align: "left",
      },
      {
        title: "MobileNumber",
        dataIndex: "mobileNumber",
        align: "left",
      },
      {
        title: "Email",
        dataIndex: "email",
        align: "left",
      },
      {
        title: "Emp Id",
        dataIndex: "empId",
        align: "left",
      },
      {
        title: "Action",
        key: "operation",
        render: (record) => (
          <Row gutter={[16, 16]}>
            <Col xs={24} sm={24} md={24} lg={24} xl={24}>
              <Tooltip title="Remove User">
                <Button
                  onClick={() => this.delete(e, record._id)}
                  danger
                  size="small"
                  shape="circle"
                  icon={<DeleteOutlined />}
                />
              </Tooltip>
            </Col>
          </Row>
        ),
      },
    ];
    let userData = [];
    userData = e.members;

    return <Table columns={userCol} dataSource={userData} rowKey="_id" />;
  };
  componentDidMount() {
    let gResp = this.props.getAllGroups(this.props.history);
  }

  render() {
    const antIcon = <LoadingOutlined style={{ fontSize: 24 }} spin />;
    const { groups } = this.props;
    return (
      <div className="container dashboard statistics-card">
        <Row className="title-row">
          <Col xs={24} sm={24} md={24} lg={24} xl={24}>
            <div className="d-flex flex-row">
              <div className="pages-header">Group Managment</div>
            </div>
          </Col>
        </Row>
        <div className="mt-4">
          <div className="card">
            <div className="card-body p-5">
              <Row gutter={[16, 24]}>
                <Col
                  xs={24}
                  sm={24}
                  md={24}
                  lg={20}
                  xl={20}
                  style={{ borderRight: "1px solid rgba(0, 0, 0, 0.05)" }}
                >
                  {groups.length ? (
                    <Table
                      expandedRowRender={(e, index) =>
                        this.expandedRowRender(e, index)
                      }
                      columns={groupCol}
                      dataSource={groups}
                      rowKey="_id"
                      align="left"
                    />
                  ) : (
                    <div className="p-5" style={{ marginLeft: "34%" }}>
                      <Spin indicator={antIcon} />
                    </div>
                  )}
                </Col>
                <Col xs={24} sm={24} md={24} lg={4} xl={4}>
                  <Row gutter={[16, 16]}>
                    <Col xs={24} sm={24} md={24} lg={24} xl={24}>
                      <AddGroup />
                    </Col>
                    <Col xs={24} sm={24} md={24} lg={24} xl={24}>
                      <AddMembers />
                    </Col>
                  </Row>
                </Col>
              </Row>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
const mapStateToProps = (state) => ({
  errors: state.errors,
  groups: state.users.groups,
});
export default connect(mapStateToProps, {
  getAllGroups,
  deleteUserFromGroup,
})(Groups);
