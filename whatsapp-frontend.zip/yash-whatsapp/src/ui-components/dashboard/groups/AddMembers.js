import React, { Component } from "react";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import { Row, Col, Modal, Button, Form, Input, Select } from "antd";
import { PlusOutlined } from "@ant-design/icons";
import { message } from "antd";
import {
  getAllGroups,
  getAllUsers,
  addMembers,
} from "../../../actions/userAction";

const { Option } = Select;

class AddMembers extends Component {
  constructor(props) {
    super(props);
    this.formRef = React.createRef();
    this.state = {
      loading: false,
      visible: false,
      members: [],
      groupName: "",
      errors: {},
    };
    this.onChange = this.onChange.bind(this);
    this.onSubmit = this.onSubmit.bind(this);
  }
  showModal = () => {
    this.setState({
      visible: true,
    });
  };

  handleModalCancel = () => {
    this.setState({ visible: false });
  };

  componentDidUpdate(prevProps, prevState) {
    if (prevProps.errors !== this.props.errors) {
      //Perform some operation here

      this.setState({ errors: this.props.errors });
      message.error(this.props.errors.message);
    }
  }
  onUserChange = (key, value) => {
    let membersArray = [];
    key.map((v) => {
      let userTemp = [];
      userTemp = v.split(",");
      let userObj = {};
      userObj = {
        _id: userTemp[0],
        name: userTemp[1],
        email: userTemp[2],
        mobileNumber: userTemp[3],
        empId: userTemp[4],
      };
      membersArray.push(userObj);
    });
    this.state.members.push(membersArray);
  };
  onGroupChange = (event) => {
    console.log("##event", event);
    this.setState({
      groupName: event,
    });
  };
  componentDidMount() {
    this.props.getAllUsers(this.props.history);
    this.props.getAllGroups(this.props.history);
  }
  onChange(event) {
    this.setState({ [event.target.name]: event.target.value });
  }

  onSubmit(event) {
    // event.preventDefault();
    this.setState({ loading: true });
    setTimeout(() => {
      this.setState({ loading: false, visible: false });
    }, 1000);
    let userObj = {
      groupName: this.state.groupName,
      members: this.state.members[this.state.members.length - 1],
    };
    console.log("#userObj", userObj);
    this.props.addMembers(userObj);
  }

  render() {
    const { visible, loading } = this.state;
    var filteredUsers = this.props.users.map((user) => {
      return (
        <Option
          key={[user._id, user.name, user.email, user.mobileNumber, user.empId]}
        >
          {user.name}
        </Option>
      );
    });
    return (
      <Row>
        <Col span={24}>
          <div className="add-button">
            <Button
              className="btn-admin btn-subCategory close-modal"
              type="primary"
              onClick={this.showModal}
            >
              Add Members
            </Button>
            <Modal
              width={1200}
              visible={visible}
              onOk={this.handleOk}
              onCancel={this.handleModalCancel}
              title="Add Members"
              style={{ top: 20 }}
              okButtonProps={{ hidden: true }}
              cancelButtonProps={{ hidden: true }}
              destroyOnClose={true}
            >
              <Form
                ref={this.formRef}
                name="add-Members"
                className="add-Members"
                onFinish={this.onSubmit}
                initialValues={{
                  remember: true,
                }}
              >
                <Row gutter={[8, 0]}>
                  <Col xs={12} sm={12} md={12} lg={12} xl={12}>
                    <Form.Item
                      name="groupName"
                      rules={[
                        {
                          required: true,
                          message: "Please Select Group Name!",
                        },
                      ]}
                    >
                      <Select
                        showSearch
                        allowClear
                        optionFilterProp="children"
                        filterOption={(input, option) =>
                          option.children
                            .toLowerCase()
                            .indexOf(input.toLowerCase()) >= 0
                        }
                        filterSort={(optionA, optionB) =>
                          optionA.children
                            .toLowerCase()
                            .localeCompare(optionB.children.toLowerCase())
                        }
                        name="groupName"
                        placeholder="Select a Group"
                        id="groupName"
                        onChange={this.onGroupChange}
                        value={this.state.groupName}
                      >
                        {this.props.groups.map((group) => (
                          <Option value={group.name}>{group.name}</Option>
                        ))}
                      </Select>
                    </Form.Item>
                  </Col>
                  <Col xs={12} sm={12} md={12} lg={12} xl={12}>
                    <Form.Item
                      name="members"
                      rules={[
                        {
                          required: true,
                          message: "Please Select Sub Business Unit!",
                        },
                      ]}
                    >
                      <Select
                        mode="multiple"
                        allowClear
                        placeholder="Select Sub Business Unit"
                        onChange={this.onUserChange}
                      >
                        {filteredUsers}
                      </Select>
                    </Form.Item>
                  </Col>
                </Row>

                <Form.Item className="float-end">
                  <Button
                    className="close-modal me-3"
                    onClick={this.handleModalCancel}
                  >
                    Close
                  </Button>
                  <Button
                    type="primary"
                    htmlType="submit"
                    className="ok-modal"
                    loading={loading}
                  >
                    Save
                  </Button>
                </Form.Item>
              </Form>
            </Modal>
          </div>
        </Col>
      </Row>
    );
  }
}

const mapStateToProps = (state) => ({
  errors: state.errors,
  users: state.users.users,
  groups: state.users.groups,
});
export default connect(mapStateToProps, {
  getAllUsers,
  getAllGroups,
  addMembers,
})(AddMembers);
