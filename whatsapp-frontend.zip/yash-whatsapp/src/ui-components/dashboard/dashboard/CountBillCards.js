import React, { Component } from "react";
import {
  HomeOutlined,
  UserOutlined,
  AmazonOutlined,
  WindowsOutlined,
  GoogleOutlined,
  ArrowRightOutlined,
  MessageFilled,
  AlignLeftOutlined,
} from "@ant-design/icons";
import { Button, Row, Col, Carousel } from "antd";
import axios from "axios";
import moment from "moment";
import { Link } from "react-router-dom";
// import { Pie } from "@ant-design/plots";
// import AccountsList from "./AccountsList";

// var pieData;
export default class CountBillCards extends Component {
  constructor(props) {
    super(props);
    this.state = { cardData: [] };
  }
  componentDidMount() {
    const defaultMonth = moment(new Date()).month() + 1;
    const defaultYear = moment(new Date()).year();
    var initalMonth = defaultYear + "-" + defaultMonth;
    console.log("##initalMonth", initalMonth);
    this.getDashboardData(initalMonth);
  }
  getDashboardData = async (month) => {
    // let azureResp = await axios.get(
    //   `https://u4l7tgv2f7.execute-api.ap-south-1.amazonaws.com/dev/monthlyazurebilling?month=${month}`
    // );
    // let awsResp = await axios.get(
    //   `https://8m8xf34hl0.execute-api.ap-south-1.amazonaws.com/dev/billingdashboard/totalaccountcostmonthly?month=${month}`
    // );
    // let gcpResp = await axios.get(
    //   `https://8m8xf34hl0.execute-api.ap-south-1.amazonaws.com/dev/gcp/total?month=${month}`
    // );
    let data = [
      {
        type: "MESSAGE_SENT",
        // value: awsResp.data.data[0].total_cost,
        value: 1000,
      },
      {
        type: "MESSAGE_READ",
        // value: gcpResp.data[0].total_exact,
        value: 600,
      },
      {
        type: "ACTIVE_USER",
        // value: azureResp.data[0].total_cost,
        value: 987,
      },
    ];
    // data.azureCost = azureResp.data[0].total_cost;
    // data.awsCost = awsResp.data.data[0].total_cost;
    // data.gcpCost = gcpResp.data[0].total_exact;
    this.setState({ cardData: data });
    // pieData = data;
  };
  render() {
    let data = this.state.cardData;
    // const config = {
    //   width: 275,
    //   height: 275,
    //   color: ["rgb(71, 145, 219)", "#1976d2", "rgb(17, 82, 147)"],
    //   appendPadding: 10,
    //   data,
    //   angleField: "value",
    //   colorField: "type",
    //   radius: 1,
    //   innerRadius: 0.64,
    //   legend: {
    //     layout: "horizontal",
    //     position: "bottom",
    //   },
    //   label: {
    //     type: "spider",
    //     offset: "-50%",
    //     style: {
    //       textAlign: "center",
    //     },
    //     autoRotate: false,
    //   },

    //   // 添加 中心统计文本 交互
    //   interactions: [
    //     {
    //       type: "element-selected",
    //     },
    //     {
    //       type: "element-active",
    //     },
    //     {
    //       type: "pie-statistic-active",
    //     },
    //   ],
    // };
    return (
      <Row gutter={[8, 8]}>
        <Col xs={24} sm={24} md={24} lg={24} xl={24}>
          <div className="count-cards mt-3">
            <Row gutter={[24, 8]}>
              <Col xs={24} sm={24} md={24} lg={8} xl={8}>
                <div className="card">
                  <div className="card-body">
                    <div className="details">
                      <MessageFilled />
                      <span className="count ms-3">
                        <span className="name-cloud">Total Messages Sent</span>
                        <h6>
                          {this.state.cardData.map((ele) => {
                            if (ele.type == "MESSAGE_SENT") {
                              return Math.round(ele.value) || 0;
                            }
                          })}
                        </h6>
                      </span>
                    </div>
                    {/* <div className="buttons">
                      <Link to="/billings/aws">
                        <Button size="large" type="text">
                          <ArrowRightOutlined />
                        </Button>
                      </Link>
                    </div> */}
                  </div>
                </div>
              </Col>
              <Col xs={24} sm={24} md={24} lg={8} xl={8}>
                <div className="card">
                  <div className="card-body">
                    <div className="details">
                      <AlignLeftOutlined />
                      <span className="count ms-3">
                        <span className="name-cloud">Total Message Read</span>
                        <h6>
                          {this.state.cardData.map((ele) => {
                            if (ele.type == "MESSAGE_READ") {
                              return Math.round(ele.value) || 0;
                            }
                          })}
                        </h6>
                      </span>
                    </div>
                    {/* <div className="buttons">
                      <Link to="/billings/azure">
                        <Button size="large" type="text">
                          <ArrowRightOutlined />
                        </Button>
                      </Link>
                    </div> */}
                  </div>
                </div>
              </Col>
              <Col xs={24} sm={24} md={24} lg={8} xl={8}>
                <div className="card">
                  <div className="card-body">
                    <div className="details">
                      <UserOutlined />
                      <span className="count ms-3">
                        <span className="name-cloud">Current Active Users</span>
                        <h6>
                          {" "}
                          {this.state.cardData.map((ele) => {
                            if (ele.type == "ACTIVE_USER") {
                              return Math.round(ele.value) || 0;
                            }
                          })}
                        </h6>
                      </span>
                    </div>
                    {/* <div className="buttons">
                      <Link to="/billings/gcp">
                        <Button size="large" type="text">
                          <ArrowRightOutlined />
                        </Button>
                      </Link>
                    </div> */}
                  </div>
                </div>
              </Col>
            </Row>
          </div>
          <Row gutter={[24, 8]} className="mt-5">
            <Col xs={24} sm={24} md={24} lg={24} xl={24}>
              {/* <AccountsList /> */}
            </Col>
            {/**<Col xs={24} sm={24} md={24} lg={8} xl={8}>
              <div className="dash-chart-count">
                <div className="card">
                  <div className="card-body p-4">
                    <div style={{ display: "flex" }}>
                      <p className="fs-4">Total Billing</p>
                      <h5 className="mt-2 ms-3">Current Month</h5>
                    </div>
                    <Pie {...config} />
                  </div>
                </div>
              </div>
            </Col> */}
          </Row>
        </Col>
      </Row>
    );
  }
}
