import React, { Component } from "react";
import CountBillCards from "./CountBillCards";

export default class Dashboard extends Component {
  render() {
    return (
      <div className="container-fluid statistics-card ">
        <CountBillCards />
      </div>
    );
  }
}
