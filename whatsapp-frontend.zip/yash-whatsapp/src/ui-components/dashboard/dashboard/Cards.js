import React, { Component } from "react";
import azure from "../../../assests/img/azure.png";
import aws from "../../../assests/img/aws-card.png";
import gcp from "../../../assests/img/gcp.png";
import axios from "axios";
import moment from "moment";
import { Link } from "react-router-dom";

export default class Cards extends Component {
  constructor(props) {
    super(props);
    this.state = { cardData: {} };
  }
  componentDidMount() {
    const defaultMonth = moment(new Date()).month() + 1;
    const defaultYear = moment(new Date()).year();
    var initalMonth = defaultYear + "-" + defaultMonth;
    console.log("##initalMonth", initalMonth);
    this.getDashboardData(initalMonth);
  }
  getDashboardData = async (month) => {
    let azureResp = await axios.get(
      `https://u4l7tgv2f7.execute-api.ap-south-1.amazonaws.com/dev/monthlyazurebilling?month=${month}`
    );
    let awsResp = await axios.get(
      `https://8m8xf34hl0.execute-api.ap-south-1.amazonaws.com/dev/billingdashboard/totalaccountcostmonthly?month=${month}`
    );
    let gcpResp = await axios.get(
      `https://8m8xf34hl0.execute-api.ap-south-1.amazonaws.com/dev/gcp/total?month=${month}`
    );
    let data = {};
    data.azureCost = azureResp.data[0].total_cost;
    data.awsCost = awsResp.data.data[0].total_cost;
    data.gcpCost = gcpResp.data[0].total_exact;
    this.setState({ cardData: data });
  };
  render() {
    return (
      <div class="dash-card">
        <div class="row mt-3">
          <div class="col-md-4 col-xl-4">
            <Link to="/billings/aws">
              <div class="card bg-c-blue order-card">
                <div class="card-block">
                  <div className="d-flex flex-row">
                    <h2 class="m-b-20 text-white ">Microsoft Azure</h2>
                    <img className="ms-2" src={azure} width={25} height={25} />
                  </div>
                  <h3 class="text-right text-white">
                    <i class="fa fa-credit-card f-left"></i>
                    <span>
                      <i class="fa fa-rupee"></i>
                      <span>
                        {Math.round(this.state.cardData.azureCost) || 0}
                      </span>
                    </span>
                  </h3>
                  <p class="m-b-0">
                    Total Monthly Bill{/**<span class="f-right">351</span> */}
                  </p>
                </div>
              </div>
            </Link>
          </div>

          <div class="col-md-4 col-xl-4">
            <Link to="/billings/azure">
              <div class="card bg-c-yellow order-card">
                <div class="card-block">
                  <div className="d-flex flex-row">
                    <h2 class="m-b-20 text-white ">Amazon Web Services</h2>
                    <img
                      className="ms-2 mt-1"
                      src={aws}
                      width={25}
                      height={20}
                    />
                  </div>
                  <h3 class="text-right text-white">
                    <i class="fa fa-credit-card f-left"></i>
                    <span>
                      <i class="fa fa-dollar"></i>
                      <span>
                        {Math.round(this.state.cardData.awsCost) || 0}
                      </span>
                    </span>
                  </h3>
                  <p class="m-b-0">
                    Total Monthly Bill{/**<span class="f-right">351</span> */}
                  </p>
                </div>
              </div>
            </Link>
          </div>

          <div class="col-md-4 col-xl-4">
            <Link to="/billings/gcp">
              <div class="card bg-c-pink order-card">
                <div class="card-block">
                  <div className="d-flex flex-row">
                    <h2 class="m-b-20 text-white ">Google Cloud Platform</h2>
                    <img className="ms-2" src={gcp} width={25} height={25} />
                  </div>
                  <h3 class="text-right text-white">
                    <i class="fa fa-credit-card f-left"></i>
                    <span>
                      <i class="fa fa-rupee"></i>
                      <span>
                        {Math.round(this.state.cardData.gcpCost) || 0}
                      </span>
                    </span>
                  </h3>
                  <p class="m-b-0">
                    Total Monthly Bill{/**<span class="f-right">351</span> */}
                  </p>
                </div>
              </div>
            </Link>
          </div>
        </div>
      </div>
    );
  }
}
