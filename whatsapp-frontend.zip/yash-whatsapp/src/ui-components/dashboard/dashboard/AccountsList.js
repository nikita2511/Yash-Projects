import React, { Component } from "react";
import { Row, Col, Table, Button, Input, Space, Carousel } from "antd";
import axios from "axios";
import Highlighter from "react-highlight-words";
import { SearchOutlined } from "@ant-design/icons";
import aws from "../../../assests/img/aws-card.png";
import gcp from "../../../assests/img/gcp.png";
import azure from "../../../assests/img/azure.png";
import { AWSDonut } from "../charts/dashboard-charts/AWSDonut";
import { AzureDonut } from "../charts/dashboard-charts/AzureDonut";
import { GCPDonut } from "../charts/dashboard-charts/GCPDonut";
import moment from "moment";

const monthFormat = "YYYY-MM";
const defaultMonth = moment(new Date()).month() + 1;
const defaultYear = moment(new Date()).year();
var initalMonth = defaultYear + "-" + defaultMonth;

const { Column } = Table;

export default class AccountsList extends Component {
  constructor(props) {
    super(props);
    this.state = {
      awsAccounts: [],
      gcpAccounts: [],
      azureAccounts: [],
      month: initalMonth,
    };
  }
  getColumnSearchProps = (dataIndex) => ({
    filterDropdown: ({
      setSelectedKeys,
      selectedKeys,
      confirm,
      clearFilters,
    }) => (
      <div style={{ padding: 8 }}>
        <Input
          ref={(node) => {
            this.searchInput = node;
          }}
          placeholder={`Search ${dataIndex}`}
          value={selectedKeys[0]}
          onChange={(e) =>
            setSelectedKeys(e.target.value ? [e.target.value] : [])
          }
          onPressEnter={() =>
            this.handleSearch(selectedKeys, confirm, dataIndex)
          }
          style={{ marginBottom: 8, display: "block" }}
        />
        <Space>
          <Button
            type="primary"
            onClick={() => this.handleSearch(selectedKeys, confirm, dataIndex)}
            icon={<SearchOutlined />}
            size="small"
            style={{ width: 90 }}
            className="search-name"
          >
            Search
          </Button>
          <Button
            onClick={() => this.handleReset(clearFilters, confirm)}
            size="small"
            style={{ width: 90 }}
          >
            Reset
          </Button>
          {/**<Button
            type="link"
            size="small"
            onClick={() => {
              confirm({ closeDropdown: false });
              this.setState({
                searchText: selectedKeys[0],
                searchedColumn: dataIndex,
              });
            }}
          >
            Filter
          </Button> */}
        </Space>
      </div>
    ),
    filterIcon: (filtered) => (
      <SearchOutlined style={{ color: filtered ? "#1890ff" : undefined }} />
    ),
    onFilter: (value, record) =>
      record[dataIndex]
        ? record[dataIndex]
            .toString()
            .toLowerCase()
            .includes(value.toLowerCase())
        : "",
    onFilterDropdownVisibleChange: (visible) => {
      if (visible) {
        setTimeout(() => this.searchInput.select(), 100);
      }
    },
    render: (text) =>
      this.state.searchedColumn === dataIndex ? (
        <Highlighter
          highlightStyle={{ backgroundColor: "#ffc069", padding: 0 }}
          searchWords={[this.state.searchText]}
          autoEscape
          textToHighlight={text ? text.toString() : ""}
        />
      ) : (
        text
      ),
  });

  handleSearch = (selectedKeys, confirm, dataIndex) => {
    confirm();
    this.setState({
      searchText: selectedKeys[0],
      searchedColumn: dataIndex,
    });
  };

  handleReset = (clearFilters, confirm) => {
    clearFilters();
    confirm();
    this.setState({ searchText: "" });
  };
  componentDidMount() {
    this.getAccounts(this.state.month);
  }
  getAccounts = async (month) => {
    console.log("####", month);
    let awsResp = await axios.get(
      `https://8m8xf34hl0.execute-api.ap-south-1.amazonaws.com/dev/dashboard/accountlist?month=${month}`
    );
    let gcpResp = await axios.get(
      `https://8m8xf34hl0.execute-api.ap-south-1.amazonaws.com/dev/gcp/billingproject?month=${month}&projectname=undefined`
    );
    let azureResp = await axios.get(
      `https://7cgmhapq84.execute-api.ap-south-1.amazonaws.com/dev/dashboard`
    );
    console.log("#azureResp", azureResp);
    this.setState({
      awsAccounts: awsResp.data.data,
      gcpAccounts: gcpResp.data.data,
      azureAccounts: azureResp.data.body,
    });
  };
  render() {
    const contentStyle = {
      height: "350px",
      color: "#fff",
      lineHeight: "350px",
      textAlign: "center",
      // background: "#364d79",
    };
    return (
      <div className="list-accounts">
        <div className="card">
          <div className="card-body">
            <Carousel dotPosition="right">
              <div className="p-2">
                <Row gutter={[8, 48]} className="mt-4">
                  <Col xs={24} sm={24} md={12} lg={12} xl={12}>
                    <h3 style={contentStyle}>
                      <div className="d-flex flex-row my-2">
                        <h2 class="m-b-20 text-secondary ">
                          Amazon Web Services
                        </h2>
                        <img
                          className="ms-2 mt-2"
                          src={aws}
                          width={25}
                          height={20}
                        />
                      </div>

                      <Table
                        dataSource={this.state.awsAccounts}
                        bordered={false}
                        size="middle"
                        pagination={false}
                      >
                        <Column
                          title="SRN"
                          key="index"
                          render={(value, item, index) => index + 1}
                          width={60}
                        />

                        <Column
                          title="Account Name"
                          dataIndex="account_name"
                          key="account_name"
                          {...this.getColumnSearchProps("account_name")}
                        />
                        <Column
                          title="Cost"
                          dataIndex="cost"
                          key="cost"
                          render={(value, item, index) => Math.round(item.cost)}
                        />
                      </Table>
                    </h3>
                  </Col>
                  <Col xs={24} sm={24} md={12} lg={12} xl={12}>
                    <AWSDonut />
                  </Col>
                </Row>
              </div>
              <div className="p-2">
                <Row gutter={[8, 48]} className="mt-4">
                  <Col xs={24} sm={24} md={12} lg={12} xl={12}>
                    <h3 style={contentStyle}>
                      <div className="d-flex flex-row my-2">
                        <h2 class="m-b-20 text-secondary ">
                          Google Cloud Platform
                        </h2>
                        <img
                          className="ms-2"
                          src={gcp}
                          width={25}
                          height={25}
                        />
                      </div>
                      <Table
                        dataSource={this.state.gcpAccounts}
                        bordered={false}
                        size="middle"
                        pagination={false}
                      >
                        <Column
                          title="SRN"
                          key="index"
                          render={(value, item, index) => index + 1}
                          width={60}
                        />

                        <Column
                          title="Project Name"
                          dataIndex="project_name"
                          key="project_name"
                          {...this.getColumnSearchProps("project_name")}
                        />
                        <Column
                          title="Cost"
                          dataIndex="cost"
                          key="cost"
                          render={(value, item, index) =>
                            Math.round(item.total_exact)
                          }
                        />
                      </Table>
                    </h3>
                  </Col>
                  <Col xs={24} sm={24} md={12} lg={12} xl={12}>
                    <GCPDonut />
                  </Col>
                </Row>
              </div>
              <div className="p-2">
                <Row gutter={[8, 48]} className="mt-4">
                  <Col xs={24} sm={24} md={12} lg={12} xl={12}>
                    <h3 style={contentStyle}>
                      <div className="d-flex flex-row my-2">
                        <h2 class="m-b-20 text-secondary ">Microsoft Azure</h2>
                        <img
                          className="ms-2 mt-1"
                          src={azure}
                          width={25}
                          height={20}
                        />
                      </div>
                      <Table
                        dataSource={this.state.azureAccounts}
                        bordered={false}
                        size="middle"
                        pagination={false}
                      >
                        <Column
                          title="SRN"
                          key="index"
                          render={(value, item, index) => index + 1}
                          width={60}
                        />

                        <Column
                          title="Account Name"
                          dataIndex="account_name"
                          key="account_name"
                          {...this.getColumnSearchProps("account_name")}
                        />
                        <Column
                          title="Cost"
                          dataIndex="cost"
                          key="cost"
                          {...this.getColumnSearchProps("cost")}
                        />
                      </Table>
                    </h3>
                  </Col>
                  <Col xs={24} sm={24} md={12} lg={12} xl={12}>
                    <AzureDonut />
                  </Col>
                </Row>
              </div>
            </Carousel>
          </div>
        </div>
      </div>
    );
  }
}
