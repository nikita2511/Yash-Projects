import React, { Component } from "react";
import { Row, Col, Statistic } from "antd";
import { LineChart, Line, Tooltip } from "recharts";
import { ArrowUpOutlined, ArrowDownOutlined } from "@ant-design/icons";
const data = [
  {
    name: "Page A",
    uv: 4000,
    pv: 2400,
    amt: 2400,
  },
  {
    name: "Page B",
    uv: 3000,
    pv: 1398,
    amt: 2210,
  },
  {
    name: "Page C",
    uv: 2000,
    pv: 9800,
    amt: 2290,
  },
  {
    name: "Page D",
    uv: 2780,
    pv: 3908,
    amt: 2000,
  },
  {
    name: "Page E",
    uv: 1890,
    pv: 4800,
    amt: 2181,
  },
  {
    name: "Page F",
    uv: 2390,
    pv: 3800,
    amt: 2500,
  },
  {
    name: "Page G",
    uv: 3490,
    pv: 4300,
    amt: 2100,
  },
];
export default class CardLineGraphDetails extends Component {
  render() {
    return (
      <div className="card-line-details mt-4">
        <Row gutter={[40, 32]}>
          <Col xs={{ span: 24 }} lg={{ span: 12 }}>
            <div className="card order-graph">
              <div className="card-header ">
                <h6
                  style={{
                    letterSpacing: "2px",
                  }}
                >
                  Total Sales
                </h6>
                <Row>
                  <Col xs={24} sm={24} md={12} lg={12} xl={12}>
                    <LineChart width={250} height={100} data={data}>
                      <Line
                        type="monotone"
                        dataKey="pv"
                        stroke="#ff8084"
                        strokeWidth={1}
                      />
                      <Tooltip />
                    </LineChart>
                  </Col>
                  <Col xs={24} sm={24} md={12} lg={12} xl={12}>
                    <div className="stats-line-percent">
                      <Statistic
                        value={11.28}
                        precision={2}
                        valueStyle={{ color: "#3f8600" }}
                        prefix={<ArrowUpOutlined />}
                        suffix="%"
                      />
                    </div>
                  </Col>
                </Row>
              </div>
              <div className="card-body">
                <div className="media">
                  <div className="media-body">
                    <span>Sales Last Month</span>
                    <h3 className="mb-0">9054</h3>
                    <p>
                      0.25%{" "}
                      <span>
                        <i className="fa fa-angle-up"></i>
                      </span>
                    </p>
                    <h6 className="font-weight-bold">Avg Gross sale</h6>
                    <p>
                      Lorem Ipsum is simply dummy text of the printing and
                      typesetting
                    </p>
                  </div>
                  <div className="bg-danger rounded">
                    <div className="small-box">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="24"
                        height="24"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="feather feather-briefcase"
                      >
                        <rect
                          x="2"
                          y="7"
                          width="20"
                          height="14"
                          rx="2"
                          ry="2"
                        ></rect>
                        <path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"></path>
                      </svg>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </Col>
          <Col xs={{ span: 24 }} lg={{ span: 12 }}>
            <div className="card order-graph">
              <div className="card-header ">
                <h6
                  style={{
                    letterSpacing: "2px",
                  }}
                >
                  Total purchase
                </h6>
                <Row>
                  <Col xs={24} sm={24} md={12} lg={12} xl={12}>
                    <LineChart width={250} height={100} data={data}>
                      <Line
                        type="monotone"
                        dataKey="pv"
                        stroke="#13c9ca"
                        strokeWidth={1}
                      />
                      <Tooltip />
                    </LineChart>
                  </Col>
                  <Col xs={24} sm={24} md={12} lg={12} xl={12}>
                    <div className="stats-line-percent">
                      <Statistic
                        value={9.3}
                        precision={2}
                        valueStyle={{ color: "#cf1322" }}
                        prefix={<ArrowDownOutlined />}
                        suffix="%"
                      />
                    </div>
                  </Col>
                </Row>
              </div>
              <div className="card-body">
                <div className="media">
                  <div className="media-body">
                    <span>Monthly purchase</span>
                    <h2 className="mb-0">2154</h2>
                    <p>
                      0.13%{" "}
                      <span>
                        <i className="fa fa-angle-up"></i>
                      </span>
                    </p>
                    <h6 className="font-weight-bold">Avg Gross purchase</h6>
                    <p>
                      Lorem Ipsum is simply dummy text of the printing and
                      typesetting
                    </p>
                  </div>
                  <div className="bg-info rounded">
                    <div className="small-box">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="24"
                        height="24"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="feather feather-credit-card"
                      >
                        <rect
                          x="1"
                          y="4"
                          width="22"
                          height="16"
                          rx="2"
                          ry="2"
                        ></rect>
                        <line x1="1" y1="10" x2="23" y2="10"></line>
                      </svg>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </Col>

          <Col xs={{ span: 24 }} lg={{ span: 12 }}>
            <div className="card order-graph">
              <div className="card-header ">
                <h6
                  style={{
                    letterSpacing: "2px",
                  }}
                >
                  Total transaction
                </h6>
                <Row>
                  <Col xs={24} sm={24} md={12} lg={12} xl={12}>
                    <LineChart width={250} height={100} data={data}>
                      <Line
                        type="monotone"
                        dataKey="pv"
                        stroke="#ffbc58"
                        strokeWidth={1}
                      />
                      <Tooltip />
                    </LineChart>
                  </Col>
                  <Col xs={24} sm={24} md={12} lg={12} xl={12}>
                    <div className="stats-line-percent">
                      <Statistic
                        value={9.3}
                        precision={2}
                        valueStyle={{ color: "#cf1322" }}
                        prefix={<ArrowDownOutlined />}
                        suffix="%"
                      />
                    </div>
                  </Col>
                </Row>
              </div>
              <div className="card-body">
                <div className="media">
                  <div className="media-body">
                    <span>Cash on hand</span>
                    <h2 className="mb-0">4672</h2>
                    <p>
                      0.8%{" "}
                      <span>
                        <i className="fa fa-angle-up"></i>
                      </span>
                    </p>
                    <h6 className="font-weight-bold">Details about cash</h6>
                    <p>
                      Lorem Ipsum is simply dummy text of the printing and
                      typesetting
                    </p>
                  </div>
                  <div className="bg-warning rounded">
                    <div className="small-box">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="24"
                        height="24"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="feather feather-shopping-cart"
                      >
                        <circle cx="9" cy="21" r="1"></circle>
                        <circle cx="20" cy="21" r="1"></circle>
                        <path d="M1 1h4l2.68 13.39a2 2 0 0 0 2 1.61h9.72a2 2 0 0 0 2-1.61L23 6H6"></path>
                      </svg>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </Col>
          <Col xs={{ span: 24 }} lg={{ span: 12 }}>
            <div className="card order-graph">
              <div className="card-header ">
                <h6>User registered</h6>
                <Row>
                  <Col xs={24} sm={24} md={12} lg={12} xl={12}>
                    <LineChart width={250} height={100} data={data}>
                      <Line
                        type="monotone"
                        dataKey="pv"
                        stroke="#a5a5a5 "
                        strokeWidth={1}
                      />
                      <Tooltip />
                    </LineChart>
                  </Col>
                  <Col xs={24} sm={24} md={12} lg={12} xl={12}>
                    <div className="stats-line-percent">
                      <Statistic
                        value={11.28}
                        precision={2}
                        valueStyle={{ color: "#3f8600" }}
                        prefix={<ArrowUpOutlined />}
                        suffix="%"
                      />
                    </div>
                  </Col>
                </Row>
              </div>
              <div className="card-body">
                <div className="media">
                  <div className="media-body">
                    <span
                      style={{
                        letterSpacing: "2px",
                      }}
                    >
                      Total Users
                    </span>
                    <h2 className="mb-0">0782</h2>
                    <p>
                      0.25%{" "}
                      <span>
                        <i className="fa fa-angle-up"></i>
                      </span>
                    </p>
                    <h6 className="font-weight-bold">
                      Avg user registration per week
                    </h6>
                    <p>
                      Lorem Ipsum is simply dummy text of the printing and
                      typesetting
                    </p>
                  </div>
                  <div className="bg-secondary rounded">
                    <div className="small-box">
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="24"
                        height="24"
                        viewBox="0 0 24 24"
                        fill="none"
                        stroke="currentColor"
                        strokeWidth="2"
                        strokeLinecap="round"
                        strokeLinejoin="round"
                        className="feather feather-calendar"
                      >
                        <rect
                          x="3"
                          y="4"
                          width="18"
                          height="18"
                          rx="2"
                          ry="2"
                        ></rect>
                        <line x1="16" y1="2" x2="16" y2="6"></line>
                        <line x1="8" y1="2" x2="8" y2="6"></line>
                        <line x1="3" y1="10" x2="21" y2="10"></line>
                      </svg>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </Col>
        </Row>
      </div>
    );
  }
}
