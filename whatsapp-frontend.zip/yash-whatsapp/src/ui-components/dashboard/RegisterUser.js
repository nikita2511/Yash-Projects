import React from 'react'
import { Form, Icon, Input, Button, Checkbox, Typography } from 'antd';
import { IdcardOutlined, LockOutlined, MailOutlined, MobileOutlined, UserOutlined } from '@ant-design/icons';

const { Title } = Typography;
export default function () {
    const handleSubmit = e => {
        e.preventDefault();
        this.props.form.validateFields((err, values) => {
          if (!err) {
            console.log('Received values of form: ', values);
          }
        });
      };
  return (
    <Form onSubmit={handleSubmit} className="login-form" style={{flex:1, }}>
        <Title level={3}>Register a YASH Employee to WhatsApp Connect</Title>
        <Form.Item>
          {/* {getFieldDecorator('username', {
            rules: [{ required: true, message: 'Please input your username!' }],
          })( */}
            <Input
              prefix={<MobileOutlined style={{ color: 'rgba(0,0,0,.25)' }} />}
              placeholder="Mobile Number"
            />
          {/* )} */}
        </Form.Item>
        <Form.Item>
          {/* {getFieldDecorator('username', {
            rules: [{ required: true, message: 'Please input your username!' }],
          })( */}
            <Input
              prefix={<MailOutlined style={{ color: 'rgba(0,0,0,.25)' }} />}
              placeholder="Email"
            />
          {/* )} */}
        </Form.Item>
        <Form.Item>
          {/* {getFieldDecorator('password', {
            rules: [{ required: true, message: 'Please input your Password!' }],
          })( */}
            <Input
              prefix={<UserOutlined style={{ color: 'rgba(0,0,0,.25)' }} />}
              placeholder="Name"
            />
          {/* )} */}
        </Form.Item>
        <Form.Item>
          {/* {getFieldDecorator('password', {
            rules: [{ required: true, message: 'Please input your Password!' }],
          })( */}
            <Input
              prefix={<IdcardOutlined style={{ color: 'rgba(0,0,0,.25)' }} />}
              placeholder="Employee ID"
            />
          {/* )} */}
        </Form.Item>
        <Form.Item style={{marginLeft: 420, marginRight: 420}}>
          <Button type="primary" htmlType="submit" className="login-form-button" style={{width: "100%"}}>
           Register
          </Button>
        </Form.Item>
      </Form>
  )
}