import React, { Component } from "react";
import { Layout } from "antd";
import Dashboard from "./dashboard/Dashboard";
import PropTypes from "prop-types";
import HeaderAdmin from "../layouts/HeaderAdmin";
import SiderMenu from "./SiderMenu";
import { withAuthenticator } from "@aws-amplify/ui-react";
import RegisterUser from "./RegisterUser";
import BroadcastComponent from "./BroadcastComponent";
import Register from "../auth/Register";
import moment from "moment";
import Groups from "./groups/Groups";

const { Sider, Content, Footer } = Layout;

class AdminDashboard extends Component {
  constructor(props) {
    super(props);
    const Token = localStorage.getItem("token");
    let IsLoggedIn = true;
    if (Token === null) {
      IsLoggedIn = false;
    }
    this.state = { IsLoggedIn, collapsed: false };
  }
  toggle = () => {
    this.setState({
      collapsed: !this.state.collapsed,
    });
  };
  renderPathName(pathname) {
    switch (pathname) {
      case "/register":
        return <Register />;
      case "/broadcast":
        return <BroadcastComponent />;
      case "/groups":
        return <Groups />;
      default:
        return <Dashboard />;
    }
  }
  render() {
    const { pathname } = this.props.location;
    return (
      <>
        <Layout className="admin-dash">
          <Sider
            width={260}
            breakpoint="sm"
            collapsedWidth="0"
            theme="light"
            trigger={null}
            collapsible
            collapsed={this.state.collapsed}
          >
            <SiderMenu
              history={this.props.history}
              user={this.props.user}
              collapsed={this.state.collapsed}
            ></SiderMenu>
          </Sider>
          <Layout className="site-layout">
            <HeaderAdmin
              toggle={this.toggle}
              collapsed={this.state.collapsed}
              user={this.props.user}
              signOut={this.props.signOut}
            />
            <Content
              style={{
                margin: "30px",
                // margin: "20px 10px",
                // padding: 15,
                minHeight: "100vh",
              }}
            >
              {this.renderPathName(pathname)}
            </Content>{" "}
            <Footer
              style={{
                textAlign: "center",
              }}
            >
              YASH WhatsApp Employee Connect ©{moment().year()} Created by
              EAST-Team
            </Footer>
          </Layout>
        </Layout>
      </>
    );
  }
}
AdminDashboard.propTypes = {
  location: PropTypes.object.isRequired,
};
export default withAuthenticator(AdminDashboard);
