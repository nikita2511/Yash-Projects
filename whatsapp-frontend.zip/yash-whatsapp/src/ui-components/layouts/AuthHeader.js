import { withAuthenticator } from "@aws-amplify/ui-react";
import React from "react";
import { Link } from "react-router-dom";
// import { Auth } from "aws-amplify";
function AuthHeader(currentUser, { signOut }) {
  // Todo logic here
  console.log("Sign", currentUser.signOut);
  return (
    <nav className="navbar navbar-expand-lg rounded-0 mb-0">
      <div className="container-fluid">
        <Link className="navbar-brand text-white pt-4" to="/dashboard">
          {/* <img
              src={yashLogo}
              alt="logo"
              className="me-3"
              width="70"
              height="70"
              class ="center"
            /> */}
          <span className="fs-1 text-primary">Y</span>
          <span className="fs-3">ash</span>
          <span className="fs-1 text-danger ms-2">B</span>
          <span className="fs-3 ms-1">illings</span>
        </Link>
        <button
          className="navbar-toggler"
          type="button"
          data-bs-toggle="collapse"
          data-bs-target="#navbarNav"
          aria-controls="navbarNav"
          aria-expanded="false"
          aria-label="Toggle navigation"
        >
          <span className="navbar-toggler-icon"></span>
        </button>
        <div className="collapse navbar-collapse" id="navbarNav">
          <ul class="navbar-nav ms-auto mb-2 mb-lg-0">
            <li class="nav-item">
              <a class="nav-link text-warning fst-italic username">
                Hello {currentUser.user.username} !
              </a>{" "}
            </li>
            <li className="nav-item ">
              <a className="nav-link text-white" onClick={currentUser.signOut}>
                Sign out
              </a>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  );
}

export default withAuthenticator(AuthHeader);
