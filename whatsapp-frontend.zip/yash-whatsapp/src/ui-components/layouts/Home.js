import React, { Component } from "react";
import { LaptopOutlined } from "@ant-design/icons";
import { Button, Result } from "antd";
import Header from "./Header";
import yashLogo from "../../assests/img/YASH-LOGO.png";
import brandLogo from "../../assests/img/login-logo.png";
import { Auth } from "aws-amplify";

export default class Home extends Component {
  federatedSignInUpdateUser = async () => {
    try {
      const newUser = await Auth.federatedSignIn({ customProvider: "AzureAD" });
      console.log("newUser", newUser);
    } catch (err) {
      console.log(err);
    }
  };
  render() {
    return (
      <div className="bg-image-home">
        <div style={{ height: "4vh" }}></div>
        <div className="card home">
          <div className="card-body ">
            <div className="text-center" style={{ margin: "0 0 -25px 0" }}>
              <img src={brandLogo} alt="logo" width="175" height="175" />
            </div>
            <Result
              icon={false}
              title="Welcome to YASH WhatsApp Employee Connect Portal!"
              extra={
                <Button
                  type="primary"
                  className="ok-modal"
                  block
                  onClick={this.federatedSignInUpdateUser}
                >
                  Sign In
                </Button>
              }
            />
          </div>
        </div>
      </div>
    );
  }
}
