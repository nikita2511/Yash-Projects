import React, { Component } from "react";
import { Link } from "react-router-dom";

export default class Header extends Component {
  render() {
    return (
      <nav className="navbar  navbar-expand-lg rounded-0">
        <span className="navbar-brand text-white pt-4">
          <span className="fs-1 text-primary">Y</span>
          <span className="fs-3">ash</span>
          <span className="fs-1 text-danger ms-2">B</span>
          <span className="fs-3 ms-1">illings</span>
        </span>
      </nav>
    );
  }
}
