import "./App.css";
import { AmplifyProvider } from "@aws-amplify/ui-react";
import "@aws-amplify/ui-react/styles.css";
import {
  BrowserRouter,
  Routes,
  Route,
  Navigate,
  useNavigate,
  useLocation,
} from "react-router-dom";
import Home from "./ui-components/layouts/Home";
import SignIn from "./ui-components/auth/SignIn";
import "bootstrap/dist/css/bootstrap.min.css";
import "antd/dist/antd.css";
import { Provider } from "react-redux";
import store from "./store";
import { Auth, Hub } from "aws-amplify";
import React, { useEffect, useState } from "react";
import "@ant-design/flowchart/dist/index.css";
import AdminDashboard from "./ui-components/dashboard/AdminDashboard";

function App() {
  const [currentUser, setCurrentUser] = useState({});
  const [isLoaded, setIsLoaded] = useState(false);
  const navigate = useNavigate();
  let location = useLocation();
  const [isLogged, setIsLogged] = useState(false);
  const updateCurrentUser = async (newUser) => {
    if (newUser) {
      console.log("newUser", newUser);
      await setCurrentUser(newUser);
    }
    try {
      const user = await Auth.currentAuthenticatedUser();
      console.log("existing user", user);
      setIsLogged(true);
      console.log("LoggedIn line try ", isLogged);
      console.log("User", user.username);
      setCurrentUser(user);
      setIsLoaded(false);
    } catch (err) {
      console.log("err", err);
      setIsLogged(false);
      console.log("LoggedIn line Catch", isLogged);
      setCurrentUser(null);
      navigate("/");
      setIsLoaded(true);
    }
  };

  const onHubAuth = (data) => {
    const { payload } = data;
    if (payload.event !== "signIn") {
      updateCurrentUser();
    }
  };

  useEffect(() => {
    updateCurrentUser();
    console.log("LoggedIn", isLogged);
    Hub.listen("auth", onHubAuth);
  }, []);

  return (
    <Provider store={store}>
      <AmplifyProvider>
        <Routes location={location}>
          {console.log("###location", location)}
          <Route
            exact
            path="/"
            element={isLogged ? <Navigate to="/dashboard" /> : <Home />}
          />
          <Route
            exact
            path="/dashboard"
            element={
              isLogged ? (
                <AdminDashboard location={location} />
              ) : (
                <Navigate to="/" />
              )
            }
          />

          <Route
            exact
            path="/register"
            element={
              isLogged ? <AdminDashboard location={location} /> : <Home />
            }
          />
          <Route
            exact
            path="/broadcast"
            element={
              isLogged ? <AdminDashboard location={location} /> : <Home />
            }
          />
          <Route
            exact
            path="/groups"
            element={
              isLogged ? <AdminDashboard location={location} /> : <Home />
            }
          />
        </Routes>
      </AmplifyProvider>
    </Provider>
  );
}

export default App;
