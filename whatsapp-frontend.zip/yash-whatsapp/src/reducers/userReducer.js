// // import { USER_REGISTER } from "./../actions/type";

// const initialState = {
//   user: {},
//   users: [],
// };
// export default function (state = initialState, action) {
//   switch (action.type) {
//     //   case USER_LOGIN:
//     //     return {
//     //       ...state,
//     //       user: action.payload,
//     //     };

//     default:
//       return state;
//   }
// }

// import { USER_REGISTER } from "./../actions/type";

import {
  ADD_GROUPS,
  ADD_MEMBERS,
  DELETE_MEMBER,
  GET_ALL_GROUPS,
  GET_ALL_USERS,
  SEND_BROADCAST_MESSAGE,
} from "../actions/type";

const initialState = {
  user: {},
  group: {},
  users: [],
  groups: [],
  sendBroadCastMsgResponse: "",
};
export default function (state = initialState, action) {
  switch (action.type) {
    case ADD_GROUPS:
      return {
        ...state,
        groups: [action.payload, ...state.groups],
      };
    case ADD_MEMBERS:
      return {
        ...state,
        groups: [action.payload, ...state.groups],
      };
    case GET_ALL_USERS:
      return {
        ...state,
        users: action.payload,
      };
    case GET_ALL_GROUPS:
      return {
        ...state,
        groups: action.payload,
      };
    case SEND_BROADCAST_MESSAGE:
      console.log(action.type);
      return {
        ...state,
        sendBroadCastMsgResponse: action.payload,
      };
    case DELETE_MEMBER:
      var updatedUsers = [];
      updatedUsers = state.groups.filter((group) => {
        if (group._id == action.payload.groupId) {
          group.members = group.members.filter((user) => {
            if (user._id != action.payload.memberId) return user;
          });
          return group;
        } else {
          return group;
        }
      });

      return {
        ...state,
        groups: updatedUsers,
      };

    default:
      return state;
  }
}
