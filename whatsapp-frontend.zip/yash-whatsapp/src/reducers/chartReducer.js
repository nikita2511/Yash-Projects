import { GET_CHART_DATA } from "../actions/type";

const initialState = {
  account: {},
  accounts: [],
};
export default function (state = initialState, action) {
  switch (action.type) {
    case GET_CHART_DATA:
      console.log("#action.payload", action.payload);
      return {
        ...state,
        accounts: action.payload,
      };

    default:
      return state;
  }
}
