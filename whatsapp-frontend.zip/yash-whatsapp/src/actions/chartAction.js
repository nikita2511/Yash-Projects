import axios from "axios";
import { GET_ERRORS, GET_CHART_DATA } from "./type";
import { message } from "antd";

export const getAccoountsDataByMonth = (month) => async (dispatch) => {
  try {
    let resp = await axios.get(
      `https://8m8xf34hl0.execute-api.ap-south-1.amazonaws.com/dev/billingdashboard/allaccountscost?month=${month}`
    );
    console.log("#resp", resp.data.data);
    dispatch({
      type: GET_CHART_DATA,
      payload: resp.data.data,
    });
  } catch (error) {
    console.log("#error", error);
    dispatch({
      type: GET_ERRORS,
      payload: error.response.data,
    });
  }
};
