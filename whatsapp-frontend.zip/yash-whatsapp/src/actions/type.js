export const GET_ERRORS = "GET_ERRORS";
export const GET_CHART_DATA = "GET_CHART_DATA";
export const GET_ALL_USERS = "GET_ALL_USERS";
export const GET_ALL_GROUPS = "GET_ALL_GROUPS";
export const ADD_GROUPS = "ADD_GROUPS";
export const ADD_MEMBERS = "ADD_MEMBERS";
export const DELETE_MEMBER = "DELETE_MEMBER";
export const SEND_BROADCAST_MESSAGE = "SEND_BROADCAST_MESSAGE";
