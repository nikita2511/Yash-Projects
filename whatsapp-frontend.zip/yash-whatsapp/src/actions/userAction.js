import axios from "axios";
import {
  GET_ERRORS,
  SEND_BROADCAST_MESSAGE,
  GET_ALL_USERS,
  GET_ALL_GROUPS,
  ADD_GROUPS,
  ADD_MEMBERS,
  DELETE_MEMBER,
} from "./type";
import { message, notification } from "antd";

export const createUser = (user) => async (dispatch) => {
  try {
    console.log("#user", user);
    // let resp = await axios.post(
    //   `https://km9q24vq5c.execute-api.ap-south-1.amazonaws.com/dev/createuser`,
    //   user
    // );
    // console.log("#resp", resp);
    // message
    //   .success(`Registration Successfull !`)
    //   .then(window.location.reload(0));
  } catch (error) {
    console.log("#error", error);
    dispatch({
      type: GET_ERRORS,
      payload: error.response.data,
    });
  }
};

export const getAllUsers = () => async (dispatch) => {
  try {
    let response = await axios.get(
      `https://km9q24vq5c.execute-api.ap-south-1.amazonaws.com/dev/getallwhatsappusers`
    );
    console.log("#resp", response.data.body.data);

    dispatch({
      type: GET_ALL_USERS,
      payload: response.data.body.data,
    });
  } catch (error) {
    console.log("#error", error);
    dispatch({
      type: GET_ERRORS,
      payload: error.response.data,
    });
  }
};
export const getAllGroups = () => async (dispatch) => {
  try {
    let response = await axios.get(
      `https://km9q24vq5c.execute-api.ap-south-1.amazonaws.com/dev/group`
    );
    console.log("#resp", response.data.body.data);

    dispatch({
      type: GET_ALL_GROUPS,
      payload: response.data.body.data,
    });
  } catch (error) {
    console.log("#error", error);
    dispatch({
      type: GET_ERRORS,
      payload: error.response.data,
    });
  }
};
export const broadCastMessage =
  (requestObject, history) => async (dispatch) => {
    try {
      console.log("------action req object-------", requestObject);
      console.log("------action history-------", history);
      let response = await axios.post(
        `https://km9q24vq5c.execute-api.ap-south-1.amazonaws.com/dev/sendbroadcastmsg`,
        requestObject
      );
      console.log("#resp", response.data.statusCode);
      // if (response.data.statusCode == 200) {
      //   history.push("/register");
      // }
      notification.success({
        message: "Your message has beed broadcasted successfully",
        // description: "Hi, A new order is placed.",
      });
      dispatch({
        type: SEND_BROADCAST_MESSAGE,
        payload: response.data.statusCode,
      });
    } catch (error) {
      console.log("#error", error);
      dispatch({
        type: GET_ERRORS,
        payload: error.response.data,
      });
    }
  };

export const addGroups = (groupObj) => async (dispatch) => {
  try {
    let response = await axios.post(
      `https://km9q24vq5c.execute-api.ap-south-1.amazonaws.com/dev/group`,
      groupObj
    );
    dispatch({
      type: ADD_GROUPS,
      payload: response.data,
    });
    message.success(`Group "${response.data.name}" Added Successfully`);
  } catch (error) {
    dispatch({
      type: GET_ERRORS,
      payload: error,
    });
  }
};
export const addMembers = (membersObj) => async (dispatch) => {
  try {
    let response = await axios.post(
      `https://km9q24vq5c.execute-api.ap-south-1.amazonaws.com/dev/group/members`,
      membersObj
    );
    console.log("#ressssss", response);
    dispatch({
      type: ADD_MEMBERS,
      payload: response.data,
    });
    message.success(`Member "${response.data.name}" Added Successfully`);
  } catch (error) {
    dispatch({
      type: GET_ERRORS,
      payload: error,
    });
  }
};

export const deleteUserFromGroup = (obj) => async (dispatch) => {
  await axios.put(
    `https://km9q24vq5c.execute-api.ap-south-1.amazonaws.com/dev/group/members`,
    obj
  );
  try {
    dispatch({
      type: DELETE_MEMBER,
      payload: obj,
    });
    message.success(`User Deleted Successfully`);
  } catch (error) {
    dispatch({
      type: GET_ERRORS,
      payload: error,
    });
  }
};
