const Sequelize = require("sequelize");
exports.deleteData = async (accountNumber) => {
  const d = new Date();
  let currentMonth = d.getMonth() + 1 + "";
  const sequelize = new Sequelize(
    process.env.DATABASE,
    process.env.USER,
    process.env.PASSWORD,
    {
      host: process.env.HOST,
      dialect: process.env.DIALECT,
    }
  );
  let res = await sequelize.authenticate();
  await sequelize.query(
    `delete from monthly_billing_${accountNumber} where month='${currentMonth}'`
  );
  sequelize.close();
  return res;
};
