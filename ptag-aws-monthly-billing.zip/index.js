"use strict";
const Sequelize = require("sequelize");
const { deleteData } = require("./delete");
const AthenaExpress = require("athena-express"),
  AWS = require("aws-sdk"),
  mysql = require("mysql");
var iam = new AWS.IAM();
const athenaExpressConfig = {
  aws: AWS,
  db: process.env.DB,
  getStats: true,
};

const sequelize = new Sequelize(
  process.env.DATABASE,
  process.env.USER,
  process.env.PASSWORD,
  {
    host: process.env.HOST,
    dialect: process.env.DIALECT,
  }
);

let accountNumber;
let table1;
let alias;
const athenaExpress = new AthenaExpress(athenaExpressConfig);
let connection = mysql.createConnection({
  host: process.env.HOST,
  user: process.env.USER,
  password: process.env.PASSWORD,
  database: process.env.DATABASE,
});
const d = new Date();
async function readyForDBtoSaveAllProduct(result, callback) {
  accountNumber = result.Items[0].accountid;
  table1 = `monthly_billing_${accountNumber}`;
  const readyForDB = result.Items.map((x) => {
    let name = x.line_item_product_code;
    let cost = x.cost;
    let month = x.month;
    let account_id = x.accountid;
    let startdate = x.startdate;
    let enddate = x.enddate;
    return [name, cost, month, account_id, startdate, enddate];
  });
  return callback({
    errorResponse: false,
    rowsToInsert: readyForDB,
  });
}
exports.handler = async (callback) => {
  try {
    let params = {};
    const list = await iam.listAccountAliases(params).promise();
    if (list.AccountAliases.length) {
      alias = list.AccountAliases[0];
    } else {
      alias = "No Alias Available";
    }
    console.log("list", list);
  } catch (e) {
    console.log("error", e);
  }
  let allProductResult;
  connection.connect(function (err) {
    if (err) {
      console.error("Database connection failed: " + err.stack);
      // context.fail();
      return;
    } else {
      console.log("Connected to database.");
    }
  });
  let currentMonth = d.getMonth() + 1 + "";
  let currentYear = d.getFullYear() + "";
  const sqlQueryAllProduct = `SELECT line_item_product_code, Round(sum(line_item_blended_cost),3)  AS cost, month,max(line_item_usage_account_id) As accountid,min(line_item_usage_start_date) As startdate,max(line_item_usage_end_date) As enddate FROM aws_daily_billing_report WHERE year = '${currentYear}' And month ='${currentMonth}' GROUP BY  line_item_product_code, month HAVING sum(line_item_blended_cost) > 0  ORDER BY  cost DESC;`;
  //const sqlQueryAllProduct=`SELECT line_item_product_code, Round(sum(line_item_blended_cost),3)  AS cost, month,max(line_item_usage_account_id) As accountid,min(line_item_usage_start_date) As startdate,max(line_item_usage_end_date) As enddate FROM aws_daily_billing_report WHERE year = '2022' And month ='8' GROUP BY  line_item_product_code, month HAVING sum(line_item_blended_cost) > 0  ORDER BY  cost DESC;`;
  try {
    allProductResult = await athenaExpress.query(sqlQueryAllProduct);
    if (!allProductResult.length) {
      return readyForDBtoSaveAllProduct(
        allProductResult,
        async ({ errorResponse, rowsToInsert }) => {
          if (errorResponse) {
            throw callback.errorResponse;
          }
          await sequelize.authenticate();
          if (rowsToInsert.length != 0) {
            let response =
              await sequelize.query(`CREATE TABLE IF NOT EXISTS monthly_billing_${accountNumber} (
          line_item_product_code VARCHAR(100),
          cost dOUBLE(100,3),
          month VARCHAR(25),
          account_id VARCHAR(50),
          start_date TIMESTAMP(6),
          end_date TIMESTAMP(6)
       );`);
            if (response) {
              //insertion of accountid and table name in master table
              let searchForAccountIdQuery = `select * from aws_billing_master_table where account_id=${accountNumber};`;
              let searchResponse = await sequelize.query(
                searchForAccountIdQuery
              );
              if (searchResponse[0].length) {
                let tableNameInsertQuery = `UPDATE aws_billing_master_table set account_id=${accountNumber},account_name='${alias}', monthly_billing_table_name='${table1}';`;
                let insertResponse = await sequelize.query(
                  tableNameInsertQuery
                );
              } else {
                let tableNameInsertQuery = `INSERT  INTO aws_billing_master_table(account_id,account_name,monthly_billing_table_name) VALUES(${accountNumber},'${alias}','${table1}');`;
                let insertResponse = await sequelize.query(
                  tableNameInsertQuery
                );
              }
              await deleteData(accountNumber);
              var sqlallproduct = `INSERT  INTO monthly_billing_${accountNumber}(line_item_product_code,cost,month,account_id,start_date,end_date) VALUES ?`;
              connection.query(
                sqlallproduct,
                [rowsToInsert],
                function (err, result) {
                  if (err) throw err;
                  console.log(result.affectedRows + " rows inserted");
                }
              );
            }
            return "Data saved to DB";
          } else {
            return `sorry,data for this  ${currentMonth} month is not available`;
          }
        }
      );
    } else {
      return "test report data is empty";
    }
  } catch (error) {
    console.log("inside catch", error);
    return error;
  }
};
