'use strict';
let conceptHandler = require('../handlerservices/concept/concept-handler');

const resolvers = {
    Create: {
     
  
      createConcept: (ctx) => {
        return conceptHandler.createConcept(ctx.argument, ctx.request);
      },
  
    }

}
  