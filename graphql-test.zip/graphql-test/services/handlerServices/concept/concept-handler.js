let util = require('../../../lib/util');
let dynamobdHelper = require('../../../lib/dynamodb-helper');
//let lambdaHelper = require('../../../lib/lambda-helper');   


async function createConcept(inputData, request) {

    let newConcept;
  
    // Record in X-ray 
    util.addXraySubsegmentwithContext(inputData, request, "CreateConcept: Resolver");
  
  
    // Set the accountant from request User ID 
    // inputData.UserID = util.getRequestUserID(request);
  
  
    try {
      newConcept = await newConceptMapping(inputData);
    } catch (e) {
      return Promise.reject(e);
    }
  
  
    try {
      if (newConcept) {
        console.log("newConcept", JSON.stringify(newConcept));
        let result = await dynamobdHelper.writeConceptItemRecords(newConcept);
        console.log(result);
      }
  
    } catch (e) {
      return Promise.reject(e);
    }
  
    // Step 2: Update the Recipe to ES
  
    // let finalconSet = getConceptSetforES(newConcept);
    // console.log("finalconSet", JSON.stringify(finalconSet));
  
    // let requestParameter = {
    //   conceptSet: finalconSet,
    //   isUpdate: false
    // }
  
    // let requestParams = {
    //   functionName: 'updateConcepttoElasticSearch',
    //   requestParameter: requestParameter
    // };
    // try {
    //   let result = await lambdaHelper.callESMicroRecipeFunction(requestParams);
    //   console.log('result', result);
    //   // return Promise.resolve(result);
    // } catch (e) {
    //   return Promise.reject(e);
    // }
  
    return Promise.resolve(newConcept);
  
  }

  async function newConceptMapping(inputData) {
    let conceptId = `${inputData.Country}${inputData.ConceptName}`;
    let concept = {
        ID: conceptId,
        conceptName:  inputData.ConceptName,
        country:  inputData.Country,
    }
    return concept;
  }

  function getConceptSetforES(newConcept) {

    let finalSetCon = []
  
    let finalconRec = {
      "@timestamp": new Date().toISOString(),
      ...newConcept
    };
  
    finalSetCon.push(finalconRec);
  
    return finalSetCon;
  }


  module.exports = {
    createConcept

  }