const express = require("express");
const winston = require("winston");
const cors = require("cors");
const organization = require("././Azure-Devops/Organizations/routes/routes");
const projects = require("././Azure-Devops/Projects/routes/routes");
const teams = require("././Azure-Devops/Teams/routes/routes");
const rules = require("././OrganizationRules/Rules/routes/route");
const repositories = require("././Azure-Devops/Repository/routes/routes");
const processes = require("././Azure-Devops/Processes/routes/route");
const branches = require("././Azure-Devops/Branches/routes/routes");
const policies = require("././Azure-Devops/Policies/routes/route");
const variablegroup = require("././Azure-Devops/VariableGroup/routes/route");
const users = require("././Azure-Devops/Users/routes/route");
const pipelines = require("././Azure-Devops/Pipelines/routes/route");
const pullRequest = require("././Azure-Devops/PullRequests/routes/route");
const azureDirectory = require("././Azure-Devops/AzureDirectory/routes/route");
const githubAccessToken = require("./GitHub/Token/routes/route");
const githubOrganizations = require("./GitHub/Organization/routes/route");
const githubRepository = require("./GitHub/Repository/routes/route");
const githubBranches = require("./Github/Branches/routes/route");
const githubClientInfo = require("./Github/GithubClientDirectory/routes/route");
const githubPipeline = require("./GitHub/Pipeline/routes/route");
const githubPullRequest = require("./GitHub/PullRequest/routes/route");
const githubVariables = require("./GitHub/Variables/routes/route");
const githubSecrets = require("./GitHub/Secrets/routes/route");
const repoEnvironment = require("./GitHub/RepositoryEnvironment/routes/route");
const repositoryCollaborators = require("./GitHub/Collaborators/routes/route");
const { availableDeploymentPlatforms } = require("./sourceCodeLibrary");
const { responsHeader, statusCodes } = require("./constants");

let response = {
  headers: responsHeader,
  body: {},
};
const app = express();
app.use(express.json());
app.use(
  cors({
    origin: "*",
    methods: "GET,HEAD,PUT,PATCH,POST,DELETE",
  })
);

const { createLogs } = require("./config/loggerConfig");

const todayDate = new Date().toDateString().replace(/\ /g, "");
const logConfiguration = createLogs("index", todayDate);
const logger = winston.createLogger(logConfiguration);

// Adding routes
app.use("/api/v1/organization", organization);
app.use("/api/v1/projects", projects);
app.use("/api/v1/teams", teams);
app.use("/api/v1/rules", rules);
app.use("/api/v1/repositories", repositories);
app.use("/api/v1/branches", branches);
app.use("/api/v1/processes", processes);
app.use("/api/v1/policies", policies);
app.use("/api/v1/variablegroup", variablegroup);
app.use("/api/v1/users", users);
app.use("/api/v1/pipelines", pipelines);
app.use("/api/v1/pullrequests", pullRequest);
app.use("/api/v1/active-directory", azureDirectory);
app.use("/api/v1/git-hub/access-token", githubAccessToken);
app.use("/api/v1/git-hub/organizations", githubOrganizations);
app.use("/api/v1/git-hub/repository", githubRepository);
app.use("/api/v1/git-hub/branches", githubBranches);
app.use("/api/v1/git-hub/client-info", githubClientInfo);
app.use("/api/v1/git-hub/pipeline", githubPipeline);
app.use("/api/v1/git-hub/pull-request", githubPullRequest);
app.use("/api/v1/git-hub/variable", githubVariables);
app.use("/api/v1/git-hub/secrets", githubSecrets);
app.use("/api/v1/git-hub/environment", repoEnvironment);
app.use("/api/v1/git-hub/repository-collaborators", repositoryCollaborators);
app.get("/api/v1/deployment-platforms", (req, res) => {
  response.body = {
    availableDeploymentPlatforms: availableDeploymentPlatforms,
  };
  res.status(statusCodes.SUCCESS).send(response);
});
const port = 8080;
app.listen(port, async () => {
  logger.log("info", `DevOps PE Backend started and listening on ${port}`);
});
