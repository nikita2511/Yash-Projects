const winston = require("winston");
const { createLogs } = require("../../../config/loggerConfig");
const todayDate = new Date().toDateString().replace(/\ /g, "");
const logConfiguration = createLogs("github-Variables-dao", todayDate);
const logger = winston.createLogger(logConfiguration);
const { getConnection } = require("../../../config/githubConnection");
const repoEnvironment = require("../../RepositoryEnvironment/dao/dao");

const {
  errorStatus,
  errorMessages,
  statusCodes,
} = require("../../../constants");
const { header } = require("express-validator");

async function getAllEnvironmentsVariables(
  organizationName,
  RepoName,
  RepoId,
  accessToken
) {
  try {
    const repoEnvironments = await repoEnvironment.listRepoEnvironments(
      organizationName,
      RepoName,
      accessToken
    );
    const repositoryEnvironments = repoEnvironments.data.environments;
    const data = await repositoryEnvironments.map(async (environment) => {
      let EnvVariables = {};
      let repoEnvVariables = await listEnvironmentVariables(
        RepoId,
        environment.name,
        accessToken
      );
      let environmentVariable = repoEnvVariables.data;
      EnvVariables = {
        environmentName: environment.name,
        environmentVariables: environmentVariable.variables,
      };
      return EnvVariables;
    });

    let response = await Promise.all(data);
    return response;
  } catch (error) {
    logger.error("GetAllEnvironmentsVariables", error);
    throw error;
  }
}

/**
 *
 * @param {Integer} repository_id
 * @param {String} environment_name
 * @param {String} accessToken
 *
 *
 * @returns List of Environment Variables for a provided Environment
 */
async function listEnvironmentVariables(
  repository_id,
  environment_name,
  accessToken
) {
  if (!accessToken) return errorStatus.TNF;
  const octokit = await getConnection(accessToken);
  try {
    const EnvVariables = await octokit.actions.listEnvironmentVariables({
      repository_id: repository_id,
      environment_name: environment_name,
      headers: {
        "X-GitHub-Api-Version": "2022-11-28",
      },
    });
    if (EnvVariables.status === statusCodes.SUCCESS) {
      return {
        success: true,
        data: EnvVariables.data,
      };
    } else {
      return {
        success: false,
        message: "Failed to retrieve environment variables.",
      };
    }
  } catch (error) {
    throw error;
  }
}

/**
 *
 * @param {Integer} repository_id
 * @param {String} environment_name
 * @param {String} variablename
 * @param {String} variablevalue
 * @param {String} accessToken
 * @param {Object} headers
 *
 *
 * @returns Created Environment Variables for provided environment_name
 */
async function createEnvironmentVariables(
  repository_id,
  environment_name,
  variables,
  accessToken
) {
  try {
    if (!accessToken) return errorStatus.TNF;
    const octokit = await getConnection(accessToken);
    if (!variables.length) {
      return false;
    }
    let count = 0;
    let createdEnvVariables;
    for (let i = 0; i < variables.length; i++) {
      createdEnvVariables = await octokit.actions.createEnvironmentVariable({
        repository_id: repository_id,
        environment_name: environment_name,
        name: variables[i].name,
        value: variables[i].value,
        headers: {
          "X-GitHub-Api-Version": "2022-11-28",
        },
      });
      if (createdEnvVariables.status == statusCodes.CREATED) {
        count += 1;
      }
    }
    if (count === variables.length) {
      return createdEnvVariables;
    } else {
      throw new Error("Unable to create the provided variables");
    }
  } catch (error) {
    throw error;
  }
}

/**
 *
 * @param {Integer} repository_id
 * @param {String} environment_name
 * @param {String} variablename
 * @param {String} variablevalue
 * @param {String} accessToken
 * @param {object} headers
 *
 * @returns success message that the environment variables is updated.
 *
 */
async function updateEnvironmentVariables(
  repository_id,
  environment_name,
  variables,
  accessToken
) {
  try {
    if (!accessToken) return errorStatus.TNF;
    const octokit = await getConnection(accessToken);
    let count = 0;
    let updatedEnvVariables;
    for (let i = 0; i < variables.length; i++) {
      updatedEnvVariables = await octokit.actions.updateEnvironmentVariable({
        repository_id: repository_id,
        environment_name: environment_name,
        name: variables[i].name,
        value: variables[i].value,
        headers: {
          "X-GitHub-Api-Version": "2022-11-28",
        },
      });
      if (updatedEnvVariables.status == statusCodes.NO_CONTENT) {
        count += 1;
      }
    }
    if (count >= 1) {
      return updatedEnvVariables;
    } else {
      throw new Error("Unable to update the variable!");
    }
  } catch (error) {
    throw error;
  }
}

/**
 *
 * @param {Integer} repository_id
 * @param {String} environment_name
 * @param {String} variablename
 * @param {String} accessToken
 * @param {object} headers
 *
 *
 */
async function deleteEnvironmentVariables(
  repository_id,
  environment_name,
  variablename,
  accessToken
  // headers
) {
  if (!accessToken) return errorStatus.TNF;
  const octokit = await getConnection(accessToken);
  try {
    const deletedEnvVariables = await octokit.actions.deleteEnvironmentVariable(
      {
        repository_id: repository_id,
        environment_name: environment_name,
        name: variablename,
        // headers: headers,
      }
    );
    console.log("deletedEnvVariables", deletedEnvVariables);
    if (deletedEnvVariables.status == statusCodes.NO_CONTENT) {
      return deletedEnvVariables;
    }
  } catch (error) {
    throw error;
  }
}

module.exports.listEnvironmentVariables = listEnvironmentVariables;
module.exports.createEnvironmentVariables = createEnvironmentVariables;
module.exports.updateEnvironmentVariables = updateEnvironmentVariables;
module.exports.deleteEnvironmentVariables = deleteEnvironmentVariables;
module.exports.getAllEnvironmentsVariables = getAllEnvironmentsVariables;
