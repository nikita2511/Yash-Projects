const winston = require("winston");
const { createLogs } = require("../../../config/loggerConfig");
const todayDate = new Date().toDateString().replace(/\ /g, "");
const logConfiguration = createLogs("GitHub-Variable-controller", todayDate);
const logger = winston.createLogger(logConfiguration);
const tokenDAO = require("../dao/dao");
const {
  responsHeader,
  statusCodes,
  errorStatus,
  errorMessages,
  successMessages,
} = require("../../../constants");

let response = {
  headers: responsHeader,
  body: {},
};

const variableDAO = require("../dao/dao");

module.exports.getAllEnvironmentVariables = async (req, res) => {
  const bearerHeader = req.headers.authorization;
  const accessToken = bearerHeader && bearerHeader.split(" ")[1];

  const { organizationName, RepoName, RepoId } = req.query;

  try {
    const result = await variableDAO.getAllEnvironmentsVariables(
      organizationName,
      RepoName,
      RepoId,
      accessToken
    );
    if (result.length >= 0) {
      response.body = {
        result: result,
      };
      res.status(statusCodes.SUCCESS).send(response);
    } else {
      throw new Error("Unable to get ALL Environment Variables");
    }
  } catch (error) {
    logger.error("Get ALL ENVIRONMENTs Variables Controller....", error);
    if (error.response.status) {
      response.body = {
        message: error.response.data.message,
      };
      res.status(error.response.status).send(response);
    } else if (error.message) {
      response.body = {
        message: error.message,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    } else {
      response.body = {
        message: error,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};

/**
 * A handler function to list environment variables
 *
 * @param {String} req
 * @param {JSON Object} res
 *
 * @returns A list of environment variable objects with Http SUCCESS status code or errors with Http error status codes.
 */
module.exports.listEnvironmentVariables = async (req, res) => {
  const bearerHeader = req.headers.authorization;
  const accessToken = bearerHeader && bearerHeader.split(" ")[1];

  const { repository_id, environment_name } = req.query;

  try {
    const EnvironmentVariable = await variableDAO.listEnvironmentVariables(
      repository_id,
      environment_name,
      accessToken
    );
    if (
      EnvironmentVariable.success &&
      EnvironmentVariable.hasOwnProperty("data")
    ) {
      response.body = {
        EnvironmentVariable: EnvironmentVariable.data,
      };
      res.status(statusCodes.SUCCESS).send(response);
    } else {
      response.body = {
        message: EnvironmentVariable.message,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  } catch (error) {
    logger.error(
      `Error in Github list Environment Variable controller : ${error}`
    );
    if (error.response.status) {
      response.body = {
        message: error.response.data.message,
      };
      res.status(error.response.status).send(response);
    } else if (error.message) {
      response.body = {
        message: error.message,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    } else {
      response.body = {
        message: error,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};

/**
 * A handler function to create environment variables.
 *
 * @param {JSON Object} req
 * @param {JSON Object} res
 *
 * @returns A success message with Http SUCCESS status code or errors with Http error status codes.
 */
module.exports.createEnvironmentVariables = async (req, res) => {
  const bearerHeader = req.headers.authorization;
  const accessToken = bearerHeader && bearerHeader.split(" ")[1];

  const { repository_id, environment_name, variables } = req.body;

  try {
    const EnvironmentVariable = await variableDAO.createEnvironmentVariables(
      repository_id,
      environment_name,
      variables,
      accessToken
    );
    if (!EnvironmentVariable) {
      response.body = { message: errorMessages.NVF };
      res.status(statusCodes.SUCCESS).send(response);
    } else if (EnvironmentVariable.status == statusCodes.CREATED) {
      response.body = {
        EnvironmentVariable: successMessages.ENVC,
      };
      res.status(EnvironmentVariable.status).send(response);
    } else {
      res.status(statusCodes.SERVER_ERROR).send({
        error: "Failed to create environment variables.",
      });
    }
  } catch (error) {
    logger.error(
      `Error in Github create Environment Variable controller : ${error}`
    );
    if (error.response.status) {
      response.body = {
        message: error.response.data.message,
      };
      res.status(error.response.status).send(response);
    } else if (error.message) {
      response.body = {
        message: error.message,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    } else {
      response.body = {
        message: error,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};

/**
 * A handler function to update existing environment variables.
 *
 * @param {JSON Object} req
 * @param {JSON Object} res
 *
 * @returns A success message with Http SUCCESS status code or errors wiht Http error status codes.
 */
module.exports.updateEnvironmentVariables = async (req, res) => {
  const bearerHeader = req.headers.authorization;
  const accessToken = bearerHeader && bearerHeader.split(" ")[1];

  const { repository_id, environment_name, variables } = req.body;

  try {
    const updateEnvironmentVariable =
      await variableDAO.updateEnvironmentVariables(
        repository_id,
        environment_name,
        variables,
        accessToken
      );
    if (updateEnvironmentVariable.status == statusCodes.NO_CONTENT) {
      response.body = {
        EnvironmentVariable: successMessages.ENUC,
      };
      res.status(statusCodes.SUCCESS).send(response);
    }
  } catch (error) {
    logger.error(
      `Error in Github update Environment Variable controller : ${error}`
    );
    if (error.response.status) {
      response.body = {
        message: error.response.data.message,
      };
      res.status(error.response.status).send(response);
    } else if (error.message) {
      response.body = {
        message: error.message,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    } else {
      response.body = {
        message: error,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};

/**
 * A handler function to delete an environment variable
 *
 * @param {JSON Object} req
 * @param {JSON Object} res
 *
 * @returns An object for deleted environment variable with Http SUCCESS status code or errors with Http error status codes.
 */
module.exports.deleteEnvironmentVariables = async (req, res) => {
  const bearerHeader = req.headers.authorization;
  const accessToken = bearerHeader && bearerHeader.split(" ")[1];

  const { repository_id, environment_name, variablename } = req.query;
  // const { headers } = req.headers;

  try {
    console.log(
      "repository_id, environment_name, variablename, headers",
      repository_id,
      environment_name,
      variablename
      // headers
    );
    const EnvironmentVariable = await variableDAO.deleteEnvironmentVariables(
      repository_id,
      environment_name,
      variablename,
      accessToken
      // headers
    );
    console.log("EnvironmentVariable", EnvironmentVariable);
    if (EnvironmentVariable == errorStatus.TNF) {
      response.body = {
        message: errorMessages.TNF,
      };
      res.status(statusCodes.NOT_FOUND).send(response);
    } else if (EnvironmentVariable.status == statusCodes.NO_CONTENT) {
      response.body = {
        isVariableDeleted: true,
      };
      res.status(statusCodes.SUCCESS).send(response);
    }
  } catch (error) {
    logger.error(
      `Error in Github delete environment variable controller : ${error}`
    );
    if (error.response.status) {
      response.body = {
        message: error.response.data.message,
      };
      res.status(error.response.status).send(response);
    } else if (error.message) {
      response.body = {
        message: error.message,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    } else {
      response.body = {
        message: error,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};
