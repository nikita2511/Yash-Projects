const express = require("express");
const router = express.Router();
const controller = require("../controller/controller");

//Get All Environment Variables
router.get("/envvariables", controller.getAllEnvironmentVariables);
//Creates environment variable
router.post("/", controller.createEnvironmentVariables);

//Gets a list of environment variables
router.get("/", controller.listEnvironmentVariables);

//Update environment variable
router.put("/", controller.updateEnvironmentVariables);
router.delete("/", controller.deleteEnvironmentVariables);

module.exports = router;
