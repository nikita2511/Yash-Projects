const winston = require("winston");
const { createLogs } = require("../../../config/loggerConfig");
const todayDate = new Date().toDateString().replace(/\ /g, "");
const logConfiguration = createLogs("github-repository-dao", todayDate);
const logger = winston.createLogger(logConfiguration);
const { getConnection } = require("../../../config/githubConnection");

const {
  errorStatus,
  errorMessages,
  statusCodes,
} = require("../../../constants");

/**
 * A function to create a pull request
 *
 * @param {String} accessToken
 * @param {String} organizationName
 * @param {String} repositoryName
 * @param {String} sourceBranch
 * @param {String} targetBranch
 *
 * @returns An object of created pull request or an error object
 */
async function createPullRequest(
  accessToken,
  organizationName,
  repositoryName,
  sourceBranch,
  targetBranch
) {
  try {
    if (!accessToken) return errorStatus.TNF;
    const octokit = await getConnection(accessToken);
    try {
      const createdPullRequest = await octokit.pulls.create({
        owner: organizationName,
        repo: repositoryName,
        title: "Merging feature branch to default branch",
        head: targetBranch,
        base: sourceBranch,
        headers: {
          "X-GitHub-Api-Version": "2022-11-28",
        },
      });
      if (createdPullRequest.status == statusCodes.SUCCESS);
      {
        logger.log(
          "info",
          `createdPullRequest : ${JSON.stringify(createdPullRequest.data)}`
        );
        return createdPullRequest.data;
      }
    } catch (error) {
      logger.error(`Error from github create pull request dao : ${error}`);
      throw error;
    }
  } catch (error) {
    logger.error(`Error from github create pull request dao : ${error}`);
    throw error;
  }
}

/**
 * A function to add reviewers to a pull request
 *
 * @param {String} accessToken
 * @param {String} organizationName
 * @param {String} repositoryName
 * @param {String} pullRequestId
 * @param {Number} reviewers
 *
 * @returns A boolean value or an error object.
 */
async function addReviewersToPullRequest(
  accessToken,
  organizationName,
  repositoryName,
  pullRequestId,
  reviewers
) {
  try {
    if (!accessToken) return errorStatus.TNF;
    const octokit = await getConnection(accessToken);
    try {
      const addedPullRequestReviewers = await octokit.pulls.requestReviewers({
        owner: organizationName,
        repo: repositoryName,
        pull_number: pullRequestId,
        reviewers: reviewers,
        headers: {
          "X-GitHub-Api-Version": "2022-11-28",
        },
      });
      logger.log(
        "info",
        `addedPullRequestReviewers : ${JSON.stringify(
          addedPullRequestReviewers.data
        )}`
      );
      logger.log(
        "info",
        `addedPullRequestReviewers.status : ${addedPullRequestReviewers.status}`
      );
      if (addedPullRequestReviewers.status == statusCodes.CREATED) {
        return true;
      } else return false;
    } catch (error) {
      logger.error(
        `Error from github create pull request reviewers dao : ${error}`
      );
      throw error;
    }
  } catch (error) {
    logger.error(
      `Error from github create pull request reviewers dao : ${error}`
    );
    throw error;
  }
}

module.exports.createPullRequest = createPullRequest;
module.exports.addReviewersToPullRequest = addReviewersToPullRequest;
