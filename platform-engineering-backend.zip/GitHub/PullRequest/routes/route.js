const express = require("express");
const router = express.Router();
const controller = require("../controller/controller");

//Creates a  pull request
router.post("/test", controller.test);

//Adds reviewers to a pull request
router.post(
  "/test-add-pull-request-reviewers",
  controller.testAddReviewersToPullRequest
);

module.exports = router;
