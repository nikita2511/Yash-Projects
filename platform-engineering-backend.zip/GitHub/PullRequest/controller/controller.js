const winston = require("winston");
const { createLogs } = require("../../../config/loggerConfig");
const todayDate = new Date().toDateString().replace(/\ /g, "");
const logConfiguration = createLogs(
  "GitHub-pull-request-controller",
  todayDate
);
const logger = winston.createLogger(logConfiguration);

const pullRequestDAO = require("../dao/dao");

const {
  responsHeader,
  statusCodes,
  errorStatus,
  errorMessages,
} = require("../../../constants");

let response = {
  headers: responsHeader,
  body: {},
};

/**
 * A handler function to create a Pull Request.
 * 
 * @param {JSON Object} req 
 * @param {JSON OBject} res 
 * 
 * @returns An object of created pull request with Http SUCCESS status code or errors with Http error status codes.
 */
module.exports.test = async (req, res) => {
  const bearerHeader = req.headers.authorization;
  const accessToken = bearerHeader && bearerHeader.split(" ")[1];
  const { organizationName, repositoryName, sourceBranch, targetBranch } =
    req.body;

  try {
    const createdPullRequest = await pullRequestDAO.createPullRequest(
      accessToken,
      organizationName,
      repositoryName,
      sourceBranch,
      targetBranch
    );
    if (createdPullRequest == errorStatus.TNF) {
      response.body = {
        message: errorMessages.TNF,
      };
      res.status(statusCodes.BAD_REQUEST).send(response);
    } else if (createdPullRequest) {
      response.body = {
        createdPullRequest: createdPullRequest,
      };
      res.status(statusCodes.SUCCESS).send(response);
    }
  } catch (error) {
    logger.error(`Error in Github create pull request controller : ${error}`);
    if (error.response.status) {
      response.body = {
        message: error.response.data.message,
      };
      res.status(error.response.status).send(response);
    } else {
      response.body = {
        message: error,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};


/**
 * A handler function to add reviewers to a pull request.
 * 
 * @param {JSON Object} req 
 * @param {JSON Object} res 
 * 
 * @returns A boolean value with Http SUCCESS status code or error with Http error status codes.
 */
module.exports.testAddReviewersToPullRequest = async (req, res) => {
  const bearerHeader = req.headers.authorization;
  const accessToken = bearerHeader && bearerHeader.split(" ")[1];
  const { organizationName, repositoryName, pullRequestId, reviewers } =
    req.body;

  try {
    const addedPullRequestReviewers =
      await pullRequestDAO.addReviewersToPullRequest(
        accessToken,
        organizationName,
        repositoryName,
        pullRequestId,
        reviewers
      );
    if (addedPullRequestReviewers == errorStatus.TNF) {
      response.body = {
        message: errorMessages.TNF,
      };
      res.status(statusCodes.BAD_REQUEST).send(response);
    } else if (addedPullRequestReviewers) {
      response.body = {
        addedPullRequestReviewers: addedPullRequestReviewers,
      };
      res.status(statusCodes.SUCCESS).send(response);
    }
  } catch (error) {
    logger.error(
      `Error in Github create pull request reviewers controller : ${error}`
    );
    if (error.response.status) {
      response.body = {
        message: error.response.data.message,
      };
      res.status(error.response.status).send(response);
    } else {
      response.body = {
        message: error,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};
