const winston = require("winston");
const { createLogs } = require("../../../config/loggerConfig");
const todayDate = new Date().toDateString().replace(/\ /g, "");
const logConfiguration = createLogs("GitHub-token-controller", todayDate);
const logger = winston.createLogger(logConfiguration);

const dao = require("../dao/dao");

const {
  responsHeader,
  statusCodes,
  errorStatus,
  errorMessages,
} = require("../../../constants");

let response = {
  headers: responsHeader,
  body: {},
};

/**
 * A handler function to fetch organization for a user
 *
 * @param {JSON Object} req The request object
 * @param {JSON} res The response object
 *
 * @returns A list of organization object with Http SUCCESS status code or error with Http error status codes.
 */
module.exports.listOrganizations = async (req, res) => {
  const bearerHeader = req.headers.authorization;
  const accessToken = bearerHeader && bearerHeader.split(" ")[1];
  const { platform } = req.query;
  try {
    const organizations = await dao.listOrganizations(platform, accessToken);
    if (organizations == errorStatus.TNF) {
      response.body = {
        message: errorMessages.TNF,
      };
      res.status(statusCodes.BAD_REQUEST).send(response);
    } else if (organizations) {
      response.body = {
        organizations: organizations,
      };
      res.status(statusCodes.SUCCESS).send(response);
    }
  } catch (error) {
    logger.error(`Error in Github Organizations controller : ${error}`);
    if (error.response.status) {
      response.body = {
        message: error.response.data.message,
      };
      res.status(error.response.status).send(response);
    } else {
      response.body = {
        message: error,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};

/**
 * A handler function to add members to an organization
 *
 * @param {JSON Object} req The request object
 * @param {JSON Object} res The response object
 *
 * @returns An object of added member with Http CREATED status code or erros with Http error status codes.
 */
module.exports.addMemberToOrganization = async (req, res) => {
  const bearerHeader = req.headers.authorization;
  const accessToken = bearerHeader && bearerHeader.split(" ")[1];

  const { organizationName, memberEmailId, organizationMemberRole } = req.body;
  try {
    const addedMember = await dao.addMemberToOrganization(
      accessToken,
      organizationName,
      memberEmailId,
      organizationMemberRole
    );
    if (addedMember == errorStatus.TNF) {
      response.body = {
        message: errorMessages.TNF,
      };
      res.status(statusCodes.BAD_REQUEST).send(response);
    } else if (addedMember) {
      response.body = {
        addedMember: addedMember,
      };
      res.status(statusCodes.CREATED).send(response);
    }
  } catch (error) {
    logger.error(
      `Error in Github add members to organizations controller : ${error}`
    );
    if (error.response.status == statusCodes.FORBIDDEN) {
      response.body = {
        message: error.response.data.message,
      };
      res.status(error.response.status).send(response);
    } else if (error.response.status) {
      response.body = {
        message: error.response.data.message,
      };
      res.status(error.response.status).send(response);
    } else {
      response.body = {
        error: error,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};

/**
 * A handler function to list members in an organization
 *
 * @param {JSON Object} req The request object
 * @param {JSON Object} res The response object
 *
 * @returns A list of user ojects with Http SUCCESS status code or erros with Http error status codes.
 */
module.exports.listMembersInOrganization = async (req, res) => {
  const bearerHeader = req.headers.authorization;
  const accessToken = bearerHeader && bearerHeader.split(" ")[1];
  const organizationName = req.query.organizationName;

  try {
    const members = await dao.listMembersInOrganization(
      accessToken,
      organizationName
    );
    if (members == errorStatus.TNF) {
      response.body = {
        message: errorMessages.TNF,
      };
      res.status(statusCodes.BAD_REQUEST).send(response);
    } else if (members) {
      response.body = {
        members: members,
      };
      res.status(statusCodes.SUCCESS).send(response);
    }
  } catch (error) {
    logger.error(
      `Error in Github list members in organizations controller : ${error}`
    );
    if (error.response.status) {
      response.body = {
        message: error.response.data.message,
      };
      res.status(error.response.status).send(response);
    } else {
      response.body = {
        error: error,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};
