const axios = require("axios");

const { Octokit } = require("@octokit/rest");

const winston = require("winston");
const { createLogs } = require("../../../config/loggerConfig");
const todayDate = new Date().toDateString().replace(/\ /g, "");
const logConfiguration = createLogs("github-organizations-dao", todayDate);
const logger = winston.createLogger(logConfiguration);
const { getConnection } = require("../../../config/githubConnection");
const {
  getOrgnizationRulesList,
} = require("../../../OrganizationRules/Rules/dao/dao");
const { errorStatus, errorMessages } = require("../../../constants");

/**
 * A function to list organization for a user
 * 
 * @param {String} platform 
 * @param {String} accessToken 
 * 
 * @returns A list of organization objects or an error object
 */
async function listOrganizations(platform, accessToken) {
  try {
    try {
      if (!accessToken) return errorStatus.TNF;
      const octokit = await getConnection(accessToken);
      const organizations = await octokit.orgs.listForAuthenticatedUser();
      let orgRuleList = await getOrgnizationRulesList(platform);
      if (organizations.data) {
        // Set isRuleExists flag for each organization
        organizations.data.forEach((organization) => {
          organization.isRuleExists = false;
          orgRuleList.forEach((orgRule) => {
            if (orgRule.organizationName == organization.login)
              organization.isRuleExists = true;
          });
        });
      }
      return organizations.data;
    } catch (error) {
      logger.error(`Error from github oraganization dao : ${error}`);
      throw error;
    }
  } catch (error) {
    logger.error(`Error in GitHub Organizations dao : ${error}`);
    throw error;
  }
}

/**
 * A function to add member to an orgranization
 *
 * @param {String} accessToken
 * @param {String} organizationName
 * @param {String} memberEmailId
 * @param {String} organizationMemberRole
 *
 * @returns An response object of createdInvitation or an error object
 */
async function addMemberToOrganization(
  accessToken,
  organizationName,
  memberEmailId,
  organizationMemberRole
) {
  try {
    if (!accessToken) return errorStatus.TNF;
    const octokit = await getConnection(accessToken);
    const response = await octokit.orgs.createInvitation({
      org: organizationName,
      email: memberEmailId,
      role: organizationMemberRole,
    });

    if (response.data) {
      return response.data;
    }
  } catch (error) {
    logger.error(
      `Error from github add members to oraganization dao : ${error}`
    );
    throw error;
  }
}

/**
 * A function to list members of an organization
 * 
 * @param {String} accessToken 
 * @param {String} organizationName 
 * 
 * @returns A list of users object or an error object
 */
async function listMembersInOrganization(accessToken, organizationName) {
  try {
    if (!accessToken) return errorStatus.TNF;
    const octokit = await getConnection(accessToken);
    try {
      const response = await octokit.orgs.listMembers({
        org: organizationName, // Replace with your organization name
      });
      const members = response.data;
      logger.log("info", `Members in an org : ${JSON.stringify(members)}`);
      return members;
    } catch (error) {
      logger.error(
        `Error from github list members in oraganization dao : ${error}`
      );
      throw error;
    }
  } catch (error) {
    logger.error(
      `Error from github list members in oraganization dao : ${error}`
    );
    throw error;
  }
}

module.exports.listOrganizations = listOrganizations;
module.exports.addMemberToOrganization = addMemberToOrganization;
module.exports.listMembersInOrganization = listMembersInOrganization;
