const express = require("express");
const router = express.Router();
const controller = require("../controller/controller");

//Gets a list of organizations
router.get("/", controller.listOrganizations);

//Creates an invite to add member to an organization
router.post("/add-member", controller.addMemberToOrganization);

//Gets a list of members of an organization
router.get("/members", controller.listMembersInOrganization);

module.exports = router;
