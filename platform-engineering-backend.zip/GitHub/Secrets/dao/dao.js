const winston = require("winston");
const { createLogs } = require("../../../config/loggerConfig");
const todayDate = new Date().toDateString().replace(/\ /g, "");
const logConfiguration = createLogs("github-Secrets-dao", todayDate);
const logger = winston.createLogger(logConfiguration);
const { getConnection } = require("../../../config/githubConnection");

const sodium = require("libsodium-wrappers");

const repositoryDAO = require("../../Repository/dao/dao");
const repoEnvironment = require("../../RepositoryEnvironment/dao/dao");
const {
  errorStatus,
  errorMessages,
  statusCodes,
} = require("../../../constants");
const { header } = require("express-validator");

/**
 * Retrieves the public key for a specific environment.
 *
 * @param {Integer} repositoryId - The ID of the repository.
 * @param {String} accessToken - The access token for authentication.
 * @param {String} environmentname - The name of the environment.
 * @returns {Object} - The public key for the environment.
 * @throws {Error} - If the access token is missing or unable to retrieve the environment public key.
 */

async function EnvironmentPublicKey(
  repositoryId,
  accessToken,
  environmentname
) {
  try {
    if (!accessToken) {
      throw new Error("Access token is missing");
    }

    const octokit = await getConnection(accessToken);
    const EnvPublicKey = await octokit.actions.getEnvironmentPublicKey({
      repository_id: repositoryId,
      environment_name: environmentname,
      headers: {
        "X-GitHub-Api-Version": "2022-11-28",
      },
    });
    if (EnvPublicKey.status == statusCodes.SUCCESS) {
      return EnvPublicKey;
    }
  } catch (error) {
    logger.error("Error in getting Environment Public Key ", error);
    throw error;
  }
}

/**
 * Creates or updates an environment secret.
 *
 * @param {Integer} repository_id - The ID of the repository.
 * @param {String} accessToken - The access token for authentication.
 * @param {String} environment_name - The name of the environment.
 * @param {String} secret_name - The name of the secret.
 * @param {String} encrypted_value - The encrypted value of the secret.
 * @returns {Object} - The created or updated environment secret.
 * @throws {Error} - If the access token is missing or unable to get the KeyID.
 */
async function createorUpdateEnvironmentSecret(
  accessToken,
  organizationName,
  repositoryName,
  environmentName,
  secrets
) {
  try {
    if (!accessToken) {
      throw new Error("Access token is missing");
    }
    let keyId,
      key,
      encryptedValue,
      encBytes,
      binsec,
      binkey,
      createdEnvSecrets,
      createdEnvSecretsArray = [];

    if(!secrets.length)
    {
      return false;
    }
    const octokit = await getConnection(accessToken);
    const repository = await repositoryDAO.getRepository(
      accessToken,
      organizationName,
      repositoryName
    );
    logger.log("info", ` repository  : ${JSON.stringify(repository.id)}`);

    const EnvPublicKey = await EnvironmentPublicKey(
      repository.id,
      accessToken,
      environmentName
    );

    if (EnvPublicKey.hasOwnProperty("data")) {
      keyId = EnvPublicKey.data.key_id;
      key = EnvPublicKey.data.key;
    } else {
      throw new Error("Unable to get the KeyID....");
    }
    logger.log(
      "info",
      `${JSON.stringify({
        repositoryId: repository.id,
        environmentName: environmentName,
        secrets: secrets,
        keyId: keyId,
        key: key,
      })}`
    );
    for (let secret of secrets) {
      const secretValue = secret.secretValue; // replace with the secret you want to encrypt
      const publicKey = key; // replace with the Base64 encoded public key

      //Check if libsodium is ready and then proceed.
      if (sodium.ready) {
        // Convert Secret & Base64 key to Uint8Array.
        binkey = sodium.from_base64(publicKey, sodium.base64_variants.ORIGINAL);
        binsec = sodium.from_string(secretValue);

        //Encrypt the secret using LibSodium
        encBytes = sodium.crypto_box_seal(binsec, binkey);

        // Convert encrypted Uint8Array to Base64
        encryptedValue = sodium.to_base64(
          encBytes,
          sodium.base64_variants.ORIGINAL
        );
      }

      createdEnvSecrets = await octokit.actions.createOrUpdateEnvironmentSecret(
        {
          repository_id: repository.id,
          environment_name: environmentName,
          secret_name: secret.secretName,
          encrypted_value: encryptedValue,
          key_id: keyId,
          headers: {
            "X-GitHub-Api-Version": "2022-11-28",
          },
        }
      );
      createdEnvSecretsArray.push(createdEnvSecrets);
      logger.log(
        "info",
        `createdEnvSecretsArray : ${JSON.stringify(createdEnvSecretsArray)}`
      );
    }
    if (createdEnvSecretsArray.length) {
      return true;
    } else return false;
  } catch (error) {
    logger.error("Secrets Dao Error ", error);
    throw error;
  }
}

async function getAllEnvironmentsSecrets(
  organizationName,
  RepoName,
  RepoId,
  accessToken
) {
  try {
    const repoEnvironments = await repoEnvironment.listRepoEnvironments(
      organizationName,
      RepoName,
      accessToken
    );
    const repositoryEnvironments = repoEnvironments.data.environments;
    console.log("repositoryEnvironments", repositoryEnvironments);
    const data = await repositoryEnvironments.map(async (environment) => {
      let EnvSecrets = {};
      let repoEnvSecrets = await listEnvironmentSecrets(
        RepoId,
        environment.name,
        accessToken
      );
      let environmentSecret = repoEnvSecrets.data;
      EnvSecrets = {
        environmentName: environment.name,
        environmentSecrets: environmentSecret.secrets,
      };
      return EnvSecrets;
    });

    let response = await Promise.all(data);
    return response;
  } catch (error) {
    logger.error("GetAllEnvironmentsSecrets", error);
    throw error;
  }
}

/**
 *
 * @param {Integer} repository_id
 * @param {String} environment_name
 * @param {String} accessToken
 * @param {object} headers
 *
 * @returns List of Environment secrets for a provided Environment_name of a given repository
 */
async function listEnvironmentSecrets(
  repository_id,
  environment_name,
  accessToken
) {
  if (!accessToken) return errorStatus.TNF;
  const octokit = await getConnection(accessToken);
  try {
    const EnvVariables = await octokit.actions.listEnvironmentSecrets({
      repository_id: repository_id,
      environment_name: environment_name,
      headers: {
        "X-GitHub-Api-Version": "2022-11-28",
      },
    });
    if (EnvVariables.status === statusCodes.SUCCESS) {
      return {
        success: true,
        data: EnvVariables.data,
      };
    } else {
      return {
        success: false,
        message: "Failed to retrieve environment variables.",
      };
    }
  } catch (error) {
    throw error;
  }
}

async function deleteEnvironmentSecret(
  accessToken,
  repositoryId,
  environmentName,
  secretName
) {
  try {
    if (!accessToken) return errorStatus.TNF;
    const octokit = await getConnection(accessToken);
    const deletedEnvSecret = await octokit.actions.deleteEnvironmentSecret({
      repository_id: repositoryId,
      environment_name: environmentName,
      secret_name: secretName,
      headers: {
        "X-GitHub-Api-Version": "2022-11-28",
      },
    });
    logger.log(
      "info",
      `Deleted Env Secret :  ${JSON.stringify(deletedEnvSecret)}`
    );
    return deletedEnvSecret;
  } catch (error) {
    logger.error("Delete environment secret error : ", error);
  }
}

module.exports.EnvironmentPublicKey = EnvironmentPublicKey;
module.exports.createorUpdateEnvironmentSecret =
  createorUpdateEnvironmentSecret;
module.exports.listEnvironmentSecrets = listEnvironmentSecrets;
module.exports.getAllEnvironmentsSecrets = getAllEnvironmentsSecrets;
module.exports.deleteEnvironmentSecret = deleteEnvironmentSecret;
