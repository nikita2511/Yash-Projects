const winston = require("winston");
const { createLogs } = require("../../../config/loggerConfig");
const todayDate = new Date().toDateString().replace(/\ /g, "");
const logConfiguration = createLogs("GitHub-Secrets-controller", todayDate);
const logger = winston.createLogger(logConfiguration);

const {
  responsHeader,
  statusCodes,
  errorStatus,
  errorMessages,
  successMessages,
} = require("../../../constants");

let response = {
  headers: responsHeader,
  body: {},
};

const secretDAO = require("../dao/dao");
/**


Retrieves the public key for a specific environment, required for secret encryption.
@param {*} req - The request object containing headers and query parameters.
@param {*} res - The response object used to send the result.
@returns The public key of the environment.
*/
module.exports.EnvironmentPublicKey = async (req, res) => {
  const bearerHeader = req.headers.authorization;
  const accessToken = bearerHeader && bearerHeader.split(" ")[1];
  const { repositoryId, environmentname } = req.query;

  try {
    //Environment Public key is necessary for the encryption of secrets
    const EnvPublicKey = await secretDAO.EnvironmentPublicKey(
      repositoryId,
      accessToken,
      environmentname
    );
    if (EnvPublicKey.hasOwnProperty("data")) {
      response.body = {
        EnvPublicKey: EnvPublicKey.data,
      };
      return res.status(statusCodes.SUCCESS).send(response);
    } else {
      throw new Error("Unable to get the Environment Public Key");
    }
  } catch (error) {
    logger.error("Error in GetEnvironmentPublicKey ", error);
    if (error.response.status) {
      response.body = {
        message: error.response.data.message,
      };
      res.status(error.response.status).send(response);
    } else {
      response.body = {
        message: error,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};

module.exports.getAllEnvironmentSecrets = async (req, res) => {
  const bearerHeader = req.headers.authorization;
  const accessToken = bearerHeader && bearerHeader.split(" ")[1];

  const { organizationName, RepoName, RepoId } = req.query;

  try {
    const result = await secretDAO.getAllEnvironmentsSecrets(
      organizationName,
      RepoName,
      RepoId,
      accessToken
    );
    if (result) {
      response.body = {
        result: result,
      };
      res.status(statusCodes.SUCCESS).send(response);
    } else {
      throw new Error("Unable to get ALL Environment Secrets");
    }
  } catch (error) {
    logger.error("Get ALL ENVIRONMENTs Secrets Controller....", error);
    if (error.response.status) {
      response.body = {
        message: error.response.data.message,
      };
      res.status(error.response.status).send(response);
    } else if (error.message) {
      response.body = {
        message: error.message,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    } else {
      response.body = {
        message: error,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};

/**

Creates or updates an environment secret.
@param {*} req - The request object containing headers and body parameters.
@param {*} res - The response object used to send the result.
@returns The created environment secret.
*/
module.exports.createorUpdateEnvironmentSecret = async (req, res) => {
  const bearerHeader = req.headers.authorization;
  const accessToken = bearerHeader && bearerHeader.split(" ")[1];

  const { organizationName, repositoryName, environmentName, secrets } =
    req.body;

  try {
    const createdEnvSecrets = await secretDAO.createorUpdateEnvironmentSecret(
      accessToken,
      organizationName,
      repositoryName,
      environmentName,
      secrets
    );
    if (!createdEnvSecrets) {
      response.body = { message: errorMessages.NVF };
      res.status(statusCodes.SUCCESS).send(response);
    } else if (createdEnvSecrets) {
      response.body = {
        createdEnvSecrets: true,
      };
      return res.status(statusCodes.SUCCESS).send(response);
    }
  } catch (error) {
    logger.error("Error in GetEnvironmentPublicKey ", error);
    if (error.response.status) {
      response.body = {
        message: error.response.data.message,
      };
      res.status(error.response.status).send(response);
    } else if (error.message) {
      response.body = {
        message: error.message,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    } else {
      response.body = {
        message: error,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};

/**

Lists environment secrets.
@param {Object} req - The request object containing headers and query parameters.
@param {Object} res - The response object used to send the result.
@returns The list of environment secrets.
*/
module.exports.listEnvironmentSecrets = async (req, res) => {
  const bearerHeader = req.headers.authorization;
  const accessToken = bearerHeader && bearerHeader.split(" ")[1];

  const { repository_id, environment_name } = req.query;

  try {
    const EnvironmentVariable = await secretDAO.listEnvironmentSecrets(
      repository_id,
      environment_name,
      accessToken
    );

    if (EnvironmentVariable.success) {
      response.body = {
        EnvironmentVariable: EnvironmentVariable.data,
      };
      res.status(statusCodes.SUCCESS).send(response);
    } else {
      response.body = {
        message: EnvironmentVariable.message,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  } catch (error) {
    logger.error(
      `Error in Github list Environment secrets controller : ${error}`
    );
    if (error.response.status) {
      response.body = {
        message: error.response.data.message,
      };
      res.status(error.response.status).send(response);
    } else if (error.message) {
      response.body = {
        message: error.message,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    } else {
      response.body = {
        message: error,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};

module.exports.deleteEnvSecret = async (req, res) => {
  const bearerHeader = req.headers.authorization;
  const accessToken = bearerHeader && bearerHeader.split(" ")[1];
  const { repositoryId, environmentName, secretName } = req.query;

  try {
    const deletedEnvSecret = await secretDAO.deleteEnvironmentSecret(
      accessToken,
      repositoryId,
      environmentName,
      secretName
    );

    logger.log(
      "info",
      `deleted env secret response : ${JSON.stringify(deletedEnvSecret)}`
    );
    if (deletedEnvSecret == errorStatus.TNF) {
      response.body = {
        message: errorMessages.TNF,
      };
      res.status(statusCodes.NOT_FOUND).send(response);
    }else if (!deletedEnvSecret) {
      response.body = {
        isSecretDeleted: false,
        message : errorMessages.NVF
      };
      res.status(statusCodes.NOT_FOUND).send(response);
    } else if (deletedEnvSecret.status == statusCodes.NO_CONTENT) {
      response.body = {
        isSecretDeleted: true,
      };
      res.status(statusCodes.SUCCESS).send(response);
    }
  } catch (error) {
    logger.error(
      `Error in Github delete environment secret controller : ${error}`
    );
    if (error.response.status) {
      response.body = {
        message: error.response.data.message,
      };
      res.status(error.response.status).send(response);
    } else if (error.message) {
      response.body = {
        message: error.message,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    } else {
      response.body = {
        message: error,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};
