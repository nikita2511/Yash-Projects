const express = require("express");
const router = express.Router();
const controller = require("../controller/controller");

// router.get("/", controller.EnvironmentPublicKey);
router.post("/",controller.createorUpdateEnvironmentSecret);
router.get("/",controller.listEnvironmentSecrets);
router.get("/envSecrets",controller.getAllEnvironmentSecrets);
router.delete("/",controller.deleteEnvSecret);

module.exports = router;
