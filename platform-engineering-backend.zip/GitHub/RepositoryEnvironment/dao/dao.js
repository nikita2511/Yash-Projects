const winston = require("winston");
const { createLogs } = require("../../../config/loggerConfig");
const todayDate = new Date().toDateString().replace(/\ /g, "");
const logConfiguration = createLogs(
  "github-RepositoryEnvironment-dao",
  todayDate
);
const logger = winston.createLogger(logConfiguration);
const { getConnection } = require("../../../config/githubConnection");

const {
  errorStatus,
  errorMessages,
  statusCodes,
} = require("../../../constants");
const { header } = require("express-validator");

/**
 * Create or update a repository environment.
 *
 * @param {string} organizationName - The name of the organization.
 * @param {string} accessToken - The access token for authentication.
 * @param {string} repositoryName - The name of the repository.
 * @param {string} environment_name - The name of the environment.
 * @param {number} wait_timer - The wait timer value.
 * @param {Array<string>} reviewers - The array of reviewers.
 * @param {string} deployment_branch_policy - The deployment branch policy.
 * @param {object} headers - The headers object.
 * @returns {object} - The created or updated repository environment data.
 *
 * scope used repo
 */
async function createRepoEnvironment(
  organizationName,
  accessToken,
  repositoryName,
  environment_name
) {
  try {
    if (!accessToken) {
      throw new Error("Access token is missing");
    }

    const octokit = await getConnection(accessToken); // Assuming getConnection returns the Octokit instance

    const repoEnvironment = await octokit.repos.createOrUpdateEnvironment({
      owner: organizationName,
      repo: repositoryName,
      environment_name: environment_name,
      headers: {
        "X-GitHub-Api-Version": "2022-11-28",
      },
    });
    // Check the status code of the repoEnvironment response
    if (repoEnvironment.status === statusCodes.SUCCESS) {
      return repoEnvironment;
    } else {
      throw new Error("Failed to create or update repository environment");
    }
  } catch (error) {
    throw error;
  }
}

/**
 *
 * @param {String} repository_name
 * @param {String} organization_name
 * @param {String} accessToken
 * scope used = repo
 *
 *
 * @returns List of Environments for a provided Repository in the given organization
 */
async function listRepoEnvironments(
  organizationName,
  repositoryName,
  accessToken
) {
  if (!accessToken) return errorStatus.TNF;
  const octokit = await getConnection(accessToken);
  try {
    const Environements = await octokit.repos.getAllEnvironments({
      owner: organizationName,
      repo: repositoryName,
      headers: {
        "X-GitHub-Api-Version": "2022-11-28",
      },
    });
    if (Environements.status === statusCodes.SUCCESS) {
      return {
        success: true,
        data: Environements.data,
      };
    } else {
      return {
        success: false,
        message: "Failed to retrieve environment variables.",
      };
    }
  } catch (error) {
    throw error;
  }
}

/**
 *
 * @param {String} organization_name
 * @param {String} repository_name
 * @param {String} environment_name
 * @param {String} accessToken
 * scope used = repo
 *
 *
 * @returns a particular environment details
 */
async function getRepoEnvironment(
  organizationName,
  repositoryName,
  EnvironmentName,
  accessToken
) {
  if (!accessToken) return errorStatus.TNF;
  const octokit = await getConnection(accessToken);
  try {
    const Environment = await octokit.repos.getEnvironment({
      owner: organizationName,
      repo: repositoryName,
      environment_name: EnvironmentName,
      headers: {
        "X-GitHub-Api-Version": "2022-11-28",
      },
    });
    if (Environment.status === statusCodes.SUCCESS) {
      return {
        success: true,
        data: Environment.data,
      };
    } else {
      return {
        success: false,
        message: "Failed to retrieve environment variables.",
      };
    }
  } catch (error) {
    throw error;
  }
}

module.exports.createRepoEnvironment = createRepoEnvironment;
module.exports.listRepoEnvironments = listRepoEnvironments;
module.exports.getRepoEnvironment = getRepoEnvironment;
