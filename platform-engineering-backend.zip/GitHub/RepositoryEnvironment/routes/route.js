const express = require("express");
const router = express.Router();
const controller = require("../controller/controller");

//Creates a repoEnvironment
router.post("/", controller.createRepoEnvironment);

//list all the environment available for repository
router.get("/", controller.listRepoEnvironment);

// get details of a particular environment in a repository
router.get("/env", controller.getRepoEnvironment);

module.exports = router;
