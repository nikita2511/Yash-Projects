const winston = require("winston");
const { createLogs } = require("../../../config/loggerConfig");
const todayDate = new Date().toDateString().replace(/\ /g, "");
const logConfiguration = createLogs(
  "GitHub-RepositoryEnvironment-controller",
  todayDate
);
const logger = winston.createLogger(logConfiguration);

const {
  responsHeader,
  statusCodes,
  errorStatus,
  errorMessages,
  successMessages,
} = require("../../../constants");

let response = {
  headers: responsHeader,
  body: {},
};

const repoEnvDAO = require("../dao/dao");

/**
 * Create a repository environment.
 *
 * @param {object} req - The request object containing the following parameters:
 *   - organizationName: The name of the organization.
 *   - repositoryName: The name of the repository.
 *   - environment_name: The name of the environment.
 *   - wait_timer: The wait timer value.
 *   - reviewers: The reviewers array.
 *   - deployment_branch_policy: The deployment branch policy.
 *
 * @param {object} res - The response object.
 * @returns {object} - The created repository environment data.
 */
module.exports.createRepoEnvironment = async (req, res) => {
  const bearerHeader = req.headers.authorization;
  const accessToken = bearerHeader && bearerHeader.split(" ")[1];

  const {
    organizationName,
    repositoryName,
    environment_name,
  } = req.body;

  try {
    const repoEnvironment = await repoEnvDAO.createRepoEnvironment(
      organizationName,
      accessToken,
      repositoryName,
      environment_name,
    );
    if (
      repoEnvironment.status === statusCodes.SUCCESS &&
      repoEnvironment.hasOwnProperty("data")
    ) {
      response.body = {
        repoEnvironment: repoEnvironment.data,
      };
      return res.status(statusCodes.CREATED).send(response);
    } else {
      throw new Error("Unable to create Repository Environment!");
    }
  } catch (error) {
    logger.error(`Error in Github create Environment controller : ${error}`);
    if (error.response.status) {
      response.body = {
        message: error.response.data.message,
      };
      res.status(error.response.status).send(response);
    } else if (error.message) {
      response.body = {
        message: error.message,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    } else {
      response.body = {
        message: error.message,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};

/**
 * Lists repository environment.
 *
 * @param {object} req - The request object containing the following parameters:
 *   - organizationName: The name of the organization.
 *   - repositoryName: The name of the repository.
 *
 * @param {object} res - The response object.
 * @returns {object} - The created repository environment data.
 */
module.exports.listRepoEnvironment = async (req, res) => {
  const bearerHeader = req.headers.authorization;
  const accessToken = bearerHeader && bearerHeader.split(" ")[1];

  const { organizationName, RepoName } = req.query;
  try {
    const EnvironmentList = await repoEnvDAO.listRepoEnvironments(
      organizationName,
      RepoName,
      accessToken
    );
    if (EnvironmentList.success && EnvironmentList.hasOwnProperty("data")) {
      response.body = {
        EnvironmentList: EnvironmentList.data.environments,
      };
      res.status(statusCodes.SUCCESS).send(response);
    } else {
      response.body = {
        message: EnvironmentList.message,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  } catch (error) {
    logger.error(`Error in Github create Environment controller : ${error}`);
    if (error.response.status) {
      response.body = {
        message: error.response.data.message,
      };
      res.status(error.response.status).send(response);
    } else if (error.message) {
      response.body = {
        message: error.message,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    } else {
      response.body = {
        message: error,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};

/**
 * Get repository environment.
 *
 * @param {object} req - The request object containing the following parameters:
 *   - organizationName: The name of the organization.
 *   - repositoryName: The name of the repository.
 *   = environmentName : The name of the environment
 *
 * @param {object} res - The response object.
 * @returns {object} - Repository Environment Information
 */

module.exports.getRepoEnvironment = async (req, res) => {
  const bearerHeader = req.headers.authorization;
  const accessToken = bearerHeader && bearerHeader.split(" ")[1];

  const { organizationName, RepoName, EnvironmentName } = req.query;
  try {
    const Environment = await repoEnvDAO.getRepoEnvironment(
      organizationName,
      RepoName,
      EnvironmentName,
      accessToken
    );
    if (Environment.success && Environment.hasOwnProperty("data")) {
      response.body = {
        Environment: Environment.data,
      };
      res.status(statusCodes.SUCCESS).send(response);
    } else {
      response.body = {
        message: Environment.message,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  } catch (error) {
    logger.error(`Error in Github create Environment controller : ${error}`);
    if (error.response.status) {
      response.body = {
        message: error.response.data.message,
      };
      res.status(error.response.status).send(response);
    } else if (error.message) {
      response.body = {
        message: error.message,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    } else {
      response.body = {
        message: error,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};
