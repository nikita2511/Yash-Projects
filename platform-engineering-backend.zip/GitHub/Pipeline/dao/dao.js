const winston = require("winston");
const { createLogs } = require("../../../config/loggerConfig");
const todayDate = new Date().toDateString().replace(/\ /g, "");
const logConfiguration = createLogs("github-Pipeline-dao", todayDate);
const logger = winston.createLogger(logConfiguration);
const jsonToYml = require("js-yaml");
const YAML = require("yaml");
const builder = require("xml2js").Builder;
const { execSync } = require("child_process");
const fs = require("fs");
const path = require("path");
const base64 = require("base-64");
const axios = require("axios");

const { getConnection } = require("../../../config/githubConnection");
const orgRuleDAO = require("../../../OrganizationRules/Rules/dao/dao");
const repositoryDAO = require("../../Repository/dao/dao");
const branchDAO = require("../../Branches/dao/dao");
const {
  createPullRequest,
  addReviewersToPullRequest,
} = require("../../PullRequest/dao/dao");

const {
  errorStatus,
  errorMessages,
  statusCodes,
} = require("../../../constants");

const {
  YMLConfigBuildTasks,
  YMLConfigDeploymentTasks,
} = require("../../github-library");
const { sourceCodeLibrary } = require("../../../sourceCodeLibrary");
// const deepCopy = require("lodash.clonedeep");

/**
 *This method is reponsible for converting
 *
 * @param {String} ymlJsonObject
 * @returns YML content
 */
async function createYMLfromJson(ymlJsonObject) {
  // try catch block to handle errors
  try {
    // log the message to the logger
    logger.log(
      "info",
      `inside createYMLfromJson ${JSON.stringify(ymlJsonObject)}`
    );
    // check if the ymlJsonObject is not null
    if (!ymlJsonObject) {
      // log the message to the logger
      logger.log("info", "Json object not found");
      // return the error message
      return "YML_JSON_OBJECT_NOT_FOUND";
    } else {
      let data = jsonToYml.dump(ymlJsonObject, {
        noRefs: true,
        noCompatMode: true,
      });
      logger.log("info", data);
      // return the data
      return data;
    }
  } catch (error) {
    // log the error to the logger
    logger.error("createYMLfromJson error", error);
    // throw the error
    throw error;
  }
}

/**
 * This function is reponsible to prepare and commit YML configuration code
 *
 * @param {String} organizationName
 * @param {String} applicationType
 * @param {String} publishArtifacts
 * @returns boolean value for complete operation and failure
 */
async function prepareYMLConfigurationCode(
  accessToken,
  repositoryName,
  name,
  organizationName,
  applicationType,
  publishArtifacts,
  toBeDeployed,
  deploymentEnvironments,
  existingPipeline
) {
  // Create an empty object to store the yml configuration
  let YMLJsonObject = {
    name: "",
    on: {
      push: {
        branches: [],
      },
    },
    env: null,
    jobs: {
      build: {
        "runs-on": "",
        steps: [],
      },
    },
  };

  let sha = null,
    environmentVariablesArray = [],
    dependentJob = "build";
  var YMLBuildConfigJSON;
  var YMLdeploymentTasks;

  if (!existingPipeline) {
    // Get the project creation rules for the given organization
    const organizationRule = await orgRuleDAO.getOrganizationRules(
      organizationName,
      "Github"
    );
    // Add all the branches from the project creation rules to the trigger list
    for (let branch of organizationRule.branchingModel.branches) {
      YMLJsonObject.on.push.branches.push(branch.name);
    }
    YMLBuildConfigJSON = YMLConfigBuildTasks.find((element) => {
      return element.key == applicationType;
    });


    YMLJsonObject.jobs.build.steps = JSON.parse(
      JSON.stringify(YMLBuildConfigJSON.steps)
    );

    YMLJsonObject.name = name;
    YMLJsonObject.jobs.build["runs-on"] = YMLBuildConfigJSON["runs-on"];
    logger.log("info", `ymlJsonObject : ${JSON.stringify(YMLJsonObject)}`);
    if (!publishArtifacts) {
      logger.log("info", `Removing publish artifact step`);
      const publistArtifactsStep = YMLJsonObject.jobs.build.steps.find(
        (element) => {
          return element.name == "Publish Artifacts";
        }
      );
      YMLJsonObject.jobs.build.steps.pop(publistArtifactsStep);
    }
  } else {
    const path = `.github/workflows/${applicationType}-github-pipelines.yml`;
    const response = await axios.get(
      `https://api.github.com/repos/${organizationName}/${repositoryName}/contents/${path}?`,
      {
        headers: {
          Authorization: `Bearer ${accessToken}`,
          "Content-Type": "application/vnd.github.v3+json",
        },
      }
    );
    const base64String = response.data.content;
    sha = response.data.sha;
    base64String.replace("\n", "");
    const bytes = base64.decode(base64String);
    logger.log("info", `Decoded content : ${bytes}`);
    const { name, on, jobs } = jsonToYml.load(bytes);
    YMLJsonObject = {
      name: name,
      on: on,
      env: null,
      jobs: jobs,
    };
    logger.log("info", `ymlJsonObject : ${JSON.stringify(YMLJsonObject)}`);
  }

  if (toBeDeployed) {
    const deploymentPlatform = deploymentEnvironments[0].platformToDeploy;
    YMLdeploymentTasks = YMLConfigDeploymentTasks.find((type) => {
      return type.platform === deploymentPlatform;
    });

    //Adding environment variables object in the array
    environmentVariablesArray = Object.keys(YMLdeploymentTasks.env_variables);
    //Finding and adding build steps
    let buildSteps = YMLdeploymentTasks.steps.find((type) => {
      return type.key == "build";
    });
    if (buildSteps) {
      for (const element of buildSteps.value) {
        YMLJsonObject.jobs.build.steps.push(element);
      }
    }
    //Adding env variables to object
    YMLJsonObject.env = YMLdeploymentTasks.env_variables;

    //Finding deploy steps for given deployment platform
    const deploySteps = YMLdeploymentTasks.steps.find((type) => {
      return type.key === "deploy";
    });
    // Initialize the flag variable outside the loop
    for (const environmentObject of deploymentEnvironments) {
      const deployName = `DeployOn${environmentObject.environment}`;
      YMLJsonObject.jobs[deployName] = {
        name: environmentObject.environment,
        "runs-on": YMLBuildConfigJSON["runs-on"],
        environment: environmentObject.environment,
        needs: dependentJob,
        steps: [],
      };
      if (deploySteps) {
        for (const element of deploySteps.value) {
          YMLJsonObject.jobs[deployName].steps.push(element);
        }
      }
      dependentJob = deployName;
    }
  } else {
    delete YMLJsonObject.env;
  }
  logger.log("info", `ymlJsonObject : ${JSON.stringify(YMLJsonObject)}`);
  let data = await createYMLfromJson(YMLJsonObject);
  YMLJsonObject.jobs.build.steps = [];
  return { data, sha, environmentVariablesArray };
}

/**
 * This method is reponsible for prepare java code
 *
 * @param {String} accessToken
 * @param {String} organizationName
 * @param {String} repositoryName
 * @param {String} ref
 * @returns boolean value for complete operation and failure
 */
async function prepareSourceSkeletonCode(
  accessToken,
  organizationName,
  repositoryName,
  ref,
  applicationType
) {
  // This function prepares the Java source skeleton code.
  try {
    logger.log("info", "inside prepareSourceSkeletonCode ");
    const sourceCodeFiles = sourceCodeLibrary.find(
      (type) => type.key === applicationType
    );
    let changesOfSourceCode = [];
    for (const file of sourceCodeFiles.sourceCode) {
      changesOfSourceCode.push({
        content: file.content,
        path: file.path,
      });
    }
    let commitedCodeArr = [];
    for (let index = 0; index < changesOfSourceCode.length; index++) {
      let createdCommit = await createCommit(
        accessToken,
        organizationName,
        repositoryName,
        changesOfSourceCode[index].content,
        changesOfSourceCode[index].path,
        ref
      );
      commitedCodeArr.push(createdCommit);
    }
    if (commitedCodeArr.length) {
      return true;
    }
  } catch (error) {
    logger.error("Prepare  Skeleton Code Error", error);
  }
}
/**
 * This method is responsible for creating pipeline in github with given application type
 *
 * @param {String} accessToken
 * @param {String} organizationName
 * @param {String} repositoryName
 * @param {String} applicationType
 * @param {String} reviewers
 * @param {String} userNameInitials
 * @param {String} publishArtifacts
 * @returns created pipeline boolean
 */
async function createPipeline(
  accessToken,
  organizationName,
  repositoryName,
  name,
  applicationType,
  publishArtifacts,
  toBeDeployed,
  deploymentEnvironments,
  userNameInitials,
  reviewers,
  existingPipeline
) {
  if (!accessToken) return errorStatus.TNF;
  try {
    var response = {},
      committedSkeletonCode = false;
    const preparedYMLConfiguration = await prepareYMLConfigurationCode(
      accessToken,
      repositoryName,
      name,
      organizationName,
      applicationType,
      publishArtifacts,
      toBeDeployed,
      deploymentEnvironments,
      existingPipeline
    );
    // listToCreateBlobs.push(preparedYMLConfiguration);
    const repository = await repositoryDAO.getRepository(
      accessToken,
      organizationName,
      repositoryName
    );
    const sourceBranchName = repository.default_branch;
    const uid =
      new Date().toISOString().replace(/:/g, ".") +
      Math.random().toString().substring(2, 7);
    const targetBranchName = `${"feature-" + userNameInitials + uid}`;
    const createdBranch = await branchDAO.createBranch(
      accessToken,
      organizationName,
      repositoryName,
      sourceBranchName,
      targetBranchName
    );
    logger.log("info", `created branch : ${JSON.stringify(createdBranch)}`);
    if (createdBranch) {
      let splittedRef = createdBranch.ref.split("refs/heads/")[1];
      const ref = splittedRef;
      let path = `.github/workflows/${
        applicationType + "-github-pipelines.yml"
      }`;
      let { data, sha } = preparedYMLConfiguration;
      let createdCommitForYML = await createCommit(
        accessToken,
        organizationName,
        repositoryName,
        data,
        path,
        ref,
        sha
      );
      if (createdCommitForYML) {
        response.createdCommitForYML = true;
        let createPRAndAddReviewersResponse = await createPRAndAddReviewers(
          accessToken,
          organizationName,
          repositoryName,
          sourceBranchName,
          targetBranchName,
          reviewers
        );
        response.createdPullRequest =
          createPRAndAddReviewersResponse.createdPullRequest;
        response.addedReviewersToPRResponse =
          createPRAndAddReviewersResponse.addedReviewersToPRResponse;
        response.environmentVariables =
          preparedYMLConfiguration.environmentVariablesArray;
        if (!existingPipeline) {
          // switch (applicationType) {
          //   case "java":
          //     committedSkeletonCode = await prepareJavaSourceSkeletonCode(
          //       accessToken,
          //       organizationName,
          //       repositoryName,
          //       ref
          //     );
          //     break;
          //   case "dotNet":
          //     committedSkeletonCode = await prepareDotnetSourceSkeletonCode(
          //       accessToken,
          //       organizationName,
          //       repositoryName,
          //       ref
          //     );
          //     break;
          //   default:
          //     break;
          // }
          committedSkeletonCode = await prepareSourceSkeletonCode(
            accessToken,
            organizationName,
            repositoryName,
            ref,
            applicationType
          );
        }
        if (committedSkeletonCode) {
          response.committedSkeletonCode = true;
        } else {
          response.committedSkeletonCode = false;
        }
      } else {
        response.createdCommitForYML = false;
      }
      return response;
    }
    throw {
      message: errorMessages.ECB,
      statusCode: statusCodes.BAD_REQUEST,
    };
  } catch (error) {
    logger.error("createPipeline error ", error);
    throw error;
  }
}

/**
 *This method is responsible for creating commit to repo
 *
 * @param {String} accessToken
 * @param {String} organizationName
 * @param {String} repositoryName
 * @param {String} content
 * @param {String} path
 * @param {String} branch
 * @returns returns status of the commit
 */
async function createCommit(
  accessToken,
  organizationName,
  repositoryName,
  content,
  path,
  branch,
  sha
) {
  if (!accessToken) return errorStatus.TNF;
  try {
    const octokit = await getConnection(accessToken);

    let commitedCode = await octokit.repos.createOrUpdateFileContents({
      owner: organizationName,
      repo: repositoryName,
      path: path,
      message: `Add code`,
      content: Buffer.from(content).toString("base64"),
      branch: branch,
      sha: sha,
    });
    return commitedCode;
  } catch (error) {
    logger.error("create source file error ", error);
    throw error;
  }
}

/**
 * Function to create DotnetSourceSkeletonCode
 * @param {String} accessToken ,
 * @param {String} organizationName
 * @param {String} repositoryName
 * @returns Dotnet Skeleton Code reponse or error
 */
// async function prepareDotnetSourceSkeletonCode(
//   accessToken,
//   organizationName,
//   repositoryName,
//   ref
// ) {
//   try {
//     logger.log("info", "inside prepareDotnetSourceSkeletonCode ");
//     const dotNetConfigJson = sourceCodeLibrary.find(
//       (type) => type.key === "dotNet"
//     );

//     let changesOfDotNetSourceCode = [];

//     for (const file of dotNetConfigJson.sourceCode) {
//       changesOfDotNetSourceCode.push({
//         content: file.content,
//         path: file.path,
//       });
//     }

//     let commitedCodeArr = [];
//     for (let index = 0; index < changesOfDotNetSourceCode.length; index++) {
//       let createdCommit = await createCommit(
//         accessToken,
//         organizationName,
//         repositoryName,
//         changesOfDotNetSourceCode[index].content,
//         changesOfDotNetSourceCode[index].path,
//         ref
//       );
//       commitedCodeArr.push(createdCommit);
//     }
//     if (commitedCodeArr.length === changesOfDotNetSourceCode.length) {
//       return true;
//     }
//   } catch (error) {
//     logger.error("Prepare Dot Net skeleton code Error ", error);
//     throw error;
//   }
// }




/**
 * This method is responsible for
 *
 * @param {String} accessToken
 * @param {String} organizationName
 * @param {String} repository
 * @returns list of available pipelines
 */
async function getPipelines(accessToken, organizationName, repository) {
  try {
    const octokit = await getConnection(accessToken);
    const pipelines = await octokit.actions.listRepoWorkflows({
      owner: organizationName,
      repo: repository,
      headers: {
        "X-GitHub-Api-Version": "2022-11-28",
      },
    });
    if (pipelines) {
      return pipelines;
    }
  } catch (error) {
    logger.error(`Error from github get repositories dao : ${error}`);
    throw error;
  }
}
async function createPRAndAddReviewers(
  accessToken,
  organizationName,
  repositoryName,
  sourceBranchName,
  targetBranchName,
  reviewers
) {
  try {
    let response = {};
    const createdPullRequest = await createPullRequest(
      accessToken,
      organizationName,
      repositoryName,
      sourceBranchName,
      targetBranchName
    );
    if (createdPullRequest) {
      response.createdPullRequest = true;
      var addedReviewersToPRResponse = await addReviewersToPullRequest(
        accessToken,
        organizationName,
        repositoryName,
        createdPullRequest.number,
        reviewers
      );
    } else {
      response.createdPullRequest = false;
    }
    if (addedReviewersToPRResponse) {
      response.addedReviewersToPRResponse = true;
    } else {
      response.addedReviewersToPRResponse = false;
    }
    return response;
  } catch (error) {
    logger.error(`Error from github createPRAndAddReviewers dao : ${error}`);
    throw error;
  }
}

module.exports.createPipeline = createPipeline;
module.exports.getPipelines = getPipelines;
