const express = require("express");
const router = express.Router();
const controller = require("../controller/controller");

//Creates a repository
router.post("/", controller.createPipeline);
router.get("/", controller.getPipelines);
module.exports = router;
