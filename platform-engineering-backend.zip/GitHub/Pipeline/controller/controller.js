const winston = require("winston");
const { createLogs } = require("../../../config/loggerConfig");
const todayDate = new Date().toDateString().replace(/\ /g, "");
const logConfiguration = createLogs("GitHub-Pipeline-controller", todayDate);
const logger = winston.createLogger(logConfiguration);

const pipleineDAO = require("../dao/dao");

const {
  responsHeader,
  statusCodes,
  errorStatus,
  errorMessages,
} = require("../../../constants");

let response = {
  headers: responsHeader,
  body: {},
};

/**
 *The handler function to create piepline
 *
 * @param {object} req
 * @param {object} res
 * @returns success response or an error object.
 */
module.exports.createPipeline = async (req, res) => {
  const bearerHeader = req.headers.authorization;
  const accessToken = bearerHeader && bearerHeader.split(" ")[1];
  const {
    organizationName,
    repositoryName,
    name,
    applicationType,
    publishArtifacts,
    toBeDeployed,
    deploymentEnvironments,
    usernameInitials,
    reviewers,
    existingPipeline
  } = req.body;

  try {
    const createdSourceFiles = await pipleineDAO.createPipeline(
      accessToken,
      organizationName,
      repositoryName,
      name,
      applicationType,
      publishArtifacts,
      toBeDeployed,
      deploymentEnvironments,
      usernameInitials,
      reviewers,
      existingPipeline
    );
    if (createdSourceFiles == errorStatus.TNF) {
      response.body = {
        message: errorMessages.TNF,
      };
      res.status(statusCodes.BAD_REQUEST).send(response);
    } else if (createdSourceFiles) {
      response.body = {
        createdSourceFiles: createdSourceFiles,
      };
      res.status(statusCodes.SUCCESS).send(response);
    }
  } catch (error) {
    logger.error(`Error in Github create repository controller : ${error}`);
    if (error.response.status) {
      response.body = {
        message: error.response.data.message,
      };
      res.status(error.response.status).send(response);
    } else {
      response.body = {
        message: error,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};
/**
 * The handler function to list pieplines
 *
 * @param {object} req
 * @param {object} res
 * @returns array of the pipelines ot error object
 */
module.exports.getPipelines = async (req, res) => {
  const bearerHeader = req.headers.authorization;
  const accessToken = bearerHeader && bearerHeader.split(" ")[1];
  const organizationName = req.query.organizationName;
  const repository = req.query.repository;
  try {
    const pipelines = await pipleineDAO.getPipelines(
      accessToken,
      organizationName,
      repository
    );
    logger.log("info", `pipelines : ${JSON.stringify(pipelines)}`);
    if (pipelines) {
      response.body = {
        pipelines: pipelines.data,
      };
      res.status(statusCodes.SUCCESS).send(response);
    }
  } catch (error) {
    logger.error(`Error in Github get pipelines controller : ${error}`);
    if (error.response.status) {
      response.body = {
        message: error.response.data.message,
      };
      res.status(error.response.status).send(response);
    } else {
      response.body = {
        message: error,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};
