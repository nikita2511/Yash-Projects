const YMLConfigBuildTasks = [
  {
    key: "java",
    steps: [
      {
        name: "actions/checkout@v2",
        uses: "actions/checkout@v2",
      },
      {
        name: "Setup JDK 1.8",
        uses: "actions/setup-java@v1",
        with: {
          distribution: "corretto",
          "java-version": 1.8,
        },
      },
      {
        name: "Install Maven",
        run: "#sudo yum install -y maven\nsudo apt-get update && sudo apt-get install -y maven\n",
      },
      {
        name: "Build Maven",
        run: "mvn -B package --file pom.xml",
      },
      {
        name: "Publish Artifacts",
        uses: "actions/upload-artifact@v2",
        with: {
          path: "${{ github.workspace }}",
          name: "drop",
        },
      },
    ],
    "runs-on": "ubuntu-latest",
  },
  {
    key: "dotNet",
    steps: [
      {
        name: "actions/checkout@v2",
        uses: "actions/checkout@v2",
      },
      {
        name: "Restore",
        run: "dotnet restore MySolution.sln",
      },
      {
        name: "Build",
        run: "dotnet build MySolution.sln --configuration Release",
      },
      {
        name: "Publish Artifacts",
        uses: "actions/upload-artifact@v2",
        with: {
          path: "${{ github.workspace }}",
          name: "drop",
        },
      },
    ],
    "runs-on": "ubuntu-latest",
  },
];

const YMLConfigDeploymentTasks = [
  {
    platform: "EKS",
    steps: [
      {
        key: "build",
        value: [
          {
            name: "Login to Amazon ECR",
            id: "login-ecr",
            uses: "aws-actions/amazon-ecr-login@aaf69d68aa3fb14c1d5a6be9ac61fe15b48453a2",
          },
          {
            name: "Build, tag, and push image to Amazon ECR",
            id: "build-image",
            env: {
              ECR_REGISTRY: "${{ steps.login-ecr.outputs.registry }}",
              IMAGE_TAG: "${{ github.sha }}",
            },
            run: `# Build a docker container and\n# push it to ECR so that it can\n# be deployed to ECS.\nls\npwd\ndocker build -t $ECR_REGISTRY/$ECR_REPOSITORY:$IMAGE_TAG .\ndocker push $ECR_REGISTRY/$ECR_REPOSITORY:$IMAGE_TAG\necho "::set-output name=image::$ECR_REGISTRY/$ECR_REPOSITORY:$IMAGE_TAG"\n`,
          },
        ],
      },
      {
        key: "deploy",
        value: [
          {
            name: "Fill in the new image ID in the Amazon ECS task definition",
            id: "task-def",
            uses: "aws-actions/amazon-ecs-render-task-definition@97587c9d45a4930bf0e3da8dd2feb2a463cf4a3a",
            with: {
              "task-definition": "${{ env.ECS_TASK_DEFINITION }}",
              "container-name": "${{ env.CONTAINER_NAME }}",
              image: "${{ steps.build-image.outputs.image }}",
            },
          },
          {
            name: "Deploy Amazon ECS task definition",
            uses: "aws-actions/amazon-ecs-deploy-task-definition@de0132cf8cdedb79975c6d42b77eb7ea193cf28e",
            with: {
              "task-definition":
                "${{ steps.task-def.outputs.task-definition }}",
              service: "${{ env.ECS_SERVICE }}",
              cluster: "${{ env.ECS_CLUSTER }}",
              "wait-for-service-stability": true,
            },
          },
        ],
      },
    ],
    env_variables: {
      AWS_REGION: "${{ vars.AWS_REGION }}",
      ECR_REPOSITORY: "${{ vars.ECR_REPOSITORY }}",
      ECS_SERVICE: "${{ vars.ECS_SERVICE }}",
      ECS_CLUSTER: "${{ vars.ECS_CLUSTER }}",
      ECS_TASK_DEFINITION: "${{ vars.ECS_TASK_DEFINITION }}",
      CONTAINER_NAME: "${{ vars.CONTAINER_NAME }}",
    },
  },
  {
    platform: "ECS",
    steps: [
      {
        key: "build",
        value: [
          {
            name: "Login to Amazon ECR",
            id: "login-ecr",
            uses: "aws-actions/amazon-ecr-login@aaf69d68aa3fb14c1d5a6be9ac61fe15b48453a2",
          },
          {
            name: "Build, tag, and push image to Amazon ECR",
            id: "build-image",
            env: {
              ECR_REGISTRY: "${{ steps.login-ecr.outputs.registry }}",
              IMAGE_TAG: "${{ github.sha }}",
            },
            run: '# Build a docker container and\n# push it to ECR so that it can\n# be deployed to ECS.\nls\npwd\ndocker build -t $ECR_REGISTRY/$ECR_REPOSITORY:$IMAGE_TAG .\ndocker push $ECR_REGISTRY/$ECR_REPOSITORY:$IMAGE_TAG\necho "::set-output name=image::$ECR_REGISTRY/$ECR_REPOSITORY:$IMAGE_TAG"\n',
          },
        ],
      },
      {
        key: "deploy",
        value: [
          {
            name: "Fill in the new image ID in the Amazon ECS task definition",
            id: "task-def",
            uses: "aws-actions/amazon-ecs-render-task-definition@97587c9d45a4930bf0e3da8dd2feb2a463cf4a3a",
            with: {
              "task-definition": "${{ env.ECS_TASK_DEFINITION }}",
              "container-name": "${{ env.CONTAINER_NAME }}",
              image: "${{ steps.build-image.outputs.image }}",
            },
          },
          {
            name: "Deploy Amazon ECS task definition",
            uses: "aws-actions/amazon-ecs-deploy-task-definition@de0132cf8cdedb79975c6d42b77eb7ea193cf28e",
            with: {
              "task-definition":
                "${{ steps.task-def.outputs.task-definition }}",
              service: "${{ env.ECS_SERVICE }}",
              cluster: "${{ env.ECS_CLUSTER }}",
              "wait-for-service-stability": true,
            },
          },
        ],
      },
    ],
    env_variables: {
      AWS_REGION: "${{ vars.AWS_REGION }}",
      ECR_REPOSITORY: "${{ vars.ECR_REPOSITORY }}",
      ECS_SERVICE: "${{ vars.ECS_SERVICE }}",
      ECS_CLUSTER: "${{ vars.ECS_CLUSTER }}",
      ECS_TASK_DEFINITION: "${{ vars.ECS_TASK_DEFINITION }}",
      CONTAINER_NAME: "${{ vars.CONTAINER_NAME }}",
    },
  },
  {
    platform: "TOMCAT",

    steps: [
      {
        key: "build",
        value: [
          {
            name: "Archive WAR file",
            uses: "actions/upload-artifact@v2",
            with: {
              name: "myproject-war",
              path: "${{ github.workspace }}/target/java-hello-world.war",
            },
          },
          {
            name: "Print GitHub Actions workspace path",
            run: 'echo "GitHub Actions workspace path: $GITHUB_WORKSPACE"\ncd $GITHUB_WORKSPACE/target\nls\n',
          },
          {
            name: "Verify JAR file",
            run: 'JAR_FILE="${{ github.workspace }}/target/java-hello-world.war"\necho "JAR file path: $JAR_FILE"\nls -l "$JAR_FILE"\n',
          },
          {
            name: "Modify JAR file permissions",
            run: 'chmod +rw "${{ github.workspace }}/target/java-hello-world.war"',
          },
        ],
      },
      {
        key: "deploy",
        value: [
          {
            name: "Download WAR artifact",
            uses: "actions/download-artifact@v2",
            with: {
              name: "myproject-war",
              path: "${{ github.workspace }}/target",
            },
          },
          {
            name: "Deploy to Tomcat",
            run: 'curl -T "${{ github.workspace }}/target/java-hello-world.war" "http://${{env.TOMCAT_HOST}}/manager/text/deploy?path=/${{env.CONTEXT_PATH}}&update=true" \\\n--user "${{env.TOMCAT_USERNAME}}:${{env.TOMCAT_PASSWORD}}"\n',
          },
        ],
      },
    ],
    env_variables: {
      TOMCAT_HOST: "${{ vars.TOMCAT_HOST }}",
      TOMCAT_USERNAME: "${{ vars.TOMCAT_USERNAME }}",
      TOMCAT_PASSWORD: "${{ vars.TOMCAT_PASSWORD }}",
      CONTEXT_PATH: "${{ vars.CONTEXT_PATH }}",
    },
  },
];

module.exports = { YMLConfigBuildTasks, YMLConfigDeploymentTasks };
