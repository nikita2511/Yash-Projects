const winston = require("winston");
const { createLogs } = require("../../../config/loggerConfig");
const todayDate = new Date().toDateString().replace(/\ /g, "");
const logConfiguration = createLogs(
  "GitHub-repository-collaboraotrs-controller",
  todayDate
);
const logger = winston.createLogger(logConfiguration);

const repositoryCollaboratorsDAO = require("../dao/dao");

const {
  responsHeader,
  statusCodes,
  errorStatus,
  errorMessages,
} = require("../../../constants");

let response = {
  headers: responsHeader,
  body: {},
};

/**
 * A handler function to list collaborators for a repository.
 *
 * @param {String} req The request object containing query parameters
 * @param {JSON object} res The response object
 *
 * @returns A list of user objects as collaboraotrs with Http SUCCESS status code or errors with Http error status codes.
 */
module.exports.getRepositoryCollaborators = async (req, res) => {
  const bearerHeader = req.headers.authorization;
  const accessToken = bearerHeader && bearerHeader.split(" ")[1];
  const repositoryName = req.query.repositoryName;
  const organizationName = req.query.organizationName;
  try {
    const repositoryCollaborators =
      await repositoryCollaboratorsDAO.getRepositoryCollaborators(
        accessToken,
        organizationName,
        repositoryName
      );
    logger.log(
      "info",
      `${JSON.stringify({
        repositoryCollaborators: repositoryCollaborators,
      })}`
    );
    if (repositoryCollaborators == errorStatus.TNF) {
      response.body = {
        message: errorMessages.TNF,
      };
      res.status(statusCodes.BAD_REQUEST).send(response);
    } else if (repositoryCollaborators) {
      response.body = {
        repositoryCollaborators: repositoryCollaborators.data,
      };
      res.status(statusCodes.SUCCESS).send(response);
    }
  } catch (error) {
    logger.error(`Error in Github get branches controller : ${error}`);
    if (error.response.status) {
      response.body = {
        message: error.response.data.message,
      };
      res.status(error.response.status).send(response);
    } else {
      response.body = {
        message: error,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};
/**
 * This method is reponsible for handling the adding collaborators to repository
 *
 * @param {object} req
 * @param {object} res
 * @returns reponse object or error object
 */
module.exports.addCollaboratorsToRepository = async (req, res) => {
  const bearerHeader = req.headers.authorization;
  const accessToken = bearerHeader && bearerHeader.split(" ")[1];

  const { organizationName, collaborators, repositoryName, permission } =
    req.body;
  try {
    const addedCollaborator =
      await repositoryCollaboratorsDAO.addCollaboratorsToRepository(
        accessToken,
        organizationName,
        collaborators,
        repositoryName,
        permission
      );
    if (addedCollaborator == errorStatus.TNF) {
      response.body = {
        message: errorMessages.TNF,
      };
      res.status(statusCodes.BAD_REQUEST).send(response);
    } else if (addedCollaborator) {
      response.body = {
        addedCollaborator: addedCollaborator,
      };
      res.status(statusCodes.CREATED).send(response);
    }
  } catch (error) {
    logger.error(
      `Error in Github add collaborator to repo controller : ${error}`
    );
    if (error.response.status == statusCodes.FORBIDDEN) {
      response.body = {
        message: error.response.data.message,
      };
      res.status(error.response.status).send(response);
    } else if (error.response.status) {
      response.body = {
        message: error.response.data.message,
      };
      res.status(error.response.status).send(response);
    } else {
      response.body = {
        error: error,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};
/**
 *
 * @param {object} req
 * @param {JSOn object} res
 *
 * return successmessage with StatusCodes.success when the user removed from the repository
 */
module.exports.removeUsersFromRepo = async (req, res) => {
  const bearerHeader = req.headers.authorization;
  const accessToken = bearerHeader && bearerHeader.split(" ")[1];

  const { organizationname, repoName, users } = req.body;
  try {
    let result = await repositoryCollaboratorsDAO.removeUsersFromRepo(
      organizationname,
      repoName,
      users,
      accessToken
    );
    if (result) {
      response.body = {
        result: true,
        message: "Users removed successfully",
      };
      res.status(statusCodes.SUCCESS).send(response);
    } else {
      response.body = {
        result: false,
        message: "Unable to remove user",
      };
    }
  } catch (error) {
    if (error.response.status) {
      response.body = {
        message: error.response.data.message,
      };
      res.status(error.response.status).send(response);
    } else if (error.message) {
      response.body = {
        message: error.message,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    } else {
      response.body = {
        message: error,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};
