const express = require("express");
const router = express.Router();
const controller = require("../controller/controller");

//Gets a list of repository collaborators
router.get("/", controller.getRepositoryCollaborators);

//add collaborators to repo
router.post("/", controller.addCollaboratorsToRepository);

//remove user from repo
router.delete("/", controller.removeUsersFromRepo);

module.exports = router;
