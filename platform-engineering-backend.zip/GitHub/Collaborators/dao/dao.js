const winston = require("winston");
const { createLogs } = require("../../../config/loggerConfig");
const todayDate = new Date().toDateString().replace(/\ /g, "");
const logConfiguration = createLogs(
  "github-repository-collaboraotrs-dao",
  todayDate
);
const logger = winston.createLogger(logConfiguration);
const { getConnection } = require("../../../config/githubConnection");

const {
  errorStatus,
  errorMessages,
  statusCodes,
} = require("../../../constants");

/**
 * A function to list collaborators for a repository
 *
 * @param {String} accessToken
 * @param {String} organizationName
 * @param {String} repositoryName
 *
 * @returns A response object of listCollaborators method call or an error object.
 */
async function getRepositoryCollaborators(
  accessToken,
  organizationName,
  repositoryName
) {
  try {
    if (!accessToken) return errorStatus.TNF;
    const octokit = await getConnection(accessToken);
    try {
      const repositoryCollaborators = await octokit.repos.listCollaborators({
        owner: organizationName,
        repo: repositoryName,
      });
      if (repositoryCollaborators) {
        return repositoryCollaborators;
      } else return false;
    } catch (error) {
      logger.error(`Error from github repository collaborators dao : ${error}`);
      throw error;
    }
  } catch (error) {
    logger.error(`Error from github repository collaborators dao : ${error}`);
    throw error;
  }
}

/**
 * This method is responsible for adding collaborators to repository
 *
 * @param {String} accessToken
 * @param {String} organizationName
 * @param {String} collaborators
 * @param {String} repositoryName
 * @param {String} permission
 * @returns addedCollobartors array or an error object
 */
async function addCollaboratorsToRepository(
  accessToken,
  organizationName,
  collaborators,
  repositoryName,
  permission
) {
  try {
    let addedCollaborators = [];
    if (!accessToken) return errorStatus.TNF;
    const octokit = await getConnection(accessToken);
    for (let index = 0; index < collaborators.length; index++) {
      const addedCollaboratorsResponse = await octokit.repos.addCollaborator({
        owner: organizationName,
        repo: repositoryName,
        username: collaborators[index],
        permission: permission,
        headers: {
          "X-GitHub-Api-Version": "2022-11-28",
        },
      });
      if (addedCollaboratorsResponse.status === 201) {
        addedCollaborators.push(addedCollaboratorsResponse);
      }
    }
    return addedCollaborators;
  } catch (error) {
    logger.error(
      `Error from github add collaborator to repository dao : ${error}`
    );
  }
}
/**
 * Removes users from a repository in an organization.
 * @param {string} organizationname - The name of the organization.
 * @param {string} reponame - The name of the repository.
 * @param {string[]} users - An array of usernames to be removed from the repository.
 * @param {string} accessToken - The access token for authentication.
 * @returns {boolean} - Returns true if all users were successfully removed, false otherwise.
 * @throws {Error} - Throws an error if there was an issue removing the users.
 */
async function removeUsersFromRepo(
  organizationname,
  reponame,
  users,
  accessToken
) {
  try {
    if (!accessToken) return errorStatus.TNF;
    const octokit = await getConnection(accessToken);
    let removedusercount = 0;
    for (let user of users) {
      let userremoved = await octokit.repos.removeCollaborator({
        owner: organizationname,
        repo: reponame,
        username: user,
        headers: {
          "X-GitHub-Api-Version": "2022-11-28",
        },
      });

      if (userremoved.status === statusCodes.NO_CONTENT) {
        removedusercount += 1;
      }
    }
    if (removedusercount == users.length) {
      return true;
    } else {
      return false;
    }
  } catch (error) {
    logger.error("Error in removed Users ===>", error);
    throw error;
  }
}

module.exports.removeUsersFromRepo = removeUsersFromRepo;
module.exports.getRepositoryCollaborators = getRepositoryCollaborators;
module.exports.addCollaboratorsToRepository = addCollaboratorsToRepository;
