const {
  errorStatus,
  errorMessages,
  responsHeader,
  statusCodes,
} = require("../../../constants");
let response = {
  headers: responsHeader,
  body: {},
};

const winston = require("winston");
const { createLogs } = require("../../../config/loggerConfig");
const todayDate = new Date().toDateString().replace(/\ /g, "");
const logConfiguration = createLogs("azure-directories-controller", todayDate);
const logger = winston.createLogger(logConfiguration);
const githubClientDetailsDao = require("../dao/dao");

/**
 * Returns Saved github client detail Object with HTTP CREATED Http Code or errors with Http error status codes.
 *
 * @param {JSON Object} req An github client detail Object
 * @param {Array} res Saved github client detail Object
 *
 * @returns A saved github client detail Object
 */
module.exports.saveGithubClientDetails = async (req, res) => {
  const githubObject = req.body;
  try {
    const savedGithubClientDetails =
      await githubClientDetailsDao.saveGithubClientDetails(githubObject);
    if (savedGithubClientDetails) {
      response.body = {
        savedGithubClientDetails: savedGithubClientDetails,
      };
      return res.status(statusCodes.CREATED).send(response);
    }
  } catch (error) {
    response.body = {
      message: error,
    };
    res.status(error.statusCode).send(response);
  }
};

/**
 * Returns a list of github client details with HTTP SUCCESS status code or errors with Http error status codes.
 *
 * @param {Array} res A list of github client detail Object
 *
 * @return A list of github client detail Objects
 */
module.exports.getAllGithubClientDetails = async (req, res) => {
  try {
    const githubClientDetails =
      await githubClientDetailsDao.getAllGithubClientDetails();

    response.body = {
      githubClientDetails: githubClientDetails,
    };
    res.status(statusCodes.SUCCESS).send(response);
  } catch (error) {
    response.body = {
      message: error,
    };
    res.status(statusCodes.SERVER_ERROR).send(response);
  }
};

/**
 * A handler function to update an existing github client detail.
 *
 * @param {JSON Object} req The request object
 * @param {JSON Object} res The response object
 *
 * @returns An object of updated github client detail with Http SUCCESS status code or error with Http errors status codes.
 */

module.exports.updateGithubClientDetails = async (req, res) => {
  try {
    let objectToUpdate = req.body;
    let clientId = req.body.applicationClientId;
    await githubClientDetailsDao.getGithubClientDetail(clientId);
    let updatedCredentials =
      await githubClientDetailsDao.updateGithubClientDetails(
        { applicationClientId: clientId },
        objectToUpdate
      );
    if (updatedCredentials) {
      response.body = {
        GithubClientCredential: updatedCredentials,
      };
      return res.status(statusCodes.SUCCESS).send(response);
    }
    throw new Error("something went wrong");
  } catch (error) {
    if (error.statusCode == statusCodes.NOT_FOUND) {
      response.body = {
        message: error.message,
      };
      return res.status(statusCodes.NOT_FOUND).send(response);
    }
    logger.error("Exception in update directory controller", error);
    response.body = {
      message: error.message,
    };
    return res.status(statusCodes.SERVER_ERROR).send(response);
  }
};

/**
 * A handler function to delete an github client detail
 *
 * @param {String} req The request query parameters
 * @param {JSON Object} res The response object
 *
 * @returns An object with delete status with Http SUCCESS status code or errors with Http error status codes.
 */
module.exports.deleteGithubClientDetails = async (req, res) => {
  try {
    let clientId = req.query.clientId;
    let deletedGithubClientDetails =
      await githubClientDetailsDao.deleteGithubClientDetails(clientId);
    if (deletedGithubClientDetails.deletedCount) {
      response.body = {
        deletedGithubClientDetails: deletedGithubClientDetails,
      };
      return res.status(statusCodes.SUCCESS).send(response);
    }
    response.body = {
      errorStatus: statusCodes.BAD_REQUEST,
      errorMessage: errorMessages.CDO,
    };
    res.status(statusCodes.BAD_REQUEST).send(response);
  } catch (error) {
    logger.error("Exception in delete github controller", error);
    response.body = {
      message: error.message,
    };
    return res.status(statusCodes.SERVER_ERROR).send(response);
  }
};

/**
 * A handler function to fetch an Azure Active Directory
 *
 * @param {JSON Object} res The response object
 *
 * @return An Object of github client detail with Http
 */
module.exports.getGithubClientDetail = async (req, res) => {
  const applicationClientId = req.query.applicationClientId;
  try {
    const githubClientInfo = await githubClientDetailsDao.getGithubClientDetail(
      applicationClientId
    );
    logger.log("info", "githubClientInfo from controller : ", githubClientInfo);
    if (githubClientInfo) {
      response.body = {
        githubClientInfo: githubClientInfo,
      };
      res.status(statusCodes.SUCCESS).send(response);
    }
  } catch (error) {
    response.body = {
      message: error,
    };
    res.status(error.statusCode).send(response);
  }
};
