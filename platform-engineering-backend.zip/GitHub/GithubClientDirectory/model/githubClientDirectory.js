const mongoose = require("mongoose");
const schema = mongoose.Schema;

const GithubClientDirectory = new schema({
  _id: { type: schema.Types.ObjectId, required: true, auto: true },
  applicationName: { type: schema.Types.String, default: "NA" },
  applicationClientId: { type: schema.Types.String },
  applicationClientSecret: { type: schema.Types.String },
  scopes: {
    type: schema.Types.String,
    required: true,
    default: "",
  },

  redirectUri: { type: schema.Types.String, default: "NA" },
});

module.exports =
  mongoose.models.github_directory ||
  mongoose.model("github_directory", GithubClientDirectory);
