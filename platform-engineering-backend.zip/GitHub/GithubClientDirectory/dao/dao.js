const { connect } = require("../../../config/dbConfig");
const { errorStatus, statusCodes } = require("../../../constants");
const dbOperations = require("../../../dbOperations");
const { mongoose } = require("mongoose");

const winston = require("winston");
const { createLogs } = require("../../../config/loggerConfig");
const todayDate = new Date().toDateString().replace(/\ /g, "");
const logConfiguration = createLogs("azure-directories-dao", todayDate);
const logger = winston.createLogger(logConfiguration);

const githubClientModel = require("../model/githubClientDirectory");

/**
 * Saves a github client detail Object in database
 *
 * @param {JSON Object} github client detail object
 * @returns Saved github client detail Object
 */
async function saveGithubClientDetails(githubObject) {
  let session;
  let savedGithubClientDetails;
  try {
    await connect();
    session = await mongoose.connection.startSession();
    session.startTransaction();
    const githubClientDetails = await dbOperations.findOne(githubClientModel, {
      applicationClientId: githubObject.applicationClientId,
    });
    if (!githubClientDetails) {
      savedGithubClientDetails = await dbOperations.save(
        githubClientModel,
        githubObject
      );
      await session.commitTransaction();
      await session.endSession();
      return savedGithubClientDetails;
    }
    throw {
      message: errorStatus.RAE,
      statusCode: statusCodes.REQUEST_CONFLICT,
    };
  } catch (error) {
    logger.error("Exception in save azure directory", error);
    if (session) {
      // await session.abortTransaction();
      await session.endSession();
    }
    throw error;
  }
}

/**
 * Lists github client details saved in database
 *
 * @returns A list of github client details
 */
async function getAllGithubClientDetails() {
  let session;
  try {
    await connect();
    session = await mongoose.connection.startSession();
    session.startTransaction();
    const githubClientDetails = await dbOperations.getAll(githubClientModel);
    await session.commitTransaction();
    await session.endSession();
    if (githubClientDetails) return githubClientDetails;
  } catch (error) {
    logger.error("Exception in get azure directory", error);
    if (session) {
      await session.abortTransaction();
      await session.endSession();
    }
    throw new Error("Failed to connect to the database.");
  }
}

/**
 * A function to update existing github client detail.
 *
 * @param {String} application client id
 * @param {JSON Object} objectToUpdate
 *
 * @returns An updated github client detail Object or an error object.
 */
async function updateGithubClientDetails(clientId, objectToUpdate) {
  let session;
  try {
    await connect();
    session = await mongoose.connection.startSession();
    session.startTransaction();
    const updatedCredentials = await dbOperations.update(
      githubClientModel,
      clientId,
      objectToUpdate
    );
    await session.commitTransaction();
    await session.endSession();
    return updatedCredentials;
  } catch (error) {
    logger.error("Exception in update directory", error);
    if (session) {
      await session.abortTransaction();
      await session.endSession();
    }
    throw new Error("Failed to connect to the database.");
  }
}

/**
 * A function to delete an github client detail from database
 *
 * @param {String} application client id
 *
 * @returns An object with deleteCount field or error
 */
async function deleteGithubClientDetails(applicationClientId) {
  let session;
  try {
    await connect();
    session = await mongoose.connection.startSession();
    session.startTransaction();
    const deletedGithubClientDetails = await dbOperations.delete(
      githubClientModel,
      {
        applicationClientId: applicationClientId,
      }
    );
    await session.commitTransaction();
    await session.endSession();
    return deletedGithubClientDetails;
  } catch (error) {
    logger.error("Exception in delete azure directory", error);
    if (session) {
      await session.abortTransaction();
      await session.endSession();
    }
    throw new Error("Failed to connect to the database.");
  }
}

/**
 * A function to fetch github client detail by application client ID
 *
 * @param {String} application client id
 *
 * @returns An object of github client detail or an error object.
 */
async function getGithubClientDetail(applicationClientId) {
  let session;
  try {
    await connect();
    logger.log("info", "applicationClientId : ", applicationClientId);

    session = await mongoose.connection.startSession();
    session.startTransaction();
    const githubClientDetail = await dbOperations.findOne(githubClientModel, {
      applicationClientId: applicationClientId,
    });
    logger.log("info", "githubClientDetail : ", githubClientDetail);
    await session.commitTransaction();
    await session.endSession();
    if (githubClientDetail) return githubClientDetail;
    throw {
      message: errorStatus.NRF,
      statusCode: statusCodes.NOT_FOUND,
    };
  } catch (error) {
    logger.log("info", "githubClientDetail dao error", error);
    throw error;
  }
}
module.exports.saveGithubClientDetails = saveGithubClientDetails;
module.exports.getAllGithubClientDetails = getAllGithubClientDetails;
module.exports.updateGithubClientDetails = updateGithubClientDetails;
module.exports.deleteGithubClientDetails = deleteGithubClientDetails;
module.exports.getGithubClientDetail = getGithubClientDetail;
