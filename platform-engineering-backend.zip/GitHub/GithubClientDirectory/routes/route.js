const express = require("express");
const router = express.Router();
const controller = require("../controller/controller");

router.post("/", controller.saveGithubClientDetails);
router.get("/", controller.getAllGithubClientDetails);
router.put("/", controller.updateGithubClientDetails);
router.delete("/", controller.deleteGithubClientDetails);
router.get("/github-client-info", controller.getGithubClientDetail);
module.exports = router;
