const express = require("express");
const router = express.Router();
const controller = require("../controller/controller");

//Creates a repository
router.post("/", controller.createRepository);
//list repositories
router.get("/", controller.getRepositories);
router.get("/repo",controller.getRepository);
module.exports = router;
