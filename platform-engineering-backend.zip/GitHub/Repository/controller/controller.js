const winston = require("winston");
const { createLogs } = require("../../../config/loggerConfig");
const todayDate = new Date().toDateString().replace(/\ /g, "");
const logConfiguration = createLogs("GitHub-repository-controller", todayDate);
const logger = winston.createLogger(logConfiguration);

const repositoryDAO = require("../dao/dao");

const {
  responsHeader,
  statusCodes,
  errorStatus,
  errorMessages,
} = require("../../../constants");
// const { pipeline } = require("form-data");

let response = {
  headers: responsHeader,
  body: {},
};

/**
 * A handler function to create a reposiotory.
 *
 * @param {JSON Object} req
 * @param {JSON Object} res
 *
 * @returns An object of created repository object with Http CREATED status code or errors with Http error status code.
 */
module.exports.createRepository = async (req, res) => {
  const bearerHeader = req.headers.authorization;
  const accessToken = bearerHeader && bearerHeader.split(" ")[1];
  const {
    organizationName,
    repositoryName,
    description,
    isPrivate,
    visibility,
    pipeline,
    variables,
    secrets
  } = req.body;

  try {
    const createdRepository = await repositoryDAO.createRopsitory(
      accessToken,
      organizationName,
      repositoryName,
      description,
      isPrivate,
      visibility,
      pipeline,
      variables,
      secrets
    );
    if (createdRepository == errorStatus.TNF) {
      response.body = {
        message: errorMessages.TNF,
      };
      res.status(statusCodes.BAD_REQUEST).send(response);
    } else if (createdRepository) {
      response.body = {
        createdRepository: createdRepository,
      };
      res.status(statusCodes.CREATED).send(response);
    }
  } catch (error) {
    logger.error(`Error in Github create repository controller : ${error}`);
    if (error.response.status == statusCodes.UNPROCESSABLE_ENTITY) {
      response.body = {
        message: error.response.data.message,
      };
      res.status(statusCodes.REQUEST_CONFLICT).send(response);
    } else if (error.response.status) {
      response.body = {
        message: error.response.data.message,
      };
      res.status(error.response.status).send(response);
    } else {
      response.body = {
        message: error,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};

module.exports.getRepositories = async (req, res) => {
  const bearerHeader = req.headers.authorization;
  const accessToken = bearerHeader && bearerHeader.split(" ")[1];
  const organizationName = req.query.organizationName;
  try {
    const repositories = await repositoryDAO.getRepositories(
      accessToken,
      organizationName
    );
    logger.log("info", `repositories : ${JSON.stringify(repositories)}`);
    if (repositories) {
      response.body = {
        repositories: repositories,
      };
      res.status(statusCodes.SUCCESS).send(response);
    }
  } catch (error) {
    logger.error(`Error in Github get repositories controller : ${error}`);
    if (error.response.status) {
      response.body = {
        message: error.response.data.message,
      };
      res.status(error.response.status).send(response);
    } else {
      response.body = {
        message: error,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};

module.exports.getRepository = async (req, res) => {
  const bearerHeader = req.headers.authorization;
  const accessToken = bearerHeader && bearerHeader.split(" ")[1];
  const organizationName = req.query.organizationName;
  const repositoryName = req.query.repositoryName;
  try {
    const repository = await repositoryDAO.getRepository(
      accessToken,
      organizationName,
      repositoryName
    );
    if (repository.hasOwnProperty("id")) {
      response.body = {
        repository: repository,
      };
      res.status(statusCodes.SUCCESS).send(response);
    } else {
      throw new Error("Unable to get the Repository!");
    }
  } catch (error) {
    logger.error(`Error in Github get repositories controller : ${error}`);
    if (error.response.status) {
      response.body = {
        message: error.response.data.message,
      };
      res.status(error.response.status).send(response);
    } else {
      response.body = {
        message: error,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};
