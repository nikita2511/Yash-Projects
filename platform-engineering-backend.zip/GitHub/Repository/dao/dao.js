const winston = require("winston");
const { createLogs } = require("../../../config/loggerConfig");
const todayDate = new Date().toDateString().replace(/\ /g, "");
const logConfiguration = createLogs("github-repository-dao", todayDate);
const logger = winston.createLogger(logConfiguration);
const { getConnection } = require("../../../config/githubConnection");
const {
  createRepoEnvironment,
} = require("../../RepositoryEnvironment/dao/dao");
const {
  errorStatus,
  errorMessages,
  statusCodes,
} = require("../../../constants");

const branchDAO = require("../../Branches/dao/dao");
const { createPipeline } = require("../../Pipeline/dao/dao");
const { createEnvironmentVariables } = require("../../Variables/dao/dao");
const { createorUpdateEnvironmentSecret } = require("../../Secrets/dao/dao");
/**
 * A function to create a repository to an organization
 *
 * @param {String} accessToken
 * @param {String} organizationName
 * @param {String} repositoryName
 * @param {String} description
 *
 * @returns An object of created branch or an error object.
 */
async function createRopsitory(
  accessToken,
  organizationName,
  repositoryName,
  description,
  isPrivate,
  visibility,
  pipeline,
  variables,
  secrets
) {
  try {
    if (!accessToken) return errorStatus.TNF;
    const octokit = await getConnection(accessToken);
    let response = {};
    try {
      const createdRepository = await octokit.repos.createInOrg({
        org: organizationName,
        name: repositoryName,
        description: description,
        private: isPrivate,
        visibility: visibility,
        auto_init: true,
        allow_auto_merge: true,
        delete_branch_on_merge: true,
        homepage: "https://github.com",
        headers: {
          "X-GitHub-Api-Version": "2022-11-28",
        },
      });
      // logger.log(
      //   "info",
      //   `createdRepository : ${JSON.stringify(createdRepository.data)}`
      // );
      if (createdRepository.status == statusCodes.CREATED) {
        var repositoryId = createdRepository.data.id;
        response = await branchDAO.createBranchesFromRule(
          accessToken,
          organizationName,
          createdRepository.data.name
        );
        response.respositoryCreated = true;
        //create default enviornment with repository name
        let repo = repositoryName.replace(/\s+/g, "-");
        let environmentsToCreate = [repo];
        if (pipeline && pipeline.toBeDeployed) {
          for (const environmentName of pipeline.deploymentEnvironments) {
            let updatedEnvName = environmentName.environment.replace(
              /\s+/g,
              "-"
            );
            if (updatedEnvName === repo) {
              const index = environmentsToCreate.indexOf(updatedEnvName);
              if (index > -1) {
                // only splice array when item is found
                environmentsToCreate.splice(index, 1); // 2nd parameter means remove one item only
              }
            }
            environmentsToCreate.push(environmentName.environment);
          }
        }
        logger.log(
          "info",
          `Environments to create : ${JSON.stringify(environmentsToCreate)}`
        );
        for (const environment of environmentsToCreate) {
          let createdEnvironment = await createRepoEnvironment(
            organizationName,
            accessToken,
            repo,
            environment
          );
          if (createdEnvironment) {
            response.createdEnvironment = true;
          }
        }
        //pipeline creation
        if (pipeline) {
          const {
            name,
            applicationType,
            publishArtifacts,
            toBeDeployed,
            deploymentEnvironments,
            usernameInitials,
            reviewers,
          } = pipeline;
          let createdPipipeline = await createPipeline(
            accessToken,
            organizationName,
            repo,
            name,
            applicationType,
            publishArtifacts,
            toBeDeployed,
            deploymentEnvironments,
            usernameInitials,
            reviewers
          );
          response.createdPipipeline = true;
          response.environmentVariables =
            createdPipipeline.environmentVariables;
        }
        // variable creation
        if (variables) {
          let createdEnvironmentVariables = await createEnvironmentVariables(
            repositoryId,
            repo,
            variables,
            accessToken
          );
          response.createdEnvironmentVariables = true;
        }
        if (secrets) {
          let createdSecrets = await createorUpdateEnvironmentSecret(
            accessToken,
            organizationName,
            repo,
            repo,
            secrets
          );
          response.areSecretsCreated = true;
        }
        return response;
      }
      throw {
        message: errorStatus.RAE,
        statusCode: statusCodes.REQUEST_CONFLICT,
      };
    } catch (error) {
      logger.error(`Error from github create repository dao : ${error}`);
      throw error;
    }
  } catch (error) {
    logger.error(`Error from github create repository dao : ${error}`);
    throw error;
  }
}

async function getRepositories(accessToken, organizationName) {
  try {
    let page = 1;
    let repositories = [];
    const octokit = await getConnection(accessToken);
    while (true) {
      const repositoriesResponse = await octokit.repos.listForOrg({
        org: organizationName,
        per_page: 100,
        page: page,
        direction: "desc",
        headers: {
          "X-GitHub-Api-Version": "2022-11-28",
        },
      });

      if (repositoriesResponse.data.length === 0) {
        break;
      }
      repositories = repositories.concat(repositoriesResponse.data);
      page++;
    }
    return repositories;
  } catch (error) {
    logger.error(`Error from github get repositories dao : ${error}`);
    throw error;
  }
}

async function getRepository(accessToken, organizationName, repositoryName) {
  try {
    if (!accessToken) return errorStatus.TNF;
    const octokit = await getConnection(accessToken);
    const repository = await octokit.repos.get({
      owner: organizationName,
      repo: repositoryName,
      headers: {
        "X-GitHub-Api-Version": "2022-11-28",
      },
    });
    if (repository) {
      return repository.data;
    }
  } catch (error) {
    logger.error(`Error from github get repository dao : ${error}`);
    throw error;
  }
}

module.exports.createRopsitory = createRopsitory;
module.exports.getRepositories = getRepositories;
module.exports.getRepository = getRepository;
