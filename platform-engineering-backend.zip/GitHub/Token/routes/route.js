const express = require("express");
const router = express.Router();
const controller = require("../controller/controller");

//Generates an access token 
router.post("/",controller.generateAccessToken);

module.exports = router;
