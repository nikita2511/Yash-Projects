const axios = require("axios");

const winston = require("winston");
const { createLogs } = require("../../../config/loggerConfig");
const todayDate = new Date().toDateString().replace(/\ /g, "");
const logConfiguration = createLogs("github-token-dao", todayDate);
const logger = winston.createLogger(logConfiguration);

const githubClientDirectoryDAO = require("../../GithubClientDirectory/dao/dao");

/**
 * A function to generate access token on the basis of code.
 *
 * @param {String} code
 *
 * @returns An object of access token or error object.
 */
async function generateAccessToken(code) {
  try {
    const githubClientDetail = await githubClientDirectoryDAO.getAllGithubClientDetails();
    logger.log(
      "info",
      `${JSON.stringify({ githubClientDetail: githubClientDetail })}`
    );
    const data = {
      code: code,
      client_id: githubClientDetail[0].applicationClientId,
      client_secret: githubClientDetail[0].applicationClientSecret,
    };
    const accessToken = await axios.post(
      `https://github.com/login/oauth/access_token`,
      data,
      {
        headers: {
          Accept: "application/json",
        },
      }
    );
    logger.log("info", `Access Token : ${accessToken.data}`);
    if (accessToken.data) {
      return accessToken.data;
    }
  } catch (error) {
    logger.error(`Error in GitHub Token dao : ${error}`);
    throw error;
  }
}

module.exports.generateAccessToken = generateAccessToken;
