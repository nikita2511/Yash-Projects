const winston = require("winston");
const { createLogs } = require("../../../config/loggerConfig");
const todayDate = new Date().toDateString().replace(/\ /g, "");
const logConfiguration = createLogs("GitHub-token-controller", todayDate);
const logger = winston.createLogger(logConfiguration);

const tokenDAO = require("../dao/dao");

const { responsHeader, statusCodes } = require("../../../constants");

let response = {
  headers: responsHeader,
  body: {},
};

/**
 * A handler function to retrieve access token
 *
 * @param {JSON Object} req The request object
 * @param {JSON} res The response object
 *
 * @returns An object of access token with Http SUCCESS status code or error with Http error status codes.
 */
module.exports.generateAccessToken = async (req, res) => {
  const code = req.body.code;
  try {
    const accessToken = await tokenDAO.generateAccessToken(code);
    if (accessToken.error) {
      response.body = {
        error: accessToken,
      };
      res.status(statusCodes.BAD_REQUEST).send(response);
    } else if (accessToken) {
      response.body = {
        accessToken: accessToken,
      };
      res.status(statusCodes.SUCCESS).send(response);
    }
  } catch (error) {
    logger.error(`Error in Access Token controller : ${error}`);
    if (error.response.status) {
      response.body = {
        message: error.response.data.message,
      };
      res.status(error.response.status).send(response);
    }
    else
    {
    response.body = {
      message: error,
    };
    res.status(statusCodes.SERVER_ERROR).send(response);
  }
  }
};
