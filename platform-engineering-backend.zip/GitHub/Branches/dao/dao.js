const winston = require("winston");
const { createLogs } = require("../../../config/loggerConfig");
const todayDate = new Date().toDateString().replace(/\ /g, "");
const logConfiguration = createLogs("github-branches-dao", todayDate);
const logger = winston.createLogger(logConfiguration);
const { getConnection } = require("../../../config/githubConnection");
const orgRuleDAO = require("../../../OrganizationRules/Rules/dao/dao");
const axios = require("axios");
const { delay } = require("../../../Utilities/util");
const {
  errorStatus,
  errorMessages,
  statusCodes,
} = require("../../../constants");

/**
 * A function to fetch a list of branches for a repository in an organization
 *
 * @param {String} accessToken
 * @param {String} organizationName
 * @param {String} repositoryName
 *
 * @returns A list of branch objects or an error object.
 */
async function getBranches(accessToken, organizationName, repositoryName) {
  try {
    if (!accessToken) return errorStatus.TNF;
    const octokit = await getConnection(accessToken);
    try {
      const branches = await octokit.repos.listBranches({
        owner: organizationName,
        repo: repositoryName,
        headers: {
          "X-GitHub-Api-Version": "2022-11-28",
        },
      });
      if (branches) {
        return branches.data;
      }
    } catch (error) {
      logger.error(`Error from github get branches dao : ${error}`);
      throw error;
    }
  } catch (error) {
    logger.error(`Error from github get branches dao : ${error}`);
    throw error;
  }
}

/**
 * A function to create a branch.
 *
 * @param {String} accessToken
 * @param {String} organizationName
 * @param {String} repositoryName
 * @param {String} sourceBranchName
 * @param {String} targetBranchName
 *
 * @returns An object of created branch or an error object.
 */
async function createBranch(
  accessToken,
  organizationName,
  repositoryName,
  sourceBranchName,
  targetBranchName
) {
  try {
    if (!accessToken) return errorStatus.TNF;
    const octokit = await getConnection(accessToken);
    try {
      const sourceBranch = await getBranch(
        accessToken,
        organizationName,
        repositoryName,
        sourceBranchName
      );
      const createdBranch = await octokit.git.createRef({
        owner: organizationName,
        repo: repositoryName,
        ref: `refs/heads/${targetBranchName}`,
        sha: sourceBranch.commit.sha,
      });
      if (createdBranch) {
        return createdBranch.data;
      }
    } catch (error) {
      logger.error(`Error from github create branch dao : ${error}`);
      throw error;
    }
  } catch (error) {
    logger.error(`Error from github create branch dao : ${error}`);
    throw error;
  }
}

/**
 * A function to fetch a branch in a repository.
 *
 * @param {String} accessToken
 * @param {String} organizationName
 * @param {String} repositoryName
 * @param {String} branchName
 *
 * @returns An object of branch or an error object.
 */
async function getBranch(
  accessToken,
  organizationName,
  repositoryName,
  branchName
) {
  try {
    if (!accessToken) return errorStatus.TNF;
    const octokit = await getConnection(accessToken);
    try {
      const branch = await octokit.repos.getBranch({
        owner: organizationName,
        repo: repositoryName,
        branch: branchName,
        headers: {
          "X-GitHub-Api-Version": "2022-11-28",
        },
      });
      if (branch) {
        return branch.data;
      }
    } catch (error) {
      logger.error(`Error from github get branch dao : ${error}`);
      throw error;
    }
  } catch (error) {
    logger.error(`Error from github get branch dao : ${error}`);
    throw error;
  }
}

/**
 * A function to delete a branch from a repository.
 *
 * @param {String} accessToken
 * @param {String} organizationName
 * @param {String} repositoryName
 * @param {String} branchName
 *
 * @returns A delete branch status code or an error object.
 */
async function deleteBranch(
  accessToken,
  organizationName,
  repositoryName,
  branchName
) {
  try {
    if (!accessToken) return errorStatus.TNF;
    const octokit = await getConnection(accessToken);
    try {
      const deletedBranch = await octokit.git.deleteRef({
        owner: organizationName,
        repo: repositoryName,
        ref: `heads/${branchName}`,
        headers: {
          "X-GitHub-Api-Version": "2022-11-28",
        },
      });
      if (deletedBranch) {
        return deletedBranch.status;
      }
    } catch (error) {
      logger.error(`Error from github delete branch dao : ${error}`);
      throw error;
    }
  } catch (error) {
    logger.error(`Error from github delete branch dao : ${error}`);
    throw error;
  }
}

/**
 * A function to apply/update branch policies to an existing branch.
 *
 * @param {String} accessToken
 * @param {String} organizationName
 * @param {String} repositoryName
 * @param {String} branchName
 * @param {String} requiredApprovingReviewCount
 *
 * @returns An object of appliedBranchPolices or an error object.
 */
async function applyBranchPolicies(
  accessToken,
  organizationName,
  repositoryName,
  branchName,
  requiredApprovingReviewCount
) {
  try {
    if (!accessToken) return errorStatus.TNF;
    const octokit = await getConnection(accessToken);

    try {
      const appliedBranchPolicies = await octokit.repos.updateBranchProtection({
        owner: organizationName,
        repo: repositoryName,
        branch: branchName,
        required_pull_request_reviews: {
          required_approving_review_count: requiredApprovingReviewCount,
        },
        required_status_checks: null,
        restrictions: null,
        enforce_admins: null,
      });
      if (appliedBranchPolicies.status == statusCodes.SUCCESS) return true;
    } catch (error) {
      logger.error(`Error from github apply branch policies dao : ${error}`);
      throw error;
    }
  } catch (error) {
    logger.error(`Error from github apply branch policies dao : ${error}`);
    throw error;
  }
}

/**
 * A function to create branches from organization rule
 *
 * @param {String} accessToken
 * @param {String} organizationName
 * @param {String} repositoryName
 *
 * @returns An object with isDefaultBranchSet, reviewersPolicyCreated, branchCreation.
 */
async function createBranchesFromRule(
  accessToken,
  organizationName,
  repositoryName
) {
  try {
    const orgRule = await orgRuleDAO.getOrganizationRules(
      organizationName,
      "Github"
    );
    logger.log("info", `orgRule : ${JSON.stringify(orgRule)}`);

    let branchingStrategy,
      branchFromRule = [],
      defaultBranchName,
      createdReviewerPolicies = [],
      branch,
      response = {},
      branches = [],
      branchesCreated = [];
    if (orgRule) {
      branchingStrategy = orgRule.branchingModel;
      logger.log(
        "info",
        `branchingStrategy.branches : ${JSON.stringify(
          branchingStrategy.branches
        )}`
      );
      branchingStrategy.branches.forEach((branch) => {
        branchFromRule.push(branch.name);
        branches.push({
          name: branch.name,
          mergeType: branch.mergeType,
          reviewersCount: branch.noOfReviewers,
        });
        logger.log("info", `branches : ${JSON.stringify(branches)}`);
        if (branch.type == "default") {
          defaultBranchName = branch.name;
        }
      });
    }

    let defaultCreatedBranch = await getBranches(
      accessToken,
      organizationName,
      repositoryName
    );
    const existingBranch = defaultCreatedBranch[0].name;
    logger.log("info", `existingBranch : ${JSON.stringify(existingBranch)}`);

    logger.log("info", `branchFromRule : ${JSON.stringify(branchFromRule)}`);

    const remainingBranchesToCreate = branchFromRule.filter(
      (branch) => existingBranch.indexOf(branch) === -1
    );
    logger.log(
      "info",
      `remainingBranchesToCreate : ${JSON.stringify(remainingBranchesToCreate)}`
    );
    if (remainingBranchesToCreate.length) {
      for (const bname of remainingBranchesToCreate) {
        try {
          let createdBranch = await createBranch(
            accessToken,
            organizationName,
            repositoryName,
            existingBranch,
            bname
          );
          logger.log(
            "info",
            `createdBranch : ${JSON.stringify(createdBranch)}`
          );
          if (createdBranch) {
            branchesCreated.push(createdBranch.ref.split("/")[2]);
          } else {
            return false;
          }
        } catch (error) {
          logger.error(
            "Exception in create model for brnaches utilities",
            error
          );
        }
      }

      const defaultBranch = await setDefaultBranch(
        accessToken,
        organizationName,
        repositoryName,
        defaultBranchName
      );
      if (defaultBranch) {
        response.isDefaultBranchSet = true;
      } else {
        response.isDefaultBranchSet = false;
      }

      if (!branchFromRule.includes(existingBranch)) {
        const deletedBranch = await deleteBranch(
          accessToken,
          organizationName,
          repositoryName,
          existingBranch
        );
        if (deletedBranch) {
          mainBranchDeleted = true;
        }
      }

      /**
       * Applying reviewers count policy to created branches.
       */
      for (const bname of branches) {
        let createdPolicy = await applyBranchPolicies(
          accessToken,
          organizationName,
          repositoryName,
          bname.name,
          parseInt(bname.reviewersCount)
        );
        if (createdPolicy) {
          createdReviewerPolicies.push(createdPolicy);
        }
      }
      if (
        createdReviewerPolicies.length &&
        branchesCreated.length === remainingBranchesToCreate.length
      ) {
        response.reviewersPolicyCreated = true;
        response.branchCreation = true;
        logger.log(
          "info",
          `response from branches : ${JSON.stringify(response)}`
        );
        return response;
      }
    } else {
      response.reviewersPolicyCreated = false;
      return response;
    }
  } catch (error) {
    logger.error(`Error from github createBranchesFromRule dao : ${error}`);
    throw error;
  }
}

/**
 * A function to set different branch as default branch
 *
 * @param {String} accessToken
 * @param {String} organizationName
 * @param {String} repositoryName
 * @param {String} branchToSetDefault
 *
 * @returns A boolean value or an error object.
 */
async function setDefaultBranch(
  accessToken,
  organizationName,
  repositoryName,
  branchToSetDefault
) {
  try {
    if (!accessToken) return errorStatus.TNF;
    const octokit = await getConnection(accessToken);

    const defaultBranch = await octokit.repos.update({
      owner: organizationName,
      repo: repositoryName,
      default_branch: branchToSetDefault,
    });

    if ((defaultBranch.status = statusCodes.SUCCESS)) {
      return true;
    } else return false;
  } catch (error) {
    throw error;
  }
}

/**
 * A function to update reference for a branch.
 *
 * @param {String} accessToken
 * @param {String} organizationName
 * @param {String} repositoryName
 * @param {String} ref
 * @param {String} sha
 *
 * @returns An object of updated reference or an error object.
 */
async function updateRef(
  accessToken,
  organizationName,
  repositoryName,
  ref,
  sha
) {
  try {
    if (!accessToken) return errorStatus.TNF;
    const octokit = await getConnection(accessToken);
    const updatedRef = await octokit.git.updateRef({
      owner: organizationName,
      repo: repositoryName,
      ref: `heads/${ref}`,
      sha: sha,
      force: true,
    });
    return updatedRef;
  } catch (error) {
    logger.log(
      "error",
      `Error from github branch dao : ${JSON.stringify(error)}`
    );
    throw error;
  }
}
module.exports.getBranches = getBranches;
module.exports.createBranch = createBranch;
module.exports.getBranch = getBranch;
module.exports.deleteBranch = deleteBranch;
module.exports.applyBranchPolicies = applyBranchPolicies;
module.exports.createBranchesFromRule = createBranchesFromRule;
module.exports.setDefaultBranch = setDefaultBranch;
module.exports.updateRef = updateRef;
