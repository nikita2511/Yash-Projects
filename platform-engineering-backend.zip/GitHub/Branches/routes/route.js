const express = require("express");
const router = express.Router();
const controller = require("../controller/controller");

//Gets a list of branches
router.get("/", controller.getBranches);

//Get a branch by branch name
router.get("/branch", controller.getBranch);

//Created a branch in a repository
router.post("/", controller.createBranch);

//Deletes a branch from a repository
router.delete("/", controller.deleteBranch);

//Sets a different branch as the default branch.
router.post("/setDefault",controller.setDefaultBranch);

//Applies reviewers count to a branch;
router.put("/branch-policies", controller.applyBranchPolicies);

//Triggers the createBranchesFromRule method
router.post("/create-branches-from-rule", controller.createBranchesFromRule);


module.exports = router;
