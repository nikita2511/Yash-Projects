const winston = require("winston");
const { createLogs } = require("../../../config/loggerConfig");
const todayDate = new Date().toDateString().replace(/\ /g, "");
const logConfiguration = createLogs("GitHub-branches-controller", todayDate);
const logger = winston.createLogger(logConfiguration);

const branchesDAO = require("../dao/dao");

const {
  responsHeader,
  statusCodes,
  errorStatus,
  errorMessages,
} = require("../../../constants");

let response = {
  headers: responsHeader,
  body: {},
};

/**
 * A handler function to fetch a list of branches in a repository
 *
 * @param {String} req The request query parameters
 * @param {JSON Object} res The response object
 *
 * @returns A list of branch objects with Http SUCCESS status code or errors with Http error status codes.
 */
module.exports.getBranches = async (req, res) => {
  const bearerHeader = req.headers.authorization;
  const accessToken = bearerHeader && bearerHeader.split(" ")[1];
  const repositoryName = req.query.repositoryName;
  const organizationName = req.query.organizationName;
  try {
    const branches = await branchesDAO.getBranches(
      accessToken,
      organizationName,
      repositoryName
    );
    if (branches == errorStatus.TNF) {
      response.body = {
        message: errorMessages.TNF,
      };
      res.status(statusCodes.BAD_REQUEST).send(response);
    } else if (branches) {
      response.body = {
        branches: branches,
      };
      res.status(statusCodes.SUCCESS).send(response);
    }
  } catch (error) {
    logger.error(`Error in Github get branches controller : ${error}`);
    if (error.response.status) {
      response.body = {
        message: error.response.data.message,
      };
      res.status(error.response.status).send(response);
    } else {
      response.body = {
        message: error,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};

/**
 * A handler function to fetch a branch in a repository
 *
 * @param {String} req The request query parameters
 * @param {JSON Object} res The response object
 *
 * @returns A branch object with Http SUCCESS status code or errors with Http error status codes.
 */
module.exports.getBranch = async (req, res) => {
  const bearerHeader = req.headers.authorization;
  const accessToken = bearerHeader && bearerHeader.split(" ")[1];
  const repositoryName = req.query.repositoryName;
  const organizationName = req.query.organizationName;
  const branchName = req.query.branchName;
  try {
    const branch = await branchesDAO.getBranch(
      accessToken,
      organizationName,
      repositoryName,
      branchName
    );
    if (branch == errorStatus.TNF) {
      response.body = {
        message: errorMessages.TNF,
      };
      res.status(statusCodes.BAD_REQUEST).send(response);
    } else if (branch) {
      response.body = {
        branch: branch,
      };
      res.status(statusCodes.SUCCESS).send(response);
    }
  } catch (error) {
    logger.error(`Error in Github get branch controller : ${error}`);
    if (error.response.status) {
      response.body = {
        message: error.response.data.message,
      };
      res.status(error.response.status).send(response);
    } else {
      response.body = {
        message: error,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};

/**
 * A handler function to create a branch in a repository
 *
 * @param {JSON Object} req The request object
 * @param {JSON OBject} res The response object
 *
 * @returns A created branch object with Http CREATED status code or errors with Http error status codes.
 */
module.exports.createBranch = async (req, res) => {
  const bearerHeader = req.headers.authorization;
  const accessToken = bearerHeader && bearerHeader.split(" ")[1];
  const {
    organizationName,
    repositoryName,
    sourceBranchName,
    targetBranchName,
  } = req.body;
  try {
    const createdBranch = await branchesDAO.createBranch(
      accessToken,
      organizationName,
      repositoryName,
      sourceBranchName,
      targetBranchName
    );
    if (createdBranch == errorStatus.TNF) {
      response.body = {
        message: errorMessages.TNF,
      };
      res.status(statusCodes.BAD_REQUEST).send(response);
    } else if (createdBranch) {
      response.body = {
        createdBranch: createdBranch,
      };
      res.status(statusCodes.SUCCESS).send(response);
    }
  } catch (error) {
    logger.error(`Error in Github created branch controller : ${error}`);
    if (error.response.status == statusCodes.NOT_FOUND) {
      response.body = {
        message: errorMessages.TBAE,
      };
      res.status(error.response.status).send(response);
    } else if (error.response.status == statusCodes.UNPROCESSABLE_ENTITY) {
      response.body = {
        message: errorMessages.CIRI,
      };
      res.status(error.response.status).send(response);
    } else if (error.response.status) {
      response.body = {
        message: error.response.data.message,
      };
      res.status(error.response.status).send(response);
    } else {
      response.body = {
        message: error,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};

/**
 * A handler function to delete a branch from a repository
 *
 * @param {String} req The request query parameters
 * @param {JSON Object} res The response object
 *
 * @returns A boolean value with Http SUCCESS status code or errors with Http error status codes.
 */
module.exports.deleteBranch = async (req, res) => {
  const bearerHeader = req.headers.authorization;
  const accessToken = bearerHeader && bearerHeader.split(" ")[1];
  const repositoryName = req.query.repositoryName;
  const organizationName = req.query.organizationName;
  const branchName = req.query.branchName;
  try {
    const deletedBranch = await branchesDAO.deleteBranch(
      accessToken,
      organizationName,
      repositoryName,
      branchName
    );
    logger.log(
      "info",
      `deletedBranch from controller :  ${JSON.stringify(deletedBranch)}`
    );
    if (deletedBranch == errorStatus.TNF) {
      response.body = {
        message: errorMessages.TNF,
      };
      res.status(statusCodes.BAD_REQUEST).send(response);
    } else if (deletedBranch == statusCodes.NO_CONTENT) {
      response.body = {
        deletedBranch: true,
      };
      res.status(statusCodes.SUCCESS).send(response);
    }
  } catch (error) {
    logger.error(`Error in Github delete branch controller : ${error}`);
    if (error.response.status) {
      response.body = {
        message: error.response.data.message,
      };
      res.status(error.response.status).send(response);
    } else {
      response.body = {
        message: error,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};

/**
 * A handler function to apply policies to branches
 *
 * @param {String} req The request query parameters
 * @param {JSON Object} res The response object
 *
 * @returns Boolean value with Http SUCCESS status code or errors with Http error status codes.
 */
module.exports.applyBranchPolicies = async (req, res) => {
  const bearerHeader = req.headers.authorization;
  const accessToken = bearerHeader && bearerHeader.split(" ")[1];

  const {
    organizationName,
    repositoryName,
    branchName,
    requiredApprovingReviewCount,
  } = req.body;

  try {
    const appliedBranchPolicies = await branchesDAO.applyBranchPolicies(
      accessToken,
      organizationName,
      repositoryName,
      branchName,
      requiredApprovingReviewCount
    );
    if (appliedBranchPolicies == errorStatus.TNF) {
      response.body = {
        message: errorMessages.TNF,
      };
      res.status(statusCodes.BAD_REQUEST).send(response);
    } else if (appliedBranchPolicies) {
      response.body = {
        appliedBranchPolicies: appliedBranchPolicies,
      };
      res.status(statusCodes.SUCCESS).send(response);
    }
  } catch (error) {
    logger.error(`Error in Github get branches controller : ${error}`);
    if (error.response.status) {
      response.body = {
        message: error.response.data.message,
      };
      res.status(error.response.status).send(response);
    } else {
      response.body = {
        message: error,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};

/**
 * A handler function to create branches from organization rule
 *
 * @param {JSON Object} req The request object
 * @param {JSON Object} res The response object.
 *
 * @returns An object of createBranchesFromRule with Http Success status code or errors with Http error codes.
 */
module.exports.createBranchesFromRule = async (req, res) => {
  const bearerHeader = req.headers.authorization;
  const accessToken = bearerHeader && bearerHeader.split(" ")[1];
  const { organizationName, repositoryName } = req.body;

  try {
    const createdBranchesFromRule = await branchesDAO.createBranchesFromRule(
      accessToken,
      organizationName,
      repositoryName
    );
    if (createdBranchesFromRule) {
      response.body = {
        createdBranchesFromRule: createdBranchesFromRule,
      };
      res.status(statusCodes.SUCCESS).send(response);
    }
  } catch (error) {
    logger.error(
      `Error in Github createBranchesFromRule controller : ${error}`
    );
    if (error.response.status) {
      response.body = {
        message: error.response.data.message,
      };
      res.status(error.response.status).send(response);
    } else {
      response.body = {
        message: error,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};

/**
 * A handler function to set different branch as default branch
 *
 * @param {String} req The request query parameters
 * @param {JSON Object} res The response object
 *
 * @returns A boolean value with Http SUCCESS status code or errors with Http error status codes.
 */
module.exports.setDefaultBranch = async (req, res) => {
  const ownername = req.body.ownername;
  const reponame = req.body.reponame;
  const bearerHeader = req.headers.authorization;
  const accessToken = bearerHeader && bearerHeader.split(" ")[1];
  const defaultbranchtoSetName = req.body.defaultbranchtoSetName;

  try {
    const defaultbranch = await branchesDAO.setDefaultBranch(
      accessToken,
      ownername,
      reponame,
      defaultbranchtoSetName
    );
    if (defaultbranch == true) {
      response.body = {
        defaultBranchSet: true,
      };
      return res.status(statusCodes.SUCCESS).send(response);
    }
  } catch (error) {
    // If the call fails, it returns an error message in the response body.
    logger.error("Exception in setdefaultBranch", error);
    if (error.response.status) {
      response.body = {
        message: error.response.data.message,
      };
      res.status(error.response.status).send(response);
    } else {
      response.body = {
        message: error.message,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};
