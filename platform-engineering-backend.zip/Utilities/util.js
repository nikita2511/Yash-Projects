let rules = require("../OrganizationRules/Rules/dao/dao");
let branchesDAO = require("../Azure-Devops/Branches/dao/dao");
let policies = require("../Azure-Devops/Policies/dao/dao");
const azConnection = require("../config/azConnection");
const { getBranch } = require("../Azure-Devops/Branches/dao/dao");
//-------------------logger-implementation-----------------------------
const winston = require("winston");
const { createLogs } = require("../config/loggerConfig");
const todayDate = new Date().toDateString().replace(/\ /g, "");
const logConfiguration = createLogs("utils", todayDate);
const logger = winston.createLogger(logConfiguration);
const { availableDeploymentPlatforms } = require("../sourceCodeLibrary");
//------------------------------------------------------------------------------
/**
 * A function to delay the operation in mili seconds
 *
 * @param {Number} time
 */
function delay(time) {
  return new Promise((resolve) => setTimeout(resolve, time));
}

/**
 * A function to fetch a azure repository by repository name.
 *
 * @param {String} organizationName
 * @param {String} token
 * @param {String} projectName
 * @param {String} repoName
 *
 * @returns An object of repository or error.
 */
async function getRepo(organizationName, token, projectName, repoName) {
  try {
    let connection = azConnection.getConnection(organizationName, token);
    var gitApi = await connection.getGitApi();
    return await gitApi.getRepository(repoName, projectName);
  } catch (error) {
    logger.error("Exception in getRepo", error);
    throw error;
  }
}

/**
 * A function to make a branch as default branch in azure repository
 *
 * @param {String} organization
 * @param {String} token
 * @param {String} projectName
 * @param {String} projectID
 * @param {String} repoName
 * @param {String} defaultBranchName
 *
 * @returns An object of default setted branch or error.
 */
async function setDefaultBranch(
  organization,
  token,
  projectName,
  projectID,
  repoName,
  defaultBranchName,
  existingConnection
) {
  try {
    // const connection = azConnection.getConnection(organization, token);
    let azDevOpsConnection;
    if (!existingConnection) {
      azDevOpsConnection = azConnection.getConnection(organizationName, token);
    } else {
      azDevOpsConnection = existingConnection;
    }
    const gitClient = await azDevOpsConnection.getGitApi();
    const repoDetails = await getRepo(
      organization,
      token,
      projectName,
      repoName
    );
    const repoId = repoDetails.id;
    repoDetails.defaultBranch = "refs/heads/" + defaultBranchName;
    let defaultBranchSet = await gitClient.updateRepository(
      repoDetails,
      repoId,
      projectID
    );
    if (defaultBranchSet) {
      return defaultBranchSet;
    }
  } catch (error) {
    logger.error("Exception in set default branch", error);
  }
}

/**
 * A function to create a branch or branches according to organization rule.
 *
 * @param {String} organizationName
 * @param {String} token
 * @param {String} projectName
 * @param {String} repoName
 *
 * @returns An response object with properties reviewersPolicyCreated, mergeTypePolicyCreated and mergeTypePolicyCreated or error object.
 */
async function createBranchesForModel(
  organizationName,
  token,
  projectName,
  repoName,
  existingConnection
) {
  let response = {};
  let branches = [];
  let projectId;
  let branchesCreated = [];
  let azDevOpsConnection;
  if (!existingConnection) {
    azDevOpsConnection = azConnection.getConnection(organizationName, token);
  } else {
    azDevOpsConnection = existingConnection;
  }
  // let azDevOpsConnection = azConnection.getConnection(organizationName, token);
  coreAPI = await azDevOpsConnection.getCoreApi();
  let projectDetails = await coreAPI.getProject(projectName);
  if (projectDetails) {
    projectId = projectDetails.id;
  }
  let orgRule = await rules.getOrganizationRules(
    organizationName,
    "AzureDevops"
  );
  let branchingStrategy,
    branchFromRule = [];
  let defaultBranchName;
  let createdReviewerPolicies = [];
  let mergeTypePolicies = [];
  let branch;
  let isMainBranchExists = false;
  if (orgRule) {
    branchingStrategy = orgRule.branchingModel;
    branchingStrategy.branches.forEach((branch) => {
      branchFromRule.push(branch.name);
      branches.push({
        name: branch.name,
        mergeType: branch.mergeType,
        reviewersCount: branch.noOfReviewers,
      });
      if (branch.type == "default") {
        defaultBranchName = branch.name;
      }
    });
  }
  let defaultCreatedBranch = await branchesDAO.getAllBranches(
    organizationName,
    token,
    projectName,
    repoName,
    azDevOpsConnection
  );
  let existingBranch = defaultCreatedBranch[0].name;
  var remainingBranchesToCreate = branchFromRule.filter(
    (branch) => existingBranch.indexOf(branch) === -1
  );
  if (remainingBranchesToCreate.length) {
    for (const bname of remainingBranchesToCreate) {
      try {
        let createdBranch = await branchesDAO.createBranch(
          organizationName,
          token,
          projectName,
          repoName,
          existingBranch,
          bname,
          azDevOpsConnection
        );
        do {
          branch = await getBranch(
            organizationName,
            token,
            repoName,
            bname,
            projectName,
            azDevOpsConnection
          );
        } while (branch === null);
        if (branch) {
          branchesCreated.push(createdBranch[0].name);
        } else {
          return false;
        }
      } catch (error) {
        logger.error("Exception in create model for brnaches utilities", error);
      }
    }

    let defaultBranch = await setDefaultBranch(
      organizationName,
      token,
      projectName,
      projectId,
      repoName,
      defaultBranchName,
      azDevOpsConnection
    );
    if (defaultBranch) {
      response.isDefaultBranchSet = true;
    } else {
      response.isDefaultBranchSet = false;
    }

    // = remainingBranchesToCreate.includes("main");
    if (!branchFromRule.includes(existingBranch)) {
      let deletedBranch = await branchesDAO.deleteBranch(
        organizationName,
        token,
        existingBranch,
        projectName,
        repoName,
        azDevOpsConnection
      );
      if (deletedBranch[0].success) {
        mainBranchDeleted = true;
      }
    }
    for (const bname of branches) {
      let createdPolicy = await policies.createReviewerPolicy(
        organizationName,
        token,
        projectId,
        projectName,
        repoName,
        bname.name,
        bname.reviewersCount,
        azDevOpsConnection
      );
      if (createdPolicy.hasOwnProperty("createdBy")) {
        createdReviewerPolicies.push(createdPolicy);
      }
      //mergetype policy
      let mergeTypePolicy = await policies.createMergeTypeStrategy(
        organizationName,
        token,
        projectName,
        projectId,
        repoName,
        bname.name,
        bname.mergeType,
        azDevOpsConnection
      );
      if (createdPolicy.hasOwnProperty("createdBy")) {
        mergeTypePolicies.push(mergeTypePolicy);
      }
    }

    if (
      mergeTypePolicies.length &&
      createdReviewerPolicies.length &&
      branchesCreated.length === remainingBranchesToCreate.length
    ) {
      response.reviewersPolicyCreated = true;
      response.mergeTypePolicyCreated = true;
      response.branchCreation = true;
      return response;
    }
  } else {
    response.reviewersPolicyCreated = false;
    response.mergeTypePolicyCreated = false;
    return response;
  }
}
function getAvailableDeployments() {
  return availableDeploymentPlatforms;
}

exports.createBranchesForModel = createBranchesForModel;
exports.delay = delay;
exports.getAvailableDeployments = getAvailableDeployments;
