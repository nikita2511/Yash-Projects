exports.sourceCodeLibrary = [
  {
    key: "java",
    sourceCode: [
      {
        path: "pom.xml",
        content: `<project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
        xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/maven-v4_0_0.xsd">
        <modelVersion>4.0.0</modelVersion>
        <groupId>org.cloudifysource.examples</groupId>
        <artifactId>java-hello-world-webapp</artifactId>
        <packaging>war</packaging>
        <version>1.0-SNAPSHOT</version>
        <name>java-hello-world-webapp Maven Webapp</name>
        <url>http://maven.apache.org</url>
        <dependencies>
          <dependency>
            <groupId>junit</groupId>
            <artifactId>junit</artifactId>
            <version>3.8.1</version>
            <scope>test</scope>
          </dependency>
        </dependencies>
        <build>
          <finalName>java-hello-world</finalName>
        </build>
        </project>`,
      },
      {
        path: "src/main/webapp/index.jsp",
        content: `<html>
        <body>
        <h2>Hello World ?</h2>
        </body>
        </html>`,
      },
      {
        path: "src/main/webapp/WEB-INF/web.xml",
        content: `<!DOCTYPE web-app PUBLIC
        "-//Sun Microsystems, Inc.//DTD Web Application 2.3//EN"
        "http://java.sun.com/dtd/web-app_2_3.dtd" >
       
       <web-app>
         <display-name>Archetype Created Web Application</display-name>
       </web-app>`,
      },
    ],
  },
  {
    key: "dotNet",
    sourceCode: [
      {
        path: "MySolution.sln",
        content: `
Microsoft Visual Studio Solution File, Format Version 12.00
# Visual Studio 15
VisualStudioVersion = 15.0.26124.0
MinimumVisualStudioVersion = 15.0.26124.0
Project("{FAE04EC0-301F-11D3-BF4B-00C04F79EFBC}") = "MyProject", "MyProject/MyProject.csproj", "{03AE3750-30E4-4944-B08F-DC04F3D476A1}"
EndProject
Global
    GlobalSection(SolutionConfigurationPlatforms) = preSolution
      Debug|Any CPU = Debug|Any CPU
      Debug|x64 = Debug|x64
      Debug|x86 = Debug|x86
      Release|Any CPU = Release|Any CPU
      Release|x64 = Release|x64
      Release|x86 = Release|x86
    EndGlobalSection
    GlobalSection(SolutionProperties) = preSolution
      HideSolutionNode = FALSE
    EndGlobalSection
    GlobalSection(ProjectConfigurationPlatforms) = postSolution
      {03AE3750-30E4-4944-B08F-DC04F3D476A1}.Debug|Any CPU.ActiveCfg = Debug|Any CPU
      {03AE3750-30E4-4944-B08F-DC04F3D476A1}.Debug|Any CPU.Build.0 = Debug|Any CPU
      {03AE3750-30E4-4944-B08F-DC04F3D476A1}.Debug|x64.ActiveCfg = Debug|Any CPU
      {03AE3750-30E4-4944-B08F-DC04F3D476A1}.Debug|x64.Build.0 = Debug|Any CPU
      {03AE3750-30E4-4944-B08F-DC04F3D476A1}.Debug|x86.ActiveCfg = Debug|Any CPU
      {03AE3750-30E4-4944-B08F-DC04F3D476A1}.Debug|x86.Build.0 = Debug|Any CPU
      {03AE3750-30E4-4944-B08F-DC04F3D476A1}.Release|Any CPU.ActiveCfg = Release|Any CPU
      {03AE3750-30E4-4944-B08F-DC04F3D476A1}.Release|Any CPU.Build.0 = Release|Any CPU
      {03AE3750-30E4-4944-B08F-DC04F3D476A1}.Release|x64.ActiveCfg = Release|Any CPU
      {03AE3750-30E4-4944-B08F-DC04F3D476A1}.Release|x64.Build.0 = Release|Any CPU
      {03AE3750-30E4-4944-B08F-DC04F3D476A1}.Release|x86.ActiveCfg = Release|Any CPU
      {03AE3750-30E4-4944-B08F-DC04F3D476A1}.Release|x86.Build.0 = Release|Any CPU
    EndGlobalSection
EndGlobal`,
      },
      {
        path: "MyProject/MyProject.csproj",
        content: `<Project Sdk="Microsoft.NET.Sdk">
        <PropertyGroup>
          <OutputType>Exe</OutputType>
          <TargetFramework>netcoreapp3.1</TargetFramework>
        </PropertyGroup>  
        </Project>`,
      },
      {
        path: "MyProject/Program.cs",
        content: `using System;
        namespace MyProject
        {
          class Program{
            static void Main(string[] args)
            {
              Console.WriteLine("Hello World!");
            }
          }
        }`,
      },
    ],
  },
];
exports.availableDeploymentPlatforms = ["ECS", "EKS", "TOMCAT"];
