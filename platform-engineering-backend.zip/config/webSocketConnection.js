const WebSocket = require("ws");
//-------------------logger-implementation-----------------------------
const winston = require("winston");
const { createLogs } = require("./loggerConfig");
const todayDate = new Date().toDateString().replace(/\ /g, "");
const logConfiguration = createLogs("webSocketConnection", todayDate);
const logger = winston.createLogger(logConfiguration);
//----------------------------------------------------------------------

// const getWSObject = async (port) => {
//   //return new Promise((resolve, reject)=> {
//   try {
//     let ws = new WebSocket.Server({ port: port });
//     return ws;
//     //resolve(ws);
//   } catch (error) {
//     logger.error("Exception in Websocket connection", error);
//     //reject(error)
//     throw error;
//   }
// };

// exports.getWSObject = getWSObject;

// --------------------for modification ------------------------

// const WebSocket = require("ws");

// const wss = new WebSocket.Server({ port: 8080 }); // Change the port as needed
// let clientWebSocket; // Store the connected client WebSocket

// wss.on("connection", (ws) => {
//   console.log("WebSocket connection established");
//   clientWebSocket = ws; // Store the connected client WebSocket

//   // Call createFullProject when the connection is established
//   createFullProject();
// });

// // Function to send a message over WebSocket
// function sendMessage(message) {
//   if (clientWebSocket && clientWebSocket.readyState === WebSocket.OPEN) {
//     clientWebSocket.send(JSON.stringify(message));
//   }
// }

// const createFullProject = async (token, project) => {
//   // return new Promise((resolve, reject) => {
//   let azDevOpsConnection,
//     existingProject,
//     createdProject,
//     successResponse = {},
//     isMainBranchCreated,
//     projectId,
//     count = 0;

//   const {
//     organizationName,
//     name,
//     projectCreatedByUser,
//     description,
//     visibility,
//     capabilities,
//     variableGroups,
//     users,
//     pipeline,
//   } = project;
//   const projectToCreate = { name, description, visibility, capabilities };
//   if (clientWebSocket && clientWebSocket.readyState === WebSocket.OPEN) {
//     console.log("WEbSocket Connection is not in ready state yet....");
//     setTimeout(createFullProject, 1000);
//     return;
//   }

//   // wss.on("connection", async function connection(ws) {
//   try {
//     if (!organizationName) return errorStatus.ONF;
//     azDevOpsConnection = azConnection.getConnection(organizationName, token);

//     sendMessage({ type: "info", message: "Project Created" });

//     existingProject = await checkIfProjectExist(
//       azDevOpsConnection,
//       projectToCreate
//     );
//     if (existingProject.status == errorStatus.CNF) {
//       resolve(existingProject);
//       // return existingProject;
//     } else if (existingProject == true) {
//       resolve(false);
//       /* return false; */
//     } else {
//       createdProject = await createProject(
//         organizationName,
//         token,
//         projectToCreate,
//         azDevOpsConnection
//       );
//       delay(500);
//       logger.log("info", `createdProject ${createdProject}`);
//       let recentCreatedProject;
//       let projectCreatedBy;
//       do {
//         if (count === 5) break;
//         delay(200);
//         recentCreatedProject = await getProject(
//           organizationName,
//           token,
//           projectToCreate.name,
//           azDevOpsConnection
//         );
//         count++;
//       } while (
//         recentCreatedProject === undefined ||
//         recentCreatedProject === null
//       );

//       while (recentCreatedProject.state != "wellFormed") {
//         delay(200);
//         recentCreatedProject = await getProject(
//           organizationName,
//           token,
//           projectToCreate.name,
//           azDevOpsConnection
//         );
//       }

//       successResponse.projectCreation = true;
//       successResponse.message = "project creation is completed";
//       ws.send("Project Created!");

//       projectId = recentCreatedProject.id;

//       let initializedRepo = await repositoryDao.initializeRepoWithReadme(
//         recentCreatedProject.name,
//         organizationName,
//         projectId,
//         token,
//         azDevOpsConnection
//       );
//       logger.log("info", `initialized repo ${initializedRepo}`);
//       sendMessage({ type: "info", message: "Repo Initiatlized" });

//       let operationCount = 0;

//       do {
//         if (operationCount === 2) break;
//         isMainBranchCreated = await repositoryDao.getBranch(
//           organizationName,
//           token,
//           projectToCreate.name,
//           "main",
//           projectToCreate.name,
//           azDevOpsConnection
//         );
//         operationCount++;
//       } while (isMainBranchCreated === null);
//       if (initializedRepo) {
//         successResponse.defaultRepoInitialization = true;
//         successResponse.message = "default repo is initialized";
//         let createdBranchesResponse = await createBranchesForModel(
//           organizationName,
//           token,
//           recentCreatedProject.name,
//           recentCreatedProject.name,
//           azDevOpsConnection
//         );

//         if (createdBranchesResponse) {
//           successResponse.branchCreation =
//             createdBranchesResponse.branchCreation;
//           successResponse.reviewersPolicyCreated =
//             createdBranchesResponse.reviewersPolicyCreated;
//           successResponse.mergeTypePolicyCreated =
//             createdBranchesResponse.mergeTypePolicyCreated;
//           successResponse.isDefaultBranchSet =
//             createdBranchesResponse.isDefaultBranchSet;
//           if (pipeline) {
//             //pipeline creation

//             sendMessage({ type: "info", message: "Pipeline Creation Phase" });

//             const {
//               applicationType,
//               publishArtifacts,
//               userNameInitials,
//               pipelineName,
//               reviewers,
//             } = pipeline;
//             let createdPipeline = await createPipelineWithYMLandPullRequest(
//               organizationName,
//               token,
//               recentCreatedProject.name,
//               recentCreatedProject.name,
//               applicationType,
//               publishArtifacts,
//               userNameInitials,
//               pipelineName,
//               reviewers,
//               azDevOpsConnection
//             );
//             logger.log("info", `createdPipeline ${createdPipeline}`);
//             if (createdPipeline) {
//               successResponse.pipelineCreation = createdPipeline;
//               ws.send("Pipeline Created..");
//             } else {
//               successResponse.pipelineCreation = false;
//             }
//           }
//           if (variableGroups) {
//             const { variableGroupName, description, variables } =
//               variableGroups;
//             logger.log("info", `variableGroups ${variableGroups}`);
//             const createdVariableGroups =
//               await variableGroupsDAO.addVariableGroup(
//                 organizationName,
//                 token,
//                 projectToCreate.name,
//                 variableGroupName,
//                 description,
//                 variables,
//                 azDevOpsConnection
//               );
//             logger.log(
//               "info",
//               `createdVariableGroups ${createdVariableGroups}`
//             );
//             if (createdVariableGroups.id) {
//               successResponse.isVariableGroupsAdded = true;
//               //add user code
//               sendMessage({ type: "info", message: "Variable Group Created!" });
//             }
//           }

//           if (users.length) {
//             let createdUsers = await userDao.addUserToProject(
//               organizationName,
//               token,
//               projectId,
//               users
//             );
//             if (createdUsers.length) {
//               successResponse.userCreation = true;
//               sendMessage({ type: "info", message: "Users Created" });
//             } else {
//               successResponse.userCreation = false;
//             }
//           }

//           //---------------------------this is for saving project details-----------------------------

//           let orgRule = await rules.getOrganizationRules(
//             organizationName,
//             "AzureDevops"
//           );
//           let branchingStrategy;
//           if (orgRule) {
//             branchingStrategy = orgRule.branchingModel;
//           }
//           projectId = recentCreatedProject.id;
//           projectName = recentCreatedProject.name;
//           projectCreatedBy = projectCreatedByUser;
//           projectState = recentCreatedProject.state;
//           branchingModel = branchingStrategy.name;

//           //---------------------------------------------------------------------------------

//           const data = [
//             {
//               projectId: projectId,
//               projectName: projectName,
//               projectCreatedByUser: projectCreatedBy,
//               state: projectState,
//               branchingModel: branchingModel,
//               organizationName: organizationName,
//             },
//           ];

//           const inserted_details = await dbOperations.insertMany(
//             ProjectInfo,
//             data
//           );
//           logger.log("info", `Project Data inserted ${inserted_details}`);
//         }
//         resolve(successResponse);
//       } else {
//         successResponse.defaultRepoInitialization = false;
//         successResponse.message =
//           "Project is created successfully but the repository is not initialized";
//         successResponse.recentCreatedProject = recentCreatedProject;
//         resolve(successResponse);
//       }
//     }
//     wss.close();
//   } catch (error) {
//     logger.error("createFullProject Dao Error =============>", error);
//     reject(error);
//     wss.close();
//     throw error;
//   }
//   // });
// };
