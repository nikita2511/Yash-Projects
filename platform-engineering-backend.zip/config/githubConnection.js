const { Octokit } = require("@octokit/rest");
// const fetch =require("node-fetch")
const getConnection = async (token) => {
  try {
    const octokit = new Octokit({
      //  request: { fetch:fetch },
      auth: token,
    });
    return octokit;
  } catch (error) {
    throw error;
  }
};

module.exports = { getConnection };
