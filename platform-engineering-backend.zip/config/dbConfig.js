const mongoose = require("mongoose");
const {
  USERNAME,
  PASSWORD,
  HOST,
  PORT,
  DATABASE,
  AUTH_SOURCE,
  AUTH_MECHANISM,
} = require("./config.json");

//-------------------logger-implementation-----------------------------
const winston = require("winston");
const { createLogs } = require("./loggerConfig");
const todayDate = new Date().toDateString().replace(/\ /g, "");
const logConfiguration = createLogs("dbConfig", todayDate);
const logger = winston.createLogger(logConfiguration);

//----------------------------------------------------------------------
exports.connect = async () => {
  mongoose
    .connect(
      // "mongodb://" +
      //   HOST +
      //   ":" +
      //   PORT +
      //   "/" +
      //   DATABASE +
      //   "?ssl=true&replicaSet=globaldb",
      // {
      //   auth: {
      //     username: USERNAME,
      //     password: PASSWORD,
      //   },
      //   useNewUrlParser: true,
      //   useUnifiedTopology: true,
      //   retryWrites: false,
      // }
      "mongodb+srv://meeankr07:ankit123@cluster0.hqram.mongodb.net/platform-engineering?authSource=admin&replicaSet=atlas-84syeo-shard-0&readPreference=primary&appname=MongoDB%20Compass&ssl=true"
    )
    .then((connection) => {
      logger.log("info", "Database connection established successfully");
      return true;
    })
    .catch((error) => {
      logger.error("Exception in DB Connection", error);
      throw error;
    });
};
