const azDevops = require("azure-devops-node-api");


//-------------------logger-implementation-----------------------------
const winston = require("winston");
const { createLogs } = require("./loggerConfig");
const todayDate = new Date().toDateString().replace(/\ /g, "");
const logConfiguration = createLogs("azConnection", todayDate);
const logger = winston.createLogger(logConfiguration);
//----------------------------------------------------------------------


const getConnection = (organizationName, token) => {
  let orgUrl = `https://dev.azure.com/${organizationName}`;
  try {
    const authHandler = azDevops.getPersonalAccessTokenHandler(token);
    let connection = new azDevops.WebApi(
      `https://dev.azure.com/${organizationName}`,
      authHandler
    );
    return connection;
  } catch (error) {
    logger.error("Exception in azure connection", error);
    throw new Error("Failed to get Azure connection");
  }
};

module.exports = { getConnection };
