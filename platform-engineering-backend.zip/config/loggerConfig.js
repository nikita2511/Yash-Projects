const winston = require("winston");
const path = require("path");
function createLogs(fileName, date) {
  const logConfiguration = {
    transports: [
      new winston.transports.Console({
        level: "info",
      }),
      new winston.transports.Console({
        level: "error",
      }),
      new winston.transports.Console({
        level: "warn",
      }),
      new winston.transports.File({
        level: "info",
        filename: path.join("logs", date, "info.log"),
      }),
      new winston.transports.File({
        filename: path.join("logs", date, "error.log"),
        level: "error",
      }),
      new winston.transports.File({
        filename: path.join("logs", date, "warn.log"),
        level: "warn",
      }),
    ],
    format: winston.format.combine(
      winston.format.label({
        label: fileName,
      }),
      winston.format.timestamp({
        format: "MMM-DD-YYYY HH:mm:ss",
      }),
      winston.format.printf(
        (info) =>
          `${info.level}: ${info.label}: ${[info.timestamp]}: ${info.message}`
      )
    ),
  };
  return logConfiguration;
}

exports.createLogs = createLogs;
