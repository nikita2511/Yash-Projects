**PLATFORM ENGINEERING**

It is a tool to automate Dev-Ops engineering processes. It assists DevOps engineers by giving them a tool to easily and conveniently decrease repetitive manual tasks. Also, provide a dev-ops option even for developer to use within minimum input and efforts. It increases modularity in the process.

**Tools And Technologies Used**

-   ReactJs
-   Material UI
-   Azure MSAL Browser
-   Azure MSAL React
-   Axios
-   React Router DOM
-   NodeJs
-   Azure Dev-Ops Node API
-   Express
-   CORS
-   Mongoose
-   MongoDB
-   Mongo Shell
-   MongoDB Compass

**Detailed Features of Platform Engineering (PE)**

-   **Ease of Devops processes**

    Platform Engineering is the product or portal that provides Devops in easy to manage way. It reduces the repeating manual steps perform by Devops engineers.

-   **Ease of handling various Devops platfrom at one place.**

    In our portal we provide **Azure and GitHub under one roof, i.e.** Devops process of Azure and GitHub in single portal with **similar user interface.**

    Devops engineer can perform Azure devops process with Azure Devops login or he/she can perform Github devops process with Github login.

**Azure Dev Ops Features**

-   **Log In with Azure Active Directory(AAD)**

    In our portal we have connected login functionality with Azure active directory which is general practice to log in any of Microsoft application. It is also suitable method of login for any of the organization.

-   **Manage multiple Active directories**

    User having an option to add multiple active directories if he/she having access of it. User can make anyone of them as primary which will be used in his Active directory login and also after login user can switch directory.

-   **Organization Rules**

    After login a list of accessible organization is visible to user. But before entering any of the organization user must define rules for it. Rules includes

1.  what should be the Naming convention for the Project Name
2.  Number of branches, default name, and what should branch strategy (no of reviewer and merge type)
-   **Project create with multiple features with single click**

    When we create any of the project in azure devops we can add Repository with branches and branch strategy, variables, add users and unique one create CI pipeline with single click.

    In enterprise level devops process it is useful features because as of in Azure Devops user need to create a project and repos and branches in that separately.

-   **Ease of add other features in existing projects**

    After creating project, we can also create repository, variables, add user and create pipeline separately. Repository and branches will be created according to organization rule.

-   **Ease of adding release pipeline**

    For available CI pipeline user can create release pipeline to deploy code with minimum inputs.

**GitHub features**

-   **Login with Github LogIn APIs**

    For Github User can authenticate him/her self with Github login APIs, i.e. we redirect user to github login page then authenticate user with github user id and password.

-   **Organization Rules**

    After login a list of accessible organization is visible to user. But before entering any of the organization user must define rules for it. Rules includes

1.  what should be the Naming convention for the Repository Name
2.  Number of branches, default name and what should branch strategy (no of reviewer and merge type)
-   **Repository creation with multiple features with single click**
    1.  We can create repository with default initialization and one default environment.
    2.  We can create branches according to the branching model we defined in organization rules.
    3.  We can apply branch protection to the branches which includes reviewers count and merge type policy.
    4.  We can add variables to the environment and having a provision of uploading the variables with JSON file too.
    5.  We can also create build and release pipeline with minimum input and user-friendly UI.
-   **Ease of add other features in existing Repository**

    Along with all the feature set creation one go, we can manage all the features individually as well.

1.  We can create repository(which manages default initialization, branch creation and branch protection internally), environment, variables.
2.  We can create CI/CD pipeline.
3.  We can update existing CI pipeline to create release.
4.  We can add collaborators to repository.
-   **Ease of add user to organization**
1.  We can add users to organization

Architeture Diagram

![Click Here to get Architecture Diagram ](images/ArchitechtureDiagram.png)

Platform Engineering- Documentation to update library files.

Platform Engineering is a tool which support greater level of extensibility for e.g. currently we have deployment support for two technologies (Java & .NET) but it can extends to support CI/CD of any of the technology in both Github and Azure. For that we have managed our own libraries for sample source code, Github build and deployment task and Azure build and deployment task.

**Here are some steps if we add new technology CI/CD in Azure**

**Steps to add or update build tasks in Azure**

-   Go to folder Azure-Devops and look for a file 'library.js' and look for buildTasks list in YMLConfigTasks list.
-   Add a JSON object with keys "key" for technology e.g. java, "pool" for platform e.g. ubuntu-20.04, "buildTasks" for list of build phase steps e.g.

    {

    task: "Maven@3",

    displayName: "Maven Package",

    inputs: {

    mavenPomFile: "pom.xml",

    },

    }

-   Append a JSON object of task in buildTasks list for a technology.

**Steps to add or update Publish Artifacts tasks in Azure**

-   Go to folder Azure-Devops and look for a file 'library.js' and look for publishArtifactsTasks list in YMLConfigTasks list.
-   Add a JSON object with key "publishArtifactsTasks" for list of publish artifacts steps e.g.

    {

    upload: "\$(Build.ArtifactStagingDirectory)/target",

    artifact: "drop",

    }

-   Append a JSON object of task in publishArtifactsTasks list to update steps in Publish Artifacts steps.

**Here are some steps if we add new technology CI/CD in GitHub**

**Steps to add or update build task in Github**

-   Go to folder Github and look for a file 'github-library.js' and look for YMLConfigBuildTasks list.

    Add a JSON object with keys "key" for technology e.g. java, "runs-on" for platform e.g. ubuntu-latest, "steps" for build steps e.g.

    {

    name: "Setup JDK 1.8",

    uses: "actions/setup-java@v1",

    with: {

    distribution: "corretto",

    "java-version": 1.8,

    },

    },

-   Append a JSON object of task in steps list to update steps for a technology.

**Steps to add or update deployment task in Github**

-   Go to folder Github and look for a file 'github-library.js' and look for YMLConfigDeploymentTasks list.
-   Add a JSON object with keys "platform" for deployment platform e.g. TOMCAT, "steps" for deployment steps list, "env_variables" for variables needed for deployment e.g. TOMCAT_HOST.
-   Add a JSON object in steps list with keys "key" e.g. build or deploy and add steps in value list for phase build e.g.

    {

    name: "Build, tag, and push image to Amazon ECR",

    id: "build-image",

    env: {

    ECR_REGISTRY: "\${{ steps.login-ecr.outputs.registry }}",

    IMAGE_TAG: "\${{ github.sha }}",

    },

    run: \`\# Build a docker container and\\n\# push it to ECR so that it can\\n\# be deployed to ECS.\\nls\\npwd\\ndocker build -t \$ECR_REGISTRY/\$ECR_REPOSITORY:\$IMAGE_TAG .\\ndocker push \$ECR_REGISTRY/\$ECR_REPOSITORY:\$IMAGE_TAG\\necho "::set-output name=image::\$ECR_REGISTRY/\$ECR_REPOSITORY:\$IMAGE_TAG"\\n\`,

    },

    or phase deploy

    {

    name: "Deploy Amazon ECS task definition",

    uses: "aws-actions/amazon-ecs-deploy-task-definition@de0132cf8cdedb79975c6d42b77eb7ea193cf28e",

    with: {

    "task-definition":

    "\${{ steps.task-def.outputs.task-definition }}",

    service: "\${{ env.ECS_SERVICE }}",

    cluster: "\${{ env.ECS_CLUSTER }}",

    "wait-for-service-stability": true,

    },

    },

-   Append a JSON object in value list of build or deploy to update steps.

**Steps to add or update source code for different technology**

-   Go to file 'sourceCodeLibrary.js' and look for sourceCodeLibrary list.
-   Add a JSON object with keys "key" for technology e.g. java and "sourceCode" for list of source code files.
-   Add a JSON object with Keys "path" for file path e.g. pom.xml and "content" for file content.

    e.g.

    {

    path: "pom.xml",

    content:

    \`\<project xmlns="http://maven.apache.org/POM/4.0.0" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"

    xsi:schemaLocation="http://maven.apache.org/POM/4.0.0 http://maven.apache.org/maven-v4_0_0.xsd"\>

    \<modelVersion\>4.0.0\</modelVersion\>

    \<groupId\>org.cloudifysource.examples\</groupId\>

    \<artifactId\>java-hello-world-webapp\</artifactId\>

    \<packaging\>war\</packaging\>

    \<version\>1.0-SNAPSHOT\</version\>

    \<name\>java-hello-world-webapp Maven Webapp\</name\>

    \<url\>http://maven.apache.org\</url\>

    \<dependencies\>

    \<dependency\>

    \<groupId\>junit\</groupId\>

    \<artifactId\>junit\</artifactId\>

    \<version\>3.8.1\</version\>

    \<scope\>test\</scope\>

    \</dependency\>

    \</dependencies\>

    \<build\>

    \<finalName\>java-hello-world\</finalName\>

    \</build\>

    \</project\>\`

    },

-   Append a JSON object in sourceCode list to update source code files for a technology.

**Steps to add deployment platforms.**

-   Go to file 'sourceCodeLibrary.js' and look for availableDeploymentPlatforms list.
-   Add a deployment platform in availableDeploymentPlatforms list e.g. TOMCAT.

**Steps to import the api collection.**

-   Go to the 'APi-docs' folder and look for the JSON file ZIP "Platform-Engineering.postman_collection".
-   Download the ZIP file and exract to the specific folder.
-   Open postman App(web or desktop) look for the option "import".

    ![Click Here to get Architecture Diagram ](images/import.PNG)

-   After clicking the import option choose or drag the extracted JSON file.
    

**Steps to publish imported collection(If you want to publish your collection)**

-   Go to the postman and look for the option "view documentation".

    ![](images/view-documentation.PNG)

-   At the right corner click on 'publish' option.

    ![Click Here to get Architecture Diagram ](images/publishOptionOnPostman.PNG)

-   After ckicking on 'publish option' you will be redirected to the postman web page.
-   At the bottom of the page click on the option 'publish'.

    ![Click Here to get Architecture Diagram ](images/publishOptionOnWeb.PNG)

-   After that copy the generated published url.


**Platform Engineering UI**
-  Folder Structure for Azure and Github Describing the folder structures and placements of  components and sub-components for azure as well as github.
-  src/assets : Contains files like  images,svg,logo.
-  src/components : Contains all the javascript files for Azure and Github.
-  src/components/azure : Contains sub folders of Active Directory info, Dashboard, Onboarding, Organization, Projects.
-  src/components/error : Contains error handling javascript files.
-  src/components/github : Contains sub folders of Client info, Dashboard, Onboarding, Organization, Repositories.
-  src/router : Contains javascript file for routing/navigaton purpose.
-  src/utils : Contains Js files for Landing bar, Progress Bar, API Url constants, Helper.
-  src/authConfig : Contains JavaScript files MSAL authenticattion related code for Azure.
-  src/DevOpsPlatformSelector : Contains Github related authenticattion code.
-  src/Config : Contains Server URL.

** Folder Structure for Azure**
 ![Click Here to get Architecture Diagram ](images/azure.png)


 **Flow Diagram for  Azure**

![Click Here to get Architecture Diagram ](images/azure-flow-diagram.PNG)

 -  The above flow diagram showcase end to end flow for the azure referencing to the UI screen. As how the components calling one an after.
![Click Here to get Architecture Diagram ](images/azureflowDiagram.png)


 **Flow Diagram for  Github**

![Click Here to get Architecture Diagram ](images/github-FD.PNG)

 -  The above flow diagram showcase end to end flow for the github referencing to the UI screen. As how the components calling one an after.
![Click Here to get Architecture Diagram ](images/gitflow.png)

