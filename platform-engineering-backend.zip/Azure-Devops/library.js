exports.YMLConfigTasks = [
  {
    key: "java",
    value: {
      pool: {
        vmImage: "ubuntu-20.04",
      },
      tasks: {
        build: {
          task: "Maven@3",
          displayName: "Build Maven",
          inputs: {
            mavenPomFile: "pom.xml",
            goals: "package",
            publishJUnitResults: true,
            testResultsFiles: "**/surefire-reports/TEST-*.xml",
            javaHomeOption: "JDKVersion",
            jdkVersionOption: "1.8",
            mavenVersionOption: "Default",
            mavenOptions: "-Xmx3072m",
            mavenAuthenticateFeed: false,
            effectivePomSkip: false,
            sqMavenPluginVersionChoice: "latest",
          },
        },
        publishArtifacts: {
          task: "PublishBuildArtifacts@1",
          displayName: "Publish Artifacts",
          inputs: {
            PathtoPublish: "$(Build.ArtifactStagingDirectory)",
            ArtifactName: "drop",
            publishLocation: "Container",
          },
        },
        copyFiles: {
          task: "CopyFiles@2",
          inputs: {
            Contents: "**/*.jar",
            TargetFolder: "$(Build.ArtifactStagingDirectory)",
          },
        },
      },
    },
    pool: {
      vmImage: "ubuntu-20.04",
    },
    buildTasks: [
      {
        task: "Maven@3",
        displayName: "Maven Package",
        inputs: {
          mavenPomFile: "pom.xml",
        },
      },
    ],
    publishArtifactsTasks: [
      {
        task: "CopyFiles@2",
        displayName: "Copy Files to artifact staging directory",
        inputs: {
          SourceFolder: "$(System.DefaultWorkingDirectory)",
          Contents: "**/target/*.?(war|jar)",
          TargetFolder: "$(Build.ArtifactStagingDirectory)",
        },
      },
      {
        upload: "$(Build.ArtifactStagingDirectory)/target",
        artifact: "drop",
      },
    ],
  },
  {
    key: "dotNet",
    value: {
      pool: {
        vmImage: "windows-latest",
      },
      tasks: {
        build: {
          task: "DotNetCoreCLI@2",
          inputs: {
            command: "build",
            projects: "*.sln",
            arguments:
              "--output $(Build.BinariesDirectory)/publish_output --configuration Release",
          },
        },
        publishArtifacts: {
          task: "PublishBuildArtifacts@1",
          inputs: {
            PathtoPublish: "$(Build.ArtifactStagingDirectory)",
            ArtifactName: "drop",
            publishLocation: "Container",
          },
        },
        restorePackages: {
          task: "DotNetCoreCLI@2",
          displayName: "Restore",
          inputs: { command: "restore", projects: "**/*.sln" },
        },
        archiveFiles: {
          task: "ArchiveFiles@2",
          inputs: {
            rootFolderOrFile: "$(Build.BinariesDirectory)/publish_output",
            includeRootFolder: false,
            archiveType: "zip",
            archiveFile:
              "$(Build.ArtifactStagingDirectory)/$(Build.BuildId).zip",
            replaceExistingArchive: true,
          },
        },
      },
    },
    pool: {
      vmImage: "windows-latest",
    },
    buildTasks: [
      {
        task: "DotNetCoreCLI@2",
        displayName: "Restore",
        inputs: { command: "restore", projects: "**/*.sln" },
      },
      {
        task: "DotNetCoreCLI@2",
        inputs: {
          command: "build",
          projects: "*.sln",
          arguments:
            "--output $(Build.BinariesDirectory)/publish_output --configuration Release",
        },
      },
    ],
    publishArtifactsTasks: [
      {
        task: "ArchiveFiles@2",
        inputs: {
          rootFolderOrFile: "$(Build.BinariesDirectory)/publish_output",
          includeRootFolder: false,
          archiveType: "zip",
          archiveFile: "$(Build.ArtifactStagingDirectory)/$(Build.BuildId).zip",
          replaceExistingArchive: true,
        },
      },
      {
        task: "PublishBuildArtifacts@1",
        inputs: {
          PathtoPublish: "$(Build.ArtifactStagingDirectory)",
          ArtifactName: "drop",
          publishLocation: "Container",
        },
      },
    ],
  },
];
