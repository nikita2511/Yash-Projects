const pipelineDao = require("../dao/dao");
const {
  errorStatus,
  errorMessages,
  responsHeader,
  statusCodes,
  successMessages,
} = require("../../../constants");
//-------------------logger-implementation-----------------------------
const winston = require("winston");
const { createLogs } = require("../../../config/loggerConfig");
const todayDate = new Date().toDateString().replace(/\ /g, "");
const logConfiguration = createLogs("Pipelines Controller", todayDate);
const logger = winston.createLogger(logConfiguration);
//------------------------------------------------------------------------------
let response = {
  headers: responsHeader,
  body: {},
};

module.exports.createYamlConfiguration = async (req, res) => {
  // Get the bearer token from the request header
  const bearerHeader = req.headers.authorization;
  const personalAccessToken = bearerHeader && bearerHeader.split(" ")[1];
  const {
    organizationName,
    projectName,
    repoName,
    applicationType,
    publishArtifacts,
    userNameInitials,
  } = req.body;
  // Get the organization name, project name, repo name, application type, publish artifacts, and user name initials from the request body.

  try {
    // Try to create the YAML configuration using the pipeline dao. If the creation is successful, the function sends a response with the created YAML configuration. If the creation fails, the function throws an error.
    let createdYamlConfig = await pipelineDao.createYamlConfiguration(
      organizationName,
      personalAccessToken,
      repoName,
      projectName,
      applicationType,
      publishArtifacts,
      userNameInitials
    );
    if (createdYamlConfig.status) {
      // If the creation is successful, send a response with the created YAML configuration.
      response.body = {
        createdYamlConfig: createdYamlConfig,
      };
      return res.status(statusCodes.CREATED).send(response);
    } else if (createdYamlConfig == false) {
      // If the creation fails, throw an error.
      throw new Error("Unable to create Yaml Configuration.");
    }
  } catch (error) {
    // Catch any errors that occur and send a response with the error details.
    logger.error("Exception in createYamlConfiguration", error);
    if (error.statusCode) {
      response.body = {
        errorStatus: error.statusCode,
        errorMessage: error.message,
      };
      res.status(error.statusCode).send(response);
    } else if (error.statusCode == statusCodes.BAD_REQUEST) {
      response.body = {
        message: "Authentication Failed",
        errorStatus: error.statusCode,
      };
      res.status(error.statusCode).send(response);
    }
    response.body = {
      errorStatus: error,
      errorMessage: error.message,
    };
    return res.status(statusCodes.SERVER_ERROR).send(response);
  }
};

/**
 * Handler function to create YML from JSON
 *
 * @param {JSON Object} req The request object.
 * @param {JSON Object} res The response object.
 * @returns createdYML with success status codes or with Http error status codes
 */
module.exports.createYMLfromJson = async (req, res) => {
  // Get the ymlJsonObject from the request body
  const ymlJsonObject = req.body;

  try {
    // Create the ymlConfiguration using the ymlJsonObject
    const ymlConfiguration = await pipelineDao.createYMLfromJson(ymlJsonObject);

    // Log the ymlConfiguration
    logger.log(
      "info",
      `inside createYMLfromJson controller ${ymlConfiguration}`
    );

    // Check if the ymlConfiguration is not found
    if (ymlConfiguration === "YML_JSON_OBJECT_NOT_FOUND") {
      // Set the response body to an error message
      response.body = {
        message: "Json object to create a YAML configuration not found!",
      };

      // Return a status code of 404 (Not Found)
      return res.status(statusCodes.NOT_FOUND).send(response);
    }

    // Set the response body to the ymlConfiguration
    response.body = {
      ymlConfiguration: ymlConfiguration,
    };

    // Return a status code of 200 (OK)
    return res.status(statusCodes.SUCCESS).send(response);
  } catch (error) {
    // Log the exception
    logger.error("Exception in ymlConfiguration controller", error);

    // Set the response body to the exception
    response.body = {
      error: error,
    };

    // Return a status code of 500 (Internal Server Error)
    return res.status(statusCodes.SERVER_ERROR).send(response);
  }
};

module.exports.createPipeline = async (req, res) => {
  // Get the personal access token from the request header
  const bearerHeader = req.headers.authorization;
  const personalAccessToken = bearerHeader && bearerHeader.split(" ")[1];

  // Get the request body parameters
  const {
    organizationName,
    projectName,
    repoName,
    applicationType,
    pipelineName,
  } = req.body;

  // Create a new pipeline
  let createdPipeline;
  try {
    createdPipeline = await pipelineDao.createPipeline(
      organizationName,
      personalAccessToken,
      projectName,
      repoName,
      applicationType,
      pipelineName
    );
    logger.log("info", `created pipeline controller ${createdPipeline}`);

    // Check if the pipeline was created successfully
    if (createdPipeline == errorStatus.ONF) {
      response.body = {
        message: errorMessages.ONF,
      };
      return res.status(statusCodes.NOT_FOUND).send(response);
    } else if (createdPipeline == errorStatus.TNF) {
      response.body = {
        message: errorMessages.TNF,
      };
      return res.status(statusCodes.NOT_FOUND).send(response);
    } else if (createdPipeline) {
      response.body = {
        createdPipeline: createdPipeline,
      };
      return res.status(statusCodes.CREATED).send(response);
    }
  } catch (error) {
    // Log the exception
    logger.error("Exception in create pipeline controller", error);

    // Send an error response to the client
    response.body = {
      message: error.response.data.message,
    };
    return res.status(error.response.status).send(response);
  }
};
/**
 * Handleer Function for ListPipeline
 *
 * @param {JSON Object} req The request object.
 * @param {JSON Object} res The response object.
 * @returns listPipeline object with success status codes or error with Http error status codes
 */
module.exports.listPipeline = async (req, res) => {
  // Get the personal access token from the request header.
  const bearerHeader = req.headers.authorization;
  const personalAccessToken = bearerHeader && bearerHeader.split(" ")[1];

  // Get the organization name and project name from the request query parameters
  const { organizationName, projectName } = req.query;
  logger.log(
    "info",
    "rquest query parameters create pipeline controller",
    req.query
  );
  try {
    let listPipelines = await pipelineDao.listPipeline(
      organizationName,
      personalAccessToken,
      projectName
    );
    logger.log(
      "info",
      "list of pipelines create pipeline controller",
      listPipelines
    );
    // If the list of pipelines is not empty, send it back to the client
    if (listPipelines) {
      response.body = {
        listPipelines: listPipelines,
      };
      res.status(statusCodes.SUCCESS).send(response);
    } else {
      // Otherwise, send back an error message
      response.body = {
        errorStatus: statusCodes.NOT_FOUND,
        errorMessages: errorMessages.NRF,
      };
      res.status(statusCodes.NOT_FOUND).send(response);
    }
  } catch (error) {
    logger.error("Exception in list pipeline", error);
    // If the error has a status code, send it back to the client
    if (error.statusCode) {
      response.body = {
        errorStatus: error.statusCode,
        errorMessage: error.message,
      };
      res.status(error.statusCode).send(response);
    } else if (error.response) {
      // Otherwise, if the error has a response, send back the response status code and message
      response.body = {
        errorStatus: error.response.status,
        errorMessage: error.response.data.message,
      };
      res.status(error.response.status).send(response);
    } else {
      response.body = {
        errorStatus: error,
        errorMessage: error.message,
      };
      return res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};

/**
 * 
 /**
 * handler function to create Pipeline with YML and PullRequest
 * 
 * @param {JSON Object} req The request object.
 * @param {JSON Object} res The response object.
 * 
 * @returns An object of createPipelineWithYmlandPullRequest with success status codes or error with Http error status codes.
 */
module.exports.createPipelineWithYMLandPullRequest = async (req, res) => {
  // Get the bearer header and personal access token from the request.
  const bearerHeader = req.headers.authorization;
  const personalAccessToken = bearerHeader && bearerHeader.split(" ")[1];
  // Get the organization name, project name, repo name, application type, publish artifacts, user name initials, pipeline name, and reviewers from the request body.
  const {
    organizationName,
    projectName,
    repoName,
    applicationType,
    publishArtifacts,
    userNameInitials,
    pipelineName,
    reviewers,
  } = req.body;

  try {
    // Try to create the pipeline with yaml and pull request using the pipeline dao.
    let createdPipelineWithYMLAndPullRequest =
      await pipelineDao.createPipelineWithYMLandPullRequest(
        organizationName,
        personalAccessToken,
        projectName,
        repoName,
        applicationType,
        publishArtifacts,
        userNameInitials,
        pipelineName,
        reviewers
      );
    logger.log(
      "info",
      "createdPipelineWithYMLAndPullRequest controller",
      createdPipelineWithYMLAndPullRequest
    );
    // If the pipeline was created successfully, send a response with the created pipeline.
    if (createdPipelineWithYMLAndPullRequest) {
      response.body = {
        createdPipeline: createdPipelineWithYMLAndPullRequest,
      };
      res.status(statusCodes.CREATED).send(response);
    } else {
      // Otherwise, throw an error.
      throw new Error("Unable to create yaml and pr request ");
    }
  } catch (error) {
    // Log the error.
    logger.error("Exception in createdPipelineWithYMLAndPullRequest", error);

    // If the error message includes the application type, send a response with a REQUEST_CONFLICT status code.
    if (error.message.includes(`${applicationType}-azure-pipelines.yml`)) {
      response.body = {
        errorMessage: `Pipeline already exists for ${applicationType}.`,
      };
      res.status(statusCodes.REQUEST_CONFLICT).send(response);
    } else if (error.response) {
      response.body = {
        errorMessage: error.response.data.message,
      };
      res.status(error.response.status).send(response);
    } else if (error.statusCode) {
      response.body = {
        errorMessage: error.message,
      };
      res.status(error.statusCode).send(response);
    } else if (error.statusCode == statusCodes.BAD_REQUEST) {
      response.body = {
        errorStatus: error.statusCode,
        errorMessage: "Authentication Failed",
      };
      res.status(error.statusCode).send(response);
    } else {
      response.body = {
        errorStatus: error,
        errorMessage: error.message,
      };
      return res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};

/**
 * handler function to commit JavaSkeletonCode
 *
 * @param {JSON Object} req The request object.
 * @param {JSON Object} res The response object.
 */
module.exports.commitJavaSkeltonCode = async (req, res) => {
  // Get the personal access token from the authorization header
  const bearerHeader = req.headers.authorization;
  const personalAccessToken = bearerHeader && bearerHeader.split(" ")[1];

  // Get the required parameters from the request body
  const { organizationName, projectName, repoName, featureBranchName } =
    req.body;

  // Commit the Java skeleton code to the specified branch
  const javaSkeletonCodeCommit = await pipelineDao.commitJavaSkeltonCode(
    organizationName,
    personalAccessToken,
    projectName,
    repoName,
    featureBranchName
  );

  // Log the commit details
  if (javaSkeletonCodeCommit)
    logger.log(
      "info",
      "javaSkeletonCodeCommit controller",
      javaSkeletonCodeCommit
    );

  // Send the response to the client
  res.send(statusCodes.SUCCESS).send(javaSkeletonCodeCommit);
};

/**
 * handler function to commit DotnetSkeletonCode
 *
 * @param {JSON Object} req The request object.
 * @param {JSON Object} res The response object.
 */
module.exports.commitDotnetSkeletonCode = async (req, res) => {
  // Get the personal access token from the request header
  const bearerHeader = req.headers.authorization;
  const personalAccessToken = bearerHeader && bearerHeader.split(" ")[1];

  // Get the required parameters from the request body
  const { organizationName, projectName, repoName, featureBranchName } =
    req.body;

  // Commit the .NET skeleton code to the specified branch
  const commitedDotnetSkeletonCode = await pipelineDao.commitDotnetSkeletonCode(
    organizationName,
    personalAccessToken,
    projectName,
    repoName,
    featureBranchName
  );

  // If the commit was successful, log the result and send a success response
  if (commitedDotnetSkeletonCode) {
    logger.log(
      "info",
      "commitedDotnetSkeletonCode controller",
      commitedDotnetSkeletonCode
    );
    res.status(statusCodes.SUCCESS).send(commitedDotnetSkeletonCode);
  }
};

/**
 * A handler function to add task group to a project
 *
 * @param {JSON Object} req The request object
 * @param {JSON Object} res The response object
 *
 * @returns An object of task groups with Http SUCCESS status code or an error object with Http error status code
 */
module.exports.addTaskGroup = async (req, res) => {
  const bearerHeader = req.headers.authorization;
  const personalAccessToken = bearerHeader && bearerHeader.split(" ")[1];
  const { organizationName, projectId, taskGroup } = req.body;
  try {
    const addedTaskGroup = await pipelineDao.addTaskGroup(
      organizationName,
      personalAccessToken,
      projectId,
      taskGroup
    );
    logger.log(
      "info",
      `addedTaskGroup from controller : ${JSON.stringify(addedTaskGroup.data)}`
    );
    if (addedTaskGroup) {
      response.body = {
        addedTaskGroup: addedTaskGroup.data,
      };
      res.status(addedTaskGroup.status).send(response);
    }
  } catch (error) {
    logger.error(`Error from add task group controller :`, error);
    if (error.response.status) {
      response.body = {
        message: error.response.data.message,
      };
      res.status(error.response.status).send(response);
    } else {
      response.body = {
        message: errorMessages.ISE,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};

/**
 * A handler function to list available agents.
 *
 * @param {String} req The request query parameters.
 * @param {JSON Object} res The response object.
 *
 * @returns A list of agent objects with Http SUCCESS status code or an error message with Http error status code.
 */
module.exports.getAgentList = async (req, res) => {
  const bearerHeader = req.headers.authorization;
  const personalAccessToken = bearerHeader && bearerHeader.split(" ")[1];

  const organizationName = req.query.organizationName;
  const projectId = req.query.projectId;

  try {
    const agentList = await pipelineDao.getAgentList(
      organizationName,
      personalAccessToken,
      projectId
    );
    if (agentList) {
      response.body = {
        agentList: agentList,
      };
      res.status(statusCodes.SUCCESS).send(response);
    } else if (!agentList) {
      response.body = {
        message: errorMessages.ANF,
      };
      res.status(statusCodes.UNPROCESSABLE_ENTITY).send(response);
    }
  } catch (error) {
    logger.error(`Error from get agents controller :`, error);
    if (error.statusCode) {
      response.body = {
        message: error.result.message,
      };
      res.status(error.statusCode).send(response);
    } else {
      response.body = {
        message: errorMessages.ISE,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};

/**
 * A handler function to list task groups for a project.
 *
 * @param {String} req The request query parameters.
 * @param {JSON Object} res The response object.
 *
 * @returns A list of task groups object with Http SUCCESS status code or an error message with Http error status code.
 */
module.exports.getTaskGroup = async (req, res) => {
  const bearerHeader = req.headers.authorization;
  const personalAccessToken = bearerHeader && bearerHeader.split(" ")[1];
  const { organizationName, projectName } = req.query;
  try {
    const taskGroups = await pipelineDao.listTaskGroup(
      organizationName,
      projectName,
      personalAccessToken
    );
    let variablesArray = [];
    if (taskGroups.count) {
      for (const taskGroup of taskGroups.value) {
        if (taskGroup.inputs.length) {
          for (let element of taskGroup.inputs) {
            if (!variablesArray.includes(element.name)) {
              variablesArray.push(element.name);
            }
          }
        }
        for (const element of taskGroup.tasks) {
          element.taskId = element.task.id;
          element.version = element.task.versionSpec;
          element.name = element.displayName;
          element.definitionType = element.task.definitionType;
          delete element.task;
        }
      }
    }
    logger.log(
      "info",
      `List tasks groups: ${JSON.stringify(taskGroups.value)}`
    );
    logger.log("info", `variablesArray : ${JSON.stringify(variablesArray)}`);
    if (taskGroups.value) {
      response.body = {
        taskGroups: taskGroups.value,
        variables: variablesArray,
      };
      res.status(statusCodes.SUCCESS).send(response);
    } else {
      response.body = {
        taskGroup: successMessages.NTGF,
      };
      res.status(statusCodes.SUCCESS).send(response);
    }
  } catch (error) {
    logger.error(`Error from add task group controller :`, error);
    if (error.response.status) {
      response.body = {
        message: error.response.data.message,
      };
      res.status(error.response.status).send(response);
    } else {
      response.body = {
        message: errorMessages.ISE,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};

/**
 * A Handler function to list builds
 *
 * @param {String} req The request query parameters.
 * @param {JSON Object} res The response object.
 *
 * @returns A list of build objects with Http SUCCESS status code or an error message with Http error status code.
 */
module.exports.getBuilds = async (req, res) => {
  const bearerHeader = req.headers.authorization;
  const personalAccessToken = bearerHeader && bearerHeader.split(" ")[1];
  const { organizationName, projectName } = req.query;
  try {
    const Builds = await pipelineDao.listBuilds(
      organizationName,
      projectName,
      personalAccessToken
    );
    if (Builds.value) {
      response.body = {
        Builds: Builds.value,
      };
      res.status(statusCodes.SUCCESS).send(response);
    } else {
      response.body = {
        Builds: successMessages.NBF,
      };
      res.status(statusCodes.SUCCESS).send(response);
    }
  } catch (error) {
    logger.error(`Error from get Builds  controller :`, error);
    if (error.response.status) {
      response.body = {
        message: error.response.data.message,
      };
      res.status(error.response.status).send(response);
    } else {
      response.body = {
        message: errorMessages.ISE,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};

/**
 * A handler function to create a release defintion and a release pipeline for it
 *
 * @param {JSON Object} req The request object
 * @param {JSON Object} res The response object
 *
 * @returns An JSON object with properties releasePipeline and releaseDefintion as Boolean with Http SUCEESS status code or an error message with Http error status code
 */
module.exports.createReleasePipeline = async (req, res) => {
  const bearerHeader = req.headers.authorization;
  const personalAccessToken = bearerHeader && bearerHeader.split(" ")[1];

  const {
    organizationName,
    projectName,
    projectId,
    stageName,
    queueId,
    agentName,
    tasks,
    branchesForStageTrigger,
    branchesForArtifactTrigger,
    CIPipelineId,
    CIPipelineName,
    description,
    name,
  } = req.body;

  try {
    const createdReleasePipelineResponse =
      await pipelineDao.createReleasePipeline(
        organizationName,
        personalAccessToken,
        projectName,
        projectId,
        stageName,
        queueId,
        agentName,
        tasks,
        branchesForStageTrigger,
        branchesForArtifactTrigger,
        CIPipelineId,
        CIPipelineName,
        description,
        name
      );

    if (createdReleasePipelineResponse == errorStatus.NBF) {
      response.body = {
        message: errorMessages.NBF,
      };
      res.status(statusCodes.UNPROCESSABLE_ENTITY).send(response);
    } else if (
      createdReleasePipelineResponse.releaseDefintion &&
      createdReleasePipelineResponse.releasePipeline
    ) {
      response.body = {
        releasePipeline: true,
        releaseDefintion: true,
      };
      res.status(statusCodes.SUCCESS).send(response);
    } else {
      response.body = {
        message: errorMessages.RDNF,
      };
      res.status(statusCodes.UNPROCESSABLE_ENTITY).send(response);
    }
  } catch (error) {
    logger.error(`Error from create release pipeline controller :`, error);
    if (error.response.status) {
      response.body = {
        message: error.response.data.message,
      };
      res.status(error.response.status).send(response);
    } else {
      response.body = {
        message: errorMessages.ISE,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};

module.exports.listReleasePipelines = async (req, res) => {
  const bearerHeader = req.headers.authorization;
  const personalAccessToken = bearerHeader && bearerHeader.split(" ")[1];
  const { organizationName, projectName } = req.query;
  try {
    const releasePipelines = await pipelineDao.listRealeasePipelines(
      organizationName,
      personalAccessToken,
      projectName
    );

    if (releasePipelines.status == statusCodes.SUCCESS) {
      response.body = {
        releasePipelines: releasePipelines.data,
      };
      res.status(statusCodes.SUCCESS).send(response);
    } else if (!releasePipelines) {
      response.body = {
        message: errorMessages.PGRP,
      };
      res.status(statusCodes.UNPROCESSABLE_ENTITY).send(response);
    }
  } catch (error) {
    logger.error(`Error from list release pipelines controller :`, error);
    if (error.response.status) {
      response.body = {
        message: error.response.data.message,
      };
      res.status(error.response.status).send(response);
    } else {
      response.body = {
        message: errorMessages.ISE,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};
