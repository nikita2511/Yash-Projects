const express = require("express");
const router = express.Router();
const controller = require("../controller/controller");

router.post("/create-yml-config", controller.createYamlConfiguration);

router.post("/create-yml", controller.createYMLfromJson);

router.post("/pipeline", controller.createPipeline);

router.post(
  "/create-pipeline-yaml-pull-request",
  controller.createPipelineWithYMLandPullRequest
);
router.get("/", controller.listPipeline);
router.post("/commit-java-skeleton-code", controller.commitJavaSkeltonCode);
router.post(
  "/commit-dotnet-skeleton-code",
  controller.commitDotnetSkeletonCode
);
router.post("/release", controller.createReleasePipeline);
router.post("/task-group", controller.addTaskGroup);
router.get("/task-group", controller.getTaskGroup);
router.get("/agents", controller.getAgentList);
router.get("/builds", controller.getBuilds);
router.get("/release", controller.listReleasePipelines);

module.exports = router;
