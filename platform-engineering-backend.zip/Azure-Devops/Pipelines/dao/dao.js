const azConnection = require("../../../config/azConnection");
const branchDao = require("../../Branches/dao/dao");
const rules = require("../../../OrganizationRules/Rules/dao/dao");
const YAML = require("yaml");
const repositoryDao = require("../../Repository/dao/dao");
const pullRequestDao = require("../../PullRequests/dao/dao");
const { YMLConfigTasks } = require("../../library");
const { sourceCodeLibrary } = require("../../../sourceCodeLibrary");
const {
  statusCodes,
  errorStatus,
  errorMessages,
} = require("../../../constants");
const axios = require("axios");
const { execSync } = require("child_process");
const fs = require("fs");
const builder = require("xml2js").Builder;
const path = require("path");

//-------------------logger-implementation-----------------------------
const winston = require("winston");
const { createLogs } = require("../../../config/loggerConfig");
const { TaskAgentApi } = require("azure-devops-node-api/TaskAgentApi");
const todayDate = new Date().toDateString().replace(/\ /g, "");
const logConfiguration = createLogs("pipelines dao", todayDate);
const logger = winston.createLogger(logConfiguration);
//------------------------------------------------------------------------------

/**
 * Function to create Java Source Skeleton Code
 *
 * @returns JavaSourceSkeletonCode response or error
 */
async function prepareSourceSkeletonCode(applicationType) {
  // This function prepares the Java source skeleton code.
  try {
    logger.log("info", "inside prepare Source Skeleton Code ");
    const sourceCodeFiles = sourceCodeLibrary.find(
      (type) => type.key === applicationType
    );

    // Create an array of changes to be made to the source code
    let changesOfSourceCode = [];

    for (const file of sourceCodeFiles.sourceCode) {
      const fileContent = file.content;
      const contentStream = Buffer.from(fileContent, "utf8");
      changesOfSourceCode.push({
        changeType: "add",
        item: {
          path: file.path,
        },
        newContent: {
          content: contentStream.toString("base64"),
          contentType: 1,
        },
      });
    }
    // Return the array of changes.
    return changesOfSourceCode;
  } catch (error) {
    logger.error("Prepare Skeleton Code Error", error);
  }
}

/**
 * Function to create DotnetSourceSkeletonCode
 *
 * @returns Dotnet Skeleton Code reponse or error
 */
// async function prepareDotnetSourceSkeletonCode() {
//   try {
//     logger.log("info", "inside prepareDotnetSourceSkeletonCode ");
//     const dotNetConfigJson = sourceCodeLibrary.find(
//       (type) => type.key === "dotNet"
//     );

//     let changesOfDotNetSourceCode = [];
//     for (const file of dotNetConfigJson.sourceCode) {
//       const fileContent = file.content;
//       const contentStream = Buffer.from(fileContent, "utf8");
//       changesOfDotNetSourceCode.push({
//         changeType: "add",
//         item: {
//           path: file.path,
//         },
//         newContent: {
//           content: contentStream.toString("base64"),
//           contentType: 1,
//         },
//       });
//     }

//     return changesOfDotNetSourceCode;
//   } catch (error) {
//     logger.error("Prepare Dot Net skeleton code Error ", error);
//     throw error;
//   }
// }

/**
 * Function to create commit to repository
 *
 * @param {String} organizationName
 * @param {String} token
 * @param {String} commit
 * @param {String} branchName
 * @param {String} commitId
 * @param {String} repoId
 * @returns pushed code object or error object
 */
async function createCommitToRepository(
  organizationName,
  token,
  commit,
  branchName,
  commitId,
  repoId,
  existingConnection
) {
  // Get the connection to Azure DevOps
  try {
    let azDevOpsConnection;
    if (!existingConnection) {
      azDevOpsConnection = azConnection.getConnection(organizationName, token);
    } else {
      azDevOpsConnection = existingConnection;
    }
    // const azDevOpsConnection = azConnection.getConnection(
    //   organizationName,
    //   token
    // );
    // Get the Git API
    const gitApi = await azDevOpsConnection.getGitApi();
    // Create a push with the commit and ref updates
    let pushedCode = await gitApi.createPush(
      {
        commits: [commit],
        refUpdates: [
          {
            isLocked: false,
            name: `refs/heads/${branchName}`,
            oldObjectId: `${commitId}`,
            repositoryId: `${repoId}`,
          },
        ],
      },
      repoId
    );
    // Log the pushed code
    logger.log("info", `line 700 PushedCode ${pushedCode}`);
    // Return the pushed code
    return pushedCode;
  } catch (error) {
    // Log the error
    logger.error("createCommitTo Repository Error ", error);
    // Throw the error
    throw error;
  }
}
/**
 * Function to createPipeline
 *
 * @param {String} organizationName
 * @param {String} token
 * @param {String} projectName
 * @param {String} repoName
 * @param {String} applicationType
 * @param {String} pipelineName
 * @returns createdPipeline respone object or error object
 */
async function createPipeline(
  organizationName,
  token,
  projectName,
  repoName,
  applicationType,
  pipelineName,
  existingConnection
) {
  // Check if organizationName and token are provided
  if (!organizationName) return errorStatus.ONF;
  if (!token) return errorStatus.TNF;

  try {
    // Get the repository details
    const repo = await repositoryDao.getRepo(
      organizationName,
      token,
      projectName,
      repoName,
      existingConnection
    );

    logger.log("info", `Repository  : ${repo}`);

    // Create the pipeline configuration
    const config = {
      path: `${applicationType + "-azure-pipelines.yml"}`,
      repository: {
        id: repo.id,
        type: "azureReposGit",
        name: repoName,
        defaultBranch: repo.defaultBranch,
        clean: null,
        checkoutSubmodules: false,
      },
      type: "yaml",
    };

    // Create the pipeline request body
    const requestBody = {
      name: pipelineName,
      configuration: config,
    };

    let createdPipeline;
    try {
      // Create the pipeline
      createdPipeline = await axios.post(
        `https://dev.azure.com/${organizationName}/${projectName}/_apis/pipelines?api-version=7.1-preview.1`,
        requestBody,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
    } catch (error) {
      logger.log("createPipeline Error", error);
      throw error;
    }

    logger.log("info", `Created Pipeline  : ${createdPipeline.data}`);

    // Check if the pipeline was created successfully
    if (createdPipeline.status == statusCodes.SUCCESS)
      return createdPipeline.data;
    else throw new Error(createdPipeline.data);
  } catch (error) {
    logger.log("create Pipeline Error", error);
    throw error;
  }
}
/**
 * Function to createSourceFiles for the given application type
 *
 * @param {String} organizationName
 * @param {String} token
 * @param {String} repoName
 * @param {String} projectName
 * @param {String} applicationType
 * @param {boolean} publishArtifacts
 * @param {String} userNameInitials
 * @returns response object or throw error
 */
async function createSourceFiles(
  organizationName,
  token,
  repoName,
  projectName,
  applicationType,
  publishArtifacts,
  userNameInitials,
  existingConnection
) {
  try {
    let preparedCodeChanges;
    let preparedYMLConfiguration = await prepareYMLConfigurationCode(
      organizationName,
      applicationType,
      publishArtifacts
    );

    const ymlContentStream = Buffer.from(preparedYMLConfiguration, "utf8");
    let repo = await repositoryDao.getRepo(
      organizationName,
      token,
      projectName,
      repoName,
      existingConnection
    );
    sourceBranchName = repo.defaultBranch.split("/")[2];
    const uid =
      new Date().toISOString().replace(/:/g, ".") +
      Math.random().toString().substring(2, 7);
    let targetBranchName = `${userNameInitials + uid}`;
    let createdBranch = await branchDao.createBranch(
      organizationName,
      token,
      projectName,
      repoName,
      sourceBranchName,
      targetBranchName,
      existingConnection
    );
    let commit = {
      comment: `Adding ${applicationType} source files and YML configuration`,
      changes: [],
    };
    let YMLChangesToPush = {
      changeType: "add",
      item: {
        path: `/${applicationType + "-azure-pipelines.yml"}`,
      },
      newContent: {
        content: ymlContentStream.toString("base64"),
        contentType: 1,
      },
    };
    commit.changes.push(YMLChangesToPush);
    logger.log("info", `commit line 163 , ${commit}`);
    if (createdBranch.length && createdBranch[0].success) {
      preparedCodeChanges = await prepareSourceSkeletonCode(applicationType);
      // switch (applicationType) {
      //   case "java":
      //     preparedCodeChanges = await prepareJavaSourceSkeletonCode();
      //     break;
      //   case "dotNet":
      //     preparedCodeChanges = await prepareDotnetSourceSkeletonCode();
      //     break;
      //   default:
      //     break;
      // }
      for (let change of preparedCodeChanges) {
        commit.changes.push(change);
      }
      // logger.log("final commit", commit);
      let committedCodeToRepo = await createCommitToRepository(
        organizationName,
        token,
        commit,
        targetBranchName,
        createdBranch[0].newObjectId,
        createdBranch[0].repositoryId,
        existingConnection
      );
      // logger.log("committedCodeToRepo", committedCodeToRepo);
      if (committedCodeToRepo.hasOwnProperty("commits")) {
        return {
          committedCodeToRepo,
          createdBranch,
          isCodePushed: true,
          status: true,
        };
      }

      return { committedCodeToRepo, isCodePushed: false, status: true };
    } else {
      throw new Error(
        "Error creating feature branch to push YML and Source Code Files"
      );
    }
  } catch (error) {
    logger.error("create source file error ", error);
    throw error;
  }
}

/**
 * Function to create Pipeline with YAML & Pull Request
 *
 * @param {String} organizationName
 * @param {String} token
 * @param {String} projectName
 * @param {String} repoName
 * @param {String} applicationType
 * @param {boolean} publishArtifacts
 * @param {String} userNameInitials
 * @param {String} pipelineName
 * @param {Number} reviewers
 *
 * @returns response object or an error object
 */
module.exports.createPipelineWithYMLandPullRequest = async (
  organizationName,
  token,
  projectName,
  repoName,
  applicationType,
  publishArtifacts,
  userNameInitials,
  pipelineName,
  reviewers,
  existingConnection
) => {
  try {
    let pushedSourceCodeAndYML,
      createdPipeline,
      createdPullRequest,
      isSourceCodeAndYMLPushed = false,
      isPipelineCreated = false,
      isPullRequestCreated = false;
    pushedSourceCodeAndYML = await createSourceFiles(
      organizationName,
      token,
      repoName,
      projectName,
      applicationType,
      publishArtifacts,
      userNameInitials,
      existingConnection
    );

    if (!pushedSourceCodeAndYML.isCodePushed)
      throw new Error("Branch created but can not push YML/Source Files");
    if (applicationType === "dotNet") {
      fs.rmSync("MySolution", { recursive: true, force: true });
    }
    let { createdBranch } = pushedSourceCodeAndYML;
    let sourceBranchName = createdBranch[0].name;
    createdPipeline = await createPipeline(
      organizationName,
      token,
      projectName,
      repoName,
      applicationType,
      pipelineName,
      existingConnection
    );
    logger.log(
      "info",
      `Created Pipeline result =============> ${createdPipeline}`
    );
    createdPullRequest = await pullRequestDao.createPullRequest(
      organizationName,
      token,
      projectName,
      repoName,
      sourceBranchName,
      reviewers,
      existingConnection
    );
    logger.log(
      "info",
      `Created Pull Request ===========> ${createdPullRequest}`
    );
    if (pushedSourceCodeAndYML.status === true) isSourceCodeAndYMLPushed = true;
    if (createdPullRequest.hasOwnProperty("mergeId"))
      isPullRequestCreated = true;
    if (createdPipeline.hasOwnProperty("id")) isPipelineCreated = true;

    return {
      isSourceCodeAndYMLPushed,
      isPipelineCreated,
      isPullRequestCreated,
    };
  } catch (error) {
    logger.error("create yaml and Pr Dao Error ==================>", error);
    throw error;
  }
};

/**
 * This function is to prepare YML configuration Code
 *
 * @param {String} organizationName
 * @param {String} applicationType
 * @param {boolean} publishArtifacts
 * @returns ymljsondata
 */
async function prepareYMLConfigurationCode(
  organizationName,
  applicationType,
  publishArtifacts
) {
  // Create an empty object to store the yml configuration
  const ymlJsonObject = {
    trigger: [],
    pool: {},
    steps: [],
  };
  // Get the project creation rules for the given organization
  const organizationRule = await rules.getOrganizationRules(
    organizationName,
    "AzureDevops"
  );
  // Add all the branches from the project creation rules to the trigger list
  for (let branch of organizationRule.branchingModel.branches) {
    ymlJsonObject.trigger.push(branch.name);
  }

  // Find the yml configuration for the given application type
  const YMLConfigJson = YMLConfigTasks.find(
    (type) => type.key === applicationType
  );
  // Get the yml configuration object for the given application type
  const YMLConfigBuildTask = YMLConfigJson.buildTasks;
  const YMLConfigPublishArtifactsTask = YMLConfigJson.publishArtifactsTasks;
  console.log(
    "YMLConfigBuildTask, YMLConfigPublishArtifactsTask",
    YMLConfigBuildTask,
    YMLConfigPublishArtifactsTask
  );

  // Add the pool configuration from the yml configuration object to the yml configuration
  ymlJsonObject.pool = YMLConfigJson.pool;

  // Switch on the application type and add the appropriate steps to the yml configuration
  // switch (applicationType) {
  //   case "java":
  //     ymlJsonObject.steps.push(YMLConfigTask.tasks.build);
  //     if (publishArtifacts) {
  //       ymlJsonObject.steps.push(YMLConfigTask.tasks.copyFiles);
  //       ymlJsonObject.steps.push(YMLConfigTask.tasks.publishArtifacts);
  //     }
  //     break;
  //   case "dotNet":
  //     ymlJsonObject.steps.push(YMLConfigTask.tasks.restorePackages);
  //     ymlJsonObject.steps.push(YMLConfigTask.tasks.build);
  //     if (publishArtifacts) {
  //       ymlJsonObject.steps.push(YMLConfigTask.tasks.archiveFiles);
  //       ymlJsonObject.steps.push(YMLConfigTask.tasks.publishArtifacts);
  //     }
  //   default:
  //     break;
  // }
  for (let task of YMLConfigBuildTask) {
    console.log("build task : ", task);
    ymlJsonObject.steps.push(task);
  }
  if (publishArtifacts) {
    for (let task of YMLConfigPublishArtifactsTask) {
      console.log("publish artifacts task : ", task);
      ymlJsonObject.steps.push(task);
    }
  }
  let data = await createYMLfromJson(ymlJsonObject);
  logger.log("info", `data from createYMLfromJson  ${data}`);
  return data;
}

/**
 * This function is to create yaml file from json Object
 *
 * @param {object} ymlJsonObject
 * @returns yml file or  error
 */
async function createYMLfromJson(ymlJsonObject) {
  // try catch block to handle errors
  try {
    // log the message to the logger
    logger.log("info", `inside createYMLfromJson ${ymlJsonObject}`);
    // check if the ymlJsonObject is not null
    if (!ymlJsonObject) {
      // log the message to the logger
      logger.log("info", "Json object not found");
      // return the error message
      return "YML_JSON_OBJECT_NOT_FOUND";
    } else {
      // create a new YAML document
      const doc = new YAML.Document();
      // set the contents of the document to the ymlJsonObject
      doc.contents = ymlJsonObject;
      // convert the document to a string
      let data = doc.toString();
      // log the message to the logger
      logger.log("info", data);
      // return the data
      return data;
    }
  } catch (error) {
    // log the error to the logger
    logger.error("createYMLfromJson", error);
    // throw the error
    throw error;
  }
}

/**
 * This function is to get the list of all the pipelines
 *
 * @param {String} organizationName
 * @param {String} token
 * @param {String} projectName
 * @returns listPipeline object or error object
 */
module.exports.listPipeline = async (organizationName, token, projectName) => {
  // Check if organizationName is not empty
  if (!organizationName) return errorStatus.ONF;
  // Check if token is not empty
  if (!token) return errorStatus.TNF;

  let listPipeline;
  try {
    // Get list of pipelines
    listPipeline = await axios.get(
      `https://dev.azure.com/${organizationName}/${projectName}/_apis/pipelines?api-version=7.1-preview.1`,
      {
        // Set Authorization header with Bearer token
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );
    // Return list of pipelines
    return listPipeline.data;
  } catch (error) {
    // Log error
    logger.error("List Pipeline Error :: ", error);
    // Throw error
    throw error;
  }
};

/**
 * A function to create task group
 *
 * @param {String} organizationName
 * @param {String} token
 * @param {String} projectId
 * @param {String} taskGroup
 *
 * @returns An object of add task group api call or an error object.
 */
async function addTaskGroup(organizationName, token, projectId, taskGroup) {
  if (!organizationName) return errorStatus.ONF;
  try {
    const headers = {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
    };
    const addedTaskGroup = await axios.post(
      `https://dev.azure.com/${organizationName}/${projectId}/_apis/distributedtask/taskgroups?api-version=7.1-preview.1`,
      taskGroup,
      { headers: headers }
    );
    if (addedTaskGroup) {
      return addedTaskGroup;
    } else return false;
  } catch (error) {
    logger.error(`Error from add task group dao : `, error);
    throw error;
  }
}

/**
 * A function to list available agents.
 *
 * @param {String} organizationName
 * @param {String} token
 * @param {String} projectId
 *
 * @returns A JSON object of list agent API call or an error object.
 */
async function getAgentsList(organizationName, token, projectId) {
  try {
    if (!organizationName) return errorStatus.ONF;

    const azDevOpsConnection = azConnection.getConnection(
      organizationName,
      token
    );

    const tasAgentAPI = await azDevOpsConnection.getTaskAgentApi();

    try {
      const agents = await tasAgentAPI.getAgentQueues(projectId);
      if (agents) return agents;
      else return false;
    } catch (error) {
      logger.error(`Error from get agents dao : `, error);
      throw error;
    }
  } catch (error) {
    logger.error(`Error from get agents dao : `, error);
    throw error;
  }
}

async function createReleaseDefinition(
  organizationName,
  token,
  projectName,
  projectId,
  stageName,
  queueId,
  agentName,
  tasks,
  branchesForStageTrigger,
  branchesForArtifactTrigger,
  CIPipelineId,
  CIPipelineName,
  releasePipelineName
) {
  const artifactAlias = `_${CIPipelineName}`;
  try {
    let definition = {
      source: "undefined",
      revision: 1,
      description: null,
      createdBy: null,
      createdOn: "0001-01-01T00:00:00",
      modifiedBy: null,
      modifiedOn: "0001-01-01T00:00:00",
      isDeleted: false,
      variables: {},
      variableGroups: [],
      environments: [
        {
          id: 0,
          name: stageName,
          variables: {},
          variableGroups: [],
          preDeployApprovals: {
            approvals: [
              {
                rank: 1,
                isAutomated: true,
                isNotificationOn: false,
                id: 0,
              },
            ],
          },
          postDeployApprovals: {
            approvals: [
              {
                rank: 1,
                isAutomated: true,
                isNotificationOn: false,
                id: 0,
              },
            ],
          },
          deployPhases: [
            {
              deploymentInput: {
                parallelExecution: {
                  parallelExecutionType: "none",
                },
                agentSpecification: {
                  identifier: "ubuntu latest",
                },
                skipArtifactsDownload: false,
                artifactsDownloadInput: {},
                queueId: queueId,
                demands: [],
                enableAccessToken: false,
                timeoutInMinutes: 0,
                jobCancelTimeoutInMinutes: 1,
                condition: "succeeded()",
                overrideInputs: {},
              },
              rank: 1,
              phaseType: "agentBasedDeployment",
              name: agentName,
              workflowTasks: tasks,
            },
          ],
          environmentOptions: {
            emailNotificationType: "OnlyOnFailure",
            emailRecipients: "release.environment.owner;release.creator",
            skipArtifactsDownload: false,
            timeoutInMinutes: 0,
            enableAccessToken: false,
            publishDeploymentStatus: false,
            badgeEnabled: false,
            autoLinkWorkItems: false,
            pullRequestDeploymentEnabled: true,
          },
          demands: [],
          conditions: [
            {
              name: "ReleaseStarted",
              conditionType: "event",
              value: "",
            },
          ],
          executionPolicy: {
            concurrencyCount: 0,
            queueDepthCount: 0,
          },
          schedules: [],
          retentionPolicy: {
            daysToKeep: 30,
            releasesToKeep: 3,
            retainBuild: true,
          },
          properties: {},
          preDeploymentGates: {
            id: 0,
            gatesOptions: null,
            gates: [],
          },
          postDeploymentGates: {
            id: 0,
            gatesOptions: null,
            gates: [],
          },
          environmentTriggers: [],
        },
      ],
      artifacts: [
        {
          alias: artifactAlias,
          type: "build",
          definitionReference: {
            project: {
              id: projectId,
              name: projectName,
            },
            definition: {
              id: CIPipelineId,
              name: CIPipelineName,
            },
          },
          isPrimary: true,
          isRetained: false,
        },
      ],
      triggers: [
        {
          artifactAlias: artifactAlias,
          triggerConditions: [],
          triggerType: "artifactSource",
        },
      ],
      releaseNameFormat: null,
      tags: [],
      properties: {},
      id: 0,
      name: releasePipelineName,
      projectReference: {
        id: projectId,
        name: projectName,
      },
      _links: {},
    };

    for (const branch of branchesForStageTrigger) {
      definition.environments[0].conditions.push({
        name: artifactAlias,
        conditionType: "artifact",
        value: JSON.stringify({
          sourceBranch: branch,
          tags: [],
          useBuildDefinitionBranch: false,
          createReleaseOnBuildTagging: false,
        }),
      });
    }

    for (const branch of branchesForArtifactTrigger) {
      definition.triggers[0].triggerConditions.push({
        sourceBranch: branch,
        tags: [],
        tagFilter: null,
        useBuildDefinitionBranch: false,
        createReleaseOnBuildTagging: false,
      });
    }

    logger.log("info", `Before calling create release definition API`);
    try {
      const releaseDefintion = await axios.post(
        `https://vsrm.dev.azure.com/${organizationName}/${projectName}/_apis/release/definitions?api-version=7.0`,
        definition,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      logger.log(
        "info",
        `After calling create release definition API ${JSON.stringify(
          releaseDefintion.data
        )}`
      );

      if (releaseDefintion.status) {
        return releaseDefintion.data;
      } else return false;
    } catch (error) {
      logger.error(`Error from create release definition dao : `, error);
      throw error;
    }
  } catch (error) {
    logger.error(`Error from create release definition dao : `, error);
    throw error;
  }
}

/**
 * A function to create a release pipeline
 *
 * @param {String} organizationName
 * @param {String} token
 * @param {String} projectName
 * @param {String} projectId
 * @param {String} stageName
 * @param {Number} queueId
 * @param {String} agentName
 * @param {Array} tasks
 * @param {Array} branchesForStageTrigger
 * @param {Array} branchesForArtifactTrigger
 * @param {Number} CIPipelineId
 * @param {String} CIPipelineName
 * @param {String} description
 *
 * @returns An JSON object with properties releasePipeline and releaseDefintion as Boolean or an error object
 */
async function createReleasePipeline(
  organizationName,
  token,
  projectName,
  projectId,
  stageName,
  queueId,
  agentName,
  tasks,
  branchesForStageTrigger,
  branchesForArtifactTrigger,
  CIPipelineId,
  CIPipelineName,
  description,
  name
) {
  try {
    const builds = await listBuilds(
      organizationName,
      projectName,
      token,
      CIPipelineId
    );

    if (!builds.count) return errorStatus.NBF;
    logger.log("info", `List of builds : ${JSON.stringify(builds)}`);
    const buildId = builds.value[0].id;

    logger.log("info", `Creating release definition`);
    const releaseDefintion = await createReleaseDefinition(
      organizationName,
      token,
      projectName,
      projectId,
      stageName,
      queueId,
      agentName,
      tasks,
      branchesForStageTrigger,
      branchesForArtifactTrigger,
      CIPipelineId,
      CIPipelineName,
      name
    );

    logger.log("info", `After creating release definition API`);
    const releaseDefintionId = releaseDefintion.id;

    if (releaseDefintionId && buildId) {
      try {
        const artifactAlias = `_${CIPipelineName}`;
        const data = {
          definitionId: releaseDefintionId,
          description: description,
          artifacts: [
            {
              alias: artifactAlias,
              instanceReference: {
                id: buildId,
                name: CIPipelineName,
              },
            },
          ],
          isDraft: false,
          reason: "none",
          manualEnvironments: null,
        };

        logger.log(
          "info",
          `Before calling create release pipeline API : ${JSON.stringify(data)}`
        );
        const releasePipeline = await axios.post(
          `https://vsrm.dev.azure.com/${organizationName}/${projectName}/_apis/release/releases?api-version=7.1-preview.8`,
          data,
          {
            headers: {
              Authorization: `Bearer ${token}`,
            },
          }
        );
        logger.log(
          "info",
          `After calling create release pipeline API : ${JSON.stringify(
            releasePipeline.data
          )}`
        );

        if (releasePipeline)
          return { releaseDefintion, releasePipeline };
        else return false;
      } catch (error) {
        logger.error(`Error from create release pipeline dao : `, error);
        throw error;
      }
    } else return errorStatus.RDNF;
  } catch (error) {
    logger.error(`Error from create release pipeline dao : `, error);
    throw error;
  }
}
/**
 *
 * @param {string} organizationName
 * @param {string} projectName
 * @param {string} token
 * @returns list of task group for a given project of particular organization
 */
const listTaskGroup = async (organizationName, projectName, token) => {
  try {
    const headers = {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
    };
    const response = await axios.get(
      `https://dev.azure.com/${organizationName}/${projectName}/_apis/distributedtask/taskgroups?api-version=7.0`,
      {
        headers: headers,
      }
    );
    return response.data;
  } catch (error) {
    logger.error(`Error in getting taskGroups`, error);
    throw error;
  }
};

/**
 *
 * @param {string} organizationName
 * @param {string} projectName
 * @param {string} token
 * @returns list of task group for a given project of particular organization
 */
const listBuilds = async (
  organizationName,
  projectName,
  token,
  definitionId
) => {
  try {
    const headers = {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
    };
    const response = await axios.get(
      `https://dev.azure.com/${organizationName}/${projectName}/_apis/build/builds?definitions=${definitionId}&api-version=7.0`,
      {
        headers: headers,
      }
    );
    return response.data;
  } catch (error) {
    logger.error(`Error in getting Builds`, error);
    throw error;
  }
};

async function listRealeasePipelines(organizationName, token, projectName) {
  try {
    const releasePipelines = await axios.get(
      `https://vsrm.dev.azure.com/${organizationName}/${projectName}/_apis/release/releases?api-version=7.2-preview.8`,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );
    logger.log(
      "info",
      `release pipelines : ${JSON.stringify(releasePipelines.data)}`
    );
    if (releasePipelines) {
      return releasePipelines;
    } else return false;
  } catch (error) {
    logger.error(`Error in getting release pipelines dao`, error);
    throw error;
  }
}

module.exports.createYMLfromJson = createYMLfromJson;
module.exports.createPipeline = createPipeline;
module.exports.addTaskGroup = addTaskGroup;
module.exports.getAgentList = getAgentsList;
module.exports.listTaskGroup = listTaskGroup;
module.exports.listBuilds = listBuilds;
module.exports.createReleasePipeline = createReleasePipeline;
module.exports.listRealeasePipelines = listRealeasePipelines;
