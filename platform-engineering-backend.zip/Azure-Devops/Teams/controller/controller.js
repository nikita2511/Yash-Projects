const teamDAO = require("../dao/dao");
const {
  errorStatus,
  errorMessages,
  responsHeader,
  statusCodes,
} = require("../../../constants");
let response = {
  headers: responsHeader,
  body: {},
};


/**
 * A handler function to fetch all teams in an organization.
 * 
 * @param {String} req The request query parameters 
 * @param {Object} res The response object
 * 
 * @returns A list of teams object with Http SUCCESS status code or errors with Http error status codes.
 */
module.exports.getAllTeams = async (req, res) => {
  const bearerHeader = req.headers.authorization;
  const organizationName = req.query.organizationName;

  const personalAccessToken = bearerHeader && bearerHeader.split(" ")[1];
  var teams = await teamDAO.getAllTeams(organizationName, personalAccessToken);

  if (teams == errorStatus.ONF) {
    response.body = {
      message: errorMessages.ONF,
      error: errorStatus.ONF,
    };
    res.status(statusCodes.BAD_REQUEST).send(response);
  } else if (teams.status == errorStatus.CNF) {
    response.body = {
      message: errorMessages.CNF,
      error: errorStatus.CNF,
    };
    res.status(statusCodes.NOT_FOUND).send(response);
  } else {
    response.body = { teams: teams };
    res.status(statusCodes.SUCCESS).send(response);
  }
};
