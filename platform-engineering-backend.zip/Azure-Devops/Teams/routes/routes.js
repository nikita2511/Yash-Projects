const express = require("express");
const router = express.Router();

const controller = require("../controller/controller");


// Get all Teams for an organization
router.get("/", controller.getAllTeams);

module.exports = router;