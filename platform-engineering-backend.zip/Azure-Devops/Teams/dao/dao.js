const azConnection = require("../../../config/azConnection");
const { errorStatus, errorMessages } = require("../../../constants");


/**
 * A function to fetch all teams in an organization
 * 
 * @param {String} organizationName 
 * @param {String} token 
 * 
 * @returns An array of teams object or error object
 */
const getAllTeams = async (organizationName, token) => {
  if (!organizationName) return errorStatus.ONF;
  let azDevOpsConnection, coreAPI;
  try {
    azDevOpsConnection = azConnection.getConnection(organizationName, token);
    coreAPI = await azDevOpsConnection.getCoreApi();
    let teams = await coreAPI.getAllTeams();
    return teams;
  } catch (error) {
    return {
      status: errorStatus.CNF,
      error: error,
      message: errorMessages.CNF,
    };
  }
};

module.exports = { getAllTeams };
