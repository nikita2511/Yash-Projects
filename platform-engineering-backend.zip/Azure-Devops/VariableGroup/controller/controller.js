const variableGroupDAO = require("../dao/dao");
const {
  errorStatus,
  errorMessages,
  responsHeader,
  statusCodes,
} = require("../../../constants");

//-------------------logger-implementation-----------------------------
const winston = require("winston");
const { createLogs } = require("../../../config/loggerConfig");
const todayDate = new Date().toDateString().replace(/\ /g, "");
const logConfiguration = createLogs("Variable Group Controller", todayDate);
const logger = winston.createLogger(logConfiguration);
//------------------------------------------------------------------------------

let response = {
  headers: responsHeader,
  body: {},
};

/**
 * Handler function for adding a new variable group to a project.
 * @param {Object} req - The request object.
 * @param {Object} res - The response object.
 * @returns {Object} - The HTTP response to the client with information about the success or failure of adding a new variable group.
 */
module.exports.addVariableGroup = async (req, res) => {

   // Extract the authorization header and required parameters from the request.
  const bearerHeader = req.headers.authorization;
  const {
    organizationName,
    projectName,
    variableGroupName,
    description,
    variables,
  } = req.body;
  const personalAccessToken = bearerHeader && bearerHeader.split(" ")[1];
  let variableGroupExist = false;
  try {
     // Get the list of variable groups for the specified organization and project.
    const variableGroupList = await variableGroupDAO.getVariableGroups(
      organizationName,
      personalAccessToken,
      projectName
    );
    logger.log("info", `variableGroupList ${variableGroupList}`);
    for (let variableGroup of variableGroupList) {
      if (variableGroupName == variableGroup.name) variableGroupExist = true;
    }

    // If the variable group already exists, send a response to the client with a 409 status code.
    if (variableGroupExist) {
      response.body = {
        message: `Variable Group with the name '${variableGroupName}' already exists!`,
      };
      res.status(409).send(response);
    }
    // If the variable group already exists, send a response to the client with a 409 status code.
    if (!variableGroupExist) {
      let addedVariableGroup = await variableGroupDAO.addVariableGroup(
        organizationName,
        personalAccessToken,
        projectName,
        variableGroupName,
        description,
        variables
      );
      logger.log("info", `addedVariableGroup ${addedVariableGroup}`);
      if (addedVariableGroup == errorStatus.ONF) {
        response.body = {
          message: errorMessages.ONF,
        };
        res.status(statusCodes.BAD_REQUEST).send(response);
      } else {
        response.body = { addedVariableGroup: addedVariableGroup };
        res.status(statusCodes.CREATED).send(response);
      }
    }
  } catch (error) {
    if (error.statusCode) {
      response.body = {
        errorStatus: error.statusCode,
        errorMessage: error.result.message,
      };
      return res.status(error.statusCode).send(response);
    } else {
      response.body = {
        errorStatus: statusCodes.SERVER_ERROR,
        errorMessage: error.message,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};


/**
 * Handler function for fetching a list of group variables.
 * 
 * @param {String} req The request parameters
 * @param {JSON Object} res The response object
 * 
 * @returns A list of group variables with Http success code or error with Http error codes.
 */
module.exports.getVariableGroups = async (req, res) => {
  const bearerHeader = req.headers.authorization;
  const { organizationName, projectName, variableGroupName } = req.query;
  const personalAccessToken = bearerHeader && bearerHeader.split(" ")[1];
  try {
    let variableGroup = await variableGroupDAO.getVariableGroups(
      organizationName,
      personalAccessToken,
      projectName,
      variableGroupName
    );

    logger.log("info", `Variable Group ============>${variableGroup}`);
    if (variableGroup == errorStatus.ONF) {
      response.body = {
        message: errorMessages.ONF,
      };
      res.status(statusCodes.BAD_REQUEST).send(response);
    } else if (variableGroup === null) {
      response.body = {
        errorStatus: statusCodes.NOT_FOUND,
        errorMessages: errorMessages.NRF,
      };
      res.status(statusCodes.NOT_FOUND).send(response);
    } else {
      response.body = { getVariableGroup: variableGroup };
      res.status(statusCodes.SUCCESS).send(response);
    }
  } catch (error) {
    if (error.statusCode) {
      response.body = {
        errorStatus: error.statusCode,
        errorMessage: error.message,
      };
      return res.status(error.statusCode).send(response);
    } else {
      response.body = {
        errorStatus: statusCodes.SERVER_ERROR,
        errorMessage: error.message,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};

/**
 * Handler fucntion for updating a group variable for a project
 * 
 * @param {Object} req The request object
 * @param {Object} res The response object
 * 
 * @returns A updated variable group object with Http success code or error with Http error codes.
 */
module.exports.updateVariableGroup = async (req, res) => {
  const bearerHeader = req.headers.authorization;
  const personalAccessToken = bearerHeader && bearerHeader.split(" ")[1];
  const {
    organizationName,
    projectName,
    variableGroupName,
    description,
    variables,
    groupId,
  } = req.body;
  try {
    let updatedVariableGroup = await variableGroupDAO.updateVariableGroup(
      organizationName,
      personalAccessToken,
      projectName,
      variableGroupName,
      description,
      variables,
      groupId
    );
    logger.log("info", `updatedVariableGroup ${updatedVariableGroup}`);
    if (updatedVariableGroup == errorStatus.ONF) {
      response.body = {
        message: errorMessages.ONF,
      };
      res.status(statusCodes.BAD_REQUEST).send(response);
    } else if (updatedVariableGroup.status == errorStatus.ISE) {
      response.body = {
        statusCode: updatedVariableGroup.error.statusCode,
        error: updatedVariableGroup.error.result.message,
      };
      res.status(updatedVariableGroup.error.statusCode).send(response);
    } else {
      response.body = { updatedVariableGroup: updatedVariableGroup };
      res.status(statusCodes.SUCCESS).send(response);
    }
  } catch (error) {
    if (error.statusCode == statusCodes.BAD_REQUEST) {
      response.body = {
        message: "Authentication Failed",
        errorStatus: error.statusCode,
      };
      res.status(error.statusCode).send(response);
    } else {
      response.body = {
        message: error.result.message,
        errorStaus: error.statusCode,
      };
      res.status(error.statusCode).send(response);
    }
  }
};


/**
 * Handler function to fetch a variable group by group ID for a project.
 * 
 * @param {String} req The request query string parameters.
 * @param {Object} res The reponse object.
 * 
 * @returns A variable group object with Http success code or error with Http error codes.
 */
module.exports.getVariableGroupById = async (req, res) => {
  const bearerHeader = req.headers.authorization;
  const personalAccessToken = bearerHeader && bearerHeader.split(" ")[1];

  const { organizationName, projectName, groupId } = req.query;

  try {
    let getVariableGroupById = await variableGroupDAO.getVariableGroupById(
      organizationName,
      personalAccessToken,
      projectName,
      groupId
    );
    if (getVariableGroupById == errorStatus.ONF) {
      response.body = {
        message: errorMessages.ONF,
      };
      res.status(statusCodes.BAD_REQUEST).send(response);
    } else {
      response.body = { variableGroup: getVariableGroupById };
      res.status(statusCodes.SUCCESS).send(response);
    }
  } catch (error) {
    if (error.statusCode) {
      response.body = {
        errorStatus: error.statusCode,
        errorMessage: error.message,
      };
      return res.status(error.statusCode).send(response);
    } else {
      response.body = {
        errorStatus: statusCodes.SERVER_ERROR,
        errorMessage: error.message,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};
