const express = require("express");
const router = express.Router();

const controller = require("../controller/controller");

//Adds a variable group
router.post("/", controller.addVariableGroup);

//Gets a list of variable groups
router.get("/", controller.getVariableGroups);

//Updates a variable group
router.put("/", controller.updateVariableGroup);

//Gets a variable Group By Id
router.get("/variablegroupbyid", controller.getVariableGroupById);

module.exports = router;
