const azConnection = require("../../../config/azConnection");
const { errorStatus } = require("../../../constants");

//-------------------logger-implementation-----------------------------
const winston = require("winston");
const { createLogs } = require("../../../config/loggerConfig");
const todayDate = new Date().toDateString().replace(/\ /g, "");
const logConfiguration = createLogs("Variable Group Dao", todayDate);
const logger = winston.createLogger(logConfiguration);
//------------------------------------------------------------------------------

/**
 * Creates a Variable Group in Azure DevOps Pipeline Library
 *
 * @param {String} organizationName
 * @param {String} token
 * @param {String} projectName
 * @param {String} variableGroupName
 * @param {String} description
 * @param {JSON Object} variables
 *
 * @returns An Object of created Variable Group
 */
module.exports.addVariableGroup = async (
  organizationName,
  token,
  projectName,
  variableGroupName,
  description,
  variables,
  existingConnection
) => {
  if (!organizationName) return errorStatus.ONF;
  try {
    let azDevOpsConnection;
    if (!existingConnection) {
      azDevOpsConnection = azConnection.getConnection(organizationName, token);
    } else {
      azDevOpsConnection = existingConnection;
    }
    // const azDevOpsConnection = azConnection.getConnection(
    //   organizationName,
    //   token
    // );
    const taskAPI = await azDevOpsConnection.getTaskAgentApi();

    const variableGroupParameters = {
      name: variableGroupName,
      description: description,
      type: "Vsts",
      variables: variables,
      variableGroupProjectReferences: [
        {
          name: variableGroupName,
          description: description,
          projectReference: {
            name: projectName,
          },
        },
      ],
    };
    logger.log(
      "info",
      `variableGroupParameters.variableGroupProjectReferences
      ${variableGroupParameters.variableGroupProjectReferences[0].projectReference}`
    );
    const addedVariableGroup = await taskAPI.addVariableGroup(
      variableGroupParameters
    );
    logger.log("info", `addedVariableGroup ${addedVariableGroup}`);
    return addedVariableGroup;
  } catch (error) {
    throw error;
  }
};

/**
 * Lists available Variable Groups for a Project
 *
 * @param {String} organizationName
 * @param {String} token
 * @param {String} projectName
 *
 * @returns An Array of Variable Groups for a Project
 */
module.exports.getVariableGroups = async (
  organizationName,
  token,
  projectName
) => {
  if (!organizationName) return errorStatus.ONF;
  try {
    const azDevOpsConnection = azConnection.getConnection(
      organizationName,
      token
    );
    const taskAPI = await azDevOpsConnection.getTaskAgentApi();

    const variableGroup = await taskAPI.getVariableGroups(projectName);
    return variableGroup;
  } catch (error) {
    throw error;
  }
};

/**
 * Updates a Variable Group of a Project by group ID.
 *
 * @param {String} organizationName
 * @param {String} token
 * @param {String} projectName
 * @param {String} variableGroupName
 * @param {String} description
 * @param {JSON Object} variables
 * @param {Number} groupId
 *
 * @returns An Object of updated Variable Group
 */
module.exports.updateVariableGroup = async (
  organizationName,
  token,
  projectName,
  variableGroupName,
  description,
  variables,
  groupId
) => {
  if (!organizationName) return errorStatus.ONF;
  try {
    const azDevOpsConnection = azConnection.getConnection(
      organizationName,
      token
    );
    const taskAPI = await azDevOpsConnection.getTaskAgentApi();
    const variableGroupParameters = {
      name: variableGroupName,
      description: description,
      type: "Vsts",
      variables: variables,
      variableGroupProjectReferences: [
        {
          name: variableGroupName,
          description: description,
          projectReference: {
            name: projectName,
          },
        },
      ],
    };

    let updatedVariableGroup = await taskAPI.updateVariableGroup(
      variableGroupParameters,
      groupId
    );
    return updatedVariableGroup;
  } catch (error) {
    logger.error("Updated Variable Group Error =========>", error);
    throw error;
  }
};

/**
 * Fetches a Variable Group by group Id for a Project
 *
 * @param {String} organizationName
 * @param {String} token
 * @param {String} projectName
 * @param {Number} groupId
 *
 * @returns An Object of Variable Group
 */
module.exports.getVariableGroupById = async (
  organizationName,
  token,
  projectName,
  groupId
) => {
  if (!organizationName) {
    return errorStatus.ONF;
  }

  try {
    const azDevOpsConnection = azConnection.getConnection(
      organizationName,
      token
    );

    const taskAPI = await azDevOpsConnection.getTaskAgentApi();
    const variableGroup = await taskAPI.getVariableGroup(projectName, groupId);

    logger.log("info", `Variable Group ===========> ${variableGroup}`);

    return variableGroup;
  } catch (error) {
    throw error;
  }
};
