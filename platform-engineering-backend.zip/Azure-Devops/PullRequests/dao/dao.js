const azConnection = require("../../../config/azConnection");
const { errorStatus } = require("../../../constants");
const { getRepo } = require("../../Repository/dao/dao");
const rules = require("../../../OrganizationRules/Rules/dao/dao");
//-------------------logger-implementation-----------------------------
const winston = require("winston");
const { createLogs } = require("../../../config/loggerConfig");
const todayDate = new Date().toDateString().replace(/\ /g, "");
const logConfiguration = createLogs("PullRequests Dao", todayDate);
const logger = winston.createLogger(logConfiguration);
//------------------------------------------------------------------------------

/**
 * A function to create a pull request for a branch in a repository.
 *
 * @param {String} organizationName
 * @param {String} token
 * @param {String} projectName
 * @param {String} repositoryId
 * @param {String} sourceBranchName
 * @param {Array} reviewers
 *
 * @returns A object of pull request or an error object.
 */
module.exports.createPullRequest = async (
  organizationName,
  token,
  projectName,
  repositoryId,
  sourceBranchName,
  reviewers,
  existingConnection
) => {
  try {
    let azDevOpsConnection;
    if (!existingConnection) {
      azDevOpsConnection = azConnection.getConnection(organizationName, token);
    } else {
      azDevOpsConnection = existingConnection;
    }
    if (!organizationName) return errorStatus.ONF;
    if (!token) return errorStatus.TNF;
    let pullRequest, defaultBranchMergeType, mergeType;

    // const azDevOpsConnection = azConnection.getConnection(
    //   organizationName,
    //   token
    // );
    const organizationRule = await rules.getOrganizationRules(
      organizationName,
      "AzureDevops"
    );
    logger.log(
      "info",
      `inside create pull request dao organizationRule ${organizationRule}`
    );
    const gitAPI = await azDevOpsConnection.getGitApi();
    logger.log(
      "info",
      `inside create pull request gitapi connection ${gitAPI}`
    );
    if (gitAPI) {
      logger.log("info", `inside create pull request inside if of gitapi`);
    } else {
      logger.log("info", `inside create pull request inside else of gitapi`);
    }
    logger.log(
      "info",
      `inside create pull request repositoryid ${repositoryId} projectName ${projectName}`
    );
    let repo = await gitAPI.getRepository(repositoryId, projectName);
    logger.log("info", "inside create pull request reo console", repo);
    if (repo) {
      logger.log("info", "inside if of getrepo in create pull request");
    }
    let targetBranchName = repo.defaultBranch;
    logger.log(
      "info",
      "inside create pull request targetBranchName",
      targetBranchName
    );
    for (let branch of organizationRule.branchingModel.branches) {
      if (branch.name == repo.defaultBranch.split("/")[2])
        defaultBranchMergeType = branch.mergeType;
    }
    switch (defaultBranchMergeType) {
      case "allowNoFastForward":
        mergeType = 1;
        break;
      case "allowSquash":
        mergeType = 2;
        break;
      case "allowRebase":
        mergeType = 3;
        break;
      case "allowRebaseMerge":
        mergeType = 4;
        break;
    }
    try {
      const pullRequestObject = {
        sourceRefName: sourceBranchName,
        targetRefName: targetBranchName,
        title: "YML Configuration Creation",
        description: "Adding YML Configuration",
        reviewers: reviewers,
      };
      pullRequest = await gitAPI.createPullRequest(
        pullRequestObject,
        repositoryId,
        projectName
      );
      logger.log("info", "created pull request dao", pullRequest);
    } catch (error) {
      logger.error("Exception create pull request", error);
      throw error;
    }

    if (pullRequest.status) {
      const autoCompleteSetBy = {
          id: `${pullRequest.createdBy.id}`,
        },
        completionOptions = {
          deleteSourceBranch: true,
          mergeCommitMessage: "Merge commit for YML Configuration",
          mergeStrategy: mergeType,
        };
      const updatedPullRequest = await gitAPI.updatePullRequest(
        { autoCompleteSetBy, completionOptions },
        repositoryId,
        pullRequest.pullRequestId,
        projectName
      );
      logger.log("info", "updated pull request dao", updatedPullRequest);
      return pullRequest;
    } else throw new Error(pullRequest);
  } catch (error) {
    logger.error("Exception in create pull request", error);
    throw error;
  }
};

/**
 * A function to fetch a list of pull request for a repository.
 *
 * @param {String} organizationName
 * @param {String} token
 * @param {String} projectName
 * @param {String} repositoryId
 *
 * @returns A list of pull request objects or an error object.
 */
module.exports.getPullRequests = async (
  organizationName,
  token,
  projectName,
  repositoryId
) => {
  try {
    if (!organizationName) return errorStatus.ONF;
    if (!token) return errorStatus.TNF;
    let pullRequests;
    const azDevOpsConnection = azConnection.getConnection(
      organizationName,
      token
    );
    const gitAPI = await azDevOpsConnection.getGitApi();

    try {
      pullRequests = await gitAPI.getPullRequests(repositoryId, projectName);
      logger.log("info", "all pull requests dao", pullRequests);
    } catch (error) {
      logger.error("Exception in get all pull requests", error);
      throw error;
    }
    if (pullRequests) return pullRequests;
  } catch (error) {
    logger.error("Exception in all pull requests", error);
    throw error;
  }
};

/**
 * A function to fetch a pull request by pull request ID.
 *
 * @param {String} organizationName
 * @param {String} token
 * @param {String} pullRequestId
 *
 * @returns An object of pull request or an error object.
 */
module.exports.getPullRequestById = async (
  organizationName,
  token,
  pullRequestId
) => {
  try {
    if (!organizationName) return errorStatus.ONF;

    if (!token) return errorStatus.TNF;

    let pullRequest;
    const azDevOpsConnection = azConnection.getConnection(
      organizationName,
      token
    );
    const gitAPI = await azDevOpsConnection.getGitApi();
    try {
      pullRequest = await gitAPI.getPullRequestById(pullRequestId);
      logger.log("info", "get pull request by id dao", pullRequest);
    } catch (error) {
      logger.error("Exception get pull request by id dao", error);
      throw error;
    }
    if (pullRequest) return pullRequest;
  } catch (error) {
    logger.error("Exception get pull request by id dao", error);
    throw error;
  }
};
