const {
  errorStatus,
  errorMessages,
  responsHeader,
  statusCodes,
} = require("../../../constants");
//-------------------logger-implementation-----------------------------
const winston = require("winston");
const { createLogs } = require("../../../config/loggerConfig");
const todayDate = new Date().toDateString().replace(/\ /g, "");
const logConfiguration = createLogs("PullRequests Controller", todayDate);
const logger = winston.createLogger(logConfiguration);
//------------------------------------------------------------------------------
let response = {
  headers: responsHeader,
  body: {},
};
const pullRequestDAO = require("../dao/dao");


/**
 * A handler function to create a pull request for a branch in a repository.
 * 
 * @param {JSON Object} req The request object
 * @param {JSON Object} res The response object
 * 
 * @returns An object of created pull request with Http CREATED status code or error with Http error status code.
 */
module.exports.createPullRequest = async (req, res) => {
  const bearerHeader = req.headers.authorization;
  const personalAccessToken = bearerHeader && bearerHeader.split(" ")[1];

  const {
    organizationName,
    projectName,
    repositoryId,
    sourceBranchName,
    reviewers,
  } = req.body;

  logger.log("info", "inside pull request controller", req.body);
  try {
    const createdPullRequest = await pullRequestDAO.createPullRequest(
      organizationName,
      personalAccessToken,
      projectName,
      repositoryId,
      sourceBranchName,
      reviewers
    );

    if (createdPullRequest === errorStatus.ONF) {
      response.body = {
        messages: errorMessages.ONF,
      };
      res.status(statusCodes.NOT_FOUND).send(response);
    } else if (createdPullRequest === errorStatus.TNF) {
      response.body = {
        messages: errorMessages.TNF,
      };
      res.status(statusCodes.NOT_FOUND).send(response);
    } else if (createdPullRequest.pullRequestId) {
      response.body = {
        pullRequest: createdPullRequest,
      };
      res.status(statusCodes.CREATED).send(response);
    }
  } catch (error) {
    logger.error("Exception in create pull request", error);
    response.body = error;
    res.status(error.statusCode).send(response);
  }
};


/**
 * A handler function to fetch a list of pull request for a repository.
 * 
 * @param {String} req The request query parameters
 * @param {JSON Object} res The respone object
 * 
 * @returns A list of pull request objects with Http SUCCESS status code or error with Http error status codes.
 */
module.exports.getPullRequests = async (req, res) => {
  const bearerHeader = req.headers.authorization;
  const personalAccessToken = bearerHeader && bearerHeader.split(" ")[1];
  const { organizationName, projectName, repositoryId } = req.query;
  logger.log(
    "info",
    "inside get pull request controller request query parameter",
    req.query
  );
  try {
    const pullRequests = await pullRequestDAO.getPullRequests(
      organizationName,
      personalAccessToken,
      projectName,
      repositoryId
    );

    if (pullRequests === errorStatus.ONF) {
      response.body = {
        messages: errorMessages.ONF,
      };
      res.status(statusCodes.NOT_FOUND).send(response);
    } else if (pullRequests === errorStatus.TNF) {
      response.body = {
        messages: errorMessages.TNF,
      };
      res.status(statusCodes.NOT_FOUND).send(response);
    } else if (pullRequests) {
      response.body = {
        pullRequests: pullRequests,
      };
      res.status(statusCodes.SUCCESS).send(response);
    }
  } catch (error) {
    logger.error("Exception in get pull request ", error);
    response.body = error;
    res.status(error.statusCode).send(response);
  }
};

/**
 * A handler function to fetch a pull request by pull request ID.
 * 
 * @param {String} req The request query parameters 
 * @param {JSON OBject} res The response object.
 * 
 * @returns An object of pull request with Http SUCCESS status code or error with Http error status codes.
 */
module.exports.getPullRequestById = async (req, res) => {
  const bearerHeader = req.headers.authorization;
  const personalAccessToken = bearerHeader && bearerHeader.split(" ")[1];

  const { organizationName, pullRequestId } = req.query;

  try {
    const pullRequest = await pullRequestDAO.getPullRequestById(
      organizationName,
      personalAccessToken,
      pullRequestId
    );
    if (pullRequest === errorStatus.ONF) {
      response.body = {
        messages: errorMessages.ONF,
      };
      res.status(statusCodes.NOT_FOUND).send(response);
    } else if (pullRequest === errorStatus.TNF) {
      response.body = {
        messages: errorMessages.TNF,
      };
      res.status(statusCodes.NOT_FOUND).send(response);
    } else if (pullRequest == null) {
      response.body = {
        message: `Pull Request with ID ${pullRequestId} does not exist.`,
      };
      res.status(statusCodes.NOT_FOUND).send(response);
    } else if (pullRequest) {
      response.body = {
        pullRequest: pullRequest,
      };
      res.status(statusCodes.SUCCESS).send(response);
    }
  } catch (error) {
    logger.error("Exception in get pull request by id", error);
    response.body = error;
    res.status(error.statusCode).send(response);
  }
};
