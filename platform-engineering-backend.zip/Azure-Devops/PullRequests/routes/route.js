const express = require("express");
const router = express.Router();
const controller = require("../controller/controller");


//Creates an pull request
router.post("/", controller.createPullRequest);

//Fetches a list of pull requests
router.get("/", controller.getPullRequests);

//Fetches a pull request by pull request ID
router.get("/pullrequest", controller.getPullRequestById);

module.exports = router;