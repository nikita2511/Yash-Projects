const projectDAO = require("../dao/dao");
const { getProject } = require("../dao/dao");

const {
  errorStatus,
  errorMessages,
  responsHeader,
  statusCodes,
} = require("../../../constants");

let response = {
  headers: responsHeader,
  body: {},
};

//-------------------logger-implementation-----------------------------
const winston = require("winston");
const { createLogs } = require("../../../config/loggerConfig");
const todayDate = new Date().toDateString().replace(/\ /g, "");
const logConfiguration = createLogs("Projects Controller", todayDate);
const logger = winston.createLogger(logConfiguration);
//------------------------------------------------------------------------------

/**
 * A handler function to fetch a list of projects for an organization
 * 
 * @param {String} req The request query parameters
 * @param {JSON Object} res The response object.
 * 
 * @returns A list of project objects with Http SUCCESS status code or error with Http error status codes.
 */
module.exports.getAllProjects = async (req, res) => {
  try {
    const bearerHeader = req.headers.authorization;
    const organizationName = req.query.organizationName;

    const personalAccessToken = bearerHeader && bearerHeader.split(" ")[1];
    var projects = await projectDAO.getAllDevOpsProjects(
      organizationName,
      personalAccessToken
    );

    if (projects == errorStatus.ONF) {
      response.body = {
        message: errorMessages.ONF,
        error: errorStatus.ONF,
      };
      res.status(statusCodes.BAD_REQUEST).send(response);
    } else if (projects.status == errorStatus.CNF) {
      response.body = {
        message: errorMessages.CNF,
        error: errorStatus.CNF,
      };
      res.status(statusCodes.NOT_FOUND).send(response);
    } else {
      response.body = {
        projects: projects,
      };
      res.status(statusCodes.SUCCESS).send(response);
    }
  } catch (error) {
    logger.error("getAllProjects Controller Error ===============>", error);
    if (error.statusCode) {
      response.body = {
        errorStatus: error.statusCode,
        errorMessage: error.message,
      };
      return res.status(error.statusCode).send(response);
    } else {
      response.body = {
        errorStatus: statusCodes.SERVER_ERROR,
        errorMessage: error.message,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};


/**
 * A handler function to create a project in an organization.
 * 
 * @param {JSON Object} req The request object.
 * @param {JSON Object} res The response object.
 * 
 * @returns An object of created project with Http CREATED status code or error with Http error status codes.
 */
module.exports.createProject = async (req, res) => {
  const bearerHeader = req.headers.authorization;
  const organizationName = req.query.organizationName;
  const project = req.body;

  const personalAccessToken = bearerHeader && bearerHeader.split(" ")[1];
  try {
    var createdProject = await projectDAO.createProject(
      organizationName,
      personalAccessToken,
      project
    );
    if (createdProject == errorStatus.ONF) {
      response.body = {
        message: errorMessages.ONF,
        error: errorStatus.ONF,
      };
      res.status(statusCodes.BAD_REQUEST).send(response);
    } else if (createdProject.status == errorStatus.CNF) {
      response.body = {
        message: errorMessages.CNF,
        error: errorStatus.CNF,
      };
      res.status(statusCodes.NOT_FOUND).send(response);
    } else if (createdProject.status == errorStatus.CCP) {
      response.body = {
        message: errorMessages.CCP,
        error: errorStatus.CCP,
      };
      res.status(statusCodes.SUCCESS).send(response);
    } else if (createdProject == false) {
      response.body = {
        message: errorMessages.PAE,
        error: errorStatus.PAE,
      };
      res.status(statusCodes.SUCCESS).send(response);
    } else {
      response.body = createdProject;
      res.status(statusCodes.CREATED).send(response);
    }
  } catch (error) {
    if (error.statusCode) {
      response.body = {
        errorStatus: error.statusCode,
        errorMessage: error.message,
      };
      return res.status(error.statusCode).send(response);
    } else {
      response.body = {
        errorStatus: statusCodes.SERVER_ERROR,
        errorMessage: error.message,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};


/**
 * A handler function to create a project in an organization with optionally creating branches, adding users to a project, creating Variable Groups or Pipeline creation.
 * 
 * @param {JSON Object} req The request object
 * @param {JSON Object} res The response object
 * 
 * @returns An object with Http CREATED status code or error with Http error status codes.
 */
module.exports.createFullProject = async (req, res) => {
  const bearerHeader = req.headers.authorization;
  // const organizationName = req.query.organizationName;
  const project = req.body;

  const personalAccessToken = bearerHeader && bearerHeader.split(" ")[1];
  try {
    var createdProject = await projectDAO.createFullProject(
      personalAccessToken,
      project
    );
    if (createdProject == errorStatus.ONF) {
      response.body = {
        message: errorMessages.ONF,
        error: errorStatus.ONF,
      };
      res.status(statusCodes.BAD_REQUEST).send(response);
    } else if (createdProject.status == errorStatus.CNF) {
      response.body = {
        message: errorMessages.CNF,
        error: errorStatus.CNF,
      };
      res.status(statusCodes.NOT_FOUND).send(response);
    } else if (createdProject == false) {
      response.body = {
        message: errorMessages.PAE,
        error: errorStatus.PAE,
      };
      res.status(statusCodes.REQUEST_CONFLICT).send(response);
    } else {
      response.body = createdProject;
      res.status(statusCodes.CREATED).send(response);
    }
  } catch (error) {
    if (error.statusCode) {
      response.body = {
        errorStatus: error.statusCode,
        errorMessage: error.message,
      };
      return res.status(error.statusCode).send(response);
    } else {
      response.body = {
        errorStatus: statusCodes.SERVER_ERROR,
        errorMessage: error.message,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};


/**
 * A handler method to fetch a project by project name.
 * 
 * @param {String} req The request query parameters
 * @param {JSON Object} res The response object
 * 
 * @returns An object of project with Http SUCCESS status code or error with Http error status codes.
 */
module.exports.getProject = async (req, res) => {
  const bearerHeader = req.headers.authorization;
  const organizationName = req.query.organizationName;
  const projectName = req.query.projectName;

  const personalAccessToken = bearerHeader && bearerHeader.split(" ")[1];

  try {
    var project = await getProject(
      organizationName,
      personalAccessToken,
      projectName
    );

    if (project == errorStatus.CNF) {
      response.body = {
        message: errorMessages.CNF,
      };
      res.status(statusCodes.NOT_FOUND).send(response);
    } else if (project) {
      response.body = {
        project: project,
      };
      res.status(statusCodes.SUCCESS).send(response);
    }
  } catch (error) {
    if (error.statusCode) {
      response.body = {
        errorStatus: error.statusCode,
        errorMessage: error.message,
      };
      return res.status(error.statusCode).send(response);
    } else {
      response.body = {
        errorStatus: statusCodes.SERVER_ERROR,
        errorMessage: error.message,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};

module.exports.getProjectInfo = async(req,res) => {
  // // const organizationName = req.query.organizationName;
  // const projectName = req.query.projectName;
try{
  const projectDetails = await projectDAO.getProjectDBInfo();
  if(projectDetails.length > 0){
    response.body = {
      projectDetails : projectDetails
    }
    return res.status(statusCodes.SUCCESS).send(response);
  }
  else{
    response.body = {
      projectDetails: errorMessages.DAE
    }
    return res.status(statusCodes.NOT_FOUND).send(response);
  }

}catch(error){
  logger.error('Error in getting Project Details===>',error);
  response.body= {
    error : error.message
  }
  return res.status(statusCodes.SERVER_ERROR).send(response);
}
  
}


module.exports.getProjectInfoByName = async(req,res) => {
  const projectName = req.query.projectName;
try{
  const projectDetails = await projectDAO.getProjectInfoByName(projectName);
  if(projectDetails._id){
    response.body = {
      projectDetails : projectDetails
    }
    return res.status(statusCodes.SUCCESS).send(response);
  }
  else{
    response.body = {
      projectDetails: errorMessages.DAE
    }
    return res.status(statusCodes.NOT_FOUND).send(response);
  }

}catch(error){
  logger.error('Error in getting Project Details===>',error);
  response.body= {
    error : error.message
  }
  return res.status(statusCodes.SERVER_ERROR).send(response);
}
  
}

module.exports.getProjectsByOrganizationName = async(req,res) => {
  const organizationName = req.query.organizationName;
try{
  const projectDetails = await projectDAO.getProjectsByOrganizationName(organizationName);

  if(projectDetails.length > 0){
    response.body = {
      projectDetails : projectDetails
    }
    return res.status(statusCodes.SUCCESS).send(response);
  }
  else{
    response.body = {
      projectDetails: errorMessages.DAE
    }
    return res.status(statusCodes.NOT_FOUND).send(response);
  }

}catch(error){
  logger.error('Error in getting Project Details===>',error);
  response.body= {
    error : error.message
  }
  return res.status(statusCodes.SERVER_ERROR).send(response);
}
  
}
