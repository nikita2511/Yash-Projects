const azConnection = require("../../../config/azConnection");
const { errorStatus, errorMessages } = require("../../../constants");
const repositoryDao = require("../../Repository/dao/dao");
const variableGroupsDAO = require("../../VariableGroup/dao/dao");
const { createBranchesForModel, delay } = require("../../../Utilities/util");
const userDao = require("../../Users/dao/dao");
const ProjectInfo = require("../models/ProjectInfo");
const dbOperations = require("../../../dbOperations");
let rules = require("../../../OrganizationRules/Rules/dao/dao");
const {
  createPipelineWithYMLandPullRequest,
  commitDotnetSkeletonCode,
  commitJavaSkeltonCode,
} = require("../../Pipelines/dao/dao");
const { connect } = require("../../../config/dbConfig");

const WebSocket = require("ws");

//-------------------logger-implementation-----------------------------
const winston = require("winston");
const { createLogs } = require("../../../config/loggerConfig");
const todayDate = new Date().toDateString().replace(/\ /g, "");
const logConfiguration = createLogs("Projects Dao", todayDate);
const logger = winston.createLogger(logConfiguration);
//------------------------------------------------------------------------------

/**
 * A function to fetch a list of project for an organization.
 *
 * @param {String} organizationName
 * @param {String} token
 *
 * @returns A list of project objects or an error object.
 */
const getAllDevOpsProjects = async (organizationName, token) => {
  if (!organizationName) return errorStatus.ONF;
  let azDevOpsConnection, coreAPI, projects;
  try {
    azDevOpsConnection = azConnection.getConnection(organizationName, token);
    coreAPI = await azDevOpsConnection.getCoreApi();
    projects = await coreAPI.getProjects();
    const sortedProjects = projects.sort((a, b) => {
      const lastUpdateTimeComparison = b.lastUpdateTime - a.lastUpdateTime;
      if (lastUpdateTimeComparison !== 0) {
        return lastUpdateTimeComparison;
      }

      return a.name.localeCompare(b.name);
    });
    return sortedProjects;
  } catch (error) {
    logger.error("getAllDevOpsProjects Dao Error =============>", error);
    throw error;
  }
};

/**
 * A function to create a project in an organization.
 *
 * @param {String} organizationName
 * @param {String} token
 * @param {JSON Object} project
 *
 * @returns An object of created project or an error object.
 */
const createProject = async (
  organizationName,
  token,
  project,
  existingConnection
) => {
  let azDevOpsConnection, coreAPI, existingProject, createdProject;
  try {
    if (!organizationName) return errorStatus.ONF;
    if (!existingConnection) {
      azDevOpsConnection = azConnection.getConnection(organizationName, token);
    } else {
      azDevOpsConnection = existingConnection;
    }
    existingProject = await checkIfProjectExist(azDevOpsConnection, project);
    if (existingProject.status == errorStatus.CNF) {
      return existingProject;
    } else if (existingProject == true) return false;
    else {
      coreAPI = await azDevOpsConnection.getCoreApi();
      createdProject = await coreAPI.queueCreateProject(project);
      return createdProject;
    }
  } catch (error) {
    logger.error("createProject Dao Error =============>", error);
    throw error;
  }
};

/**
 * A function to fetch a project by project name.
 *
 * @param {String} organizationName
 * @param {String} token
 * @param {String} projectName
 *
 * @returns An object of project or an error object.
 */
async function getProject(
  organizationName,
  token,
  projectName,
  existingConnection
) {
  let azDevOpsConnection, coreAPI, project;
  try {
    if (!organizationName) return errorStatus.ONF;
    if (!existingConnection) {
      azDevOpsConnection = azConnection.getConnection(organizationName, token);
    } else {
      azDevOpsConnection = existingConnection;
    }
    // azDevOpsConnection = azConnection.getConnection(organizationName, token);
    coreAPI = await azDevOpsConnection.getCoreApi();
    project = await coreAPI.getProject(projectName);
    return project;
  } catch (error) {
    logger.error("getProject Dao Error =============>", error);
    throw error;
  }
}

/**
 * A function to check whether a project with given project name exists or not.
 *
 * @param {JSON Object} azDevOpsConnection
 * @param {String} project
 *
 * @returns A boolean value or error object.
 */
const checkIfProjectExist = async (azDevOpsConnection, project) => {
  try {
    let coreAPI = await azDevOpsConnection.getCoreApi();
    let projects = await coreAPI.getProjects();
    for (let i = 0; i < projects.length; i++) {
      const element = projects[i];
      if (element.name === project.name) {
        return true;
      }
    }
    return false;
  } catch (error) {
    throw error;
  }
};

/**
 * A function to create a project with option parameter to create Variable Group, to Add Users in a Project or to create a Pipeline.
 *
 * @param {String} token
 * @param {JSON Object} project
 *
 * @returns An object with parameters defaultRepoInitialization, branchCreation, isDefaultBranchSet, reviewersPolicyCreated, mergeTypePolicyCreated, isVariableGroupsAdded, userCreation, pipelineCreation or an error object.
 */
const createFullProject = async (token, project) => {
  //return new Promise((resolve, reject) => {
    //const wss = new WebSocket.Server({ port:443 });
    let azDevOpsConnection,
      existingProject,
      createdProject,
      successResponse = {},
      isMainBranchCreated,
      projectId,
      count = 0;

    const {
      organizationName,
      name,
      projectCreatedByUser,
      description,
      visibility,
      capabilities,
      variableGroups,
      users,
      pipeline,
    } = project;
    const projectToCreate = { name, description, visibility, capabilities };
    //wss.on("connection", async function connection(ws) {
      try {
        if (!organizationName) return errorStatus.ONF;
        azDevOpsConnection = azConnection.getConnection(
          organizationName,
          token
        );

        //ws.send("Project Creation on progress..");

        existingProject = await checkIfProjectExist(
          azDevOpsConnection,
          projectToCreate
        );
        if (existingProject.status == errorStatus.CNF) {
          //resolve(existingProject);
           return existingProject;
        } else if (existingProject == true) {
          //resolve(false);
          return false; 
        } else {
          createdProject = await createProject(
            organizationName,
            token,
            projectToCreate,
            azDevOpsConnection
          );
          delay(500);
          logger.log("info", `createdProject ${createdProject}`);
          let recentCreatedProject;
          let projectCreatedBy;
          do {
            if (count === 5) break;
            delay(200);
            recentCreatedProject = await getProject(
              organizationName,
              token,
              projectToCreate.name,
              azDevOpsConnection
            );
            count++;
          } while (
            recentCreatedProject === undefined ||
            recentCreatedProject === null
          );

          while (recentCreatedProject.state != "wellFormed") {
            delay(200);
            recentCreatedProject = await getProject(
              organizationName,
              token,
              projectToCreate.name,
              azDevOpsConnection
            );
          }

          successResponse.projectCreation = true;
          successResponse.message = "project creation is completed";
          //ws.send("Project Successfully Created!!");

          projectId = recentCreatedProject.id;

          let initializedRepo = await repositoryDao.initializeRepoWithReadme(
            recentCreatedProject.name,
            organizationName,
            projectId,
            token,
            azDevOpsConnection
          );
          logger.log("info", `initialized repo ${initializedRepo}`);
          //ws.send("Repository Initialization..");

          let operationCount = 0;

          do {
            if (operationCount === 2) break;
            isMainBranchCreated = await repositoryDao.getBranch(
              organizationName,
              token,
              projectToCreate.name,
              "main",
              projectToCreate.name,
              azDevOpsConnection
            );
            operationCount++;
          } while (isMainBranchCreated === null);
          if (initializedRepo) {
            successResponse.defaultRepoInitialization = true;
            successResponse.message = "default repo is initialized";
            //ws.send("Default repo has initialized!!");
            let createdBranchesResponse = await createBranchesForModel(
              organizationName,
              token,
              recentCreatedProject.name,
              recentCreatedProject.name,
              azDevOpsConnection
            );

            if (createdBranchesResponse) {
              successResponse.branchCreation =
                createdBranchesResponse.branchCreation;
              successResponse.reviewersPolicyCreated =
                createdBranchesResponse.reviewersPolicyCreated;
              successResponse.mergeTypePolicyCreated =
                createdBranchesResponse.mergeTypePolicyCreated;
              successResponse.isDefaultBranchSet =
                createdBranchesResponse.isDefaultBranchSet;
              // ws.send(
              //   "Repositary has created according to org rule & branch policies has applied!!"
              // );
              if (pipeline) {
                //pipeline creation

                //ws.send("Pipeline Creation ..");

                const {
                  applicationType,
                  publishArtifacts,
                  userNameInitials,
                  pipelineName,
                  reviewers,
                } = pipeline;
                let createdPipeline = await createPipelineWithYMLandPullRequest(
                  organizationName,
                  token,
                  recentCreatedProject.name,
                  recentCreatedProject.name,
                  applicationType,
                  publishArtifacts,
                  userNameInitials,
                  pipelineName,
                  reviewers,
                  azDevOpsConnection
                );
                logger.log("info", `createdPipeline ${createdPipeline}`);
                if (createdPipeline) {
                  successResponse.pipelineCreation = createdPipeline;
                  //ws.send("Pipeline Created..");
                } else {
                  successResponse.pipelineCreation = false;
                }
              }
              if (variableGroups) {
                const { variableGroupName, description, variables } =
                  variableGroups;
                logger.log("info", `variableGroups ${variableGroups}`);
                const createdVariableGroups =
                  await variableGroupsDAO.addVariableGroup(
                    organizationName,
                    token,
                    projectToCreate.name,
                    variableGroupName,
                    description,
                    variables,
                    azDevOpsConnection
                  );
                logger.log(
                  "info",
                  `createdVariableGroups ${createdVariableGroups}`
                );
                if (createdVariableGroups.id) {
                  successResponse.isVariableGroupsAdded = true;
                  //add user code
                  //ws.send("Variable Group Created..");
                }
              }

              if (users.length) {
                let createdUsers = await userDao.addUserToProject(
                  organizationName,
                  token,
                  projectId,
                  users
                );
                if (createdUsers.length) {
                  successResponse.userCreation = true;
                  //ws.send("Users Created ..");
                } else {
                  successResponse.userCreation = false;
                }
              }

              //---------------------------this is for saving project details-----------------------------

              let orgRule = await rules.getOrganizationRules(
                organizationName,
                "AzureDevops"
              );
              let branchingStrategy;
              if (orgRule) {
                branchingStrategy = orgRule.branchingModel;
              }
              projectId = recentCreatedProject.id;
              projectName = recentCreatedProject.name;
              projectCreatedBy = projectCreatedByUser;
              projectState = recentCreatedProject.state;
              branchingModel = branchingStrategy.name;

              //---------------------------------------------------------------------------------

              const data = [
                {
                  projectId: projectId,
                  projectName: projectName,
                  projectCreatedByUser: projectCreatedBy,
                  state: projectState,
                  branchingModel: branchingModel,
                  organizationName: organizationName,
                },
              ];

              const inserted_details = await dbOperations.insertMany(
                ProjectInfo,
                data
              );
              logger.log("info", `Project Data inserted ${inserted_details}`);
            }
            //resolve(successResponse);
            return successResponse
          } else {
            successResponse.defaultRepoInitialization = false;
            successResponse.message =
              "Project is created successfully but the repository is not initialized";
            successResponse.recentCreatedProject = recentCreatedProject;
            //resolve(successResponse);
            return successResponse
          }
        }
        //wss.close();
      } catch (error) {
        logger.error("createFullProject Dao Error =============>", error);
        //reject(error);
        //wss.close();
        throw error;
      }
    //});
  //});
};

const getProjectDBInfo = async () => {
  try {
    try {
      await connect();
    } catch (error) {
      logger.error("Exception in project rule dao", error);
      throw new Error("Failed to connect to the database.");
    }

    let result = await dbOperations.getAll(ProjectInfo);
    return result;
  } catch (error) {
    logger.error("Error in getting projectInfoDB Details=====>", error);
    throw error;
  }
};

const getProjectInfoByName = async (projectName) => {
  try {
    try {
      await connect();
    } catch (error) {
      logger.error("Exception in project rule dao", error);
      throw new Error("Failed to connect to the database.");
    }

    let result = await ProjectInfo.findOne({ projectName: projectName });
    return result;
  } catch (error) {
    logger.error("Error in getting projectInfoDB Details=====>", error);
    throw error;
  }
};

const getProjectsByOrganizationName = async (organizationName) => {
  try {
    try {
      await connect();
    } catch (error) {
      logger.error("Exception in project rule dao", error);
      throw new Error("Failed to connect to the database.");
    }

    let result = await ProjectInfo.find({ organizationName: organizationName });
    return result;
  } catch (error) {
    logger.error("Error in getting projectInfoDB Details=====>", error);
    throw error;
  }
};

module.exports = {
  getAllDevOpsProjects,
  createProject,
  createFullProject,
  getProject,
  getProjectsByOrganizationName,
  getProjectInfoByName,
  getProjectDBInfo,
};
