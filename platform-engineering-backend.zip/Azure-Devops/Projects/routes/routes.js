const express = require("express");
const router = express.Router();

const controller = require("../controller/controller");
const {
  validate,
  getAllProjectsValidation,
  createProjectValidation,
  getProjectValidation,
} = require("../middleware/validator");

//Fetches A list of Projects for an organization
router.get(
  "/",
  getAllProjectsValidation(),
  validate,
  controller.getAllProjects
);

//Create a project for an organization
// router.post(
//   "/",
//   createProjectValidation(),
//   validate,
//   controller.createProjectWithDefaultRepo
// );

//Creates a project with optional features like Variable Groups, Adding Users, Pipeline Creation.
router.post(
  "/",
  createProjectValidation(),
  validate,
  controller.createFullProject
);

//Fetches a project by projectId
router.get("/project", getProjectValidation(), validate, controller.getProject);
router.get("/projectInfo",controller.getProjectInfo);
router.get("/projectByName",controller.getProjectInfoByName);
router.get("/projectsByOrganization",controller.getProjectsByOrganizationName)

module.exports = router;
