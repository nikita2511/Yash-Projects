const mongoose = require("mongoose");
const schema = mongoose.Schema;

/**
 * Schema for Project Inforamtion
 * 
 * @returns An object of project information model.
 **/
const ProjectInfo = new schema({
  _id: { type: schema.Types.ObjectId, required: true, auto: true },
  organizationName: { type: schema.Types.String },
  projectId: { type: schema.Types.String },
  projectName: { type: schema.Types.String },
  projectCreatedByUser: { type: schema.Types.String },
  state: { type: schema.Types.String },
  branchingModel: { type: schema.Types.String },
  created_at: { type: Date, required: true, default: Date.now },
  updated_at: { type: Date, required: true, default: Date.now },
});

module.exports = mongoose.model("projectInfo", ProjectInfo);
