const { check, validationResult } = require("express-validator");

/**
 * A function to validate parameters in request body object.
 *
 * @returns A list of missing parameters in request body object.
 */
module.exports.createProjectValidation = () => {
  return [
    check("organizationName")
      .exists()
      .withMessage("organization name is missing!")
      .notEmpty()
      .withMessage("organization name must not empty!"),
    check("name")
      .isString()
      .withMessage("Project name must be a string!")
      .exists()
      .withMessage("Project name is missing!")
      .notEmpty()
      .withMessage("Project name must not be empty!"),
    check("capabilities")
      .isObject()
      .withMessage("Project capability properties must be an object!")
      .exists()
      .withMessage("Project capabilities is missing!")
      .notEmpty()
      .withMessage("Project capabilities must not empty!"),
    check("capabilities.*")
      .isObject()
      .withMessage("Project capability properties must be an object!")
      .exists()
      .withMessage("Project capability properties is/are is missing!")
      .notEmpty()
      .withMessage(
        "Project capability property/properties! must not be empty!"
      ),
    check("capabilities.*.*")
      .isString()
      .withMessage("Project capability sub-properties must be an String!")
      .exists()
      .withMessage("Project capability sub-properties is/are is missing!")
      .notEmpty()
      .withMessage(
        "Project capability sub-property/sub-properties! must not be empty!"
      ),
    check("visibility")
      .exists()
      .withMessage("Project visibility is missing!")
      .notEmpty()
      .withMessage("Project visibility must not be empty!"),
  ];
};

/**
 * A function to validate parameters in request query.
 *
 * @returns A list of missing parameters in request query.
 */
module.exports.getAllProjectsValidation = () => {
  return [
    check("organizationName")
      .exists()
      .withMessage("organization name is missing")
      .notEmpty()
      .withMessage("organization name must not empty"),
  ];
};

/**
 * A function to validate parameters in request query.
 *
 * @returns A list of missing parameters in request query.
 */
module.exports.getProjectValidation = () => {
  return [
    check("organizationName")
      .exists()
      .withMessage("organization name is missing")
      .notEmpty()
      .withMessage("organization name must not empty"),
    check("projectName")
      .exists()
      .withMessage("Project name is missing")
      .notEmpty()
      .withMessage("Project name must not empty"),
  ];
};


/**
 * A handler function to validate parameters in request object.
 * 
 * @param {Array} req The request as array
 * @param {JSON Object} res The response object
 * @param {Callback function} next A callback function 
 * 
 * @returns A callback function or a error object with Http error status code.
 */
module.exports.validate = (req, res, next) => {
  const errors = validationResult(req);
  if (errors.isEmpty()) {
    return next();
  }
  const extractedErrors = [];
  errors.array().map((err) => extractedErrors.push({ [err.param]: err.msg }));

  return res.status(422).json({
    errors: extractedErrors,
  });
};
