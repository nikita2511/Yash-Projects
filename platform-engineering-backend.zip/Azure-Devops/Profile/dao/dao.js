const axios = require("axios");
const { errorStatus, errorMessages } = require("../../../constants");

//-------------------logger-implementation-----------------------------
const winston = require("winston");
const { createLogs } = require("../../../config/loggerConfig");
const todayDate = new Date().toDateString().replace(/\ /g, "");
const logConfiguration = createLogs("Profile Dao", todayDate);
const logger = winston.createLogger(logConfiguration);
//------------------------------------------------------------------------------

/**
 * This function is to getUserProfile
 * 
 * @param {String} token 
 * @returns user object or an error object
 */
const getUserProfile = async (token) => {
  // Try to get the user profile.
  try {
    // Make a GET request to the user profile endpoint.
    const response = await axios.get(
      `https://app.vssps.visualstudio.com/_apis/profile/profiles/me?api-version=7.0`,
      {
        // Set the Authorization header to the Bearer token.
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );
    // Return the user profile data.
    return response.data;
  } catch (error) {
    // Log the error.
    logger.error("Error in getUserProfile: ", error);
    // If there is a response, throw an error with the response message.
    if (error.response) {
      throw new Error(
        "Failed to retrieve user profile: " + error.response.data.message
      );
    } else {
      // Otherwise, throw a generic error.
      throw new Error("Failed to retrieve user profile.");
    }
  }
};

module.exports = { getUserProfile };
