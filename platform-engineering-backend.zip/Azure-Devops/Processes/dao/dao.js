const azConnection = require("../../../config/azConnection");
const { errorStatus, errorMessages } = require("../../../constants");

/**
 * This function is to get Processes
 * @param {String} organizationName 
 * @param {String} token 
 * @returns Processes Object
 */
module.exports.getProcesses = async (organizationName, token) => {
  // Check if the organization name is provided
  if (!organizationName) return errorStatus.ONF;

  // Initialize the Azure DevOps connection and the core API
  let azDevOpsConnection, coreAPI;
  try {
    azDevOpsConnection = azConnection.getConnection(organizationName, token);
    coreAPI = await azDevOpsConnection.getCoreApi();

    // Get the processes from the core API
    let processes = await coreAPI.getProcesses();
    return processes;
  } catch (error) {
    // Return an error if an error occurred
    return {
      status: errorStatus.CNF,
      error: error,
    };
  }
};
