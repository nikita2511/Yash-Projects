const processDAO = require("../dao/dao");
const {
  errorStatus,
  errorMessages,
  responsHeader,
  statusCodes,
} = require("../../../constants");
let response = {
  headers: responsHeader,
  body: {},
};

/**
 * A handler function to get Processes.
 * 
 * @param {String} req The request query parameters
 * @param {JSON Object} res The response object
 * 
 * @returns An object with Http CREATED status code or error with Http error status codes.
 */
module.exports.getProcesses = async (req, res) => {
  // Get the bearer header from the request
  const bearerHeader = req.headers.authorization;
  // Get the organization name from the query parameters
  const organizationName = req.query.organizationName;

  // Get the personal access token from the bearer header
  const personalAccessToken = bearerHeader && bearerHeader.split(" ")[1];
  // Get the processes from the processDAO
  var processes = await processDAO.getProcesses(
    organizationName,
    personalAccessToken
  );

  // Check if the processes are empty
  if (processes == errorStatus.ONF) {
    // Create a response object
    response.body = {
      message: errorMessages.ONF,
      error: errorStatus.ONF,
    };
    // Send the response with a BAD_REQUEST status code
    res.status(statusCodes.BAD_REQUEST).send(response);
  } else if (processes.status == errorStatus.CNF) {
    // Create a response object
    response.body = {
      message: errorMessages.CNF,
      error: errorStatus.CNF,
    };
    // Send the response with a NOT_FOUND status code
    res.status(statusCodes.NOT_FOUND).send(response);
  } else {
    // Create a response object
    response.body = { processes: processes };
    // Send the response with a SUCCESS status code
    res.status(statusCodes.SUCCESS).send(response);
  }
};
