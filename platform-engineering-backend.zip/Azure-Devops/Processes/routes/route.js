const express = require("express");
const router = express.Router();

const controller = require("../controller/controller");


// Get Processes for an organization
router.get("/", controller.getProcesses);

module.exports = router;