const { connect } = require("../../../config/dbConfig");
const { errorStatus } = require("../../../constants");
const dbOperations = require("../../../dbOperations");
const { mongoose } = require("mongoose");

const winston = require("winston");
const { createLogs } = require("../../../config/loggerConfig");
const todayDate = new Date().toDateString().replace(/\ /g, "");
const logConfiguration = createLogs("azure-directories-dao", todayDate);
const logger = winston.createLogger(logConfiguration);

const azureDirectoryModel = require("../model/azureDirectoryModel");

/**
 * Saves a Azure Actve Directory Object in database
 *
 * @param {JSON Object} activeDirectory
 * @returns Saved Azure Active Directory Object
 */
async function saveActiveDirectory(activeDirectory) {
  try {
    await connect();
    const checkExistingDirectory = await dbOperations.findOne(
      azureDirectoryModel,

      { activeDirectoryId: activeDirectory.activeDirectoryId },
    );

    if (checkExistingDirectory) {
      return errorStatus.RAE;
    }

    if (activeDirectory.isActiveDirectoryPrimary) {
      let primaryActiveDirectory = await dbOperations.findOne(
        azureDirectoryModel,
        { isActiveDirectoryPrimary: true },

      );
      let updatedADInfo = await dbOperations.update(
        azureDirectoryModel,
        { activeDirectoryId: primaryActiveDirectory.activeDirectoryId },
        {
          isActiveDirectoryPrimary: false,
        },
      );

      if (!updatedADInfo) {
        throw new Error("cannot save the info");
      }
    }

    const savedActiveDirectory = await dbOperations.save(
      azureDirectoryModel,
      activeDirectory
    );

    if (savedActiveDirectory) return savedActiveDirectory;
  } catch (error) {
    logger.error(`Create AD DAO error : ${error}`);
    throw error;
  }
}

/**
 * Lists Azure Active Directories saved in database
 *
 * @returns A list of Azure Active Directories
 */
async function getActiveDirectories() {
  let session;
  try {
    await connect();
    session = await mongoose.connection.startSession();
    session.startTransaction();
    const activeDirectories = await dbOperations.getAll(azureDirectoryModel);

    await session.commitTransaction();
    await session.endSession();
    if (activeDirectories) return activeDirectories;
  } catch (error) {
    logger.error("Exception in get azure directory", error);
    if (session) {
      await session.abortTransaction();
      await session.endSession();
    }
    throw new Error("Failed to connect to the database.");
  }
}

/**
 * A function to update existing Azure Active Directory.
 *
 * @param {String} directoryId
 * @param {JSON Object} objectToUpdate
 *
 * @returns An updated Azure Active Directory Object or an error object.
 */
async function updateDirectory(directoryId, objectToUpdate) {
  try {
    await connect();
    const updatedDirectory = await dbOperations.update(
      azureDirectoryModel,
      directoryId,
      objectToUpdate
    );
    return updatedDirectory;
  } catch (error) {
    logger.error("Exception in delete update directory", error);
    throw new Error("Failed to connect to the database.");
  }
}

/**
 * A function to delete an Azure Active Directory from database
 *
 * @param {String} directoryId
 *
 * @returns An object with deleteCount field or error
 */
async function deleteDirectory(directoryId) {
  try {
    await connect();
    const deletedDirectory = await dbOperations.delete(azureDirectoryModel, {
      activeDirectoryId: directoryId,
    });
    return deletedDirectory;
  } catch (error) {
    logger.error("Exception in delete azure directory", error);
    throw new Error("Failed to connect to the database.");
  }
}

/**
 * A function to fetch Azure Active Directory by Active Direcytory ID
 *
 * @param {String} activeDirectoryId
 *
 * @returns An object of Azure Active Directory or an error object.
 */
async function getActiveDirectory(activeDirectoryId) {
  try {
    await connect();
    // logger.log("info", "activeDirectoryId : ", activeDirectoryId);
    if (!activeDirectoryId) return errorStatus.ADINF;

    const azureActiveDirectory = await dbOperations.findOne(
      azureDirectoryModel,
      { activeDirectoryId: activeDirectoryId }
    );

    // logger.log("info", "azureActiveDirectory : ", azureActiveDirectory);
    if (azureActiveDirectory) return azureActiveDirectory;
    else return errorStatus.NRF;
  } catch (error) {
    logger.log("info", "getActiveDirectory dao error", error);
    throw error;
  }
}
module.exports.saveActiveDirectory = saveActiveDirectory;
module.exports.getActiveDirectories = getActiveDirectories;
module.exports.updateDirectory = updateDirectory;
module.exports.deleteDirectory = deleteDirectory;
module.exports.getActiveDirectory = getActiveDirectory;
