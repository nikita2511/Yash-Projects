const mongoose = require("mongoose");
const schema = mongoose.Schema;

const AzureDirectoryModel = new schema({
  _id: { type: schema.Types.ObjectId, required: true, auto: true },
  companyName: { type: schema.Types.String },
  activeDirectoryId: { type: schema.Types.String },
  activeDirectoryName: { type: schema.Types.String, default: "NA" },
  activeDirectorydomain: { type: schema.Types.String, default: "NA" },
  isActiveDirectoryPrimary: { type: schema.Types.Boolean },
  applicationName: { type: schema.Types.String, default: "NA" },
  applicationClientId: { type: schema.Types.String },
  scope: { type: schema.Types.String, default: "NA" },
});

module.exports = mongoose.model("azure_directory", AzureDirectoryModel);
