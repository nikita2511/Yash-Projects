const {
  errorStatus,
  errorMessages,
  responsHeader,
  statusCodes,
} = require("../../../constants");
let response = {
  headers: responsHeader,
  body: {},
};

const winston = require("winston");
const { createLogs } = require("../../../config/loggerConfig");
const todayDate = new Date().toDateString().replace(/\ /g, "");
const logConfiguration = createLogs("azure-directories-controller", todayDate);
const logger = winston.createLogger(logConfiguration);

const azureDirectoryDAO = require("../dao/dao");

/**
 * Returns Saved Azure Directory Object with HTTP CREATED Http Code or errors with Http error status codes.
 *
 * @param {JSON Object} req An Azure Active Directory Object
 * @param {Array} res Saved Azure Active Directory Object
 *
 * @returns A saved Azure Active Directory Object
 */
module.exports.saveAzureDirectory = async (req, res) => {
  const azureDirectory = req.body;

  try {
    const savedActiveDirectory = await azureDirectoryDAO.saveActiveDirectory(
      azureDirectory
    );
    if (savedActiveDirectory == errorStatus.RAE) {
      response.body = {
        message: errorMessages.ADAE,
      };
      return res.status(statusCodes.REQUEST_CONFLICT).send(response);
    } else if (savedActiveDirectory.length) {
      response.body = {
        azureDirectory: savedActiveDirectory,
      };
      return res.status(statusCodes.CREATED).send(response);
    }
  } catch (error) {
    logger.error(`Create AD Controller error : ${error}`);
    response.body = {
      error: error,
    };
    return res.status(statusCodes.SERVER_ERROR).send(response);
  }
};

/**
 * Returns a list of Azure Active Directories with HTTP SUCCESS status code or errors with Http error status codes.
 *
 * @param {Array} res A list of Azure Active Directories Object
 *
 * @return A list of Azure Active Directories Object
 */
module.exports.getActiveDirectories = async (req, res) => {
  try {
    const activeDirectories = await azureDirectoryDAO.getActiveDirectories();

    if (activeDirectories) {
      response.body = {
        activeDirectories: activeDirectories,
      };
      res.status(statusCodes.SUCCESS).send(response);
    }
  } catch (error) {
    response.body = {
      error: error,
    };
    res.status(statusCodes.SERVER_ERROR).send(response);
  }
};

/**
 * A handler function to update an existing Azure Active Directory.
 *
 * @param {JSON Object} req The request object
 * @param {JSON Object} res The response object
 *
 * @returns An object of updated Azure Active Directory with Http SUCCESS status code or error with Http errors status codes.
 */
module.exports.updateActiveDirectory = async (req, res) => {
  try {
    let objectToUpdate = req.body;
    let directoryId = req.body.activeDirectoryId;
    let isDirectoryExist = await azureDirectoryDAO.getActiveDirectory(
      directoryId
    );
    if (isDirectoryExist === errorStatus.NRF) {
      response.body = {
        message: errorMessages.ADNF,
      };
      return res.status(statusCodes.NOT_FOUND).send(response);
    }
    let updatedDirectory = await azureDirectoryDAO.updateDirectory(
      { activeDirectoryId: directoryId },
      objectToUpdate
    );
    if (updatedDirectory) {
      response.body = {
        azureDirectory: updatedDirectory,
      };
      return res.status(statusCodes.SUCCESS).send(response);
    }
    throw new Error("something went wrong");
  } catch (error) {
    logger.error("Exception in update directory controller", error);
    response.body = {
      error: error.message,
    };
    return res.status(statusCodes.SERVER_ERROR).send(response);
  }
};

/**
 * A handler function to delete an Azure Active Directory
 *
 * @param {String} req The request query parameters
 * @param {JSON Object} res The response object
 *
 * @returns An object with delete status with Http SUCCESS status code or errors with Http error status codes.
 */
module.exports.deleteDirectory = async (req, res) => {
  try {
    let directoryId = req.body.activeDirectoryId;
    let isDirectoryExist = await azureDirectoryDAO.getActiveDirectory(
      directoryId
    );
    if (isDirectoryExist === errorStatus.NRF) {
      response.body = {
        message: errorMessages.ADNF,
      };
      return res.status(statusCodes.NOT_FOUND).send(response);
    }
    let deletedDirectory = await azureDirectoryDAO.deleteDirectory(directoryId);
    if (deletedDirectory) {
      if (deletedDirectory.deletedCount) {
        response.body = {
          azureDirectory: deletedDirectory,
        };
        return res.status(statusCodes.SUCCESS).send(response);
      }
      response.body = {
        errorStatus: statusCodes.BAD_REQUEST,
        errorMessage: errorMessages.CDO,
      };
      return res.status(statusCodes.BAD_REQUEST).send(response);
    }
    response.body = {
      errorStatus: statusCodes.BAD_REQUEST,
      errorMessage: errorMessages.CDO,
    };
    return res.status(statusCodes.BAD_REQUEST).send(response);
  } catch (error) {
    logger.error("Exception in delete directory controller", error);
    response.body = {
      error: error.message,
    };
    return res.status(statusCodes.SERVER_ERROR).send(response);
  }
};

/**
 * A handler function to fetch an Azure Active Directory
 *
 * @param {JSON Object} res The response object
 *
 * @return An Object of Azure Active Directory with Http
 */
module.exports.getActiveDirectory = async (req, res) => {
  const activeDirectoryId = req.query.activeDirectoryId;
  try {
    const activeDirectory = await azureDirectoryDAO.getActiveDirectory(
      activeDirectoryId
    );
    // logger.log("info", "activeDirectory from controller : ",activeDirectory);
    if (activeDirectory == errorStatus.ADINF) {
      response.body = {
        message: errorMessages.ADINF,
      };
      res.status(statusCodes.BAD_REQUEST).send(response);
    } else if (activeDirectory == errorStatus.NRF) {
      response.body = {
        message: errorMessages.ADNF,
      };
      res.status(statusCodes.NOT_FOUND).send(response);
    } else if (activeDirectory) {
      response.body = {
        activeDirectory: activeDirectory,
      };
      res.status(statusCodes.SUCCESS).send(response);
    }
  } catch (error) {
    response.body = {
      error: error,
    };
    res.status(statusCodes.SERVER_ERROR).send(response);
  }
};
