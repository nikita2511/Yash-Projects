const express = require("express");
const router = express.Router();
const controller = require("../controller/controller");

router.post("/", controller.saveAzureDirectory);

router.get("/", controller.getActiveDirectories);
router.put("/", controller.updateActiveDirectory);
router.delete("/", controller.deleteDirectory);

router.get("/active-directory-by-id", controller.getActiveDirectory);
module.exports = router;
