const express = require("express");
const router = express.Router();

const controller = require("../controller/controller");

//Creates a branch in a repository
router.post("/createBranch", controller.createBranch);

//Fetches a list of branches for a repository.
router.get("/getAllBranches", controller.getAllBranches);

//Fetches a branch from a repository.
router.get("/branch", controller.getBranch);

//Deletes a branch from a repository.
router.delete("/", controller.deleteBranch);

module.exports = router;
