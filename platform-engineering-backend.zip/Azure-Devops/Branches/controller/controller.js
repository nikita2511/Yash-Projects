const branchDao = require("../dao/dao");
const {
  errorStatus,
  errorMessages,
  responsHeader,
  statusCodes,
} = require("../../../constants");
//-------------------logger-implementation-----------------------------
const winston = require("winston");
const { createLogs } = require("../../../config/loggerConfig");
const todayDate = new Date().toDateString().replace(/\ /g, "");
const logConfiguration = createLogs("Branches Controller", todayDate);
const logger = winston.createLogger(logConfiguration);
//------------------------------------------------------------------------------
let response = {
  headers: responsHeader,
  body: {},
};

/**
 * A handler function to create a new branch in a repository.
 * 
 * @param {JSON object} req The request object
 * @param {JSON Object} res The response object
 * 
 * @returns An object of created branch with Http CREATED status code or errors with Http error status codes.
 */
module.exports.createBranch = async (req, res) => {
  const bearerHeader = req.headers.authorization;
  const organizationName = req.query.organizationName;
  const token = bearerHeader && bearerHeader.split(" ")[1];
  const { projectName, repoName, sourceBranchName, targetBranchName } =
    req.body;
  // The function first checks if the bearer token is valid. If the token is invalid, the function returns an error.
  // If the token is valid, the function calls the branchDao.createBranch() method to create the new branch.
  try {
    const createdBranch = await branchDao.createBranch(
      organizationName,
      token,
      projectName,
      repoName,
      sourceBranchName,
      targetBranchName
    );

    // - organizationName: The name of the organization that owns the repository.
    // - token: The bearer token used to authenticate the request.
    // - projectName: The name of the project that contains the repository.
    
    logger.log("info", "createdBranch controller", createdBranch);
    if (createdBranch == errorStatus.ONF) {
      response.body = {
        message: errorMessages.ONF,
        error: errorStatus.ONF,
      };
      res.status(statusCodes.BAD_REQUEST).send(response);
    } else if (createdBranch == errorStatus.CNF) {
      response.body = {
        message: errorMessages.CNF,
        error: errorStatus.CNF,
      };
      res.status(statusCodes.NOT_FOUND).send(response);
    } else {
      response.body = {
        createdBranch: createdBranch,
      };
      res.status(statusCodes.SUCCESS).json(response);
    }
  } catch (error) {
    logger.error("Exception in create branch controller", error);
    // If the branch could not be created, the function returns an error in the response
    if (error.statusCode) {
      response.body = {
        errorStatus: error.statusCode,
        errorMessage: error.message,
      };
      return res.status(error.statusCode).send(response);
    } else {
      response.body = {
        errorStatus: statusCodes.SERVER_ERROR,
        errorMessage: error.message,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};


/**
 * This is a handler function that fetches the branches of a repo.
 * 
 * @param {String} req The request query parameters.
 * @param {JSON Object} res The response object.
 * 
 * @returns A list of branches with Http SUCCESS status code or error with Http error status codes.
 */
module.exports.getAllBranches = async (req, res) => {
  const bearerHeader = req.headers.authorization;
  const token = bearerHeader && bearerHeader.split(" ")[1];
  const repoName = req.query.repoName;
  const projectName = req.query.projectName;
  const organizationName = req.query.organizationName;
  // The function first checks if the bearer token is valid. If the token is invalid, the function returns an error.
  // if token is valid It then calls the branchDao.getAllBranches() method to get all the branches
  try {
    const branches = await branchDao.getAllBranches(
      organizationName,
      token,
      projectName,
      repoName
    );
    if (branches == errorStatus.ONF) {
      response.body = {
        message: errorMessages.ONF,
        error: errorStatus.ONF,
      };
      res.status(statusCodes.BAD_REQUEST).send(response);
    } else if (branches == errorStatus.CNF) {
      response.body = {
        message: errorMessages.CNF,
        error: errorStatus.CNF,
      };
      res.status(statusCodes.NOT_FOUND).send(response);
    } else if (branches === null) {
      response.body = {
        errorStatus: statusCodes.NOT_FOUND,
        errorMessage: errorMessages.NRF,
      };
      res.status(statusCodes.NOT_FOUND).json(response);
    } else {
      // If the call is successful, it returns the branches in the response body.
      response.body = {
        branches: branches,
      };
      res.status(statusCodes.SUCCESS).json(response);
    }
  } catch (error) {
    logger.error("Exception in getAllBranches", error);
    // If the call fails, it returns an error message in the response body.
    if (error.statusCode) {
      response.body = {
        errorStatus: error.statusCode,
        errorMessage: error.message,
      };
      return res.status(error.statusCode).send(response);
    } else {
      response.body = {
        errorStatus: statusCodes.SERVER_ERROR,
        errorMessage: error.message,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};


/**
 * This is a handler function that deletes a branch from a repo
 * 
 * @param {String} req The request query parameters
 * @param {JSON Object} res The respones object
 * 
 * @returns An object of deleted branch with Http SUCCESS status code or error object with Http error status codes.
 */
module.exports.deleteBranch = async (req, res) => {
  const bearerHeader = req.headers.authorization;
  const { repoName, organizationName, projectName, branchName } = req.body;
  const accessToken = bearerHeader && bearerHeader.split(" ")[1];
  try {
    var deletedBranch = await branchDao.deleteBranch(
      organizationName,
      accessToken,
      projectName,
      repoName,
      branchName
    );
    if (deletedBranch == errorStatus.ONF) {
      response.body = {
        message: errorMessages.ONF,
        error: errorStatus.ONF,
      };
      res.status(statusCodes.BAD_REQUEST).send(response);
    } else if (deletedBranch == errorStatus.CNF) {
      response.body = {
        message: errorMessages.CNF,
        error: errorStatus.CNF,
      };
      res.status(statusCodes.NOT_FOUND).send(response);
    } else if (deletedBranch === null) {
      response.body = {
        errorStatus: statusCodes.NOT_FOUND,
        errorMessage: errorMessages.NRF,
      };
      res.status(statusCodes.NOT_FOUND).json(response);
    } else {
      // If the call is successful, it returns the deleted branch in the response body.
      response.body = {
        branch: deletedBranch,
      };
      res.status(statusCodes.SUCCESS).send(response);
    }
  } catch (error) {
    // If the call fails, it returns an error message in the response body.
    if (error.statusCode) {
      response.body = {
        errorStatus: error.statusCode,
        errorMessage: error.message,
      };
      return res.status(error.statusCode).send(response);
    } else {
      response.body = {
        errorStatus: statusCodes.SERVER_ERROR,
        errorMessage: error.message,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};

/**
 * This is a handler function that gets a branch from a repo. 
 * 
 * @param {String} req The request query parameters
 * @param {JSON Object} res The response object
 * 
 * @returns An Object of branch with Http SUCCESS status code or error with Http error status codes.
 */
module.exports.getBranch = async (req, res) => {
  try {
    const bearerHeader = req.headers.authorization;
    const { repositoryName, organizationName, projectName, branchName } =
      req.query;
    const accessToken = bearerHeader && bearerHeader.split(" ")[1];
    // calls the branchDao.getBranch() method to get the branch.
    var branch = await branchDao.getBranch(
      organizationName,
      accessToken,
      repositoryName,
      branchName,
      projectName
    );
    if (branch != null && branch.hasOwnProperty("commit")) {
      response.body = {
        // if the call is successful, it returns the branch in the response body.
        branch: branch,
      };
      return res.status(statusCodes.SUCCESS).send(response);
    } else {
      response.body = {
        errorStatus: statusCodes.NOT_FOUND,
        errorMessage: errorMessages.NRF,
      };
      return res.status(statusCodes.NOT_FOUND).send(response);
    }
  } catch (error) {
    // If the call fails, it returns an error message in the response body.
    logger.error("Exception in getBranch", error);
    if (error.statusCode) {
      response.body = {
        errorStatus: error.statusCode,
        errorMessage: error.message,
      };
      return res.status(error.statusCode).send(response);
    } else {
      response.body = {
        errorStatus: statusCodes.SERVER_ERROR,
        errorMessage: error.message,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};
