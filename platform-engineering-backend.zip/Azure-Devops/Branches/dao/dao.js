const azConnection = require("../../../config/azConnection");
const {
  errorStatus,
  errorMessages,
  statusCodes,
} = require("../../../constants");

//-------------------logger-implementation-----------------------------
const winston = require("winston");
const { createLogs } = require("../../../config/loggerConfig");
const todayDate = new Date().toDateString().replace(/\ /g, "");
const logConfiguration = createLogs("Branches Dao", todayDate);
const logger = winston.createLogger(logConfiguration);
//---------------------------------------------------------------------

/**
 * This function creates a new branch in the specified repository.
 *
 * @param {String} organizationName
 * @param {String} token
 * @param {String} projectName
 * @param {String} repoName
 * @param {String} sourceBranchName
 * @param {String} targetBranchName
 *
 * @returns An object of created branch or an error object.
 */
module.exports.createBranch = async (
  organizationName,
  token,
  projectName,
  repoName,
  sourceBranchName,
  targetBranchName,
  existingConnection
) => {
  //  Check if the organization name is provided. If not, return an error.
  if (!organizationName) return errorStatus.ONF;
  try {
    // Get a connection to the Azure DevOps server.
    let azDevOpsConnection;
    if (!existingConnection) {
      azDevOpsConnection = azConnection.getConnection(organizationName, token);
    } else {
      azDevOpsConnection = existingConnection;
    }
    // const connection = azConnection.getConnection(organizationName, token);
    // Get the repository details.
    const repoDetails = await getRepo(
      organizationName,
      token,
      projectName,
      repoName
    );
    // Get the source branch details.
    // Get the source branch ID.
    const repoId = repoDetails.id;
    const sourceBranchDetails = await getBranch(
      organizationName,
      token,
      repoName,
      sourceBranchName,
      projectName
    );
    const sourceBranchId = sourceBranchDetails.commit.commitId;

    // Create a refUpdate object with the name, newObjectId, and oldObjectId properties.
    var refUpdate = {
      name: "refs/heads/" + targetBranchName,
      newObjectId: sourceBranchId,
      oldObjectId: "0000000000000000000000000000000000000000",
    };
    // update the branch
    const gitApi = await azDevOpsConnection.getGitApi();
    const createbranch = await gitApi.updateRefs([refUpdate], repoId);
    return createbranch;
  } catch (error) {
    logger.error("Exception in create branch dao", error);
    throw error;
  }
};

/**
 * A function to fetch a branch by branch name in a repository for a project.
 *
 * @param {String} organizationName
 * @param {String} token
 * @param {String} repoName
 * @param {String} branchName
 * @param {String} projectName
 *
 * @returns An object of branch or an error object.
 */
async function getBranch(
  organizationName,
  token,
  repoName,
  branchName,
  projectName,
  existingConnection
) {
  try {
    // Get a connection to Azure DevOps using the organization name and token.
    let azDevOpsConnection;
    if (!existingConnection) {
      azDevOpsConnection = azConnection.getConnection(organizationName, token);
    } else {
      azDevOpsConnection = existingConnection;
    }
    // let connection = azConnection.getConnection(organizationName, token);
    // Get the Git API from the connection.
    var gitApi = await azDevOpsConnection.getGitApi();

    // Get the repository from the Git API.
    // Get the branch from the Git API
    let isRepoExist = await gitApi.getRepository(repoName, projectName);
    let branch = await gitApi.getBranch(repoName, branchName, projectName);
    return branch;
  } catch (error) {
    logger.error("Exception in get branch dao", error);
    throw error;
  }
}

/**
 * A function to fetch list of branches for a repository in a project.
 *
 * @param {String} organizationName
 * @param {String} token
 * @param {String} projectName
 * @param {String} repoName
 *
 * @returns An array of branch objects or an error object.
 */
module.exports.getAllBranches = async (
  organizationName,
  token,
  projectName,
  repoName,
  existingConnection
) => {
  // It first checks if the organization name is provided, and if not, it returns an error.
  if (!organizationName) return errorStatus.ONF;
  let azDevOpsConnection, gitAPI;
  try {
    // creates a connection to Azure DevOps using the organization name and token.
    if (!existingConnection) {
      azDevOpsConnection = azConnection.getConnection(organizationName, token);
    } else {
      azDevOpsConnection = existingConnection;
    }
    // azDevOpsConnection = azConnection.getConnection(organizationName, token);
    gitAPI = await azDevOpsConnection.getGitApi();
    const branches = await gitAPI.getBranches(repoName, projectName);
    // logs the list of branches and returns it.
    logger.log("info", `list of branches : ${branches}`);
    return branches;
  } catch (error) {
    logger.error("Exception in list branches", error);
    throw error;
  }
};

async function getRepo(organizationName, token, projectName, repoName) {
  try {
    let connection = azConnection.getConnection(organizationName, token);
    // tries to create a connection to Azure DevOps using the provided organizationName and token
    var gitApi = await connection.getGitApi();
    // connection successfull returns the repository
    let repo = await gitApi.getRepository(repoName, projectName);
    return repo;
  } catch (error) {
    logger.error("Exception in get repository", error);
    throw error;
  }
}

/**
 * A function to delete a branch by branch name.
 *
 * @param {String} organizationName
 * @param {String} token
 * @param {String} branchName
 * @param {String} projectName
 * @param {String} repoName
 *
 * @returns An object of deleted branch or an error object.
 */
module.exports.deleteBranch = async (
  organizationName,
  token,
  branchName,
  projectName,
  repoName,
  existingConnection
) => {
  try {
    // creates a connection to Azure DevOps using the organization name and token.
    let azDevOpsConnection;
    if (!existingConnection) {
      azDevOpsConnection = azConnection.getConnection(organizationName, token);
    } else {
      azDevOpsConnection = existingConnection;
    }
    // const connection = await azConnection.getConnection(
    //   organizationName,
    //   token
    // );
    const gitApi = await azDevOpsConnection.getGitApi();
    const sourceBranchDetails = await getBranch(
      organizationName,
      token,
      repoName,
      branchName,
      projectName
    );
    logger.log("info", `Source branch details in dao ${sourceBranchDetails}`);
    const sourceBranchId = sourceBranchDetails.commit.commitId;
    var refUpdate = {
      name: "refs/heads/" + branchName,
      newObjectId: "0000000000000000000000000000000000000000",
      oldObjectId: sourceBranchId,
    };
    const deletedBranch = await gitApi.updateRefs(
      [refUpdate],
      repoName,
      projectName
    );
    logger.log("info", `deleted branch dao : ${deletedBranch}`);
    return deletedBranch;
  } catch (error) {
    logger.error("Exception in delete branch", error);
    throw error;
  }
};

module.exports.getBranch = getBranch;
