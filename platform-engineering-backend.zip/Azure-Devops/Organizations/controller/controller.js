const organizationdao = require("../dao/dao");
const {
  errorStatus,
  errorMessages,
  responsHeader,
  statusCodes,
} = require("../../../constants");
let response = {
  headers: responsHeader,
  body: {},
};
/**
@description Retrieves all organizations associated with the user.
@param {Object} req - The request object.
@param {Object} res - The response object.
@returns {Promise} - A Promise that resolves to nothing.
*/
module.exports.getAllOrganizations = async (req, res) => {
  try {
    const bearerHeader = req.headers.authorization;
    const personalAccessToken = bearerHeader && bearerHeader.split(" ")[1];
    const { platform } = req.query;
    if (personalAccessToken) {
      const organizations = await organizationdao.getAllOrganizations(
        platform,
        personalAccessToken
      );
      response.body = {
        organizations: organizations,
      };
      res.status(statusCodes.SUCCESS).send(response);
    } else {
      response.body = {
        message: errorMessages.EGAC,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  } catch (error) {
    if (error.message.includes("Failed to retrieve user profile")) {
      response.body = {
        message: errorMessages.ISE,
        error: error.message,
      };
      res.status(statusCodes.BAD_REQUEST).send(response);
    } else {
      response.body = {
        message: errorMessages.ISE,
        error: errorMessages.FRO,
      };
    }
    res.status(statusCodes.SERVER_ERROR).send(response);
  }
};
