router.get("/", getStates);
