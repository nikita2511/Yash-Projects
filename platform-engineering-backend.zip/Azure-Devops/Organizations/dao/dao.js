const axios = require("axios");
const dbOperations = require("../../../dbOperations");
const { errorStatus, errorMessages } = require("../../../constants");
const profiledao = require("../../Profile/dao/dao");
const projectRulesDAO = require("../../../OrganizationRules/Rules/dao/dao");
//-------------------logger-implementation-----------------------------
const winston = require("winston");
const { createLogs } = require("../../../config/loggerConfig");
const todayDate = new Date().toDateString().replace(/\ /g, "");
const logConfiguration = createLogs("Organizations Dao", todayDate);
const logger = winston.createLogger(logConfiguration);
//------------------------------------------------------------------------------

/**
 * Function to get All Organizations
 *
 * @param {String} token
 * @returns organizations object or an error object
 */
const getAllOrganizations = async (platform, token) => {
  // Get user profile
  let user, account, orgRuleList;
  try {
    user = await profiledao.getUserProfile(token);
  } catch (error) {
    logger.error("Exception in get all organization", error);
    throw new Error(
      "Failed to retrieve user profile due to an internal error."
    );
  }

  // Get organizations
  try {
    account = await axios.get(
      `https://app.vssps.visualstudio.com/_apis/accounts?api-version=6.1-preview.1&memberId=${user.id}`,
      {
        headers: {
          authorization: `Bearer ` + `${token}`,
        },
      }
    );

    let organizations = account.data;

    // Get organization rules list
    orgRuleList = await projectRulesDAO.getOrgnizationRulesList(platform);

    // Set isRuleExists flag for each organization
    organizations.value.forEach((organization) => {
      organization.isRuleExists = false;
      orgRuleList.forEach((orgRule) => {
        if (orgRule.organizationName == organization.accountName)
          organization.isRuleExists = true;
      });
    });

    return organizations;
  } catch (error) {
    logger.error("Exception in get all organization", error);

    // Throw error if error.response is present
    if (error.response) {
      throw new Error(
        "Failed to retrieve organizations: " + error.response.data.message
      );
    }

    // Throw error if error.message includes "Failed to connect to the database"
    else if (error.message.includes("Failed to connect to the database")) {
      throw new Error("Failed to connect to the database.");
    }

    // Throw generic error
    throw new Error("Failed to retrieve organizations.");
  }
};

module.exports = { getAllOrganizations };
