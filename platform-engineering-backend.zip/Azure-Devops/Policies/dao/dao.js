const azConnection = require("../../../config/azConnection");
const { errorStatus, errorMessages } = require("../../../constants");

//-------------------logger-implementation-----------------------------
const winston = require("winston");
const { createLogs } = require("../../../config/loggerConfig");
const todayDate = new Date().toDateString().replace(/\ /g, "");
const logConfiguration = createLogs("Policies Dao", todayDate);
const logger = winston.createLogger(logConfiguration);
//------------------------------------------------------------------------------

/**
 * Function to create Merge Type Strategy
 *
 * @param {String} organizationName
 * @param {String} token
 * @param {String} projectName
 * @param {String} projectId
 * @param {String} repoName
 * @param {String} targetBranchName
 * @param {String} mergeTypeStrategy
 * @returns createdMergeTypeStrategy object or an error object
 */
module.exports.createMergeTypeStrategy = async (
  organizationName,
  token,
  projectName,
  projectId,
  repoName,
  targetBranchName,
  mergeTypeStrategy,
  existingConnection
) => {
  // Check if organization name is provided
  if (!organizationName) return errorStatus.ONF;

  // Get repo id
  let repoId;
  try {
    // Get connection to Azure DevOps
    let azDevOpsConnection;
    if (!existingConnection) {
      azDevOpsConnection = azConnection.getConnection(organizationName, token);
    } else {
      azDevOpsConnection = existingConnection;
    }
    // const azDevOpsConnection = azConnection.getConnection(
    //   organizationName,
    //   token
    // );

    // Get policy API
    let policyAPI = await azDevOpsConnection.getPolicyApi();

    // Get git API
    var gitApi = await azDevOpsConnection.getGitApi();

    // Get repo details
    const repoDetails = await gitApi.getRepository(repoName, projectName);

    // Set repo id
    repoId = repoDetails.id;

    // Create policy configuration
    const policyConfig = {
      isEnabled: true,
      isBlocking: true,
      type: {
        id: "fa4e907d-c16b-4a4c-9dfa-4916e5d171ab", // ID for this policy ensures that pull requests use a consistent merge strategy.
      },
      settings: {
        [mergeTypeStrategy]: true, //merge type stratgies  : basicMerge, squashMerge, rebaseAndFastForward, rebaseWithMergeCommit
        scope: [
          {
            repositoryId: repoId,
            refName: "refs/heads/" + targetBranchName,
            matchKind: "exact",
          },
        ],
      },
    };

    // Create policy configuration
    let createdMergeTypeStrategy = await policyAPI.createPolicyConfiguration(
      policyConfig,
      projectId,
      repoId
    );

    // Return created merge type strategy
    return createdMergeTypeStrategy;
  } catch (error) {
    // Throw error
    throw error;
  }
};

/**
 * Funtion to create Reviewer Policy
 *
 * @param {String} organizationName
 * @param {String} token
 * @param {String} projectId
 * @param {String} projectName
 * @param {String} repoName
 * @param {String} targetBranchName
 * @param {Number} minimumApproverCount
 * @returns reviewer policy object or error object
 */
module.exports.createReviewerPolicy = async (
  organizationName,
  token,
  projectId,
  projectName,
  repoName,
  targetBranchName,
  minimumApproverCount,
  existingConnection
) => {
  // Check if the organization name is provided
  try {
    if (!organizationName) return errorStatus.ONF;
    // Get the connection to Azure DevOps
    let azDevOpsConnection;
    if (!existingConnection) {
      azDevOpsConnection = azConnection.getConnection(organizationName, token);
    } else {
      azDevOpsConnection = existingConnection;
    }
    // const azDevOpsConnection = azConnection.getConnection(
    //   organizationName,
    //   token
    // );
    // Get the Git API client
    var gitApi = await azDevOpsConnection.getGitApi();
    // Get the repository details
    const repoDetails = await gitApi.getRepository(repoName, projectName);
    // Get the repository ID
    const repoId = repoDetails.id;
    // Get the Policy API client
    const policyClient = await azDevOpsConnection.getPolicyApi();
    // Create the policy configuration
    const policyConfig = {
      isEnabled: true,
      isBlocking: false,
      type: {
        id: "fa4e907d-c16b-4a4c-9dfa-4906e5d171dd", // ID for the "Minimum number of reviewers" policy type
      },
      settings: {
        minimumApproverCount: minimumApproverCount,
        creatorVoteCounts: false,
        allowDownvotes: false,
        resetOnSourcePush: false,
        scope: [
          {
            refName: "refs/heads/" + targetBranchName,
            matchKind: "exact",
            repositoryId: repoId,
          },
        ],
      },
    };

    // Create the policy
    const createdPolicy = await policyClient.createPolicyConfiguration(
      policyConfig,
      projectId,
      repoId
    );
    // Return the created policy
    return createdPolicy;
  } catch (error) {
    // Log the error
    logger.error("Policy Dao error ==============>", error);
    // Throw the error
    throw error;
  }
};
