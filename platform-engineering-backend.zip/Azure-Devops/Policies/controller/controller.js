const policiesDAO = require("../dao/dao");
const {
  errorStatus,
  errorMessages,
  responsHeader,
  statusCodes,
} = require("../../../constants");
let response = {
  headers: responsHeader,
  body: {},
};

//-------------------logger-implementation-----------------------------
const winston = require("winston");
const { createLogs } = require("../../../config/loggerConfig");
const todayDate = new Date().toDateString().replace(/\ /g, "");
const logConfiguration = createLogs("Policies Controller", todayDate);
const logger = winston.createLogger(logConfiguration);
//------------------------------------------------------------------------------

/**
 * Creates a merge type strategy for a repository.
 *
 * @param {Object} req - The request object containing the necessary information.
 * @param {Object} res - The response object used to send the response.
 * @returns {Promise<void>} - A promise that resolves once the merge type strategy is created.
 */
module.exports.createMergeTyoeStrategy = async (req, res) => {
  const bearerHeader = req.headers.authorization;
  const {
    organizationName,
    repoName,
    projectId,
    projectName,
    targetBranchName,
    mergeTypeStrategy,
  } = req.body;
  const personalAccessToken = bearerHeader && bearerHeader.split(" ")[1];

  try {
    let createdMergeTypeStrategy = await policiesDAO.createMergeTypeStrategy(
      organizationName,
      personalAccessToken,
      repoName,
      projectId,
      projectName,
      targetBranchName,
      mergeTypeStrategy
    );

    if (createdMergeTypeStrategy == errorStatus.ONF) {
      response.body = {
        message: errorMessages.ONF,
      };
      res.status(statusCodes.BAD_REQUEST).send(response);
    } else if (createdMergeTypeStrategy.status == errorStatus.ISE) {
      response.body = {
        message: errorMessages.ISE,
        error: createdMergeTypeStrategy.error,
      };
      res.status(statusCodes.NOT_FOUND).send(response);
    } else {
      response.body = { createdMergeTypeStrategy: createdMergeTypeStrategy };
      res.status(statusCodes.SUCCESS).send(response);
    }
  } catch (error) {
    logger.error("Controller Error creating  Branch ....", error);
    if (error.statusCode) {
      response.body = {
        errorStatus: error.statusCode,
        errorMessage: error.message,
      };
      return res.status(error.statusCode).send(response);
    } else {
      response.body = {
        errorStatus: statusCodes.SERVER_ERROR,
        errorMessage: error.message,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};
/**
 * Creates a reviewer policy for a repository.
 *
 * @param {Object} req - The request object containing the necessary information.
 * @param {Object} res - The response object used to send the response.
 * @returns {Promise<void>} - A promise that resolves once the merge type strategy is created.
 */
module.exports.createReviewerPolicy = async (req, res) => {
  const bearerHeader = req.headers.authorization;
  const personalAccessToken = bearerHeader && bearerHeader.split(" ")[1];
  let {
    organizationName,
    projectId,
    projectName,
    repoName,
    targetBranchName,
    minimumApproverCount,
  } = req.body;
  try {
    let createdPolicy = await policiesDAO.createReviewerPolicy(
      organizationName,
      personalAccessToken,
      projectId,
      projectName,
      repoName,
      targetBranchName,
      minimumApproverCount
    );
    if (createdPolicy.hasOwnProperty("id")) {
      response.body = {
        policy: createdPolicy,
      };
      res.status(statusCodes.SUCCESS).send(response);
    } else {
      response.body = {
        Error: createdPolicy.error,
        policy: errorMessages.EUP,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  } catch (error) {
    logger.error("Controller Error creating  Branch ....", error);
    if (error.statusCode) {
      response.body = {
        errorStatus: error.statusCode,
        errorMessage: error.message,
      };
      return res.status(error.statusCode).send(response);
    } else {
      response.body = {
        errorStatus: statusCodes.SERVER_ERROR,
        errorMessage: error.message,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};
