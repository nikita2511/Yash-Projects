const express = require("express");
const router = express.Router();
const controller = require("../controller/controller");

//Create a repo for an project
router.post(
  "/merge-type-strategy",
  controller.createMergeTyoeStrategy
);

router.post("/reviewer-count", controller.createReviewerPolicy);
module.exports = router;
