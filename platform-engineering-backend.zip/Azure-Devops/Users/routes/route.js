const express = require("express");
const router = express.Router();
const userController = require("../controller/controller");

router.get("/", userController.getAllUsers);
router.post("/", userController.addUserToProject);
router.delete("/", userController.removeUsersFromProject);
router.get("/project-members", userController.getAllMembersOfProject);
router.get(
  "/project-collection-administrators",
  userController.getProjectCollectionAdministrators
);
module.exports = router;
