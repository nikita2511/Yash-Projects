const {
  errorStatus,
  errorMessages,
  responsHeader,
  statusCodes,
} = require("../../../constants");
let response = {
  headers: responsHeader,
  body: {},
};

//-------------------logger-implementation-----------------------------
const winston = require("winston");
const { createLogs } = require("../../../config/loggerConfig");
const todayDate = new Date().toDateString().replace(/\ /g, "");
const logConfiguration = createLogs("Users Controller", todayDate);
const logger = winston.createLogger(logConfiguration);
//------------------------------------------------------------------------------
const usersDAO = require("../dao/dao");
/**
Retrieves all users based on specified criteria.
@param {Object} req - The request object containing headers and query parameters.
@param {Object} res - The response object for sending the response.
@returns {Promise} - A promise that resolves to the response sent to the client.
*/
module.exports.getAllUsers = async (req, res) => {
  const bearerHeader = req.headers.authorization;
  const organizationName = req.query.organizationName;
  const name = req.query.name;

  const personalAccessToken = bearerHeader && bearerHeader.split(" ")[1];
  let users;
  try {
    users = await usersDAO.getAllUsers(
      organizationName,
      personalAccessToken,
      name
    );

    if (users == errorStatus.ONF) {
      response.body = {
        message: errorMessages.ONF,
      };
      return res.status(statusCodes.BAD_REQUEST).send(response);
    } else if (users == errorStatus.TNF) {
      response.body = {
        message: errorMessages.TNF,
      };
      return res.status(statusCodes.BAD_REQUEST).send(response);
    } else if (users == errorStatus.NRF) {
      response.body = {
        message: errorMessages.NRF,
      };
      return res.status(statusCodes.NOT_FOUND).send(response);
    } else if (users) {
      response.body = {
        users: users,
      };
      return res.status(statusCodes.SUCCESS).send(response);
    }
  } catch (error) {
    logger.error("", error);
    {
      response.body = {
        message: errorMessages.ISE,
        error: error,
      };
      return res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};
/**
Adds a user to a project.
@param {Object} req - The request object containing headers and body parameters.
@param {Object} res - The response object used to send responses.
@returns {Object} The response object with appropriate status code and data.
@throws {Error} If an error occurs during the process.
*/
module.exports.addUserToProject = async (req, res) => {
  const bearerHeader = req.headers.authorization;
  const organizationName = req.body.organizationName;
  const users = req.body.users;
  const projectId = req.body.projectId;

  const personalAccessToken = bearerHeader && bearerHeader.split(" ")[1];
  let createdUsers;
  try {
    createdUsers = await usersDAO.addUserToProject(
      organizationName,
      personalAccessToken,
      projectId,
      users
    );
    logger.log(
      "info",
      `Created Users from controller ${JSON.stringify(createdUsers)}`
    );
    if (createdUsers == errorStatus.ONF) {
      response.body = {
        message: errorMessages.ONF,
      };
      return res.status(statusCodes.BAD_REQUEST).send(response);
    } else if (createdUsers == errorStatus.TNF) {
      response.body = {
        message: errorMessages.TNF,
      };
      return res.status(statusCodes.BAD_REQUEST).send(response);
    } else if (
      !createdUsers[0].operationResult.isSuccess &&
      !createdUsers[0].isCreated
    ) {
      response.body = {
        message:
          createdUsers[0].createUserResponse.operationResult.errors[0].value,
      };
      return res.status(statusCodes.BAD_REQUEST).send(response);
    } else if (!createdUsers.length) {
      response.body = {
        message: "Can not create user!",
        error: createdUsers,
      };
      return res.status(statusCodes.BAD_REQUEST).send(response);
    } else if (createdUsers.length) {
      response.body = {
        createdUsers: createdUsers,
      };
      return res.status(statusCodes.CREATED).send(response);
    }
  } catch (error) {
    logger.error(error);
    {
      response.body = {
        message: errorMessages.ISE,
        error: error,
      };
      return res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};

/**
Retrieves all members of a project from the database.
@param {Object} req - The request object containing the headers and query parameters.
@param {Object} res - The response object used to send the response.
@returns {Object} - Returns the response with the retrieved members or an error message.
*/
module.exports.getAllMembersOfProject = async (req, res) => {
  const bearerHeader = req.headers.authorization;
  const organizationName = req.query.organizationName;
  const projectId = req.query.projectId;

  const personalAccessToken = bearerHeader && bearerHeader.split(" ")[1];
  let membersInProject;
  try {
    membersInProject = await usersDAO.getAllMembersOfProject(
      organizationName,
      personalAccessToken,
      projectId
    );
    if (membersInProject == errorStatus.ONF) {
      response.body = {
        message: errorMessages.ONF,
      };
      return res.status(statusCodes.BAD_REQUEST).send(response);
    } else if (membersInProject == errorStatus.TNF) {
      response.body = {
        message: errorMessages.TNF,
      };
      return res.status(statusCodes.BAD_REQUEST).send(response);
    } else if (membersInProject == errorStatus.NRF) {
      response.body = {
        message: errorMessages.NRF,
      };
      return res.status(statusCodes.NOT_FOUND).send(response);
    } else if (
      membersInProject.members &&
      membersInProject.members.length > 0
    ) {
      response.body = {
        data: membersInProject,
      };
      return res.status(statusCodes.SUCCESS).send(response);
    }
  } catch (error) {
    if (error.response) {
      logger.error(
        "getAllMembersOfProject Controller Error ================>",
        error
      );
      {
        response.body = {
          errorStatus: error.response.status,
          errorMessage: error.response.data,
          message: error.response.data.message,
        };
        return res.status(error.response.status).send(response);
      }
    } else {
      response.body = {
        errorStatus: errorStatus.SERVER_ERROR,
        message: error.message,
      };
      return res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};

/**
 * Removes users from a project.
 *
 * @param {Object} req - The request object containing headers and body.
 * @param {Object} res - The response object used to send the response.
 * @returns {Promise} - A Promise representing the asynchronous operation.
 */
module.exports.removeUsersFromProject = async (req, res) => {
  // Extract necessary data from the request
  const bearerHeader = req.headers.authorization;
  const organizationName = req.body.organizationName;
  const userIds = req.body.userIds;
  const projectId = req.body.projectId;
  const personalAccessToken = bearerHeader && bearerHeader.split(" ")[1];

  let removedUsers;

  try {
    // Call the DAO function to remove users from the project
    removedUsers = await usersDAO.removedUsersFromProject(
      organizationName,
      personalAccessToken,
      userIds,
      projectId
    );

    // Handle different scenarios based on the returned result
    if (removedUsers == errorStatus.ONF) {
      // If the users could not be found
      response.body = {
        message: errorMessages.ONF,
      };
      return res.status(statusCodes.BAD_REQUEST).send(response);
    } else if (removedUsers == errorStatus.TNF) {
      // If the provided token is invalid or expired
      response.body = {
        message: errorMessages.TNF,
      };
      return res.status(statusCodes.BAD_REQUEST).send(response);
    } else if (removedUsers.isRemoved == false) {
      // If user deletion was unsuccessful
      response.body = {
        message: "Can not delete user!",
        error: removedUsers.operationResults[0].errors,
      };
      return res.status(statusCodes.SERVER_ERROR).send(response);
    } else if (removedUsers.length >= 0) {
      // If users were successfully removed
      response.body = {
        removedUser: removedUsers,
      };
      return res.status(statusCodes.SUCCESS).send(response);
    } else {
      // In case of an undefined error
      response.body = {
        message: errorMessages.UDU,
      };
    }
  } catch (error) {
    // Handle errors thrown during the execution
    response.body = {
      errorStatus: error.response.status,
      message: error.response.data.message,
    };
    return res.status(error.response.status).send(response);
  }
};

module.exports.getProjectCollectionAdministrators = async (req, res) => {
  const bearerHeader = req.headers.authorization;
  const personalAccessToken = bearerHeader && bearerHeader.split(" ")[1];
  const organizationName = req.query.organizationName;
  try {
    const projectCollectionAdministrators =
      await usersDAO.getProjectCollectionAdministrators(
        organizationName,
        personalAccessToken
      );
    if (projectCollectionAdministrators.status === statusCodes.SUCCESS) {
      response.body = {
        projectCollectionAdministrators:
          projectCollectionAdministrators.data.members,
      };
      return res.status(statusCodes.SUCCESS).send(response);
    } else {
      response.body = {
        message: errorMessages.NRF,
      };
      return res.status(statusCodes.NOT_FOUND).send(response);
    }
  } catch (error) {
    logger.error("Exception in getProjectCollectionAdministrators ", error);
    if (error.response) {
      response.body = {
        message: error.response.data.message,
      };
      return res.status(error.response.status).send(response);
    } else {
      response.body = {
        message: error.message,
      };
      return res.status(statusCodes.NON_AUTHORATIVE_INFORMATION).send(response);
    }
  }
};
