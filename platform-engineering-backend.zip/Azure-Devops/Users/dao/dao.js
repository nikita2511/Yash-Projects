const azConnection = require("../../../config/azConnection");
const { errorStatus, errorMessages } = require("../../../constants");
const axios = require("axios");

//-------------------logger-implementation-----------------------------
const winston = require("winston");
const { createLogs } = require("../../../config/loggerConfig");
const todayDate = new Date().toDateString().replace(/\ /g, "");
const logConfiguration = createLogs("Users Dao", todayDate);
const logger = winston.createLogger(logConfiguration);
//------------------------------------------------------------------------------
/**

getAllUsers function retrieves all users in an organization with a specific name.
@param {string} organizationName - The name of the organization.
@param {string} token - Personal access token for authorization.
@param {string} name - The name to filter the users.
@returns {Array|number} - An array of users matching the criteria or an error status code.
*/

async function getAllUsers(organizationName, token, name) {
  if (!organizationName) return errorStatus.ONF;
  if (!token) return errorStatus.TNF;
  let users;
  try {
    users = await axios.get(
      `https://vsaex.dev.azure.com/${organizationName}/_apis/userentitlements?select=Projects&$filter=(name eq '${name}')&$orderBy=name asc&api-version=7.1-preview.3`,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );
    if (users.data.totalCount) {
      return users.data.members;
    } else {
      return errorStatus.NRF;
    }
  } catch (error) {
    logger.error("Get All Users Error ", error);
    return error;
  }
}
/**
getAllMembersOfProject function retrieves all members of a specific project in an organization.
@param {string} organizationName - The name of the organization.
@param {string} token - Personal access token for authorization.
@param {string} projectId - ID of the project.
@returns {Object|number} - An object containing project details and an array of members or an error status code.
*/
module.exports.getAllMembersOfProject = async (
  organizationName,
  token,
  projectId
) => {
  if (!organizationName) return errorStatus.ONF;
  if (!token) return errorStatus.TNF;
  let users,
    membersInProject = {
      projectId: "",
      projectName: "",
      members: [],
    };
  try {
    users = users = await axios.get(
      `https://vsaex.dev.azure.com/${organizationName}/_apis/userentitlements?select=Projects&$filter=(name eq '')&$orderBy=name asc&api-version=7.1-preview.3`,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );
    if (users.data.totalCount) {
      for (let user of users.data.members) {
        for (let project of user.projectEntitlements) {
          if (projectId == project.projectRef.id) {
            membersInProject.projectId = project.projectRef.id;
            (membersInProject.projectName = project.projectRef.name),
              membersInProject.members.push(user);
          }
        }
      }
      return membersInProject;
    } else {
      return errorStatus.NRF;
    }
  } catch (error) {
    logger.error("getAllMembersOfProject Dao Error =================>", error);
    throw error;
  }
};
/**

addUserToProject function adds users to a specific project in an organization.
@param {string} organizationName - The name of the organization.
@param {string} token - Personal access token for authorization.
@param {string} projectId - ID of the project.
@param {Array} users - Array of user names to add to the project.
@returns {Array|Object} - An array of created users' data or an object indicating whether the user creation was successful or not.
*/
module.exports.addUserToProject = async (
  organizationName,
  token,
  projectId,
  users
) => {
  if (!organizationName) return errorStatus.ONF;
  if (!token) return errorStatus.TNF;
  let createdUser,
    createdUsersArray = [];
  try {
    for (let user of users) {
      const body = {
        user: {
          principalName: user,
          subjectKind: "user",
        },
        projectEntitlements: [
          {
            group: {
              groupType: "projectContributor",
            },
            projectRef: {
              id: `${projectId}`,
            },
          },
        ],
      };
      createdUser = await axios.post(
        `https://vsaex.dev.azure.com/${organizationName}/_apis/userentitlements?api-version=7.1-preview.3`,
        body,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json",
          },
        }
      );
      if (createdUser.data.operationResult.isSuccess) {
        createdUsersArray.push(createdUser.data);
      } else {
        createdUsersArray.push(
          createdUsersArray.push({
            createUserResponse: createdUser.data,
            isCreated: false,
          })
        );
      }
    }
    return createdUsersArray;
  } catch (error) {
    logger.error(error);
    return error;
  }
};
/**

removedUserFromProject function removes a user from a specific project in an organization.
@param {string} organizationName - The name of the organization.
@param {string} token - Personal access token for authorization.
@param {string} userId - ID of the user.
@param {string} projectId - ID of the project.
@returns {Object} - The result of removing the user from the project.
*/
module.exports.removedUserFromProject = async (
  organizationName,
  token,
  userId,
  projectId
) => {
  if (!organizationName) return errorStatus.ONF;
  if (!token) return errorStatus.TNF;
  let removedUser, body;
  body = [
    {
      from: ``,
      op: `remove`,
      path: `/projectEntitlements/${projectId}`,
      value: ``,
    },
  ];
  try {
    removedUser = await axios.patch(
      `https://vsaex.dev.azure.com/${organizationName}/_apis/userentitlements/${userId}?api-version=7.1-preview.3`,
      body,
      {
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json-patch+json",
        },
      }
    );
    if (removedUser.data.operationResults[0].isSuccess) {
      return removedUser.data;
    } else {
      return { isUserRemoved: removedUser.data.operationResults[0].isSuccess };
    }
  } catch (error) {
    logger.error(error);
    return error;
  }
};

module.exports.removedUsersFromProject = async (
  organizationName,
  token,
  userIds,
  projectId
) => {
  if (!organizationName) return errorStatus.ONF;
  if (!token) return errorStatus.TNF;
  let removedUsers = [],
    body;
  let removedUser;
  body = [
    {
      from: ``,
      op: `remove`,
      path: `/projectEntitlements/${projectId}`,
      value: ``,
    },
  ];
  try {
    for (let userId of userIds) {
      removedUser = await axios.patch(
        `https://vsaex.dev.azure.com/${organizationName}/_apis/userentitlements/${userId}?api-version=7.1-preview.3`,
        body,
        {
          headers: {
            Authorization: `Bearer ${token}`,
            "Content-Type": "application/json-patch+json",
          },
        }
      );
      if (removedUser.data.operationResults[0].isSuccess) {
        removedUsers.push(removedUser.data);
      } else {
        let isUserRemoved = removedUser.data.operationResults[0].isSuccess;
        removedUsers.push(isUserRemoved);
      }
    }
    return removedUsers;
  } catch (error) {
    logger.error("Exception in removedUsersFromProject ", error);
    throw error;
  }
};
/**
 * Retrieves permission groups from Azure DevOps for a given organization.
 *
 * @param {string} organizationName - The name of the organization.
 * @param {string} token - The access token for authentication.
 * @returns {Array|errorStatus} - An array of permission groups or an error status.
 * @throws {Error} - If there is an exception during the API call.
 */
async function getPermissionGroups(organizationName, token) {
  let groups;
  try {
    // Input validation
    if (!organizationName) return errorStatus.ONF;
    if (!token) return errorStatus.TNF;

    // API call to retrieve permission groups
    groups = await axios.get(
      `https://vssps.dev.azure.com/${organizationName}/_apis/graph/groups?api-version=6.1-preview.1`,
      {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      }
    );
    const response = {
      status: groups.status,
      data: groups.data,
    };
    return response;
  } catch (error) {
    // Log and rethrow any exceptions
    logger.error("Exception in getPermissionGroups ", error);
    throw error;
  }
}
/**
 * Retrieves permission groups from Azure DevOps for a given organization.
 *
 * @param {string} organizationName - The name of the organization.
 * @param {string} token - The access token for authentication.
 * @returns {Array|errorStatus} - An array of members or an error status.
 * @throws {Error} - If there is an exception during the API call.
 */
module.exports.getProjectCollectionAdministrators = async (
  organizationName,
  token
) => {
  let groups, group, groupMembers;
  const groupNames = ["Project Collection Administrators"];
  try {
    groups = await getPermissionGroups(organizationName, token);
    if (groups.status === 200) {
      group = groups.data.value.filter((groupName) =>
        groupNames.includes(groupName.displayName)
      );
      const groupId = group[0].originId;
      groupMembers = await axios.get(
        `https://vsaex.dev.azure.com/${organizationName}/_apis/GroupEntitlements/${groupId}/members?api-version=6.1-preview.1`,
        {
          headers: {
            Authorization: `Bearer ${token}`,
          },
        }
      );
      return groupMembers;
    } else {
      throw new Error("Token is invalid or Expired");
    }
  } catch (error) {
    logger.error("Exception in getProjectCollectionAdministrators ", error);
    throw error;
  }
};

module.exports.getAllUsers = getAllUsers;
