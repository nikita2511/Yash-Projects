const express = require("express");
const router = express.Router();
const {
  createRepositoryValidation,
  validate,
} = require("../middlewares/validator");
const controller = require("../controller/controller");



//Creates a repository for in a project
router.post(
  "/",
  createRepositoryValidation(),
  validate,
  controller.createRepository
);


//Gets a list of repositories for a project
router.get("/", controller.getRepositories);

//Gets a repository for a project
router.get("/repo",controller.getRepo);

module.exports = router;
