const azConnection = require("../../../config/azConnection");
const { errorStatus, errorMessages } = require("../../../constants");
const { createBranchesForModel } = require("../../../Utilities/util");

//-------------------logger-implementation-----------------------------
const winston = require("winston");
const { createLogs } = require("../../../config/loggerConfig");
const todayDate = new Date().toDateString().replace(/\ /g, "");
const logConfiguration = createLogs("Repository Dao", todayDate);
const logger = winston.createLogger(logConfiguration);
//------------------------------------------------------------------------------

/**
 * A function to create a repository in a project
 *
 * @param {String} repositoryName
 * @param {String} organizationName
 * @param {String} projectId
 * @param {String} token
 *
 * @returns An object with properties createdRepository, repoInitialization, and createdBranches or error.
 */
const createRepository = async (
  repositoryName,
  organizationName,
  projectId,
  token
) => {
  try {
    let azDevOpsConnection = azConnection.getConnection(
      organizationName,
      token
    );
    let coreAPI = await azDevOpsConnection.getCoreApi();
    let project = await coreAPI.getProject(projectId);
    if (project != null) {
      const gitApi = await azDevOpsConnection.getGitApi();
      const gitRepositoryToCreate = {
        name: repositoryName,
      };
      const createdRepository = await gitApi.createRepository(
        gitRepositoryToCreate,
        projectId
      );
      logger.log("info", `line 30, Created repository ${createdRepository}`);
      if (createdRepository) {
        let initializedRepo = await initializeRepoWithReadme(
          repositoryName,
          organizationName,
          projectId,
          token
        );
        if (initializedRepo) {
          let createdBranches = await createBranchesForModel(
            organizationName,
            token,
            project.name,
            repositoryName
          );
          if (createdBranches) {
            return {
              createdRepository,
              repoInitialization: true,
              createdBranches: createdBranches,
            };
          } else {
            return {
              createdRepository,
              repoInitialization: false,
              createdBranches: false,
            };
          }
        } else {
          return {
            createdRepository,
            repoInitialization: false,
            createdBranches: false,
          };
        }
      } else {
        return {
          createdRepository,
          repoInitialization: false,
          branchesCreation: false,
        };
      }
    }
    throw new Error("Project does not exist");
  } catch (error) {
    throw error;
  }
};

/**
 * A function to create a branch in a repository for a project.
 *
 * @param {String} organization
 * @param {String} token
 * @param {String} projectName
 * @param {String} repoName
 * @param {String} sourceBranchName
 * @param {String} targetBranchName
 *
 * @returns An object of created branch or error.
 */
async function updateRefs(
  organization,
  token,
  projectName,
  repoName,
  sourceBranchName,
  targetBranchName
) {
  const connection = azConnection.getConnection(organization, token);
  const repoDetails = await getRepo(organization, token, projectName, repoName);
  const repoId = repoDetails.id;
  const sourceBranchDetails = await getBranch(
    organization,
    token,
    repoName,
    sourceBranchName,
    projectName
  );
  const sourceBranchId = sourceBranchDetails.commit.commitId;
  var refUpdate = {
    name: "refs/heads/" + targetBranchName,
    newObjectId: sourceBranchId,
    oldObjectId: "0000000000000000000000000000000000000000",
  };
  // update the branch
  const gitApi = await connection.getGitApi();
  const createbranch = await gitApi.updateRefs([refUpdate], repoId);
  return createbranch;
}

/**
 * A function to fetch a branch by branch name and repository name.
 *
 * @param {String} organizationName
 * @param {String} token
 * @param {String} repoName
 * @param {String} branchName
 * @param {String} projectName
 *
 * @returns An object of branch.
 */
async function getBranch(
  organizationName,
  token,
  repoName,
  branchName,
  projectName,
  existingConnection
) {
  let azDevOpsConnection;
  if (!existingConnection) {
    azDevOpsConnection = azConnection.getConnection(organizationName, token);
  } else {
    azDevOpsConnection = existingConnection;
  }
  // let connection = azConnection.getConnection(organizationName, token);
  var gitApi = await azDevOpsConnection.getGitApi();
  return await gitApi.getBranch(repoName, branchName, projectName);
}

/**
 * A function to fetch a repository by repository name.
 *
 * @param {String} organizationName
 * @param {String} token
 * @param {String} projectName
 * @param {String} repoName
 *
 * @returns An object of repository or error.
 */
async function getRepo(
  organizationName,
  token,
  projectName,
  repoName,
  existingConnection
) {
  try {
    let azDevOpsConnection;
    if (!existingConnection) {
      azDevOpsConnection = azConnection.getConnection(organizationName, token);
    } else {
      azDevOpsConnection = existingConnection;
    }
    // let connection = azConnection.getConnection(organizationName, token);
    var gitApi = await azDevOpsConnection.getGitApi();
    let repo = await gitApi.getRepository(repoName, projectName);
    logger.log("info", `inside get repository ${JSON.stringify(repo)}`);
    return repo;
  } catch (error) {
    logger.error("getRepo Dao Error =============>", error);
    throw error;
  }
}

/**
 * A function to initialize a repository with a readme file.
 *
 * @param {String} repoName
 * @param {String} organizationName
 * @param {String} projectId
 * @param {String} token
 *
 * @returns A boolean value or error;
 */
async function initializeRepoWithReadme(
  repoName,
  organizationName,
  projectId,
  token,
  existingConnection
) {
  try {
    let azDevOpsConnection;
    if (!existingConnection) {
      azDevOpsConnection = azConnection.getConnection(organizationName, token);
    } else {
      azDevOpsConnection = existingConnection;
    }
    // let azDevOpsConnection = azConnection.getConnection(
    //   organizationName,
    //   token
    // );
    let coreAPI = await azDevOpsConnection.getCoreApi();
    let project = await coreAPI.getProject(projectId);
    if (project != null) {
      const gitApi = await azDevOpsConnection.getGitApi();
      let repo = await gitApi.getRepository(repoName, projectId);
      const readmeContent = "My README file content";
      const readmeFileName = "README.md";
      const readmePath = "/" + readmeFileName;
      const contentStream = Buffer.from(readmeContent, "utf8");
      let push = await gitApi.createPush(
        {
          refUpdates: [
            {
              name: "refs/heads/main",
              oldObjectId: "0000000000000000000000000000000000000000",
            },
          ],
          commits: [
            {
              comment: "Initial commit",
              changes: [
                {
                  changeType: "add",
                  item: {
                    path: readmePath,
                  },
                  newContent: {
                    content: contentStream.toString("base64"),
                    contentType: 1,
                  },
                },
              ],
            },
          ],
        },
        repo.id,
        projectId
      );
      if (push) {
        return true;
      }
      return false;
    }
    throw new Error("Project does not exist");
  } catch (error) {
    throw error;
  }
}

/**
 * A function to fetch a list of repositories for a project
 *
 * @param {String} organizationName
 * @param {String} token
 * @param {String} projectName
 *
 * @returns A list of repositories objects or error object.
 */
const listRepositories = async (organizationName, token, projectName) => {
  try {
    const azDevOpsConnection = azConnection.getConnection(
      organizationName,
      token
    );
    const gitApi = await azDevOpsConnection.getGitApi();
    const repoList = await gitApi.getRepositories(projectName);
    if (repoList && repoList.length > 0) {
      return repoList;
    } else {
      throw new Error(errorMessages.PA);
    }
  } catch (error) {
    logger.error("Error in listRepositories Dao function:", error);
    throw error;
    // throw new Error('Could not retrieve list of repositories.');
  }
};

module.exports = {
  initializeRepoWithReadme,
  createRepository,
  updateRefs,
  getRepo,
  getBranch,
  listRepositories,
};
