const { check, body, validationResult } = require("express-validator");
//validation rules for create and update rules
const createRepositoryValidation = () => {
  return [
    check("repositoryName")
      .exists()
      .withMessage("repository name is missing")
      .notEmpty()
      .withMessage("repository name must not empty"),
    check("organizationName")
      .exists()
      .withMessage("organization name is missing")
      .notEmpty()
      .withMessage("organization name must not empty"),
    check("projectId")
      .exists()
      .withMessage("projectId is missing!")
      .notEmpty()
      .withMessage("projectId must not empty"),
  ];
};

//validate the request object on the basis of define rules
const validate = (req, res, next) => {
  const errors = validationResult(req);
  if (errors.isEmpty()) {
    return next();
  }
  const extractedErrors = [];
  errors.array().map((err) => extractedErrors.push({ [err.param]: err.msg }));

  return res.status(422).json({
    errors: extractedErrors,
  });
};

module.exports = {
  createRepositoryValidation,
  validate,
};
