const repoDao = require("../dao/dao");
const {
  errorStatus,
  errorMessages,
  responsHeader,
  statusCodes,
} = require("../../../constants");

let response = {
  headers: responsHeader,
  body: {},
};

//-------------------logger-implementation-----------------------------
const winston = require("winston");
const { createLogs } = require("../../../config/loggerConfig");
const todayDate = new Date().toDateString().replace(/\ /g, "");
const logConfiguration = createLogs("Repository Controller", todayDate);
const logger = winston.createLogger(logConfiguration);
//------------------------------------------------------------------------------


/**
 * A handler function to create a repository in a project.
 * 
 * @param {JSON Object} req The request object.
 * @param {JSON Object} res The response object.
 * 
 * @returns An object of created repository with Http CREATED status code or error objects with Http error status codes.
 */
module.exports.createRepository = async (req, res) => {
  try {
    const bearerHeader = req.headers.authorization;
    const { repositoryName, organizationName, projectId, initializeRepo } =
      req.body;
    const accessToken = bearerHeader && bearerHeader.split(" ")[1];
    var createdRepo = await repoDao.createRepository(
      repositoryName,
      organizationName,
      projectId,
      accessToken
    );
    if (typeof createdRepo === "string") {
      response.body = {
        message: createdRepo,
      };
      res.status(statusCodes.REQUEST_CONFLICT).send(response);
    }
    if (createdRepo.createdRepository.hasOwnProperty("id")) {
      response.body = {
        repository: createdRepo,
      };
      res.status(statusCodes.SUCCESS).send(response);
    } else {
      response.body = {
        message: createdRepo,
      };
      res.status(statusCodes.NOT_FOUND).send(response);
    }
  } catch (error) {
    if (error.statusCode) {
      response.body = {
        errorStatus: error.statusCode,
        errorMessage: error.message,
      };
      return res.status(error.statusCode).send(response);
    } else {
      response.body = {
        errorStatus: statusCodes.SERVER_ERROR,
        errorMessage: error.message,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};


/**
 * A handler function to fetch a list of repositories in a project.
 * 
 * @param {String} req The request query parameters
 * @param {JSON Object} res The response object
 * 
 * @returns A list of repositories object with Http SUCCESS status code or error objects with Http error status codes.
 */
module.exports.getRepositories = async (req, res) => {
  try {
    const bearerHeader = req.headers.authorization;
    const accessToken = bearerHeader && bearerHeader.split(" ")[1];
    const { organizationName, projectName } = req.query;

    const listRepositories = await repoDao.listRepositories(
      organizationName,
      accessToken,
      projectName
    );

    if (listRepositories.length >= 0) {
      response.body = {
        listRepositories: listRepositories,
      };
      res.status(statusCodes.SUCCESS).send(response);
    } else {
      throw new Error("Could not retrieve list of repositories.");
    }
  } catch (error) {
    logger.error("Error in Controller getRepositories function:", error);
    if (error.statusCode) {
      response.body = {
        errorStatus: error.statusCode,
        errorMessage: error.message,
      };
      return res.status(error.statusCode).send(response);
    } else {
      response.body = {
        errorStatus: statusCodes.SERVER_ERROR,
        errorMessage: error.message,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};

/**
 * A handler functiont to initialize a repository with a readme file.
 * 
 * @param {*} req The request object
 * @param {*} res The response object
 * 
 * @returns An object of initialized repository with Http SUCCESS status code or error objects with Http error status codes.
 */
module.exports.initializeRepoWithReadme = async (req, res) => {
  try {
    const bearerHeader = req.headers.authorization;
    const { repositoryName, organizationName, projectId } = req.body;
    const accessToken = bearerHeader && bearerHeader.split(" ")[1];
    var createdRepo = await repoDao.initializeRepoWithReadme(
      repositoryName,
      organizationName,
      projectId,
      accessToken
    );
    if (createdRepo) {
      response.body = {
        repository: createdRepo,
      };
      res.status(statusCodes.SUCCESS).send(response);
    } else {
    }
  } catch (error) {
    if (error.statusCode) {
      response.body = {
        errorStatus: error.statusCode,
        errorMessage: error.message,
      };
      return res.status(error.statusCode).send(response);
    } else {
      response.body = {
        errorStatus: statusCodes.SERVER_ERROR,
        errorMessage: error.message,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};


/**
 * A handler function to fetch a repository by repository name.
 * 
 * @param {JSON Object} req The request object
 * @param {JSON Object} res The response object
 * 
 * @returns An object of repository with Http SUCCESS status code or error objects with Http error status codes.
 */
module.exports.getRepo = async (req, res) => {
  const bearerHeader = req.headers.authorization;
  const { organizationName, projectName, repoName } = req.body;
  const accessToken = bearerHeader && bearerHeader.split(" ")[1];

  try {
    let getRepo = await repoDao.getRepo(
      organizationName,
      accessToken,
      projectName,
      repoName
    );
    logger.log("info", `Get Repo ===============> ${getRepo}`);
    if (getRepo != null && getRepo.hasOwnProperty("id")) {
      response.body = {
        Repository: getRepo,
      };
      return res.status(statusCodes.SUCCESS).send(response);
    } else {
      response.body = {
        errorStatus: statusCodes.NOT_FOUND,
        errorMessage: errorMessages.NRF,
      };
      return res.status(statusCodes.NOT_FOUND).send(response);
    }
  } catch (error) {
    logger.error("Controller Error getting Repo ....", error);
    if (error.statusCode) {
      response.body = {
        errorStatus: error.statusCode,
        errorMessage: error.message,
      };
      return res.status(error.statusCode).send(response);
    } else {
      response.body = {
        errorStatus: statusCodes.SERVER_ERROR,
        errorMessage: error.message,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};
