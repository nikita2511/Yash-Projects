//-------------------logger-implementation-----------------------------
const winston = require("winston");
const { createLogs } = require("./config/loggerConfig");
const todayDate = new Date().toDateString().replace(/\ /g, "");
const logConfiguration = createLogs("dbOperation", todayDate);
const logger = winston.createLogger(logConfiguration);
//------------------------------------------------------------------------------

/**
 * A function perform database operation to insert multiple object at once in database.
 *
 * @param {JSON Object} model The schema model
 * @param {JSON Objects} objectToInsert The array of objects.
 *
 * @returns A list of inserted objects in database or an error object.
 */
module.exports.insertMany = async (model, objectToInsert) => {
  try {
    let insertedObjects = await model.insertMany(objectToInsert);
    return insertedObjects;
  } catch (error) {
    logger.error("Exception in insertMany db operation", error);
    return error;
  }
};

/**
 * A function to perform database operation to save a object in database.
 *
 * @param {JSON Object} model The schema model
 * @param {JSON Object} objectToSave The object to insert in database
 *
 * @returns An array of object saved in database or an error.
 */
module.exports.save = async (model, objectToSave) => {
  try {
    let savedObject = await model.insertMany(objectToSave);
    return savedObject;
  } catch (error) {
    logger.error("Exception in save Db opreration", error);
    return error;
  }
};

/**
 * A function to perform database operation to fetch a list of objects from database
 *
 * @param {JSON Model} model The schema model
 *
 * @returns A list of objects defined by schema or an error object.
 */
module.exports.getAll = async (model) => {
  try {
    let listOfObjects = await model.find();
    return listOfObjects;
  } catch (error) {
    logger.error("Exception in Get All Db opreration", error);
    return error;
  }
};

/**
 * A function to perform update operation on an object found by filter in database.
 *
 * @param {JSON Object} model The schema model
 * @param {JSON Object} filter The condition to find object to update
 * @param {JSON Object} objectToUpdate The object to update
 *
 * @returns An updated object based on filter or error object.
 */
module.exports.update = async (model, filter, objectToUpdate) => {
  try {
    const updatedObject = await model.findOneAndUpdate(filter, objectToUpdate, {
      new: true,
      // upsert: true, // Make this update into an upsert
    });
    return updatedObject;
  } catch (error) {
    logger.error("Exception in Get All Db opreration", error);
    return error;
  }
};

/**
 * A function to perform delete operation on an object found by filter in database.
 *
 * @param {JSON Object} model The schema model
 * @param {JSON Object} filter The condition to find object to delete
 *
 * @returns An object with deleteCount field or error
 */
module.exports.delete = async (model, filter) => {
  try {
    const deletedObject = await model.deleteOne(filter);
    return deletedObject;
  } catch (error) {
    logger.error("Exception in Get All Db opreration", error);
    return error;
  }
};

/**
 * A function to perform database operation to fetch an objects from database
 *
 * @param {JSON Model} model The schema model
 *
 * @returns A list of objects defined by schema or an error object.
 */
module.exports.findOne = async (model, condition) => {
  try {
    let listOfObjects = await model.findOne(condition);
    return listOfObjects;
  } catch (error) {
    logger.error("Exception in find one DB opreration", error);
    return error;
  }
};
