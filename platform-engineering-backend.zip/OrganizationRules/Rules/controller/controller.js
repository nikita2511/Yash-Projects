const projectRulesDAO = require("../dao/dao");
const {
  errorStatus,
  errorMessages,
  responsHeader,
  statusCodes,
} = require("../../../constants");
let response = {
  headers: responsHeader,
  body: {},
};

//-------------------logger-implementation-----------------------------
const winston = require("winston");
const { createLogs } = require("../../../config/loggerConfig");
const todayDate = new Date().toDateString().replace(/\ /g, "");
const logConfiguration = createLogs("projectRules Controller", todayDate);
const logger = winston.createLogger(logConfiguration);
//------------------------------------------------------------------------------

/**
 * A handler function to fetch project creation rule for an organization
 *
 * @param {String} req The request query parameter
 * @param {*} res The resposen object
 *
 * @returns An object of project creation rules with Http SUCCESS status code or error with Http error status codes.
 */
module.exports.getOrganizationRules = async (req, res) => {
  try {
    let organizationName = req.query.organizationName;
    let platform = req.query.platform;

    let projectCreationRules = await projectRulesDAO.getOrganizationRules(
      organizationName,
      platform
    );
    if (projectCreationRules == errorStatus.ONF) {
      response.body = {
        message: errorMessages.ONF,
      };
      res.status(statusCodes.BAD_REQUEST).send(response);
    } else if (projectCreationRules.status == errorStatus.NRF) {
      response.body = {
        message: errorMessages.NRF,
      };
      res.status(statusCodes.NOT_FOUND).send(response);
    } else if (projectCreationRules) {
      response.body = {
        projectCreationRules: projectCreationRules,
      };
      res.status(statusCodes.SUCCESS).send(response);
    }
  } catch (error) {
    logger.error("getOrganizationRules Error ========>", error);
    if (error.message.includes("Failed to connect to the database.")) {
      response.body = {
        message: errorMessages.AuthFailed,
        error: error.message,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    } else {
      response.body = {
        message: errorMessages.ISE,
        error: error.message,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};

/**
 * A handler function to create a project creation rule.
 *
 * @param {JSON Object} req The request object
 * @param {JSON Object} res The respones object.
 *
 * An object of project creation rule with Http CREATED status code or error with Http errors status codes.
 */
module.exports.createOrganizationRules = async (req, res) => {
  try {
    let rule = req.body;
    let projectCreationRules = await projectRulesDAO.createOrganizationRules(
      rule
    );
    if (projectCreationRules) {
      response.body = {
        rule: projectCreationRules,
      };
      res.status(statusCodes.CREATED).send(response);
    } else {
      res.status(statusCodes.NOT_FOUND).send("Rule cannot be created...");
    }
  } catch (error) {
    logger.error("createProjectCreationRules Error========>", error);
    if (error.message.includes("Failed to connect to the database.")) {
      response.body = {
        message: errorMessages.DAE,
        error: error.message,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    } else {
      response.body = {
        message: errorMessages.ISE,
        error: error.message,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};

/**
 * A handler fucntion to update an existing project creation rule.
 *
 * @param {JSON Object} req The request object
 * @param {JSON Object} res The response object
 *
 * @returns An object of updated project creation rule with Http CREATED status code or errors with Http error status codes.
 */
module.exports.updateOrganizationRules = async (req, res) => {
  try {
    let rule = req.body;
    let updatedProjectRules = await projectRulesDAO.updateOrganizationRules(
      rule
    );
    if (updatedProjectRules) {
      response.body = {
        rule: updatedProjectRules,
      };
      res.status(statusCodes.CREATED).send(response);
    } else {
      res.status(statusCodes.NOT_FOUND).send("Rule cannot be updated...");
    }
  } catch (error) {
    logger.error("updateProjectRules Error========>", error);
    if (error.message.includes("Failed to connect to the database.")) {
      response.body = {
        message: errorMessages.DAE,
        error: error.message,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    } else {
      response.body = {
        message: errorMessages.ISE,
        error: error.message,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};

module.exports.getBranchingModels = async (req, res) => {
  try {
    let branchingModels = await projectRulesDAO.getBranchingModels();
    if (branchingModels == errorStatus.NRF) {
      response.body = {
        message: errorMessages.NRF,
      };
      res.status(statusCodes.NOT_FOUND).send(response);
    } else if (branchingModels) {
      response.body = {
        branchingModels: branchingModels,
      };
      res.status(statusCodes.SUCCESS).send(response);
    }
  } catch (error) {
    logger.error("getBranchingModels Error========>", error);
    if (error.message.includes("Failed to connect to the database.")) {
      response.body = {
        message: errorMessages.DAE,
        error: error.message,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    } else {
      response.body = {
        message: errorMessages.ISE,
        error: error.message,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};

/**
 * A handler function to fetch master branching models data
 *
 * @param {JSON Object} res The response object
 *
 * @returns An object of branching model with Http SUCCESS status code or errors with Http error status codes.
 */
module.exports.getMasterBranchingModels = async (req, res) => {
  try {
    let branchingModels = await projectRulesDAO.getMasterBranchingModels();
    if (branchingModels == errorStatus.NRF) {
      response.body = {
        message: errorMessages.NRF,
      };
      res.status(statusCodes.NOT_FOUND).send(response);
    } else if (branchingModels) {
      response.body = {
        branchingModels: branchingModels,
      };
      res.status(statusCodes.SUCCESS).send(response);
    }
  } catch (error) {
    logger.error("getMasterBranchingModels Error========>", error);
    if (error.message.includes("Failed to connect to the database.")) {
      response.body = {
        message: errorMessages.DAE,
        error: error.message,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    } else {
      response.body = {
        message: errorMessages.ISE,
        error: error.message,
      };
      res.status(statusCodes.SERVER_ERROR).send(response);
    }
  }
};
