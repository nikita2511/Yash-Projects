const mongoose = require("mongoose");
const schema = mongoose.Schema;

//The schema for Branches object 
const Branch = new schema({
  _id: { type: schema.Types.ObjectId, required: true, auto: true },
  name: { type: schema.Types.String },
  type: { type: schema.Types.String },
  noOfReviewers: { type: schema.Types.String },
  mergeType: { type: schema.Types.String },
  created_at: { type: Date, required: true, default: Date.now },
  updated_at: { type: Date, required: true, default: Date.now },
});

module.exports = mongoose.model("branches", Branch);
