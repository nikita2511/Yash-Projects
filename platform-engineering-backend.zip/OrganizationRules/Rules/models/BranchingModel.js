const mongoose = require("mongoose");
const schema = mongoose.Schema;

//The schema for Branching Model objects 
const BranchingModel = new schema({
  _id: { type: schema.Types.ObjectId, required: true, auto: true },
  name: { type: schema.Types.String },
  numberOfBranches: { type: schema.Types.Number },
  branches: [{
    type: schema.Types.ObjectId,
    ref: "branches",
    required: true,
    default: [],
  }],
  created_at: { type: Date, required: true, default: Date.now },
  updated_at: { type: Date, required: true, default: Date.now },
});

module.exports = mongoose.model("branchingModels", BranchingModel);
