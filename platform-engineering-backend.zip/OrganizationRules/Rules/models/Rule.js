const mongoose = require("mongoose");
const schema = mongoose.Schema;

//The schema for Rule objects.
const rule = new schema({
  _id: { type: schema.Types.ObjectId, required: true, auto: true },
  organizationName: { type: schema.Types.String },
  namingStandard: { type: schema.Types.String },
  createdBy: { type: schema.Types.String },
  branchingModel: {
    type: schema.Types.ObjectId,
    ref: "branchingModels",
    required: true,
  },
  created_at: { type: Date, required: true, default: Date.now },
  updated_at: { type: Date, required: true, default: Date.now },
});
AzureDevopsRuleModel = mongoose.model("azure-devops-rule", rule);
GithubRuleModel = mongoose.model("github-rule", rule);
module.exports = { AzureDevopsRuleModel, GithubRuleModel };
