const { check, body, validationResult } = require("express-validator");

/**
 * A function to validate request body parameters.
 * 
 * @returns An array of missing request parameters.
 */
const createAndUpdateRuleValidation = () => {
  return [
    check("organizationName")
      .exists()
      .withMessage("organization name is missing")
      .notEmpty()
      .withMessage("organization name must not empty"),
    check("namingStandard")
      .exists()
      .withMessage("key namingStandard is missing")
      .notEmpty()
      .withMessage("naming standard must not empty"),
    check("branchingModel")
      .exists()
      .withMessage("key branchingModel is missing!")
      .notEmpty()
      .withMessage("branching model must not empty"),
    check("branchingModel.branches")
      .exists()
      .withMessage("key branches is missing!")
      .notEmpty()
      .withMessage("branches must not empty"),
    check("branchingModel.name")
      .exists()
      .withMessage("key name is missing!")
      .notEmpty()
      .withMessage("model name must not empty"),
    check("branchingModel.numberOfBranches")
      .exists()
      .withMessage("key numberOfBranches is missing!")
      .notEmpty()
      .withMessage("model name must not empty"),
    check("branchingModel.branches.*.name")
      .exists()
      .withMessage(" key name is missing in branches array")
      .notEmpty()
      .withMessage("branch name must not empty"),
    check("branchingModel.branches.*.noOfReviewers")
      .exists()
      .withMessage("key reviewrs is missing in branches array")
      .notEmpty()
      .withMessage("branch reviewrs must not empty"),
    check("branchingModel.branches.*.mergeType")
      .exists()
      .withMessage(" key mergeType is missing in branches array")
      .notEmpty()
      .withMessage("branch mergeType must not empty"),
    check("branchingModel.branches.*.type")
      .exists()
      .withMessage(" key type is missing in branches array")
      .notEmpty()
      .withMessage("branch type must not empty"),
  ];
};


/**
 * A function to validate request body parameters.
 * 
 * @returns An array of missing request parameters.
 */
const getRuleValidation = () => {
  return [
    check("organizationName")
      .exists()
      .withMessage("organization name is missing")
      .notEmpty()
      .withMessage("organization name must not empty"),
  ];
};

/**
 * A handler function to validate request body parameters
 * 
 * @param {Array} req The request parameters array
 * @param {JSON object} res The response object
 * @param {CallableFunction} next The callback function
 * 
 * @returns An array of objects with missing request parameters information with Http status code or errror with Http error status code.
 */
const validate = (req, res, next) => {
  const errors = validationResult(req);
  if (errors.isEmpty()) {
    return next();
  }
  const extractedErrors = [];
  errors.array().map((err) => extractedErrors.push({ [err.param]: err.msg }));

  return res.status(422).json({
    errors: extractedErrors,
  });
};

module.exports = {
  createAndUpdateRuleValidation,
  validate,
  getRuleValidation,
};
