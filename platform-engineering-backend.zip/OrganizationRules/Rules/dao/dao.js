const { GithubRuleModel, AzureDevopsRuleModel } = require("../models/Rule");
const Branch = require("../models/Branch");
const BranchingModel = require("../models/BranchingModel");
const MasterBranchingModel = require("../models/MasterBranchingModel");
const { connect } = require("../../../config/dbConfig");
const { errorStatus } = require("../../../constants");
const dbOperations = require("../../../dbOperations");
const { mongoose } = require("mongoose");

//-------------------logger-implementation-----------------------------
const winston = require("winston");
const { createLogs } = require("../../../config/loggerConfig");
const todayDate = new Date().toDateString().replace(/\ /g, "");
const logConfiguration = createLogs("projectRules Dao", todayDate);
const logger = winston.createLogger(logConfiguration);
//------------------------------------------------------------------------------

/**
 * A function to fetch rules to create a project for an organization
 *
 * @param {String} organizationName
 *
 * @returns An object of rule or an error object.
 */
module.exports.getOrganizationRules = async (organizationName, platform) => {
  try {
    // Check if organization name is provided
    if (!organizationName) return errorStatus.ONF;

    // Connect to database
    try {
      await connect();
    } catch (error) {
      logger.error("Exception in project rule dao", error);
      throw new Error("Failed to connect to the database.");
    }

    // Get project creation rule for the given organization name
    let RuleModel;
    switch (platform) {
      case "Github":
        RuleModel = GithubRuleModel;
        break;
      case "AzureDevops":
        RuleModel = AzureDevopsRuleModel;
        break;
      default:
        break;
    }
    let rule = await RuleModel.findOne({
      organizationName: organizationName,
    }).populate({
      path: "branchingModel",
      populate: {
        path: "branches",
        model: "branches",
      },
    });
    // logger.log("info", `Org Rule ${rule}`);
    // Return the project creation rule if found, otherwise return an error
    if (rule) {
      return rule;
    } else return { status: errorStatus.NRF };
  } catch (error) {
    logger.error("Error in getOrganizationRules: ", error);
    throw error;
  }
};

/**
 * A function to create a project creation rule for an organization.
 *
 * @param {JSON Object} rule
 *
 * @returns An object of created rule or an error object.
 */
module.exports.createOrganizationRules = async (rule) => {
  // Create a new MongoDB session
  let session;
  try {
    await connect();
    session = await mongoose.connection.startSession();
    session.startTransaction();
    // Delete the _id field from the branches array
    let branches = rule.branchingModel.branches;
    branches.forEach(async (branch) => {
      delete branch._id;
    });
    // Insert the branches into the database
    let createdBranches = await dbOperations.insertMany(Branch, branches);
    // Create an array of the branch IDs
    let branchArray = [];
    createdBranches.forEach(async (branch) => {
      branchArray.push(branch._id);
    });
    // Delete the _id field from the branching model
    let branchingModel = rule.branchingModel;
    delete branchingModel._id;
    branchingModel.branches = branchArray;

    // Save the branching model to the database
    let createdBranchingModel = await dbOperations.save(
      BranchingModel,
      branchingModel
    );

    // Set the branching model ID on the rule
    rule.branchingModel = createdBranchingModel[0]._id;
    // Save the rule to the database
    let createdRule;
    switch (rule.platform) {
      case "Github":
        createdRule = await dbOperations.save(GithubRuleModel, rule);
        break;
      case "AzureDevops":
        createdRule = await dbOperations.save(AzureDevopsRuleModel, rule);
        break;
      default:
        break;
    }
    // let createdRule = await dbOperations.save(Rule, rule);

    // Commit the transaction
    await session.commitTransaction();
    await session.endSession();
    return createdRule;
  } catch (error) {
    if (session) {
      await session.abortTransaction();
      await session.endSession();
    }

    throw new Error("Failed to connect to the database.");
  }
};

/**
 * A function to update an existing project creation rule for an organization.
 *
 * @param {JSON Object} rule
 *
 * @returns An object of updated project creation rule or an error object.
 */
module.exports.updateOrganizationRules = async (rule) => {
  let session;
  try {
    await connect();
    session = await mongoose.connection.startSession();
    session.startTransaction();
    let { namingStandard, organizationName, branchingModel } = rule;
    let { name, numberOfBranches, branches } = branchingModel;
    let RuleModel;
    switch (rule.platform) {
      case "Github":
        RuleModel = GithubRuleModel;
        break;
      case "AzureDevops":
        RuleModel = AzureDevopsRuleModel;
        break;
      default:
        break;
    }
    let ruleToUpdate = await RuleModel.findOne({
      organizationName: organizationName,
    });

    // Delete the _id field from each branch in the branching model.
    branches.forEach(async (branch) => {
      delete branch._id;
    });

    // Insert the branches into the database.
    let branchesToUpdated = await await dbOperations.insertMany(
      Branch,
      branches
    );

    // Get the updated branching model from the database.
    let branchArray = [];
    branchesToUpdated.forEach(async (branch) => {
      branchArray.push(branch._id);
    });
    let branchingModeltoUpdate = await BranchingModel.findByIdAndUpdate(
      { _id: ruleToUpdate.branchingModel },
      {
        $set: {
          name: name,
          numberOfBranches: numberOfBranches,
          branches: branchArray,
        },
      },
      { new: true }
    );
    // Update the rule in the database.
    let updatedRule = await RuleModel.findOneAndUpdate(
      { organizationName: organizationName },
      {
        $set: {
          namingStandard: namingStandard,
        },
      },
      { new: true }
    );
    // Commit the transaction and end the session.
    await session.commitTransaction();
    await session.endSession();
    return updatedRule;
  } catch (error) {
    if (session) {
      await session.abortTransaction();
      await session.endSession();
    }

    throw new Error("Failed to connect to the database.");
  }
};

/**
 * A function to fetch master data for branching models.
 *
 * @returns An object of branching model or an error object.
 */
module.exports.getMasterBranchingModels = async () => {
  try {
    await connect();
    let branchingModels = await MasterBranchingModel.find();
    if (branchingModels.length) return branchingModels;
    else return errorStatus.NRF;
  } catch (error) {
    logger.error("getMasterBranchingModels Error", error);
    throw new Error("Failed to connect to the database.");
  }
};

/**
 * A function to fetch list of project creation rules for available organization.
 *
 * @returns A list of rules object or an error object.
 */
module.exports.getOrgnizationRulesList = async (platform) => {
  try {
    await connect();
    let RuleModel;
    switch (platform) {
      case "Github":
        RuleModel = GithubRuleModel;
        break;
      case "AzureDevops":
        RuleModel = AzureDevopsRuleModel;
        break;
      default:
        break;
    }
    let orgRuleList = await RuleModel.find();
    if (orgRuleList) {
      return orgRuleList;
    } else return { status: errorStatus.NRF };
  } catch (error) {
    logger.error("Error in getOrganization: ", error);
    if (error.response) {
      throw new Error(
        "Failed to retrieve organization : " + error.response.data.message
      );
    } else {
      throw new Error("Failed to retrieve organization rule list.");
    }
  }
};
