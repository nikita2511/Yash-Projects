const express = require("express");
const router = express.Router();
const controller = require("../controller/controller");
const {
  createAndUpdateRuleValidation,
  getRuleValidation,
  validate,
} = require("../middlewares/validator");

//Get Organization Rules for an Organization
router.get(
  "/project",
  getRuleValidation(),
  validate,
  controller.getOrganizationRules
);

//Create an Organization Rule
router.post(
  "/project",
  createAndUpdateRuleValidation(),
  validate,
  controller.createOrganizationRules
);

//Update an Organization Rule
router.put(
  "/project",
  createAndUpdateRuleValidation(),
  validate,
  controller.updateOrganizationRules
);

//Get All Branching Models with Branches
router.get("/branchingmodels", controller.getMasterBranchingModels);

module.exports = router;
