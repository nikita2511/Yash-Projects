var AWS = require("aws-sdk");
AWS.config.update({
  region: "us-east-1",
});
AttributeNames = ["city", "price", "author", "title"];
const search = "chetan bhagat";
let result;
let filteredList;
let requestObj = {
  title: "fear",
};
const elementsArray = Object.entries(requestObj);

//search
AttributeNames.forEach((element) => {
  let attributeName;
  let attributevalue;
  const params = {
    TableName: "books",
    FilterExpression: "#element = :element",
    ExpressionAttributeNames: {
      "#element": element,
    },
    ExpressionAttributeValues: {
      ":element": search,
    },
  };
  console.log(params);
  const docClient = new AWS.DynamoDB.DocumentClient();
  docClient.scan(params, function (err, data) {
    if (data) {
      if (data.Items.length != 0) {
        attributeName = element;
        attributevalue = search;
        result = data;
        console.log("------result search items------", result.Items);

        elementsArray.forEach((element) => {
          let key = element[0];
          console.log("-----------element------", element);
          console.log("-----------key------", key);
          filteredList = result.Items.filter((item) => {
            console.log("---------item-----", item);
            item.title.startsWith("fear 1");
          });
          console.log(filteredList);
          // switch (element[0]) {
          //   case "title":
          //     filteredList = result.Items.filter((item) => {
          //       console.log("---------item-----", item),
          //         console.log(element[1]);
          //       item.title.startsWith(element[1]);
          //     });
          //     // filteredList = filteredList;
          //     console.log("-----------filteredList ---", filteredList);

          //     break;
          //   case "city":
          //     filteredList = result.Items.filter((item) => {
          //       console.log("---------item-----", item),
          //         item.city.startsWith(element[1]);
          //     });
          //     filteredList = filteredList;
          //     break;
          //   case "price":
          //     filteredList = result.Items.filter((item) => {
          //       console.log("---------item-----", item),
          //         item.price.startsWith(element[1]);
          //     });
          //     filteredList = filteredList;

          //     break;
          //   case "author":
          //     filteredList = result.Items.filter((item) => {
          //       console.log("---------item-----", item),
          //         item.author.startsWith(element[1]);
          //     });
          //     filteredList = filteredList;

          //     break;
          //   default:
          //     break;
          // }
          // filteredList = filteredList;
        });
      }
    } else console.log(err);
  });
});

// elementsArray.forEach((element) => {
//   console.log("-----------element------", element[0]);
//   filteredList = result.Items.filter((item) =>
//     item.element[0].startsWith(element[1])
//   );
//   filteredList = filteredList;
//   console.log(filteredList);
// });

//filter
// let object = {

//   title: "fear 1",
// };

// const objValues = object;
// const elementsArray = Object.entries(objValues);
// let FilterExpression = " ";
// const ExpressionAttributeValues = {};
// const ExpressionAttributeNames = {};
// const operator = "and";
// const str = "#";
// elementsArray.forEach((element) => {
//   FilterExpression =
//     `${FilterExpression} ` +
//     `${str}` +
//     `${element[0]} = :${element[0]}` +
//     " " +
//     operator;
//   console.log(FilterExpression);
//   ExpressionAttributeNames[`${str}` + `${element[0]}`] = element[0];
//   ExpressionAttributeValues[`:${element[0]}`] = element[1];
// });
// FilterExpression = FilterExpression.substring(0, FilterExpression.length - 3);
// console.log(FilterExpression);
// console.log(ExpressionAttributeNames);
// console.log(ExpressionAttributeValues);
// var params = {
//   TableName: "books",
//   FilterExpression: FilterExpression,
//   ExpressionAttributeNames: ExpressionAttributeNames,
//   ExpressionAttributeValues: ExpressionAttributeValues,
// };
// const docClient = new AWS.DynamoDB.DocumentClient();
// docClient.scan(params, function (err, data) {
//   if (err) console.log(err);
//   else console.log("----result for filter---- ", data.Items);
// });
