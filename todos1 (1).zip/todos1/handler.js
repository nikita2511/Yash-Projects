'use strict';
// const dynamoDbHandler = require('/opt/custom_modules/dynamodb-handler');
const creatconcept=require('./functions/createConcept');
// const { putInTable } = require('../layers/dynamo-db-layers/custom_modules/dynamodb-handler');


module.exports.hello = async (event) => {
  console.log('event.body',event.body);
  // const dynamoResp = await dynamoDbHandler.putInTablee();
  const creatresponse= await creatconcept.createconept(event);
  // console.log("dynamoResp",dynamoResp);
  console.log("creatresponse", creatresponse);
  // console.log("dynamoResp string",JSON.stringify(dynamoResp));
  console.log("dynamoResp string",JSON.stringify(creatresponse));

  return {
    statusCode: 200,
    body: JSON.stringify(
      {
        message: 'Go Serverless v1.0! Your function executed successfully!',
        input: creatresponse,
      },
      null,
      2
    ),
  };

  // Use this code if you don't use the http event with the LAMBDA-PROXY integration
  // return { message: 'Go Serverless v1.0! Your function executed successfully!', event };
};
