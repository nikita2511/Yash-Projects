const AWS = require('aws-sdk')
const dynamodb = new AWS.DynamoDB()

module.exports.handler = async (event) => {
    event = JSON.parse(event.body);
    const id = event.payload.argument.id

    const params = {
      Key: {
          "id": {
              S: id
          }
      },
      TableName: 'cg_cm_table_concepts-dev'
    }


    return dynamodb.deleteItem(params).promise()
        .then(data => {            
            return {
                id
            }
        })
        .catch(err => {
          console.log(err)
        })
};