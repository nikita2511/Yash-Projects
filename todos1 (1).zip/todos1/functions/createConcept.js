// const AWS = require('aws-sdk')
// const dynamodb = new AWS.DynamoDB()

// module.exports.handler = async (event) => {  
//     console.log("**********"+JSON.stringify(event)+"****************")  
//     event = JSON.parse(event.body);
//     const id = event.payload.argument.id
//     const name = event.payload.argument.name
//     const description = event.payload.argument.description    

//     const params = {
//         Item: {
//             "id": {
//                 S: id
//             },
//             "name": {
//                 S: name
//             },
//             "description": {
//                 S: description
//             }            
//         },
//         ReturnConsumedCapacity: "TOTAL",
//         TableName: process.env.CONCEPT_TABLE_NAME
//     }

//     return dynamodb.putItem(params).promise()
//         .then(data => {            
//             return {
//                 id,
//                 name,
//                 description
//             }
//         })
//         .catch(err => {
//             console.log(err)
//         })
// };




var AWS = require("aws-sdk");

var docClient = new AWS.DynamoDB.DocumentClient();

  

module.exports.createconept = async (event) => {

    // console.log("**********"+JSON.stringify(event)+"****************") 
    console.log("************json not parse"+JSON.stringify(event)) 
    // event = JSON.parse(event.body);
    event = JSON.parse(event.body);
    const id = event.payload.argument.id
    const name = event.payload.argument.name
    const description = event.payload.argument.description  



    var params = {

        TableName: 'cg_cm_table_concepts-dev',

        Item:{

            'id': id,

            'name': name,

            'description': description

        }

    };




   

    console.log("Adding a new item...", params);

    let response ={};

    await docClient.put(params).promise()

        .then(data => {            

            response = params.Item;

        })

        .catch(err => {

            console.log(err)

            response = {"err":err}

        })

        console.log("respone",response);

        return  response;

}
