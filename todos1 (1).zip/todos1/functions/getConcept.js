const AWS = require('aws-sdk')
const dynamodb = new AWS.DynamoDB()

module.exports.handler = async (event) => {

    const params = {        
        TableName: 'cg_cm_table_concepts-dev',
    }


    console.log("the entry in getconcept");


    return dynamodb.scan(params).promise()
        .then(data => {            
            const conceptList = [];
            console.log("data"+JSON.stringify(data))
            for (let i = 0; i < data.Items.length; i++) {
                conceptList.push({
                    id: data.Items[i].id.S,
                    name: data.Items[i].name.S,
                    description: data.Items[i].description.S
                });        
            }
            return {
                statusCode: 200,
                body: JSON.stringify(
                  {
                    message: 'Go Serverless v1.0! Your function executed successfully!',
                    input: conceptList,
                  },
                  null,
                  2
                ),
              };            
        })
        .catch(err => {
            console.log(err)
        })
};