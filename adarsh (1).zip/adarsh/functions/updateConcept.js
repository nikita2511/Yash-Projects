const AWS = require('aws-sdk')
const dynamodb = new AWS.DynamoDB()

module.exports.handler = async (event) => {
    event = JSON.parse(event.body);
    const id = event.payload.argument.id
    const name = event.payload.argument.name
    const description = event.payload.argument.description

    const params = {
      ExpressionAttributeNames: {
          "#n": "name",
          "#d": "description"          
      },
      ExpressionAttributeValues: {
          ":n": {
              S: name
          },
          ":d": {
              S: description
          }
      },
      Key: {
          "id": {
              S: id
          }
      },
      ReturnValues: "ALL_NEW",
      TableName: process.env.CONCEPT_TABLE_NAME,
      UpdateExpression: "SET #n = :n, #d = :d"
  }

  return dynamodb.updateItem(params).promise()
      .then(data => {
          const body = data.Attributes
          return {
            id: body.id.S,
            name: body.name.S,
            description: body.description.S
          }
      })
      .catch(err => {
        console.log(err)
      })
};