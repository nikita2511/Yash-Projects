const AWS = require('aws-sdk')
const dynamodb = new AWS.DynamoDB()

module.exports.handler = async (event) => {  
    console.log("**********"+JSON.stringify(event)+"****************")  
    event = JSON.parse(event.body);
    const id = event.payload.argument.id
    const name = event.payload.argument.name
    const description = event.payload.argument.description    

    const params = {
        Item: {
            "id": {
                S: id
            },
            "name": {
                S: name
            },
            "description": {
                S: description
            }            
        },
        ReturnConsumedCapacity: "TOTAL",
        TableName: process.env.CONCEPT_TABLE_NAME
    }

    return dynamodb.putItem(params).promise()
        .then(data => {            
            return {
                id,
                name,
                description
            }
        })
        .catch(err => {
            console.log(err)
        })
};