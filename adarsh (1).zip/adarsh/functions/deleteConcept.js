const AWS = require('aws-sdk')
const dynamodb = new AWS.DynamoDB()

module.exports.handler = async (event) => {
    event = JSON.parse(event.body);
    const id = event.payload.argument.id

    const params = {
      Key: {
          "id": {
              S: id
          }
      },
      TableName: process.env.CONCEPT_TABLE_NAME
    }


    return dynamodb.deleteItem(params).promise()
        .then(data => {            
            return {
                id
            }
        })
        .catch(err => {
          console.log(err)
        })
};