import { USER_REGISTRATION, USER_LOGIN } from "../actions/type";
const initialState = {
  user: {},
};
export default function func(state = initialState, action) {
  switch (action.type) {
    case USER_REGISTRATION:
      return {
        ...state,
      user: action.payload,
      }
    case USER_LOGIN:
      return {
        ...state,
        user: action.payload,
      };
      default:
        return state;
  }
}