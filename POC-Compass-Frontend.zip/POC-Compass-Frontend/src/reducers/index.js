import { combineReducers } from "redux";
import errorReducer from "./errorReducer";
import userReducer from "./userReducer";
import restaurantReducer from "./restaurantReducer";
import cartReducer from "./cartReducer";
import orderReducer from "./orderReducer";
import deliveryReducer from "./deliveryReducer";

export default combineReducers({
  errors: errorReducer,
  users: userReducer,
  restaurant: restaurantReducer,
  cartReducer: cartReducer,
  orderReducer: orderReducer,
  deliveryReducer: deliveryReducer,
});
