import {
  CREATE_ORDER,
  GET_ORDER_BY_ID,
  GET_ALL_RESTAURANT_ORDERS,
  GET_ORDER,
  GET_ALL_USER_ORDERS,
  UPDATE_ORDER_STATUS,
} from "../actions/type";
const initialState = {
  restaurantAllOrders: [],
  createOrder: null,
  userOrders: [],
  k: null,
};
export default function func(state = initialState, action) {
  switch (action.type) {
    case GET_ALL_RESTAURANT_ORDERS:
      let ordersWithKey = action.payload.map((element) => {
        element.key = element.orderId;
        return element;
      });
      return {
        ...state,
        restaurantAllOrders: ordersWithKey,
      };
    case CREATE_ORDER:
      console.log("---------", action.payload);
      return {
        ...state,
        createOrder: action.payload,
      };
    case GET_ORDER_BY_ID:
      return {
        ...state,
        createOrder: action.payload,
      };
    case GET_ALL_USER_ORDERS:
      return {
        ...state,
        userOrders: action.payload,
      };
    case GET_ORDER:
      return {
        ...state,
        restaurantAllOrders: [...state.restaurantAllOrders, action.payload],
      };
    case UPDATE_ORDER_STATUS:
      let orderList = state.restaurantAllOrders.map((element) => {
        if (element.orderId === action.payload.orderId) {
          element.orderStatus = action.payload.orderStatus;
          return element;
        }
        return element;
      });
      return {
        ...state,
        restaurantAllOrders: orderList,
      };
    default:
      return state;
  }
}
