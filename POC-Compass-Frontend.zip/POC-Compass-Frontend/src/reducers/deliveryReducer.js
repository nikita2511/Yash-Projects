import {
  GET_All_DELIVERY_ORDERS,
  UPDATE_DELIVERY_STATUS,
} from "../actions/type";
const initialState = {
  deliveryOrders: [],
  updatedDeliveryObj: {},
};
export default function func(state = initialState, action) {
  switch (action.type) {
    case GET_All_DELIVERY_ORDERS:
      return {
        ...state,
        deliveryOrders: action.payload,
      };
    case UPDATE_DELIVERY_STATUS:
      console.log("-------------action payload-----------", action.payload);
      let updatedOrders = state.deliveryOrders.map((order) => {
        console.log("-inside loop------", order);
        if (order.order.orderId === action.payload.orderId) {
          order.deliveryStatus = action.payload.deliveryStatus;
          console.log("---inside if--order", order);
          return order;
        }
        return order;
      });
      return {
        ...state,
        deliveryOrders: updatedOrders,
        updatedDeliveryObj: action.payload,
      };

    default:
      return state;
  }
}
