import {
  GET_CART_ITEMS,
  ADD_ITEM_TO_CART,
  DELETE_CART_ITEM,
  UPDATE_CART_ITEM,
} from "../actions/type";
const initialState = {
  cartItems: [],
  cartId: "",
};
export default function func(state = initialState, action) {
  switch (action.type) {
    case ADD_ITEM_TO_CART:
      return {
        ...state,
        cartItems: [...state.cartItems, action.payload],
      };
    case GET_CART_ITEMS:
      return {
        ...state,
        cartId: action.payload.cartId,
        cartItems: action.payload.cartItems,
      };
    case DELETE_CART_ITEM:
      return {
        ...state,
        cartItems: state.cartItems.filter(
          (item) => item.cartItemId !== action.payload
        ),
      };
    case UPDATE_CART_ITEM:
      let items = state.cartItems.map((cartItem) => {
        if (cartItem.cartItemId === action.payload.cartItemId)
          return action.payload;
        return cartItem;
      });
      return {
        ...state,
        cartItems: items,
      };
    default:
      return state;
  }
}
