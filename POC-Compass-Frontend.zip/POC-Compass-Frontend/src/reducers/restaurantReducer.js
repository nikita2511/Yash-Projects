import {
  CREATE_RESTAURANT,
  CREATE_MENUITEM,
  GET_MENU_ITEMS,
  GET_RESTAURANT,
  DELETE_MENU_ITEM,
  CREATE_MENUITEM_BY_EXCEL,
  UPDATE_MENU_ITEM,
  GET_RESTAURANTS,
  RESTAURANT_DETAILS,
  GET_RESTAURANT_BY_ID,
  GET_MENU_ITEMS_BY_CATEGORY,
  FILTER_RESTAURANT_BY_CATEGORY,
  UPDATE_RESTAURANT_RATING,
} from "../actions/type";

const initialState = {
  restaurant: null,
  restaurantItem: {},
  menuItems: [],
  menuItem: {},
  updatedMenuItem: {},
  restaurants: [],
  restaurantDetails: {},
  updatedRestaurantRating: {},
};

export default function func(state = initialState, action) {
  switch (action.type) {
    case CREATE_RESTAURANT:
      return {
        ...state,
        restaurant: action.payload,
      };

    case GET_RESTAURANT:
      return {
        ...state,
        restaurant: action.payload,
      };

    case CREATE_MENUITEM:
      return {
        ...state,
        menuItems: [...state.menuItems, action.payload],
      };

    case CREATE_MENUITEM_BY_EXCEL:
      return {
        ...state,
        menuItems: [...state.menuItems, action.payload],
      };

    case GET_MENU_ITEMS:
      return {
        ...state,
        menuItems: action.payload,
      };

    case GET_MENU_ITEMS_BY_CATEGORY:
      return {
        ...state,
        menuItems: action.payload,
      };

    case DELETE_MENU_ITEM:
      return {
        ...state,
        menuItems: state.menuItems.filter(
          (item) => item.menuItemId !== action.payload
        ),
      };
    case UPDATE_MENU_ITEM:
      let items = state.menuItems.map((menuItem) => {
        if (menuItem.menuItemId === action.payload.menuItem)
          return action.payload;
        return menuItem;
      });
      return {
        ...state,
        menuItems: items,
      };
    case GET_RESTAURANTS:
      return {
        ...state,
        restaurants: action.payload,
      };
    case RESTAURANT_DETAILS:
      console.log("inside reducers", action);
      return {
        ...state,
        restaurantDetails: action.payload,
      };
    case GET_RESTAURANT_BY_ID:
      console.log("inside reducers", action);
      return {
        ...state,
        restaurantDetails: action.payload,
      };

    case FILTER_RESTAURANT_BY_CATEGORY:
      console.log("inside reducers", action);
      return {
        ...state,
        restaurants: action.payload,
      };
    case UPDATE_RESTAURANT_RATING:
      console.log("inside reducers", action);
      return {
        ...state,
        updatedRestaurantRating: action.payload,
      };
    default:
      return state;
  }
}
