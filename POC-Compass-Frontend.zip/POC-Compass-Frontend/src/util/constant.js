// constants for popup modal title
const popupTitle = {
  FAILED: "Failed",
  SUCCESS: "Success",
};

const loginMessage = {
  SUCCESS: "You are successfully logged in",
};

const userType = {
  USER: "User",
  DELIVERY_BOY: "DeliveryBoy",
  RESTAURANT_OWNER: "RestaurantOwner",
};
const orderStatus = {
  InProgress: 1,
  Accept: 2,
  Preparing: 3,
  OutForDelivery: 4,
  Delivered: 5,
};

const orderStatusString = {
  InProgress: "InProgress",
  Accept: "Accept",
  Reject: "Reject",
  Preparing: "Preparing",
  OutForDelivery: "OutForDelivery",
  Failed: "Failed",
  Delivered: "Delivered",
};

const pusherChannelName = {
  NEW_ORDER_CREATED: "newOrderIsCreated",
  ORDER_UPDATED: "orderIsUpdated",
};
module.exports = {
  popupTitle,
  loginMessage,
  userType,
  orderStatus,
  pusherChannelName,
  orderStatusString,
};
