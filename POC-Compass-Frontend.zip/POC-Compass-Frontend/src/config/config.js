const awsConfig = {
  aws_graphql_endpoint:
    "https://2zi57e7yx5guviixb5oh66izm4.appsync-api.us-east-1.amazonaws.com/graphql",

  x_api_key: "da2-lsdzdmeaerdg5c5zud74u2bn2e",

  Content_Type: "application/graphql",
};
const pusherConfig = {
  API_KEY: "c3ebd4428bfc50dfd915",

  CLUSTER: "ap2",
};

module.exports = { awsConfig, pusherConfig };
