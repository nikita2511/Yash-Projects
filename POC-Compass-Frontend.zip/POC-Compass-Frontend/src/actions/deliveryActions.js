import axios from "axios";
import { Modal } from "antd";
import { awsConfig } from "../config/config";
import constant from "../util/constant";
import {
  GET_All_DELIVERY_ORDERS,
  GET_ERRORS,
  UPDATE_DELIVERY_STATUS,
} from "./type";
const baseUrl = awsConfig.aws_graphql_endpoint;
const headers = {
  "x-api-key": awsConfig.x_api_key,
  "Content-Type": awsConfig.Content_Type,
};

//getAllOrders
export const getAllDeliveryOrders = (query, history) => async (dispatch) => {
  axios
    .post(
      baseUrl,
      {
        query: query,
      },
      {
        headers: headers,
      }
    )
    .then((res) => {
      console.log("-----------list of delivery orders----------", res);
      res = res.data;
      if (res.errors) {
        dispatch({
          type: GET_ERRORS,
          payload: res.errors[0].message,
        });
      } else {
        console.log("inside else", res);
        dispatch({
          type: GET_All_DELIVERY_ORDERS,
          payload: res.data.getDeliveryDetailsByDeliveryBoyId,
        });
      }
    })
    .catch((error) => {
      console.log("error", error);
    });
};

//update delivery status
export const updateDeliveryStatus = (query, history) => async (dispatch) => {
  axios
    .post(
      baseUrl,
      {
        query,
      },
      {
        headers: headers,
      }
    )
    .then((res) => {
      res = res.data;
      console.log("----------res------", res);
      if (res.errors) {
        Modal.error({
          title: constant.popupTitle.FAILED,
          content: res.errors[0].message,
        });
        dispatch({
          type: GET_ERRORS,
          payload: res.errors[0].message,
        });
      } else {
        dispatch({
          type: UPDATE_DELIVERY_STATUS,
          payload: res.data.updateDeliveryDetails,
        });
      }
    })
    .catch((error) => {
      console.log("error", error);
    });
};
