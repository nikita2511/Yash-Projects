import axios from "axios";
import { Modal } from "antd";
import { awsConfig } from "../config/config";
import constant from "../util/constant";
import {
  GET_ERRORS,
  CREATE_RESTAURANT,
  CREATE_MENUITEM,
  GET_MENU_ITEMS,
  GET_MENU_ITEMS_BY_CATEGORY,
  GET_RESTAURANT,
  DELETE_MENU_ITEM,
  CREATE_MENUITEM_BY_EXCEL,
  UPDATE_MENU_ITEM,
  GET_RESTAURANTS,
  RESTAURANT_DETAILS,
  GET_RESTAURANT_BY_ID,
  FILTER_RESTAURANT_BY_CATEGORY,
  UPDATE_RESTAURANT_RATING,
} from "./type";
const baseUrl = awsConfig.aws_graphql_endpoint;
const headers = {
  "x-api-key": awsConfig.x_api_key,
  "Content-Type": awsConfig.Content_Type,
};

//create restaurnt
export const createRestaurant = (restaurant, history) => async (dispatch) => {
  axios
    .post(
      baseUrl,
      {
        query: restaurant,
      },
      {
        headers: headers,
      }
    )
    .then((res) => {
      res = res.data;
      if (res.errors) {
        Modal.error({
          title: constant.popupTitle.FAILED,
          content: res.errors[0].message,
        });
        dispatch({
          type: GET_ERRORS,
          payload: res.errors[0].message,
        });
      } else {
        dispatch({
          type: CREATE_RESTAURANT,
          payload: res.data.createRestaurant,
        });
        localStorage.setItem(
          "restaurant",
          JSON.stringify(res.data.createRestaurant)
        );
        history.push("/restaurant");
      }
    })
    .catch((error) => {
      console.log("error", error);
    });
};

//getRestaurantBy restaurant id
export const getRestaurantByUserId =
  (query, history, loadingFalse) => async (dispatch) => {
    try {
      var result = await axios.post(
        baseUrl,
        {
          query: query,
        },
        {
          headers: headers,
        }
      );
      result = result.data;
      if (result.errors) {
        loadingFalse();
        dispatch({
          type: GET_ERRORS,
          payload: result.errors[0].message,
        });
      } else {
        loadingFalse();
        localStorage.setItem(
          "restaurant",
          JSON.stringify(result.data.getRestaurantByUserId)
        );
        dispatch({
          type: GET_RESTAURANT,
          payload: result.data.getRestaurantByUserId,
        });
      }
    } catch (error) {
      dispatch({
        type: GET_ERRORS,
        payload: error.message,
      });
    }
  };

//createmenuItem
export const createMenuItem = (restaurant, history) => async (dispatch) => {
  axios
    .post(
      baseUrl,
      {
        query: restaurant,
      },
      {
        headers: headers,
      }
    )
    .then((res) => {
      res = res.data;
      if (res.errors) {
        Modal.error({
          title: constant.popupTitle.FAILED,
          content: res.errors[0].message,
        });
        dispatch({
          type: GET_ERRORS,
          payload: res.errors[0].message,
        });
      } else {
        dispatch({
          type: CREATE_MENUITEM,
          payload: res.data.createMenuItem,
        });
        history.push("/menu-items");
      }
    })
    .catch((error) => {
      console.log("error", error);
    });
};

//getmenuItem
export const getMenuItems = (query, loadingFalse) => async (dispatch) => {
  axios
    .post(
      baseUrl,
      {
        query: query,
      },
      {
        headers: headers,
        Pragma: "no-cache",
        "Cache-Control": "no-cache",
      }
    )
    .then((res) => {
      console.log("res", res);
      if (loadingFalse) {
        loadingFalse();
      }
      res = res.data;
      if (res.errors) {
        dispatch({
          type: GET_ERRORS,
          payload: res.errors[0].message,
        });
      } else {
        dispatch({
          type: GET_MENU_ITEMS,
          payload: res.data.getMenuItemsByRestaurantId,
        });
      }
    })
    .catch((error) => {
      console.log("error", error);
    });
};

//getmenu Item by category

export const getMenuItemsByCategory = (query, history) => async (dispatch) => {
  axios
    .post(
      baseUrl,
      {
        query: query,
      },
      {
        headers: headers,
        Pragma: "no-cache",
        "Cache-Control": "no-cache",
      }
    )
    .then((res) => {
      res = res.data;
      console.log("res data==", res);
      if (res.errors) {
        dispatch({
          type: GET_ERRORS,
          payload: res.errors[0].message,
        });
      } else {
        dispatch({
          type: GET_MENU_ITEMS_BY_CATEGORY,
          payload: res.data.getRestaurantDetailsByIndex,
        });
      }
    })
    .catch((error) => {
      console.log("error", error);
    });
};

//delete menu item
export const deleteMenuItem =
  (query, menuItemId, history) => async (dispatch) => {
    axios
      .post(
        baseUrl,
        {
          query: query,
        },
        {
          headers: headers,
        }
      )
      .then((res) => {
        res = res.data;
        if (res.errors) {
          dispatch({
            type: GET_ERRORS,
            payload: res.errors[0].message,
          });
        } else {
          dispatch({
            type: DELETE_MENU_ITEM,
            payload: menuItemId,
          });
          history.push("/menu-items");
        }
      })
      .catch((error) => {
        console.log("error", error);
      });
  };

//update menuItem

export const updateMenuItem = (query, history) => async (dispatch) => {
  console.log("query", query);
  axios
    .post(
      baseUrl,
      {
        query: query,
      },
      {
        headers: headers,
      }
    )
    .then((res) => {
      console.log("updated response", res);
      res = res.data;
      if (res.errors) {
        Modal.error({
          title: constant.popupTitle.FAILED,
          content: res.errors[0].message,
        });
        dispatch({
          type: GET_ERRORS,
          payload: res.errors[0].message,
        });
      } else {
        dispatch({
          type: UPDATE_MENU_ITEM,
          payload: res.data.updateMenuItem,
        });
        history.push("/menu-items");
      }
    })
    .catch((error) => {
      console.log("error", error.message);
    });
};

export const createMenuItemByExcelFile =
  (restaurant, history) => async (dispatch) => {
    axios
      .post(
        baseUrl,
        {
          query: restaurant,
        },
        {
          headers: headers,
        }
      )
      .then((res) => {
        res = res.data;
        if (res.errors) {
          Modal.error({
            title: constant.popupTitle.FAILED,
            content: res.errors[0].message,
          });
          dispatch({
            type: GET_ERRORS,
            payload: res.errors[0].message,
          });
        } else {
          console.log("data in action", res);
          dispatch({
            type: CREATE_MENUITEM_BY_EXCEL,
            payload: res.data.createMenuItemByExcelFile,
          });
          history.push("/menu-items");
        }
      })
      .catch((error) => {
        console.log("error", error);
      });
  };

//getmenuItem
export const getRestaurants = (query, loadingFalse) => async (dispatch) => {
  axios
    .post(
      baseUrl,
      {
        query: query,
      },
      {
        headers: headers,
      }
    )
    .then((res) => {
      if (loadingFalse) {
        loadingFalse();
      }
      res = res.data;
      if (res.errors) {
        dispatch({
          type: GET_ERRORS,
          payload: res.errors[0].message,
        });
      } else {
        console.log("inside else", res);
        dispatch({
          type: GET_RESTAURANTS,
          payload: res.data.getRestaurantList,
        });
      }
    })
    .catch((error) => {
      console.log("error", error);
    });
};

export const setRestaurantDetails =
  (restaurantDetails, history) => async (dispatch) => {
    console.log("inside actions");
    dispatch({
      type: RESTAURANT_DETAILS,
      payload: restaurantDetails,
    });
  };

export const getRestaurantByRestId = (query, history) => async (dispatch) => {
  axios
    .post(
      baseUrl,
      {
        query: query,
      },
      {
        headers: headers,
      }
    )
    .then((res) => {
      console.log("-----------list of restaurants----------", res);
      res = res.data;
      if (res.errors) {
        dispatch({
          type: GET_ERRORS,
          payload: res.errors[0].message,
        });
      } else {
        console.log("inside else", res);
        dispatch({
          type: GET_RESTAURANT_BY_ID,
          payload: res.data.getRestaurantById,
        });
      }
    })
    .catch((error) => {
      console.log("error", error);
    });
};

//getrestaurantbyfilter
export const FilterRestaurantsByCategory =
  (query, history) => async (dispatch) => {
    axios
      .post(
        baseUrl,
        {
          query: query,
        },
        {
          headers: headers,
        }
      )
      .then((res) => {
        console.log("-----------list of restaurants----------", res);
        res = res.data;
        if (res.errors) {
          dispatch({
            type: GET_ERRORS,
            payload: res.errors[0].message,
          });
        } else {
          console.log("inside else", res);
          dispatch({
            type: FILTER_RESTAURANT_BY_CATEGORY,
            payload: res.data.filterQuerryOnRestaurant,
          });
        }
      })
      .catch((error) => {
        console.log("error", error);
      });
  };

//update restaurant rating
export const updateRestaurantRating = (query) => async (dispatch) => {
  console.log("query", query);
  axios
    .post(
      baseUrl,
      {
        query: query,
      },
      {
        headers: headers,
      }
    )
    .then((res) => {
      console.log("updated response", res);
      res = res.data;
      if (res.errors) {
        Modal.error({
          title: constant.popupTitle.FAILED,
          content: res.errors[0].message,
        });
        dispatch({
          type: GET_ERRORS,
          payload: res.errors[0].message,
        });
      } else {
        dispatch({
          type: UPDATE_RESTAURANT_RATING,
          payload: res.data.updateRestaurantRating,
        });
      }
    })
    .catch((error) => {
      console.log("error", error.message);
    });
};
