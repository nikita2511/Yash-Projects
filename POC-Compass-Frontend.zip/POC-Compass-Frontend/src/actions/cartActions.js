import axios from "axios";
import { Modal } from "antd";
import { awsConfig } from "../config/config";
import constant from "../util/constant";
import {
  GET_ERRORS,
  GET_CART_ITEMS,
  ADD_ITEM_TO_CART,
  DELETE_CART_ITEM,
  UPDATE_CART_ITEM,
} from "./type";
const baseUrl = awsConfig.aws_graphql_endpoint;
const headers = {
  "x-api-key": awsConfig.x_api_key,
  "Content-Type": awsConfig.Content_Type,
};

//getmenuItem
export const getCartItems = (query, loadingFalse) => async (dispatch) => {
  axios
    .post(
      baseUrl,
      {
        query: query,
      },
      {
        headers: headers,
        Pragma: "no-cache",
        "Cache-Control": "no-cache",
      }
    )
    .then((res) => {
      console.log("-----------cartItems-----------", res);
      res = res.data;
      if (res.errors) {
        dispatch({
          type: GET_ERRORS,
          payload: res.errors[0].message,
        });
      } else {
        dispatch({
          type: GET_CART_ITEMS,
          payload: res.data.getCartlist,
        });
      }
    })
    .catch((error) => {
      console.log("error", error);
    });
};

//additemto cart
export const addItemToCart = (query, loadingFalse) => async (dispatch) => {
  axios
    .post(
      baseUrl,
      {
        query,
      },
      {
        headers: headers,
      }
    )
    .then((res) => {
      loadingFalse();
      res = res.data;
      if (res.errors) {
        Modal.error({
          title: constant.popupTitle.FAILED,
          content: res.errors[0].message,
        });
        dispatch({
          type: GET_ERRORS,
          payload: res.errors[0].message,
        });
      } else {
        dispatch({
          type: ADD_ITEM_TO_CART,
          payload: res.data.addItemToCart,
        });
        console.log("res", res);
      }
    })
    .catch((error) => {
      console.log("error", error);
    });
};

//delete Menu Item
export const deleteCartItem =
  (query, cartItemId, loadingFalse) => async (dispatch) => {
    axios
      .post(
        baseUrl,
        {
          query: query,
        },
        {
          headers: headers,
        }
      )
      .then((res) => {
        if (loadingFalse) {
          loadingFalse();
        }
        res = res.data;
        if (res.errors) {
          dispatch({
            type: GET_ERRORS,
            payload: res.errors[0].message,
          });
        } else {
          dispatch({
            type: DELETE_CART_ITEM,
            payload: cartItemId,
          });
        }
      })
      .catch((error) => {
        console.log("error", error);
      });
  };

//additemto cart
export const updateCartItem = (query, loadingFalse) => async (dispatch) => {
  axios
    .post(
      baseUrl,
      {
        query,
      },
      {
        headers: headers,
      }
    )
    .then((res) => {
      if (loadingFalse) {
        loadingFalse();
      }
      res = res.data;
      if (res.errors) {
        Modal.error({
          title: constant.popupTitle.FAILED,
          content: res.errors[0].message,
        });
        dispatch({
          type: GET_ERRORS,
          payload: res.errors[0].message,
        });
      } else {
        dispatch({
          type: UPDATE_CART_ITEM,
          payload: res.data.updateCartItem,
        });
        console.log("res", res);
      }
    })
    .catch((error) => {
      console.log("error", error);
    });
};
