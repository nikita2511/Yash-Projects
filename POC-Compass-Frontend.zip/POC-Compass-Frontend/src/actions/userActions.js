import { USER_REGISTRATION, GET_ERRORS, USER_LOGIN } from "./type";
import axios from "axios";
import { Modal } from "antd";
import { awsConfig } from "../config/config";
import constant from "../util/constant";
const baseUrl = awsConfig.aws_graphql_endpoint;
const headers = {
  "x-api-key": awsConfig.x_api_key,
  "Content-Type": awsConfig.Content_Type,
};

/**
 * @author Nikita Jaiswal
 *
 */
export const register = (user, history) => async (dispatch) => {
  axios
    .post(
      baseUrl,
      {
        query: user,
      },
      {
        headers: headers,
      }
    )
    .then((res) => {
      res = res.data;
      dispatch({
        type: USER_REGISTRATION,
        payload: res,
      });
      if (res.errors) {
        Modal.error({
          title: constant.popupTitle.FAILED,
          content: res.errors[0].message,
        });
        dispatch({
          type: GET_ERRORS,
          payload: res.errors[0].message,
        });
      } else {
        history.push("/");
      }
    })
    .catch((error) => {
      console.log("error", error);
    });
};

export const login = (query, history, loadingFalse) => async (dispatch) => {
  var res = await axios.post(
    baseUrl,
    {
      query: query,
    },
    {
      headers: headers,
    }
  );
  res = res.data;

  if (res.errors) {
    Modal.error({
      title: constant.popupTitle.FAILED,
      content: res.errors[0].message,
    });
    loadingFalse();
    dispatch({
      type: GET_ERRORS,
      payload: res.errors[0].message,
    });
  } else {
    console.log("action in login", res.data.userLogin);
    localStorage.setItem("token", res.data.userLogin.jwtToken);
    loadingFalse();
    history.push("/");
    dispatch({
      type: USER_LOGIN,
      payload: res.data.userLogin,
    });
  }
};
