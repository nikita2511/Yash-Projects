import axios from "axios";
import { Modal, notification, Result, Button } from "antd";
import { awsConfig } from "../config/config";
import constant from "../util/constant";
import Pusher from "pusher-js";
import { pusherConfig } from "../config/config";
import {
  GET_ALL_RESTAURANT_ORDERS,
  GET_ERRORS,
  CREATE_ORDER,
  GET_ORDER_BY_ID,
  GET_ORDER,
  GET_ALL_USER_ORDERS,
  UPDATE_ORDER_STATUS,
} from "./type";
const baseUrl = awsConfig.aws_graphql_endpoint;
const headers = {
  "x-api-key": awsConfig.x_api_key,
  "Content-Type": awsConfig.Content_Type,
};

//getAllOrders
export const getAllRestaurantOrders =
  (query, restaurantId, loadingFalse) => async (dispatch) => {
    var pusher = new Pusher(pusherConfig.API_KEY, {
      cluster: pusherConfig.CLUSTER,
    });
    const channelName = restaurantId.replace("#", "-");
    var channel = pusher.subscribe(channelName);
    channel.bind(constant.pusherChannelName.NEW_ORDER_CREATED, function (data) {
      notification.success({
        message: "New Order",
        description: "Hi, A new order is placed.",
      });
      dispatch({
        type: GET_ORDER,
        payload: data,
      });
    });
    axios
      .post(
        baseUrl,
        {
          query: query,
        },
        {
          headers: headers,
        }
      )
      .then((res) => {
        res = res.data;
        if (res.errors) {
          dispatch({
            type: GET_ERRORS,
            payload: res.errors[0].message,
          });
        } else {
          loadingFalse();
          dispatch({
            type: GET_ALL_RESTAURANT_ORDERS,
            payload: res.data.getOrderListByRestaurantId,
          });
        }
      })
      .catch((error) => {
        console.log("error", error);
      });
  };

//additemto cart
export const createOrder =
  (query, history, loadingFalse) => async (dispatch) => {
    axios
      .post(
        baseUrl,
        {
          query,
        },
        {
          headers: headers,
        }
      )
      .then((res) => {
        loadingFalse();
        res = res.data;
        if (res.errors) {
          Modal.error({
            title: constant.popupTitle.FAILED,
            content: res.errors[0].message,
          });
          dispatch({
            type: GET_ERRORS,
            payload: res.errors[0].message,
          });
        } else {
          Modal.success({
            title: "Order Placed",
            width: "85vw",
            content: (
              <Result
                status="success"
                title="Successfully Placed Order"
                subTitle={`Order ID: ${res.data.createOrder.orderId}, Please wait for 1-5 minutes for accepting your order`}
              />
            ),
          });

          dispatch({
            type: CREATE_ORDER,
            payload: res.data.createOrder,
          });
          history.push("/order-track/" + res.data.createOrder.orderId);
        }
      })
      .catch((error) => {
        console.log("error", error);
      });
  };

export const getOrderByOrderId = (query, history) => async (dispatch) => {
  axios
    .post(
      baseUrl,
      {
        query,
      },
      {
        headers: headers,
      }
    )
    .then((res) => {
      res = res.data;
      console.log("inside action", res);
      if (res.errors) {
        Modal.error({
          title: constant.popupTitle.FAILED,
          content: res.errors[0].message,
        });
        dispatch({
          type: GET_ERRORS,
          payload: res.errors[0].message,
        });
      } else {
        dispatch({
          type: GET_ORDER_BY_ID,
          payload: res.data.listOrderById,
        });
      }
    })
    .catch((error) => {
      console.log("error", error);
    });
};

//getordersBy userid
export const getOrdersByUserId = (query, loadingFalse) => async (dispatch) => {
  axios
    .post(
      baseUrl,
      {
        query,
      },
      {
        headers: headers,
      }
    )
    .then((res) => {
      loadingFalse();
      res = res.data;
      console.log("inside action", res);
      if (res.errors) {
        Modal.error({
          title: constant.popupTitle.FAILED,
          content: res.errors[0].message,
        });
        dispatch({
          type: GET_ERRORS,
          payload: res.errors[0].message,
        });
      } else {
        dispatch({
          type: GET_ALL_USER_ORDERS,
          payload: res.data.getOrderListUserId,
        });
      }
    })
    .catch((error) => {
      console.log("error", error);
    });
};

export const updateOrderStatus = (query, loadingFalse) => async (dispatch) => {
  axios
    .post(
      baseUrl,
      {
        query,
      },
      {
        headers: headers,
      }
    )
    .then((res) => {
      loadingFalse();
      res = res.data;
      if (res.errors) {
        Modal.error({
          title: constant.popupTitle.FAILED,
          content: res.errors[0].message,
        });
        dispatch({
          type: GET_ERRORS,
          payload: res.errors[0].message,
        });
      } else {
        dispatch({
          type: UPDATE_ORDER_STATUS,
          payload: res.data.updateOrder,
        });
      }
    })
    .catch((error) => {
      console.log("error", error);
    });
};
export const updateOrderStatusByPusher = (data) => async (dispatch) => {
  console.log("-----------data in action--------", data);
  dispatch({
    type: CREATE_ORDER,
    payload: data,
  });
};
