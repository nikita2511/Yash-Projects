export default {
    "ApiUrl": "https://wep4wdh5azadtfamrothuuvog4.appsync-api.us-east-1.amazonaws.com/graphql",
    "Region": "us-east-1",
    "AuthMode": "API_KEY",
    "ApiKey": "AKIAXVWFSAMFLW6WMDW7",
    "ClientDatabasePrefix": "fd_appsync_api-dev_API_KEY"
}