import "./App.css";
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import { Provider } from "react-redux";
import store from "./store";
import history from "./history";
import Registration from "./components/authentication/Registration";
import Login from "./components/authentication/Login";
import Dashboard from "./components/layout/Dashboard";
import PageNotFound from "./components/UtilComponents/PageNotFound";
import ViewRestaurant from "./components/restaurant/ViewRestaurant";
import Checkout from "./components/user/Checkout";
import Profile from "./components/user/Profile";

function App() {
  return (
    <Provider store={store}>
      <Router history={history}>
        <Switch>
          <Route exact path="/" component={Dashboard} />
          <Route exact path="/registration" component={Registration} />
          <Route exact path="/login" component={Login} />
          <Route exact path="/restaurant" component={Dashboard} />
          <Route exact path="/menu-items" component={Dashboard} />
          <Route exact path="/menu-items/add-menu-item" component={Dashboard} />
          <Route
            exact
            path="/menu-items/update-menu-item"
            component={Dashboard}
          />

          <Route exact path="/orders" component={Dashboard} />
          <Route exact path="/profile" component={Dashboard} />
          <Route exact path="/settings" component={Dashboard} />
          <Route exact path="/checkout" component={Dashboard} />
          <Route exact path="/my-account" component={Dashboard} />
          <Route exact path="/my-account/my-orders" component={Dashboard} />
          <Route exact path="/my-account/addresses" component={Dashboard} />
          <Route exact path="/my-account/payments" component={Dashboard} />
          <Route exact path="/my-account/settings" component={Dashboard} />
          <Route exact path="/order-track/:orderId" component={Dashboard} />
          <Route exact path="/get-restaurant" component={Dashboard} />

          {/* handling invalid routes */}
          <Route component={PageNotFound} />
        </Switch>
      </Router>
    </Provider>
  );
}

export default App;
