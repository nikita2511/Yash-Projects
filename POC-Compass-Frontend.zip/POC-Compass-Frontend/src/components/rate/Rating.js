import React, { Component } from "react";
import { Card, Rate, Row, Image } from "antd";
import { connect } from "react-redux";
import { updateRestaurantRating } from "../../actions/restaurantAction";
import thanksImage from "./../../assets/images/thanks.png";

class Rating extends Component {
  constructor(props) {
    super(props);
    this.state = {};
    this.onChange = this.onChange.bind(this);
  }
  onChange(event) {
    console.log(event);
    let query = `mutation MyMutation {
      updateRestaurantRating(input: {restaurantId: "${this.props.restId.id}", userRating: ${event}}) {
        address {
          city
          lat
          lng
          location
          pinCode
          state
        }
        category
        id
        image
        rating {
          currentRating
          sum
          totalNumberOfUser
        }
        restaurantName
        sortKey
        userId
      }
    }
  `;

    this.props.updateRestaurantRating(query);
  }
  render() {
    console.log(this.props.restId.id);
    console.log(Object.keys(this.props.updatedRestaurantRating).length);
    return (
      <div className="row" id="rating-section" style={{ width: 350 }}>
        <Card
          bordered={true}
          style={{ width: 300, marginTop: "30% " }}
          className="align-items-center mx-4 mb-4"
        >
          {Object.keys(this.props.updatedRestaurantRating).length ? (
            <Image src={thanksImage} style={{ width: 250 }} />
          ) : (
            <div>
              <Row>
                <span className="h6">Give your valuable feedback</span>
              </Row>
              <small className="order-track-text">
                How likely are you to recommend this app to your friends and
                collegues
              </small>
              <div className="row mx-4">
                <Rate allowHalf defaultValue={2.5} onChange={this.onChange} />
              </div>
            </div>
          )}
        </Card>
      </div>
    );
  }
}

const mapStateToProps = (state) => (
  console.log("---------state------------", state),
  {
    errors: state.errors,
    updatedRestaurantRating: state.restaurant.updatedRestaurantRating,
  }
);
export default connect(mapStateToProps, {
  updateRestaurantRating,
})(Rating);
