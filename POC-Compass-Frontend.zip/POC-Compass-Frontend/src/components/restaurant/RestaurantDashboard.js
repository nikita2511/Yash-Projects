import React, { Component } from "react";
import { Link } from "react-router-dom";
import { Layout, Menu } from "antd";
import { HomeFilled, SettingFilled } from "@ant-design/icons";
import { FaHotel } from "react-icons/fa";
import { BiRestaurant, BiBorderAll, BiUser } from "react-icons/bi";
import Footer from "../layout/Footer";
import RestaurantHeader from "../layout/RestaurantHeader";
import MenuItems from "../menu-item/MenuItems";
import Orders from "../order/Orders";
import Profile from "./Profile";
import Home from "./Home";
import Restaurant from "./Restaurant";
import CreateMenuItem from "../menu-item/CreateMenuItem";
import UpdateMenuItem from "./../menu-item/UpdateMenuItem";

const { Content, Sider } = Layout;
class RestaurantDashboard extends Component {
  constructor(props) {
    super(props);
    this.state = {
      collapsed: false,
    };
  }

  onCollapse = (collapsed) => {
    this.setState({ collapsed });
  };

  renderRoutes(pathname) {
    switch (pathname) {
      case "/restaurant":
        return <Restaurant props={this.props.props} />;
      case "/menu-items":
        return <MenuItems props={this.props.props} />;
      case "/menu-items/add-menu-item":
        return <CreateMenuItem props={this.props.props} />;
      case "/orders":
        return <Orders props={this.props.props} />;
      case "/profile":
        return <Profile props={this.props.props} />;
      case "/settings":
        return <div>settings</div>;
      case "/menu-items/update-menu-item":
        return <UpdateMenuItem props={this.props.props} />;
      default:
        return <Home />;
    }
  }

  defaultSelectedMenu(pathname) {
    var value = "";
    switch (pathname) {
      case "/restaurant":
        value = "2";
        break;
      case "/menu-items":
        value = "3";
        break;
      case "/menu-items/add-menu-item":
        value = "3";
        break;
      case "/menu-items/update-menu-item":
        value = "3";
        break;
      case "/orders":
        value = "4";
        break;
      case "/profile":
        value = "5";
        break;
      case "/settings":
        value = "6";
        break;
      default:
        value = "1";
        break;
    }
    return value;
  }

  render() {
    const { collapsed } = this.state;
    const { pathname } = this.props.props.location;
    return (
      <div>
        <RestaurantHeader props={this.props.props} />
        <Layout style={{ minHeight: "100vh" }}>
          <Sider
            collapsible
            collapsed={collapsed}
            onCollapse={this.onCollapse}
            theme="light"
            breakpoint="xs"
          >
            <div className="logo" />
            <Menu
              theme="light"
              defaultSelectedKeys={this.defaultSelectedMenu(pathname)}
              mode="inline"
              id="side-menu"
            >
              <Menu.Item key="1" icon={<HomeFilled />}>
                <Link to="/" className="link-deocration">
                  Home
                </Link>
              </Menu.Item>
              <Menu.Item key="2" icon={<FaHotel />}>
                <Link to="/restaurant" className="link-deocration">
                  Restaurant
                </Link>
              </Menu.Item>
              <Menu.Item key="3" icon={<BiRestaurant />}>
                <Link to="/menu-items" className="link-deocration">
                  Menu Items
                </Link>
              </Menu.Item>
              <Menu.Item key="4" icon={<BiBorderAll />}>
                <Link to="/orders" className="link-deocration">
                  Orders
                </Link>
              </Menu.Item>
              <Menu.Item key="5" icon={<BiUser />}>
                <Link to="/profile" className="link-deocration">
                  Profile
                </Link>
              </Menu.Item>
              <Menu.Item key="6" icon={<SettingFilled />}>
                <Link to="/settings" className="link-deocration">
                  Setting
                </Link>
              </Menu.Item>
            </Menu>
          </Sider>
          <Layout className="site-layout">
            <Content style={{ margin: "0 16px" }}>
              {/* <div></div> */}
              <div style={{ margin: "16px 0" }} />
              <div
                className="site-layout-background"
                style={{ padding: 24, minHeight: 360 }}
              >
                {this.renderRoutes(pathname)}
              </div>
            </Content>
            <Footer />
          </Layout>
        </Layout>
      </div>
    );
  }
}
export default RestaurantDashboard;
