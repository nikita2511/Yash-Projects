import React, { Component } from "react";
import { Form, Input, Select, Button, Upload, Modal } from "antd";
import ImgCrop from "antd-img-crop";
import { connect } from "react-redux";
import { createRestaurant } from "../../actions/restaurantAction";
import PropTypes from "prop-types";
import {
  FaLocationArrow,
  FaCity,
  FaMapPin,
  FaHotel,
  FaSearchLocation,
} from "react-icons/fa";
import Geocode from "react-geocode";
import { State } from "country-state-city";
import { UploadOutlined } from "@ant-design/icons";
import util from "../../util/util";
import { decodeToken } from "react-jwt";
import GoogleMapReact from "google-map-react";
import Marker from "../layout/Marker";
const { Option } = Select;
class CreateRestaurant extends Component {
  static defaultProps = {
    center: {
      lat: 28.1473,
      lng: 77.326,
    },
    zoom: 15,
  };
  constructor(props) {
    super(props);
    this.state = {
      restaurantName: "",
      location: "",
      city: "",
      state: "",
      pinCode: "",
      category: "",
      loading: false,
      image: "",
      visible: false,
      lat: "",
      lng: "",
      center: {},
    };
    this.onChange = this.onChange.bind(this);
    this.onSubmit = this.onSubmit.bind(this);
    this.oncategoryTypeChange = this.oncategoryTypeChange.bind(this);
    this.onStateChange = this.onStateChange.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.onMapClick = this.onMapClick.bind(this);
    this.onMapOKclick = this.onMapOKclick.bind(this);
    this.openModal = this.openModal.bind(this);
  }
  onMapOKclick(event) {
    this.setState({ visible: false });
    console.log("on map ok click", this.state.lat, this.state.lng);
    Geocode.setApiKey("AIzaSyA6ywgoC5KvkIAvAZspMfh9R7_cWnSNqQ8");
    Geocode.setLocationType("ROOFTOP");
    Geocode.fromLatLng(this.state.lat, this.state.lng).then(
      (response) => {
        const address = response.results[0].formatted_address;
        console.log("address", address);
        var commaAddeess = address.split(",");
        var lcoality = commaAddeess[commaAddeess.length - 4];
        var city = commaAddeess[commaAddeess.length - 3];
        var StatePin = commaAddeess[commaAddeess.length - 2].trim().split(" ");
        const pinCode = StatePin.pop();
        const state = StatePin.toString();
        console.log("commaAddress", lcoality, city, state, pinCode);
        this.setState({
          city,
          state,
          pinCode,
          location: lcoality,
        });
      },
      (error) => {
        console.error(error);
      }
    );
  }

  onMapClick(event) {
    this.setState({
      lat: event.lat,
      lng: event.lng,
    });
  }
  async openModal(event) {
    this.setState({ visible: true });
    let promise = new Promise(function (resolve, reject) {
      navigator.geolocation.getCurrentPosition(resolve, reject);
    });

    let pos = await promise;
    const center = {
      lat: pos.coords.latitude,
      lng: pos.coords.longitude,
    };
    this.setState({
      center,
      lat: pos.coords.latitude,
      lng: pos.coords.longitude,
    });
    console.log("k", center);
  }
  closeModal = () => this.setState({ visible: false });
  onChange(event) {
    this.setState({ [event.target.name]: event.target.value });
  }

  oncategoryTypeChange = (event) => {
    this.setState({ category: event });
  };

  onStateChange = (event) => {
    this.setState({ state: event });
  };

  onSubmit(event) {
    const user = decodeToken(localStorage.getItem("token"));
    const query = `mutation MyMutation {
                        createRestaurant(input: {address: {city: "${this.state.city}", location: "${this.state.location}", pinCode: "${this.state.pinCode}", state: "${this.state.state}", lat: "${this.state.lat}", lng: "${this.state.lng}"},  restaurantName: "${this.state.restaurantName}", 
                         userId: "${user.userId}", image: "${this.state.image}", category: "${this.state.category}"}) {
                            category
                            id
                            restaurantName
                            sortKey
                            userId
                            image
                            address {
                              city
                              location
                              pinCode
                              state
                              lat
                              lng
                            }
                        }
                    }`;
    console.log(query);
    this.props.createRestaurant(query, this.props.props.history);
  }

  dummyRequest({ file, onSuccess }) {
    setTimeout(() => {
      onSuccess("ok");
    }, 0);
  }

  handleChange(info) {
    if (info.file.status === "uploading") {
      return;
    }
    if (info.file.status === "done") {
      util.getBase64(info.file.originFileObj, (image) => {
        this.setState({
          image,
        });
      });
    }
  }

  render() {
    const { visible } = this.state;
    const indState = State.getStatesOfCountry("IN");
    return (
      <div>
        <section className="h-50 bg-light">
          <div className="row d-flex justify-content-center align-items-center">
            <h5 className="form-title text-center">CreateRestaurant</h5>
            <div className="col">
              <div class="card card-Registration my-4">
                <div>
                  <div className="row">
                    <div className="col"></div>
                    <div className="col-6">
                      <div class="card-body p-md-5 text-black">
                        {/* start */}
                        <div className="createRestaurant-content">
                          <div className="createRestaurant-form-register">
                            <Form
                              name="register"
                              scrollToFirstError
                              onFinish={this.onSubmit}
                            >
                              <Form.Item
                                name="Restaurant Name"
                                className="createRestaurant-register-input"
                                // label="Restaurant Name"
                              >
                                <Input
                                  prefix={
                                    <FaHotel className="site-form-item-icon" />
                                    // < className="fas fa-hotel" />
                                  }
                                  type="string"
                                  name="restaurantName"
                                  id="restaurantName"
                                  placeholder="Restaurant Name"
                                  value={this.state.restaurantName}
                                  onChange={this.onChange}
                                />
                              </Form.Item>
                              <Form.Item
                                name="category"
                                // label="Category"
                                showSearch
                                rules={[
                                  {
                                    required: true,
                                    message: "Please select Type!",
                                  },
                                ]}
                              >
                                <Select
                                  placeholder="Select category"
                                  name="category"
                                  id="category"
                                  value={this.state.category}
                                  onChange={this.oncategoryTypeChange}
                                >
                                  <Option value="Veg">Veg</Option>
                                  <Option value="Non Veg">Non-Veg</Option>
                                  <Option value="Both">Both</Option>
                                </Select>
                              </Form.Item>
                              <Form.Item
                                name="Mark Location"
                                className="createRestaurant-register-input"
                              >
                                <Button onClick={this.openModal}>
                                  Mark Locaiton
                                </Button>
                              </Form.Item>

                              <Modal
                                visible={visible}
                                title="Mark Your Current Location"
                                // style={{ top: 20 }}
                                onOk={this.onMapOKclick}
                                onCancel={this.closeModal}
                                okText="Ok"
                                width={1000}
                              >
                                {console.log(
                                  "inside modal",
                                  this.state.lat,
                                  this.state.lng
                                )}
                                <div style={{ height: "50vh", width: "100%" }}>
                                  <GoogleMapReact
                                    bootstrapURLKeys={{
                                      key: "AIzaSyA6ywgoC5KvkIAvAZspMfh9R7_cWnSNqQ8",
                                    }}
                                    defaultCenter={this.state.center}
                                    defaultZoom={this.props.zoom}
                                    yesIWantToUseGoogleMapApiInternals
                                    onClick={this.onMapClick}
                                  >
                                    <Marker
                                      // text={this.state.address}
                                      lat={this.state.lat}
                                      lng={this.state.lng}
                                    />
                                  </GoogleMapReact>
                                </div>
                              </Modal>
                              <div class=" row row g-0">
                                <div className=" col col-xl-6">
                                  <div className=" col col-xl-11">
                                    <Form.Item
                                      name="Landmark"
                                      className="createRestaurant-register-input"
                                    >
                                      <div></div>
                                      <Input
                                        prefix={
                                          <FaLocationArrow className="site-form-item-icon" />
                                        }
                                        type="text"
                                        name="location"
                                        id="location"
                                        placeholder="Street Location or Landmark"
                                        value={this.state.location}
                                        onChange={this.onChange}
                                      />
                                    </Form.Item>
                                  </div>
                                </div>
                                <div className=" col col-xl-6">
                                  <Form.Item name="city" label="City">
                                    <div></div>
                                    <Input
                                      prefix={
                                        <FaCity className="site-form-item-icon" />
                                      }
                                      type="text"
                                      name="city"
                                      id="city"
                                      placeholder="City"
                                      value={this.state.city}
                                      // onChange={this.onChange}
                                    />
                                  </Form.Item>
                                </div>
                              </div>
                              <div class=" row row g-0">
                                <div className=" col col-xl-6">
                                  <div className=" col col-xl-11">
                                    <Form.Item
                                      className="createRestaurant-register-input"
                                      name="state"
                                      label="State"
                                    >
                                      <div></div>
                                      <Input
                                        prefix={
                                          <FaSearchLocation className="site-form-item-icon" />
                                        }
                                        disabled={true}
                                        type="text"
                                        name="state"
                                        id="state"
                                        placeholder="State"
                                        // defaultValue={this.state.state}
                                        value={this.state.state}
                                        onChange={this.onChange}
                                      />
                                    </Form.Item>
                                  </div>
                                </div>
                                <div className=" col col-xl-6">
                                  <Form.Item
                                    name="pinCode"
                                    id="pinCode"
                                    label="Pin"
                                  >
                                    <div></div>
                                    <Input
                                      prefix={
                                        <FaMapPin className="site-form-item-icon" />
                                      }
                                      type="text"
                                      name="pinCode"
                                      id="pinCode"
                                      placeholder="Pincode"
                                      value={this.state.pinCode}
                                      onChange={this.onChange}
                                    />
                                  </Form.Item>
                                </div>
                              </div>

                              <Form.Item>
                                <ImgCrop aspect={7 / 7}>
                                  <Upload
                                    name="file"
                                    className="avatar-uploader"
                                    customRequest={this.dummyRequest}
                                    onChange={this.handleChange}
                                    multiple={false}
                                  >
                                    <Button icon={<UploadOutlined />}>
                                      Click to Upload
                                    </Button>
                                  </Upload>
                                </ImgCrop>
                              </Form.Item>
                              <Form.Item>
                                <Button type="primary" htmlType="submit">
                                  CreateRestaurant
                                </Button>
                              </Form.Item>
                            </Form>
                          </div>
                          <div className="createRestaurant-image-register"></div>
                        </div>
                        {/* end */}
                      </div>
                    </div>
                    <div className="col"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  errors: state.errors,
  restaurant: state.restaurant,
});

CreateRestaurant.propTypes = {
  createRestaurant: PropTypes.func.isRequired,
};
const connector = connect(mapStateToProps, {
  createRestaurant,
})(CreateRestaurant);
export default connector;
