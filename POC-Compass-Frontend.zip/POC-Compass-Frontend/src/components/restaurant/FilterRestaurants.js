import React, { Component } from "react";
import { MdFilterList } from "react-icons/md";
import { Navbar, Container } from "react-bootstrap";
import { Form, Input, Checkbox, Spin, Alert, Button, Radio } from "antd";
import { SearchOutlined } from "@ant-design/icons";
import {
  FilterRestaurantsByCategory,
  getRestaurants,
} from "./../../actions/restaurantAction";
import { connect } from "react-redux";

class FilterRestaurants extends Component {
  constructor(props) {
    super(props);
    this.state = {
      showbutton: false,
    };
    this.onchange = this.onchange.bind(this);
    this.allRestaurant = this.allRestaurant.bind(this);
  }

  onchange(event) {
    const query = `query MyQuery {
      filterQuerryOnRestaurant(input: {category: "${event.target.value}"}) {
        address {
          city
          lat
          lng
          pinCode
          state
          location
        }
        category
        id
        image
        rating {
          currentRating
          sum
          totalNumberOfUser
        }
        restaurantName
        sortKey
        userId
      }
    }`;
    // console.log("this is props",this.props.props)
    this.props.FilterRestaurantsByCategory(query);
  }

  allRestaurant(event) {
    const query = `query MyQuery {
    getRestaurantList {
      category
      id
      image
      restaurantName
      sortKey
      userId
      address {
        city
        location
        pinCode
        state
        lat
        lng
      }
    }
  }
  `;
    console.log("parent====", this.props);
    this.props.getRestaurants(query);
  }

  render() {
    return (
      <div>
        <Navbar bg="light" id="restaurants-header" className="container">
          <div className="row mt-2 ">
            <div id="collapseExample">
              <Form>
                <Form.Item name="" label="">
                  <Radio.Group>
                    <Radio.Button
                      name="1"
                      value="Veg"
                      style={{ lineHeight: "32px" }}
                      onChange={(e) => this.onchange(e)}
                    >
                      Veg
                    </Radio.Button>
                    <Radio.Button
                      name="1"
                      value="Non Veg"
                      style={{ lineHeight: "32px" }}
                      onChange={(e) => this.onchange(e)}
                    >
                      Non Veg
                    </Radio.Button>

                    <Radio.Button
                      name="1"
                      value="Both"
                      style={{ lineHeight: "32px" }}
                      onChange={(e) => this.onchange(e)}
                    >
                      Both
                    </Radio.Button>

                    <Radio.Button
                      name="1"
                      value="ALL"
                      style={{ lineHeight: "32px" }}
                      onChange={(e) => this.allRestaurant(e)}
                    >
                      ALL
                    </Radio.Button>
                  </Radio.Group>
                </Form.Item>
              </Form>
            </div>

            {/* <div className="col">
                {" "}
                <span
                  className="filter-icon"
                  href="#collapseExample"
                  role="button"
                  aria-expanded="false"
                  aria-controls="collapseExample"
                >
                  <p>
                    <b>Filters</b>{" "}
                    <span>
                      <MdFilterList style={{ color: "red" }} />
                    </span>
                  </p>
                </span>
              </div> */}
          </div>
        </Navbar>
      </div>
    );
  }
}

const mapStateToProps = (state) => (
  console.log("=======", state),
  {
    errors: state.errors,
    restaurants: state.restaurant.restaurantDetails,
    restaurants: state.restaurant.restaurants,
  }
);
export default connect(mapStateToProps, {
  FilterRestaurantsByCategory,
  getRestaurants,
})(FilterRestaurants);

// export default FilterRestaurants;
