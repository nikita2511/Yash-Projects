import React, { Component } from "react";
import { Navbar, Container } from "react-bootstrap";
import { Row, Col, Form, Input, Empty, Spin } from "antd";
import discount from "./../../assets/images/discount.png";
import {
  SearchOutlined,
  MenuUnfoldOutlined,
  MenuFoldOutlined,
} from "@ant-design/icons";
import { IoLeafSharp } from "react-icons/io5";
import { FcLike } from "react-icons/fc";
import { GiChickenOven, GiOpenedFoodCan } from "react-icons/gi";
import {
  getMenuItems,
  getMenuItemsByCategory,
} from "../../actions/restaurantAction";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import { List, Space, Button, Menu } from "antd";
import vegIcon from "./../../assets/images/veg-icon.png";
import nonVegIcon from "./../../assets/images/non-veg-icon.png";
import { BiRupee } from "react-icons/bi";
import Cart from "../cart/Cart";
import AddItemToCart from "../cart/AddItemToCart";

class ViewRestaurant extends Component {
  constructor(props) {
    super(props);
    this.state = {
      loading: true,
      collapsed: false,
    };
    this.loadingFalse = this.loadingFalse.bind(this);
    this.loadingTrue = this.loadingTrue.bind(this);
    this.IconText = this.IconText.bind(this);
    this.toggleCollapsed = this.toggleCollapsed.bind(this);
    this.onchangecategory = this.onchangecategory.bind(this);
    this.allItems = this.allItems.bind(this);
  }
  loadingFalse() {
    this.setState({
      loading: false,
    });
  }
  loadingTrue() {
    console.log("loading true call");
    this.setState({
      loading: true,
    });
  }
  toggleCollapsed = () => {
    this.setState({
      collapsed: !this.state.collapsed,
    });
  };
  IconText = ({ icon, text }) => (
    <Space style={{ color: "black" }}>
      {React.createElement(icon)}
      {text}
    </Space>
  );
  componentDidMount() {
    console.log(this.props.restaurantDetails);
    const query = `query MyQuery {
      getMenuItemsByRestaurantId(restaurantId: "${this.props.restaurantDetails.id}") {
        actualPrice
        description
        discount
        menuItemId
        menuItemName
        price
        restaurantId
        image
      }
    }`;

    this.props.getMenuItems(query, this.loadingFalse);
  }

  render() {
    const location = this.props.props.location;
    if (!location.hasOwnProperty("aboutProps")) {
      window.location.href = "/";
    }
    const restaurant = this.props.restaurantDetails;
    const menuItems = this.props.menuItems;
    console.log(menuItems);
    return (
      <div>
        <div className="  bg-light restaurant-container">
          <Row className="bg-dark" id="restaurant-header">
            <Col span={6} className="p-5">
              {restaurant.image ? (
                <img
                  alt="example"
                  src={restaurant.image}
                  style={{ width: 200, height: 200 }}
                />
              ) : (
                <Empty
                  description="No Image"
                  image={Empty.PRESENTED_IMAGE_SIMPLE}
                />
              )}
            </Col>
            <Col span={10} className="p-3 mt-5 w-100">
              <Row>
                <h3 className="text-white">{restaurant.restaurantName}</h3>
              </Row>
              <Row>
                <span className="text-secondary ">Chinese,Indian</span>
              </Row>
              <Row>
                <span className="text-secondary ">
                  {" "}
                  {restaurant.address.location} &nbsp;{" "}
                  {restaurant.address.pinCode} &nbsp; {restaurant.address.city}
                  &nbsp;{restaurant.address.state}
                </span>
              </Row>

              <Row className="text-white"></Row>

              <Row className="text-white mt-4">
                <Col>
                  {" "}
                  <Form scrollToFirstError>
                    <Form.Item name="searchInput">
                      <Input
                        className="p-1"
                        type="text"
                        name="searchInput"
                        id="searchInput"
                        placeholder="Search"
                        prefix={
                          <SearchOutlined className="site-form-item-icon" />
                        }
                        style={{
                          border: "none",
                        }}
                      />
                    </Form.Item>
                  </Form>
                </Col>
                &nbsp;
                <Col>
                  <div className=" bg-white text-success p-1">
                    <span>
                      {restaurant.category === "Non-Veg" ? (
                        <GiChickenOven className=" text-danger" />
                      ) : (
                        <IoLeafSharp className=" text-success" />
                      )}
                    </span>
                    <span className="text-dark">
                      {" "}
                      &nbsp;
                      <b>{restaurant.category}</b>
                    </span>
                  </div>{" "}
                </Col>
                &nbsp;
                <Col>
                  <div className=" bg-white text-dark p-1">
                    <FcLike />
                    <span>
                      &nbsp;
                      <b>Favourite</b>
                    </span>
                  </div>{" "}
                </Col>
              </Row>
            </Col>
            <Col span={8} className="text-white p-5 align-items-center">
              <div className="card bg-dark text-white" id="offer-section">
                <Row>
                  {" "}
                  <span>
                    <img
                      alt="example"
                      src={discount}
                      style={{ width: "20px" }}
                    />
                  </span>
                  <span>
                    10% off up to ₹100 on orders above ₹400 + Up to ₹100
                    cashback with Paytm | Use code JUMBO
                  </span>
                </Row>
                <Row>
                  <span>
                    <img
                      alt="example"
                      src={discount}
                      style={{ width: "20px" }}
                    />
                  </span>
                  <span> 20% off up to ₹100 | Use RUPAY100 Above ₹129</span>
                </Row>
              </div>
            </Col>
          </Row>
          <Navbar bg="light">
            <Container></Container>
          </Navbar>
          <div
            class="collapse justify-content-center align-items-center"
            id="collapseExample"
          ></div>
          <hr className="container" style={{ width: "100%", height: ".3px" }} />
        </div>
        <Row class>
          <Col span={6}>
            {" "}
            <div style={{ width: 256 }}>
              <Button
                onClick={this.toggleCollapsed}
                style={{ marginBottom: 16 }}
              >
                {" "}
                <span className="text-danger">Filters</span>
                {React.createElement(
                  this.state.collapsed ? MenuUnfoldOutlined : MenuFoldOutlined
                )}
              </Button>
              <Menu
                defaultSelectedKeys={["1"]}
                defaultOpenKeys={["sub1"]}
                mode="inline"
                theme="light"
                inlineCollapsed={this.state.collapsed}
                id="side-menu"
              >
                <Menu.Item
                  key="1"
                  danger={true}
                  icon={<GiOpenedFoodCan id="food-icon" />}
                  onClick={() => this.allItems()}
                >
                  <span className="side-nav-menu-item">ALL</span>
                </Menu.Item>

                <Menu.Item
                  key="2"
                  danger={true}
                  icon={<GiOpenedFoodCan id="food-icon" />}
                  onClick={() => this.onchangecategory("Dessert")}
                >
                  <span className="side-nav-menu-item">Dessert</span>
                </Menu.Item>
                <Menu.Item
                  key="3"
                  danger={true}
                  icon={<GiOpenedFoodCan id="food-icon" />}
                  onClick={() => this.onchangecategory("MainCourse")}
                >
                  <span className="side-nav-menu-item">Main Course</span>
                </Menu.Item>
                <Menu.Item
                  key="4"
                  danger={true}
                  icon={<GiOpenedFoodCan id="food-icon" />}
                  onClick={() => this.onchangecategory("PizzaandSandwich")}
                >
                  <span className="side-nav-menu-item">Pizza and Sandwich</span>
                </Menu.Item>

                <Menu.Item
                  key="5"
                  danger={true}
                  icon={<GiOpenedFoodCan id="food-icon" />}
                  onClick={() => this.onchangecategory("ChineseFood")}
                >
                  <span className="side-nav-menu-item">Chiness Food</span>
                </Menu.Item>

                <Menu.Item
                  key="6"
                  danger={true}
                  icon={<GiOpenedFoodCan id="food-icon" />}
                  onClick={() => this.onchangecategory("Drinks")}
                >
                  <span className="side-nav-menu-item">Drinks</span>
                </Menu.Item>
              </Menu>
            </div>
          </Col>
          <Col span={12}>
            <div id="menuitems-widget">
              <List
                avatar={
                  <img alt="example" src={vegIcon} style={{ width: "12px" }} />
                }
                itemLayout="vertical"
                size="large"
                pagination={{
                  onChange: (page) => {
                    console.log(page);
                  },
                  pageSize: 6,
                }}
                loading={this.state.loading}
                dataSource={menuItems}
                footer={<div></div>}
                renderItem={(item) => (
                  <List.Item
                    key={item.title}
                    actions={[
                      <span>
                        <img
                          alt="example"
                          src={discount}
                          style={{ width: "15px" }}
                        />
                        <span></span>
                        <span></span>{" "}
                        <span className="text-success">
                          {item.discount}% off | use <b>JUMBO</b>
                        </span>
                      </span>,
                      <this.IconText
                        icon={BiRupee}
                        text={<s>{item.actualPrice}</s>}
                        key="list-vertical-like-o"
                      />,

                      <this.IconText
                        icon={BiRupee}
                        text={item.price}
                        key="list-vertical-like-o"
                      />,
                    ]}
                    extra={
                      <div class="menu-item-image-user-dashboard">
                        <img
                          width={100}
                          src="https://burst.shopifycdn.com/photos/berries-granola.jpg?width=925&exif=1&iptc=1&attachment=berries-granola.jpg"
                          alt="Snow"
                        />
                        <AddItemToCart
                          props={this.props}
                          item={item}
                          loadingTrue={this.loadingTrue}
                          loadingFalse={this.loadingFalse}
                        />
                      </div>
                    }
                  >
                    <List.Item.Meta
                      title={
                        <a href={item.href}>
                          <div>
                            {restaurant.category === "Non-Veg" ? (
                              <img
                                alt="example"
                                src={nonVegIcon}
                                style={{ width: "12px" }}
                              />
                            ) : (
                              <img
                                alt="example"
                                src={vegIcon}
                                style={{ width: "12px" }}
                              />
                            )}
                            &nbsp;
                            {item.menuItemName}
                          </div>
                        </a>
                      }
                      description={item.description}
                    />
                  </List.Item>
                )}
              />
            </div>
          </Col>
          <Col span={6} className=" p-2">
            {this.state.loading ? (
              <div className="row w-100">
                <div className="col-4"></div>
                <div className="col-4 text-center">
                  <Spin />
                </div>
                <div className="col-4"></div>
              </div>
            ) : (
              <Cart />
            )}
          </Col>
        </Row>
      </div>
    );
  }

  onchangecategory = (category) => {
    const query = `query MyQuery {
  getRestaurantDetailsByIndex(input: {restaurantId: "${this.props.restaurantDetails.id}",category: "${category}" } ) {
    actualPrice
    description
    discount
    menuItemId
    menuItemName
    price
    restaurantId
    image
  }
}`;

    console.log(" the query===== ", query);
    this.props.getMenuItemsByCategory(query, this.props.history);
  };

  allItems = () => {
    console.log("------------allitems-------------");
    const query = `query MyQuery {
    getMenuItemsByRestaurantId(restaurantId: "${this.props.restaurantDetails.id}") {
      actualPrice
      description
      discount
      menuItemId
      menuItemName
      price
      restaurantId
      image
    }
  }`;

    this.props.getMenuItems(query);
  };
}

const mapStateToProps = (state) => ({
  errors: state.errors,
  menuItems: state.restaurant.menuItems,
  restaurantDetails: state.restaurant.restaurantDetails,
});

ViewRestaurant.propTypes = {
  getMenuItems: PropTypes.func.isRequired,
  getMenuItemsByCategory: PropTypes.func.isRequired,
};

export default connect(mapStateToProps, {
  getMenuItems,
  getMenuItemsByCategory,
})(ViewRestaurant);
