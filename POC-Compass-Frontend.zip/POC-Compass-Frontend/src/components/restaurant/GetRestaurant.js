import React, { Component } from "react";
import { Table } from "react-bootstrap";
// import { Map, InfoWindow, Marker, GoogleApiWrapper } from 'google-maps-react';
import GoogleMapReact from "google-map-react";
import Marker from "../layout/Marker";
// import Geocode from "react-geocode";
// Geocode.setApiKey("AIzaSyDP6BvjhddneKcav-s0t4f6-Mkx-_3j8Cg");
// import k from 'react-google-maps';

class GetRestaurant extends Component {
  static defaultProps = {
    center: {
      lat: 22.6849627,
      lng: 75.81852,
    },
    zoom: 15,
  };
  constructor(props) {
    super(props);
    // this.state = {
    //   lat: "28.1473",
    //   lng: "77.3260",
    // };
    this.mapClicked = this.mapClicked.bind(this);
  }
  mapClicked(mapProps, map, clickEvent) {
    console.log("inside click", clickEvent);
    this.setState({
      lat: clickEvent.latLng.lat(),
      lng: clickEvent.latLng.lng(),
    });
  }
  render() {
    const { restaurant } = this.props;
    const { address } = restaurant;
    const center = {
      lat: parseFloat(address.lat),
      lng: parseFloat(address.lng),
    };
    return (
      <section className="h-50 bg-light">
        <div className="row d-flex justify-content-center align-items-center">
          <h5 className="form-title text-center mt-4">
            <b>Restaurant Details</b>
          </h5>
          <div className="col">
            <div class="my-5">
              <Table bordered hover variant="light">
                <tbody>
                  <tr>
                    <td>Restaurant Id</td>
                    <td>{restaurant.id}</td>
                  </tr>
                  <tr>
                    <td>Restaurant Name</td>
                    <td>{restaurant.restaurantName}</td>
                  </tr>
                  <tr>
                    <td>Category</td>
                    <td>{restaurant.category}</td>
                  </tr>
                  <tr>
                    <td>Address</td>
                    <td>
                      {" "}
                      {address.location}, {address.city}, {address.state},{" "}
                      {address.pinCode}
                    </td>
                  </tr>
                </tbody>
              </Table>
            </div>
            {/* <div class="my-5"> */}
            <div style={{ height: "50vh", width: "100%" }}>
              {console.log(
                "----address-----",
                parseFloat(this.props.center.lat)
              )}
              <GoogleMapReact
                bootstrapURLKeys={{
                  key: "AIzaSyA5l6bdIVdTuCJK1RgLu6u0FjHMHbu-VbM",
                }}
                defaultCenter={center}
                defaultZoom={this.props.zoom}
                yesIWantToUseGoogleMapApiInternals
                // onClick={this.onMapClick}
              >
                {console.log("----address-----", address)}
                <Marker
                  // text={this.state.address}
                  lat={address.lat}
                  lng={address.lng}
                />
              </GoogleMapReact>
              {/* </div> */}
            </div>
          </div>
        </div>
      </section>
    );
  }
}
export default GetRestaurant;
