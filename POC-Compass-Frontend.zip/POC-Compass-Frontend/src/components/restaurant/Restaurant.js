import React, { Component } from "react";
import { connect } from "react-redux";
import { getRestaurantByUserId } from "../../actions/restaurantAction";
import CreateRestaurant from "./CreateRestaurant";
import GetRestaurant from "./GetRestaurant";
import { decodeToken } from "react-jwt";
import { Spin } from "antd";

class Restaurant extends Component {
  constructor(props) {
    super(props);
    const user = decodeToken(localStorage.getItem("token"));

    this.state = {
      user,
      loading: true,
    };
    this.loadingFalse = this.loadingFalse.bind(this);
  }
  loadingFalse() {
    this.setState({
      loading: false,
    });
  }
  componentDidMount(props) {
    const query = `query MyQuery {
            getRestaurantByUserId(userId: "${this.state.user.userId}") {
              category
              id
              restaurantName
              sortKey
              userId
              address {
                city
                location
                pinCode
                state
                lat
                lng
              }
            }
          }
          `;
    if (!this.props.restaurant.restaurant) {
      this.props.getRestaurantByUserId(
        query,
        this.props.props.history,
        this.loadingFalse
      );
    }
    if (this.props.restaurant.restaurant) {
      this.setState({
        loading: false,
      });
    }
  }
  render() {
    const { restaurant } = this.props.restaurant;
    if (this.state.loading) {
      return <Spin size="large" className="spin" />;
    } else {
      if (restaurant) {
        return (
          <GetRestaurant props={this.props.props} restaurant={restaurant} />
        );
      } else {
        return <CreateRestaurant props={this.props.props} />;
      }
    }
  }
}
const mapStateToProps = (state) => ({
  errors: state.errors,
  restaurant: state.restaurant,
});
export default connect(mapStateToProps, {
  getRestaurantByUserId,
})(Restaurant);
