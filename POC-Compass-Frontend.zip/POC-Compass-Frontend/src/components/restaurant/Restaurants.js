import React, { Component } from "react";
import { getRestaurants } from "../../actions/restaurantAction";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import { Row, Empty } from "antd";
// import { Link } from "react-router-dom";
import RestaurantDetail from "./../restaurant/RestaurantDetail";
import { MdFilterList } from "react-icons/md";
import { Navbar, Container } from "react-bootstrap";
import { Form, Input, Checkbox, Spin } from "antd";
import { SearchOutlined } from "@ant-design/icons";

class Restaurants extends Component {
  componentDidMount() {
    console.log("inside CDM");
    const query = `query MyQuery {
      getRestaurantList {
        category
        id
        image
        restaurantName
        sortKey
        userId
        address {
          city
          location
          pinCode
          state
        }
      }
    }
    `;
    this.props.getRestaurants(query, this.props.history);
  }

  render() {
    const restaurants = this.props.restaurants;
    console.log(restaurants);
    return (
      <div className="" id="restaurant-container">
        <div className="d-flex"></div>
        <Navbar bg="light" id="restaurants-header">
          <Container>
            <Navbar.Brand href="#home">
              {/* <b>7 Restaurants</b> */}
            </Navbar.Brand>
            <div className="row mt-3 col-lg-4">
              <div className="col">
                <Form scrollToFirstError>
                  <Form.Item name="searchInput">
                    <Input
                      type="text"
                      name="searchInput"
                      id="searchInput"
                      placeholder="Search"
                      size="large"
                      // defaultValue={menuItem.menuItemName}
                      prefix={
                        <SearchOutlined className="site-form-item-icon" />
                      }
                      style={{
                        border: "none",
                      }}
                    />
                  </Form.Item>
                </Form>
              </div>
              <div className="col">
                {" "}
                <span
                  className="filter-icon"
                  data-bs-toggle="collapse"
                  href="#collapseExample"
                  role="button"
                  aria-expanded="false"
                  aria-controls="collapseExample"
                >
                  <p>
                    <b>Filters</b>{" "}
                    <span>
                      <MdFilterList style={{ color: "red" }} />
                    </span>
                  </p>
                </span>
              </div>
            </div>
          </Container>
        </Navbar>
        <div
          className="collapse justify-content-center align-items-center"
          id="collapseExample"
        >
          <div className="container" id="restaurant-second-header">
            <Form>
              <Form.Item name="checkbox-group" label="Checkbox.Group">
                <Checkbox.Group>
                  <Checkbox value="Non Veg" style={{ lineHeight: "32px" }}>
                    Non Veg
                  </Checkbox>
                  <Checkbox value="Non Veg" style={{ lineHeight: "32px" }}>
                    Non Veg
                  </Checkbox>
                  <Checkbox value="Non Veg" style={{ lineHeight: "32px" }}>
                    Non Veg
                  </Checkbox>
                  <Checkbox value="Non Veg" style={{ lineHeight: "32px" }}>
                    Non Veg
                  </Checkbox>
                  <Checkbox value="Non Veg" style={{ lineHeight: "32px" }}>
                    Non Veg
                  </Checkbox>
                </Checkbox.Group>
              </Form.Item>
            </Form>
          </div>
        </div>
        <hr className="container" style={{ width: "100%", height: ".3px" }} />

        <div className="container d-flex align-items-start ">
          <Row gutter={{ xs: 8, sm: 16, md: 30, lg: 32 }}>
            {!restaurants.length ? (
              <div className="">
                <Empty description={<span>No Items</span>} />
              </div>
            ) : (
              restaurants.map((element) => {
                return (
                  <RestaurantDetail
                    restaurant={element}
                    props={this.props.props}
                    key={element.id}
                  />
                );
              })
            )}
          </Row>
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  errors: state.errors,
  restaurants: state.restaurant.restaurants,
});

export default connect(mapStateToProps, {
  getRestaurants,
})(Restaurants);
