import React, { Component } from "react";
import { Card, Empty, Col } from "antd";
import { Link } from "react-router-dom";
import { StarFilled } from "@ant-design/icons";
import { setRestaurantDetails } from "./../../actions/restaurantAction";
import { connect } from "react-redux";
import discount from "./../../assets/images/discount.png";

class RestaurantDetail extends Component {
  constructor(props) {
    super(props);
    this.state = {};
    this.viewDetails = this.viewDetails.bind(this);
    this.setRestaurant = this.setRestaurant.bind(this);
  }

  viewDetails = () => {};
  setRestaurant() {
    this.props.setRestaurantDetails(this.props.restaurant);
  }
  render() {
    const restaurant = this.props.restaurant;
    console.log("inside rest details", restaurant);
    // this.props.setRestaurantDetails(restaurant);
    return (
      <Col
        className="gutter-row restaurant-col mt-4"
        onClick={this.setRestaurant}
      >
        <Link
          to={{
            pathname: `/get-restaurant`,
            aboutProps: {
              restaurant: restaurant,
            },
          }}
          className="text-decoration-none"
          id="card-link"
        >
          <Card
            style={{ width: 280 }}
            className="restaurant-card"
            cover={
              restaurant.image ? (
                <img
                  alt="example"
                  src={restaurant.image}
                  style={{ width: 280, height: 150 }}
                />
              ) : (
                <Empty
                  description="No Image"
                  image={Empty.PRESENTED_IMAGE_SIMPLE}
                />
              )
            }
          >
            <div></div>
            <div>
              <div class="row text-start fw-bold">
                {restaurant.restaurantName}
              </div>
              <div class="row text-secondary">{restaurant.category}</div>
              <div class="row mt-3">
                <div className="col ">
                  {!restaurant.rating.currentRating ? (
                    <small>Not Rated</small>
                  ) : (
                    <span className="rating" style={{ padding: "5%" }}>
                      <span>
                        {" "}
                        <StarFilled />
                      </span>
                      <span className="mt-5">
                        {" "}
                        {restaurant.rating.currentRating}
                      </span>
                    </span>
                  )}
                </div>

                <div className="col text-secondary">45MINS</div>

                <div className="col text-secondary">{/* <BiRupee /> */}</div>
              </div>
              <div class="row text-secondary mt-3">
                <span>
                  <img alt="example" src={discount} style={{ width: "20px" }} />
                  <span></span>
                  <span></span>{" "}
                  <span className="text-danger">
                    10% off | use <b>JUMBO</b>
                  </span>
                </span>
              </div>
              <div class="row text-dark mt-3">
                <span>
                  {restaurant.address.location} &nbsp;{" "}
                  {restaurant.address.pinCode} &nbsp; {restaurant.address.city}
                  &nbsp;{restaurant.address.state}
                </span>
              </div>
            </div>
          </Card>
        </Link>
      </Col>
    );
  }
}

export default connect(null, { setRestaurantDetails })(RestaurantDetail);
