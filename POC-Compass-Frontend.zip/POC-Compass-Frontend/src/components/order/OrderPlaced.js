import React, { Component } from "react";
import { BiRupee } from "react-icons/bi";
import { Row, Button } from "antd";
import { connect } from "react-redux";
import { createOrder } from "../../actions/orderActions";
import { decodeToken } from "react-jwt";
import { Link } from "react-router-dom";
import { Spinner } from "react-bootstrap";
class OrderPlaced extends Component {
  constructor(props) {
    super();
    this.state = {
      loading: false,
    };
    this.orderPlaceClick = this.orderPlaceClick.bind(this);
    this.loadingFalse = this.loadingFalse.bind(this);
  }
  loadingFalse() {
    this.setState({
      loading: false,
    });
  }
  orderPlaceClick(event) {
    const { cartId } = this.props;
    this.setState({
      loading: true,
    });
    const user = decodeToken(localStorage.getItem("token"));

    const query = `mutation MyMutation {
            createOrder(input: {userId: "${user.userId}", cartId: "${cartId}", paymentMode: COD}) {
              userId
              isPaid
              orderId
              orderDate
              orderItem {
                menuItem {
                  actualPrice
                  description
                  discount
                  image
                  menuItemId
                  menuItemName
                  price
                  restaurantId
                }
                orderId
                quantity
                orderItemId
                totalPrice
              }
              orderStatus
              paymentMode
              restaurantId
              totalPrice
            }
          }
          `;
    this.props.createOrder(
      query,
      this.props.props.props.props.history,
      this.loadingFalse
    );
  }
  render() {
    const { toPay } = this.props;
    return (
      <Row>
        {/* <Link to={'order-track/' + }> */}
        <Button
          type="success"
          size="large"
          className="fw-bold mt-4  "
          id="deliver-here-btn"
          onClick={this.orderPlaceClick}
        >
          {this.state.loading ? (
            <Spinner animation="border" variant="light" className="spin" />
          ) : (
            <div>
              Pay <BiRupee />
              {toPay}
            </div>
          )}
        </Button>
        {/* </Link> */}
      </Row>
    );
  }
}
const mapStateToProps = (state) => ({
  errors: state.errors,
  cartId: state.cartReducer.cartId,
});
export default connect(mapStateToProps, {
  createOrder,
})(OrderPlaced);
