import React, { Component } from "react";
import { List, Avatar, Card } from "antd";
import { DownOutlined } from "@ant-design/icons";

class Notification extends Component {
  render() {
    const data = [
      "Racing car sprays burning fuel into crowd.",
      "Japanese princess to wed commoner.",
      "Australian walks 100km after outback crash.",
      "Man charged over missing wedding girl.",
      "Los Angeles battles huge wildfires.",
    ];

    return (
      <div className="bg-light">
        <div className="notification-container">
          <Card title="Orders" className="notification-card">
            <List
              size="small"
              header={<div>Header</div>}
              footer={<div>Footer</div>}
              bordered
              dataSource={data}
              renderItem={(item) => <List.Item>{item}</List.Item>}
            />
          </Card>
        </div>
      </div>
    );
  }
}

export default Notification;
