import React, { Component } from "react";
import vegIcon from "./../../assets/images/veg-icon.png";
import { BiRupee } from "react-icons/bi";
import { Row, Col } from "antd";
import { connect } from "react-redux";

class OrderItem extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    const { cartItem } = this.props;
    return (
      <Row className="my-3">
        <Col span={2}>
          <span>
            <img alt="example" src={vegIcon} style={{ width: "12px" }} />
          </span>
          &nbsp;
        </Col>
        <Col span={11}>
          <span className="cart-text">{cartItem.menuItem.menuItemName}</span>
        </Col>

        <Col span={3}>
          <span className="cart-text">
            <BiRupee />
            {cartItem.totalPrice}
          </span>
        </Col>
      </Row>
    );
  }
}

const mapStateToProps = (state) => (
  console.log("--------state------", state),
  {
    errors: state.errors,
  }
);

export default connect(mapStateToProps, {})(OrderItem);
