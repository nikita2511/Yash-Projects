import React, { Component } from "react";
import { Table } from "react-bootstrap";
import {
  LoadScript,
  GoogleMap,
  DirectionsRenderer,
} from "@react-google-maps/api";
const lib = ["places"];
const key = "AIzaSyA6ywgoC5KvkIAvAZspMfh9R7_cWnSNqQ8"; // PUT GMAP API
const google = (window.google = window.google ? window.google : {});
const defaultLocation = { lat: 40.756795, lng: -73.954298 };
// let destination = { lat: 28.4089, lng: 77.3178 };
// let origin = { lat: 28.1473, lng: 77.326 };
let directionsService;
class OrderTrackingMap extends Component {
  state = {
    directions: null,
    bounds: null,
  };
  onMapLoad = (map) => {
    console.log("onmap load", this.props);
    directionsService = new google.maps.DirectionsService();
    //load default origin and destination
    this.changeDirection(this.props.origin, this.props.destination);
  };
  //function that is calling the directions service
  changeDirection = (origin, destination) => {
    console.log("change direction", this.props);
    directionsService.route(
      {
        origin: origin,
        destination: destination,
        travelMode: google.maps.TravelMode.DRIVING,
      },
      (result, status) => {
        if (status === google.maps.DirectionsStatus.OK) {
          //changing the state of directions to the result of direction service
          this.setState({
            directions: result,
          });
        } else {
          console.error(`error fetching directions ${result}`);
        }
      }
    );
  };
  render() {
    console.log("render", this.props);
    return (
      <div>
        <LoadScript googleMapsApiKey={key} libraries={lib}>
          <div>
            <GoogleMap
              center={this.props.origin}
              zoom={5}
              onLoad={(map) => this.onMapLoad(map)}
              mapContainerStyle={{ height: "535px", width: "700px" }}
            >
              {this.state.directions !== null && (
                <DirectionsRenderer directions={this.state.directions} />
              )}
            </GoogleMap>
          </div>
        </LoadScript>
      </div>
    );
  }
}
export default OrderTrackingMap;
