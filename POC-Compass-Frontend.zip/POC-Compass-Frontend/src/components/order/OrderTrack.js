import React, { Component } from "react";
import { Card, Row, notification, Result, Button } from "antd";
import OrderSteps from "./OrderSteps";
import Rating from "../rate/Rating";
import { connect } from "react-redux";
import Pusher from "pusher-js";
import { pusherConfig } from "../../config/config";
import OrderItem from "./OrderItem";
import { BiRupee } from "react-icons/bi";
import { decodeToken } from "react-jwt";
import {
  getOrderByOrderId,
  updateOrderStatusByPusher,
} from "../../actions/orderActions";
import { getRestaurantByRestId } from "../../actions/restaurantAction";
import OrderTrackingMap from "./OrderTrackingMap";
import constant from "../../util/constant";
import { data } from "jquery";
import { CREATE_ORDER } from "../../actions/type";
import { Link } from "react-router-dom";
class OrderTrack extends Component {
  constructor(props) {
    super(props);
    this.state = {
      current: 0,
      order: {},
      restaurantDetails: {},
    };
    this.onChange = this.onChange.bind(this);
  }
  getOrderByOrderId(orderId) {
    const query = `query MyQuery {
      listOrderById(orderId: "${orderId}") {
        isPaid
        orderDate
        orderId
        orderItem {
          menuItem {
            actualPrice
            category
            description
            discount
            image
            menuItemId
            menuItemName
            price
            restaurantId
          }
          orderId
          orderItemId
          quantity
          totalPrice
        }
        orderStatus
        paymentMode
        restaurantId
        totalPrice
        userId
      }
    }
    `;
    this.props.getOrderByOrderId(query, orderId);
  }
  getRestByRestId(restId) {
    const query = `query MyQuery {
      getRestaurantById(id: "${restId}") {
        address {
          city
          lat
          lng
          location
          pinCode
          state
        }
        category
        id
        image
        sortKey
        userId
        restaurantName
      }
    }
    `;
    this.props.getRestaurantByRestId(query);
  }

  shouldComponentUpdate(nextProps, prvState) {
    console.log("inside should updATE", nextProps, prvState);
    if (nextProps.createOrder && nextProps.createOrder !== prvState.order) {
      console.log("1st if");
      const { createOrder } = nextProps;
      this.setState({
        order: createOrder,
      });
      this.getRestByRestId(createOrder.restaurantId);
      return true;
    }
    if (
      nextProps.restaurantDetails.address &&
      nextProps.restaurantDetails !== {} &&
      nextProps.restaurantDetails !== prvState.restaurantDetails
    ) {
      console.log("2nd if", nextProps);
      const { restaurantDetails } = nextProps;
      const user = decodeToken(localStorage.getItem("token"));
      let destination = {
        lat: parseFloat(restaurantDetails.address.lat),
        lng: parseFloat(restaurantDetails.address.lng),
      };
      let origin = {
        lat: parseFloat(user.address.lat),
        lng: parseFloat(user.address.lng),
      };
      this.setState({
        destination,
        origin,
        restaurantDetails,
      });
      return true;
    }
    return false;
  }
  componentDidMount() {
    console.log("inside CDM");
    const { createOrder } = this.props;
    if (!createOrder) {
      console.log("inside if ", createOrder);
      const orderId = `${this.props.props.match.params.orderId}${this.props.props.location.hash}`;
      this.getOrderByOrderId(orderId);
    } else {
      console.log("inside else ", createOrder);
      this.getRestByRestId(createOrder.restaurantId);
      this.setState({
        order: createOrder,
      });
    }
    var pusher = new Pusher(pusherConfig.API_KEY, {
      cluster: pusherConfig.CLUSTER,
    });
    const orderId = `${this.props.props.match.params.orderId}${this.props.props.location.hash}`;
    const channelName = orderId.replace("#", "-");
    var channel = pusher.subscribe(channelName);
    channel.bind(constant.pusherChannelName.ORDER_UPDATED, (data) => {
      notification.success({
        message: "Order Status Update",
        description: data.orderStatus,
      });
      this.props.updateOrderStatusByPusher(data);
    });
  }
  onChange = (current) => {
    this.setState({ current });
  };

  render() {
    const { order, destination, origin, restaurantDetails } = this.state;
    const user = decodeToken(localStorage.getItem("token"));
    var orderItem = [];
    var totalPrice = 0;
    var restaurantAddress = "";
    var orderId = "";
    var orderStatus = "";
    var userAddress = `${user.address.location}, ${user.address.city}, ${user.address.city}`;

    if (order && Object.keys(order).length !== 0) {
      console.log("inside if of ordertrack", order);
      totalPrice = order.totalPrice;
      orderItem = order.orderItem;
      orderId = order.orderId;
      orderStatus = order.orderStatus;
    }

    if (restaurantDetails && Object.keys(restaurantDetails).length !== 0) {
      restaurantAddress = `${restaurantDetails.address.location}, ${restaurantDetails.address.city},  ${restaurantDetails.address.state}`;
    }
    console.log("--------orderItem----", orderItem);
    return (
      <div className="bg-light">
        {orderStatus === "Delivered" ? (
          <Result
            status="success"
            title="Successfully Delivered!"
            extra={[
              <Link
                to={{
                  pathname: `/`,
                }}
                className="text-decoration-none btn btn-danger"
              >
                Explore Restaurants
              </Link>,
            ]}
          />
        ) : orderStatus === "Reject" ? (
          <Result
            status="error"
            title="Order Failed"
            subTitle="Your order is not placed"
            extra={[
              <Link
                to={{
                  pathname: `/`,
                }}
                className="text-decoration-none btn btn-danger"
              >
                Explore Restaurants
              </Link>,
            ]}
          ></Result>
        ) : (
          <div className="order-track-component container">
            <div className="row">
              <div className="col-8 p-3 ">
                <div className="container bg-white border ">
                  {destination ? (
                    <OrderTrackingMap
                      destination={destination}
                      origin={origin}
                    />
                  ) : (
                    ""
                  )}
                </div>
              </div>
              <div className="col-4 p-3">
                <div className="row" id="order-track-section">
                  <Card bordered={true} style={{ width: 350 }}>
                    <div className="row">
                      <small>{orderId}</small>
                    </div>
                    <div className="row">
                      <div>{restaurantDetails.restaurantName}</div>
                      <small>03:54 |1 item | 118</small>
                    </div>
                  </Card>
                </div>
                <div className="row mt-2" id="order-track-section">
                  {orderStatus ? <OrderSteps orderStatus={orderStatus} /> : ""}
                </div>
              </div>
            </div>
            <div className="row">
              <div className="col-8 p-3 ">
                <div className="container bg-white border p-4 ">
                  <div className="row">
                    <div className="col-6">
                      {" "}
                      <div id="restaurant-address" className="mt-2">
                        <Row>
                          <span className="h4">Order Details</span>
                        </Row>
                        <Row>
                          <small>From</small>
                        </Row>
                        <Row>
                          <span className="order-track-heading">
                            {restaurantDetails.restaurantName}
                          </span>
                        </Row>
                        <Row>
                          <small className="order-track-text">
                            {restaurantAddress}
                          </small>
                        </Row>
                      </div>
                      <div id="delivery-address" className="mt-5">
                        {" "}
                        <Row>
                          <small>Delivers To</small>
                        </Row>
                        <Row>
                          <span className="order-track-heading">Home</span>
                        </Row>
                        <Row>
                          <small className="order-track-text">
                            {userAddress}
                          </small>
                        </Row>
                      </div>
                    </div>
                    <div className="col-6 mt-5">
                      <div>
                        {orderItem.map((element) => {
                          return (
                            <OrderItem
                              cartItem={element}
                              key={element.orderItemId}
                            />
                          );
                        })}
                        <hr
                          className="container"
                          style={{ width: "80%", height: ".3px" }}
                        />
                        <div className="row">
                          <div className="col-6">
                            <span className="order-track-heading">
                              BILL TOTAL
                            </span>
                          </div>
                          <div className="col-6">
                            <BiRupee />
                            <small className="text-dark">{totalPrice}</small>
                          </div>
                        </div>
                        <div className="row">
                          <small className="order-track-text">
                            Paid via Cash
                          </small>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
              <div className="col-4 p-3">
                <Rating restId={restaurantDetails} />
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  errors: state.errors,
  cartItems: state.cartReducer.cartItems,
  createOrder: state.orderReducer.createOrder,
  restaurantDetails: state.restaurant.restaurantDetails,
});
export default connect(mapStateToProps, {
  getOrderByOrderId,
  getRestaurantByRestId,
  updateOrderStatusByPusher,
})(OrderTrack);
