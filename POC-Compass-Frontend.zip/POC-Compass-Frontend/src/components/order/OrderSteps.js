import React, { Component } from "react";
import { Card, Steps } from "antd";
import constant from '../../util/constant';

const { Step } = Steps;

class OrderSteps extends Component {
  render() {
    const { orderStatus } = this.props;
    const status = constant.orderStatus[orderStatus];
    return (
      <Card bordered={true} title="Track Your Order" style={{ width: 350 }}>
        <Steps direction="vertical" size="small" responsive={true} current={status}>
          <Step title="In Progress" description="This is a description." />
          <Step title="Accepted" description="This is a description." />
          <Step title="Preparing" description="This is a description." />
          <Step title="Out for delivery" description="This is a description." />
          <Step title="Delivered" description="This is a description." />
        </Steps>
        ,
      </Card>
    );
  }
}

export default OrderSteps;
