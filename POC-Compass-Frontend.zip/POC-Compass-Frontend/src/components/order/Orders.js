import React, { Component } from "react";
import { notification, Table, Card, Col, Row, Input } from "antd";
import { Menu, Dropdown, message, Button, Space, Badge, Spin } from "antd";
import { DownOutlined, CheckCircleOutlined } from "@ant-design/icons";
import {
  getAllRestaurantOrders,
  updateOrderStatus,
} from "./../../actions/orderActions";
import { connect } from "react-redux";
import { IoIosNotifications } from "react-icons/io";
import { MdDarkMode } from "react-icons/md";
import Notification from "./Notification";
import { BiRupee } from "react-icons/bi";
import constant, { orderStatus } from "../../util/constant";
import TagForOrderStatus from "../UtilComponents/TagForOrderStatus";
const { Search } = Input;

class Orders extends Component {
  constructor(props) {
    super(props);
    this.state = {
      loading: true,
      updateButtonLoading: false,
    };
    this.loadingFalse = this.loadingFalse.bind(this);
    this.updateButtonLoadingFalse = this.updateButtonLoadingFalse.bind(this);
  }
  updateButtonLoadingFalse() {
    this.setState({
      updateButtonLoading: false,
    });
  }
  loadingFalse() {
    this.setState({
      loading: false,
    });
  }
  onAcceptOrder = () => {
    this.setState({ accepted: true });
    message.success("Order has been accepted");
  };
  updateOrderStatusOnClick = (orderId, status) => {
    this.setState({
      loading: true,
    });
    const query = ` mutation MyMutation {
      updateOrder(input: {orderId: "${orderId}", orderStatus: ${status}}) {
        isPaid
        orderDate
        orderId
        orderItem {
          menuItem {
            actualPrice
            category
            description
            discount
            image
            menuItemId
            menuItemName
            price
            restaurantId
          }
          orderId
          orderItemId
          quantity
          totalPrice
        }
        orderStatus
        paymentMode
        restaurantId
        totalPrice
        userId
      }
    }
    `;
    this.props.updateOrderStatus(query, this.loadingFalse);
  };
  componentDidMount() {
    const restaurant = JSON.parse(localStorage.getItem("restaurant"));
    this.setState({
      restaurant,
    });
    if (restaurant) {
      const query = `query MyQuery {
        getOrderListByRestaurantId(restaurantID: "REST#878893") {
          isPaid
          orderDate
          orderId
          orderItem {
            orderId
            orderItemId
            quantity
            totalPrice
            menuItem {
              actualPrice
              category
              description
              discount
              image
              menuItemId
              menuItemName
              price
              restaurantId
            }
          }
          orderStatus
          paymentMode
          restaurantId
          totalPrice
          userId
          user {
            email
            lastName
            firstName
            jwtToken
            password
            phoneNumber
            userId
            userType
            address {
              city
              lat
              lng
              location
              pinCode
              state
            }
          }
        }
      }
      `;
      this.props.getAllRestaurantOrders(
        query,
        restaurant.id,
        this.loadingFalse
      );
    }
  }

  render() {
    const { orders } = this.props;
    const menu = (
      <Menu>
        <Menu.Item onClick={() => this.updateOrderStatusOnClick()} key="1">
          Preparing
        </Menu.Item>
        <Menu.Item key="2">Out for delivery</Menu.Item>
        <Menu.Item key="3">Delivered</Menu.Item>
      </Menu>
    );
    const columns = [
      { title: "Order ID", dataIndex: "orderId", key: "orderId" },
      { title: "Payment Mode", dataIndex: "paymentMode", key: "paymentMode" },
      { title: "Total Price", dataIndex: "totalPrice", key: "totalPrice" },
      {
        title: "Order Date",
        dataIndex: "orderDate",
        key: "orderDate",
        render: (record) => {
          console.log(record);
          return new Date(record).toLocaleString();
        },
      },
      {
        title: "Order Status",
        dataIndex: "orderStatus",
        key: "orderStatus",
        render: (text, record) => {
          return <TagForOrderStatus orderStatus={record.orderStatus} />;
        },
      },
      {
        title: "Action",
        key: "action",
        render: (text, record) => {
          return (
            <div>
              {(() => {
                if (record.orderStatus === "InProgress") {
                  return (
                    <div className="row ">
                      <div className="col-1"></div>
                      <div className="col-4">
                        {" "}
                        <Button
                          onClick={() =>
                            this.updateOrderStatusOnClick(
                              record.orderId,
                              constant.orderStatusString.Accept
                            )
                          }
                          className="btn-success"
                          shape="round"
                          size="small"
                        >
                          Accept
                        </Button>
                      </div>
                      <div className="col-1"></div>
                      <div className="col-4">
                        <Button
                          onClick={() =>
                            this.updateOrderStatusOnClick(
                              record.orderId,
                              constant.orderStatusString.Reject
                            )
                          }
                          type="danger"
                          shape="round"
                          size="small"
                        >
                          Reject
                        </Button>
                      </div>
                    </div>
                  );
                } else {
                  return (
                    <Dropdown
                      overlay={
                        <Menu>
                          <Menu.Item
                            onClick={() =>
                              this.updateOrderStatusOnClick(
                                record.orderId,
                                constant.orderStatusString.Preparing
                              )
                            }
                            key="1"
                          >
                            Preparing
                          </Menu.Item>
                          <Menu.Item
                            onClick={() =>
                              this.updateOrderStatusOnClick(
                                record.orderId,
                                constant.orderStatusString.OutForDelivery
                              )
                            }
                            key="2"
                          >
                            Out for delivery
                          </Menu.Item>
                          <Menu.Item
                            onClick={() =>
                              this.updateOrderStatusOnClick(
                                record.orderId,
                                constant.orderStatusString.Delivered
                              )
                            }
                            key="3"
                          >
                            Delivered
                          </Menu.Item>
                        </Menu>
                      }
                      trigger={["click"]}
                      className="mx-5"
                    >
                      <a
                        className="ant-dropdown-link text-danger text-center"
                        onClick={(e) => e.preventDefault()}
                        href
                      >
                        Status <DownOutlined />
                      </a>
                    </Dropdown>
                  );
                }
              })()}
            </div>
          );
        },
      },
    ];

    return (
      <div className="restaurant-orders-container">
        <div className="row restaurant-orders-header"></div>
        <div className="row mt-4">
          {" "}
          <span className="h4">Orders</span>
          <Table
            rowKey={orders.orderId}
            columns={columns}
            dataSource={orders}
            loading={this.state.loading}
            expandable={{
              expandedRowRender: (record) => (
                <div>
                  <small>{record.orderId}</small>
                  <div>
                    {" "}
                    <span>
                      Location :{" "}
                      <small>
                        {record.user.address.location}
                        {" ,"}
                        {record.user.address.city}
                      </small>
                    </span>
                  </div>
                  <table className="table w-50 border mt-3">
                    <thead>
                      <tr>
                        <th scope="col">Item</th>
                        <th scope="col">Quantity</th>
                        <th scope="col">Item Price</th>
                        <th scope="col">Total</th>
                      </tr>
                    </thead>
                    <tbody>
                      {record.orderItem.map((item) => {
                        return (
                          <tr>
                            <td> {item.menuItem.menuItemName}</td>
                            <td>{item.quantity}</td>
                            <td>
                              {" "}
                              <BiRupee /> {item.menuItem.price}
                            </td>
                            <td>
                              <BiRupee /> {item.totalPrice}
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              ),

              rowExpandable: (record) => record.orderItem.length !== 0,
              onExpand: (expanded, record) =>
                console.log("onExpand: ", record, expanded),
            }}
          />
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => (
  console.log("state update", state.orderReducer.restaurantAllOrders),
  {
    errors: state.errors,
    orders: state.orderReducer.restaurantAllOrders,
  }
);

export default connect(mapStateToProps, {
  getAllRestaurantOrders,
  updateOrderStatus,
})(Orders);
