/* eslint-disable no-lone-blocks */
import React, { Component } from "react";
import { getMenuItems } from "../../actions/restaurantAction";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import { Button, Empty, Row, Spin, Space } from "antd";
import { Link } from "react-router-dom";
import MenuItem from "./MenuItem";
class MenuItems extends Component {
  constructor(props) {
    super(props);
    this.state = {
      restaurant: null,
      loading: true,
    };
    this.loadingFalse = this.loadingFalse.bind(this);
  }
  loadingFalse() {
    this.setState({
      loading: false
    })
  }
  componentDidMount() {
    const restaurant = JSON.parse(localStorage.getItem("restaurant"));
    this.setState({
      restaurant,
    });
    if (restaurant) {
      const query = `query MyQuery {
        getMenuItemsByRestaurantId(restaurantId: "${restaurant.id}") {
          actualPrice
          description
          discount
          category
          menuItemId
          menuItemName
          price
          restaurantId
          image
        }
      }`;

      this.props.getMenuItems(query, this.loadingFalse);
    }
  }

  render() {
    const { menuItems = [] } = this.props;
    console.log("menuItems render", menuItems);
    return (
      <div>
        <div className="pull-right">
          {this.state.restaurant ? (
            <Button type="primary" size="large">
              <Link to="/menu-items/add-menu-item" className="link-deocration">
                Add Item
              </Link>
            </Button>
          ) : (
            <Button type="primary" size="large">
              <Link to="/restaurant" className="link-deocration">
                Create Restaurant
              </Link>
            </Button>
          )}
        </div>
        <div class="container d-flex align-items-start ">
          <Row gutter={{ xs: 8, sm: 16, md: 24, lg: 32 }}>
            {(() => {
              if (this.state.loading) {
                return <Space direction="horizontal" style={{ width: '100%', justifyContent: 'center' }}><Spin size="large" /></Space>
              } else {
                if (!menuItems.length) return (<div className="">
                  <Empty description={<span>No Items</span>} />
                </div>)
                else {
                  return (menuItems.map((element) => {
                    return <MenuItem menuItem={element} props={this.props.props} key={element.menuItemId} />;
                  }))
                }
              }
            })()}
            {/* {
              !menuItems.length ? (
                <div className="">
                  <Empty description={<span>No Items</span>} />
                </div>
              ) : (
                menuItems.map((element) => {
                  return <MenuItem menuItem={element} props={this.props.props} key={element.menuItemId} />;
                })
              )
            } */}
          </Row>
        </div>
      </div>
    );
  }
}
const mapStateToProps = (state) => ({
  errors: state.errors,
  menuItems: state.restaurant.menuItems,
});

MenuItems.propTypes = {
  getMenuItems: PropTypes.func.isRequired,
};

export default connect(mapStateToProps, {
  getMenuItems,
})(MenuItems);
