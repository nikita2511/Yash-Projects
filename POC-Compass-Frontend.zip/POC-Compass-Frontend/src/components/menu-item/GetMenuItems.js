
import React, { Component } from "react";
import { getMenuItems } from "../../actions/restaurantAction";
import PropTypes from "prop-types";
import { connect } from "react-redux";
import { Card } from "antd";
import {
  DeleteOutlined,
  EditOutlined,
  FolderViewOutlined,
} from "@ant-design/icons";
import { BiRupee } from "react-icons/bi";

class GetMenuItems extends Component {
  constructor(props) {
    super(props);
  }
  componentDidMount() {
    console.log("component- didi mount");
    const query = `query MyQuery {
      getMenuItemsByRestaurantId(restaurantId: "REST#989f7a63-50eb-42fb-a3a4-48caa6db616b") {
        actualPrice
        description
        discount
        menuItemId
        menuItemName
        price
        restaurantId
      }
    }`;
    this.props.getMenuItems(query);
  }
  render() {
    const { menuItems } = this.props;
    console.log(menuItems);
    return (
      <div class="container  d-flex align-items-start ">
        <div class="row ">
          {menuItems?.map((item) => {
            return (
              <div class="col-sm">
                {" "}
                <Card
                  style={{ width: 150 }}
                  className="menu-item-card"
                  cover={
                    <img
                      alt="example"
                      src={require("../../assets/images/pizza.jpg")}
                    />
                  }
                  actions={[
                    <DeleteOutlined
                      key="delete"
                      onClick={() => this.deleteMenuItem("delete")}
                    />,
                    <EditOutlined
                      key="edit"
                      onClick={() => this.editMenuItem("edit")}
                    />,
                    <FolderViewOutlined
                      onClick={() => this.viewDetails("view")}
                    />,
                  ]}
                >
                  <div>
                    <div class="row text-start fw-bold">
                      {item.menuItemName}
                    </div>
                    <div class="row">{item.description} </div>
                    <div class="row">
                      <span className="rupeeSign">
                        <BiRupee />
                        {item.price}
                      </span>
                    </div>
                  </div>
                </Card>
              </div>
            );
          })}
        </div>
        hello ram
      </div>
    );
    // return (
    //   <div class="col-sm col-lg-2 pt-5 ">
    //     {menuItems?.map((item) => {
    //       return (
    //         <div class="row">
    //           <div class="col-sm">
    // <Card
    //   style={{ width: 150 }}
    //   className="menu-item-card"
    //   cover={
    //     <img
    //       alt="example"
    //       src={require("../../assets/images/pizza.jpg")}
    //     />
    //   }
    //   actions={[
    //     <DeleteOutlined
    //       key="delete"
    //       onClick={() => this.deleteMenuItem("delete")}
    //     />,
    //     <EditOutlined
    //       key="edit"
    //       onClick={() => this.editMenuItem("edit")}
    //     />,
    //     <FolderViewOutlined
    //       onClick={() => this.viewDetails("view")}
    //     />,
    //   ]}
    // >
    //   <div>
    //     <div class="row text-start fw-bold">
    //       {item.menuItemName}
    //     </div>
    //     <div class="row">{item.description} </div>
    //     <div class="row">
    //       <span className="rupeeSign">
    //         <BiRupee />
    //         {item.price}
    //       </span>
    //     </div>
    //   </div>
    // </Card>
    //           </div>
    //         </div>
    //       );
    //     })}
    //   </div>
    // );
  }
}
const mapStateToProps = (state) => (
  console.log(state),
  {
    errors: state.errors,
    // menuItems: state.restaurant.menuItems.data.getMenuItemsByRestaurantId,
  }
);

GetMenuItems.propTypes = {
  getMenuItems: PropTypes.func.isRequired,
};

export default connect(mapStateToProps, {
  getMenuItems,
})(GetMenuItems);
