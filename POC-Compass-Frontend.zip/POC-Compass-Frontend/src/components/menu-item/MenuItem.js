import React, { Component } from "react";
import { Popconfirm, message, Card, Empty, Col, Image } from "antd";
import { Link } from "react-router-dom";
import {
  DeleteOutlined,
  EditOutlined,
  FolderViewOutlined,
} from "@ant-design/icons";
import { BiRupee } from "react-icons/bi";
import { deleteMenuItem } from "./../../actions/restaurantAction";
import PropTypes from "prop-types";
import { connect } from "react-redux";
// import { v4 as uuidv4 } from "uuid";
// import util from "../../util/util";
// import imageToBase64 from "image-to-base64";

class MenuItem extends Component {
  constructor(props) {
    super(props);
    this.state = {
      isModalVisible: false,
    };
    this.editMenuItem = this.editMenuItem.bind(this);
    this.viewDetails = this.viewDetails.bind(this);
  }
  confirmDelete = (e) => {
    const { menuItem } = this.props;
    const query = `mutation MyMutation {
      deleteMenuItem(input: {id: "${menuItem.restaurantId}", menuItemId: "${menuItem.menuItemId}"}) {
        menuItemName
        description
        discount
        menuItemId
      }
    }`;
    this.props.deleteMenuItem(
      query,
      menuItem.menuItemId,
      this.props.props.history
    );
  };

  cancelDelete = (e) => {
    message.error("Menu item not deleted");
  };
  editMenuItem = () => {};
  viewDetails = () => {};

  render() {
    const { menuItem } = this.props;
    // imageToBase64(menuItem.image) // Image URL
    //   .then((response) => {
    //     console.log(response);
    //   })
    //   .catch((error) => {
    //     console.log(error);
    // });
    // let k = uuidv4();
    // console.log("inside render", menuItem, k);
    // console.log("--------menu item image-", menuItem.image);
    // util.getBase64(menuItem.image, (image) => {
    //   console.log("--------------inage ---------", image);
    // });
    return (
      <Col className="gutter-row mt-3 menu-card-container">
        <Card
          style={{ width: 175 }}
          className="menu-item-card"
          cover={
            // <img alt="example" src={Empty.PRESENTED_IMAGE_SIMPLE} />
            menuItem.image ? (
              (console.log("menuItem image", menuItem),
              (
                <Image
                  width="130"
                  height="130"
                  alt="example"
                  // source={{
                  //   uri: menuItem.image,
                  //   cache: "reload",
                  //   headers: {
                  //     Pragma: "no-cache",
                  //   },
                  // }}
                  src={menuItem.image}
                />
              ))
            ) : (
              <Empty
                description="No Image"
                image={Empty.PRESENTED_IMAGE_SIMPLE}
              />
            )
          }
          actions={[
            <Popconfirm
              title="Are you sure to delete this menu item?"
              onConfirm={this.confirmDelete}
              onCancel={this.cancelDelete}
              okText="Yes"
              cancelText="No"
            >
              <DeleteOutlined key="delete"></DeleteOutlined>
            </Popconfirm>,
            <Link
              to={{
                pathname: `/menu-items/update-menu-item`,
                aboutProps: {
                  menuItem: menuItem,
                },
              }}
              className="text-decoration-none"
            >
              <EditOutlined
                key="edit"
                onClick={() => this.editMenuItem("edit")}
              />
            </Link>,
            <FolderViewOutlined onClick={() => this.viewDetails("view")} />,
          ]}
        >
          <div></div>
          <div>
            <div class="row text-start fw-bold">{menuItem.menuItemName}</div>
            <div class="row">
              <small>{menuItem.category}</small>{" "}
            </div>
            <div class="row">{menuItem.description} </div>
            <div class="row">
              <span className="rupeeSign col">
                <s>
                  <BiRupee />
                  {menuItem.actualPrice}
                </s>
              </span>
              <span className="rupeeSign col">
                <BiRupee />
                {menuItem.price}
              </span>
            </div>
          </div>
        </Card>
      </Col>
    );
  }
}

const mapStateToProps = (state) => ({
  errors: state.errors,
  deletedMenuItem: state,
});

MenuItem.propTypes = {
  deleteMenuItem: PropTypes.func.isRequired,
};

export default connect(mapStateToProps, {
  deleteMenuItem,
})(MenuItem);
