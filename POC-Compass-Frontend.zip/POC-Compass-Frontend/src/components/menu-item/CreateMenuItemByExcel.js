import React, { Component } from "react";
import { Upload, Button, message, Form } from "antd";
import { UploadOutlined } from "@ant-design/icons";
import util from "../../util/util"
import { createMenuItemByExcelFile } from '../../actions/restaurantAction';
import { connect } from 'react-redux';

class CreateMenuItemByExcel extends Component {
  constructor() {
    super();
    this.state = {
      fileList: [],
      base64: "",
      image: ""
    };
    this.onSubmit = this.onSubmit.bind(this);
    this.handleChange = this.handleChange.bind(this);
  }
  dummyRequest = ({ fileList, onSuccess }) => {
    setTimeout(() => {
      onSuccess("ok");
    }, 0);
  };
  handleChange = (info) => {
    const { status } = info.file;
    if (status === 'uploading') {
      return;
    }
    if (status === 'done') {
      util.getBase64(info.file.originFileObj, img => {
        this.setState({
          image: img,
        })
      });
      message.success(`${info.file.name} file uploaded successfully.`);
    } else if (status === 'error') {
      message.error(`${info.file.name} file upload failed.`);
    }


  };


  onSubmit(event) {
    let base64Image = this.state.image.split(';base64,').pop();
    const restaurant = JSON.parse(localStorage.getItem('restaurant'));
    const query = `mutation MyMutation {
        createMenuItemByExcelFile(input: {excelbase64: "${base64Image}" , restaurantId:"${restaurant.id}"}) {
          actualPrice
          description
          discount
          menuItemId
          menuItemName
          price
          restaurantId
        }
      }
`;
    this.props.createMenuItemByExcelFile(query, this.props.props.history);
  }


  render() {

    return (
      <div>
        <h5 className="form-title text-center">OR</h5>
        <br></br>
        <h5 className="form-title text-center">Create Menu Items by uploading excel file</h5>
        <div class="card-body p-md-5 text-black">
          <Form.Item>

            <Upload
              name='file'
              className="avatar-uploader"
              customRequest={this.dummyRequest}
              onChange={this.handleChange}
              multiple={false}
            >
              <Button icon={<UploadOutlined />}>Click to Upload</Button>
            </Upload>

          </Form.Item>
          <Form.Item>
            <Button type="primary" onClick={this.onSubmit}>
              submit
            </Button>
          </Form.Item>
        </div>
      </div>
    );
  }
}


export default connect(null, {
  createMenuItemByExcelFile,
})(CreateMenuItemByExcel);
