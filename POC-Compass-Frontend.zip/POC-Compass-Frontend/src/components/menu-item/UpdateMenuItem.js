import React, { Component } from "react";
import { Form, Input, Button, Card, Empty, Upload, Select } from "antd";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import ImgCrop from "antd-img-crop";
import util from "../../util/util";
import {
  PercentageOutlined,
  ShopOutlined,
  DollarOutlined,
  UploadOutlined,
} from "@ant-design/icons";
import { updateMenuItem } from "./../../actions/restaurantAction";
const { Option } = Select;
class UpdateMenuItem extends Component {
  constructor(props) {
    super(props);
    this.state = {
      actualPrice: "",
      description: "",
      discount: "",
      category: "",
      menuItemName: "",
      restaurantId: "",
      menuItemId: "",
      image: "",
      imageUrl: "",
    };
    this.onChange = this.onChange.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.handleChangeImageURL = this.handleChangeImageURL.bind(this);
    this.oncategoryTypeChange = this.oncategoryTypeChange.bind(this);
  }
  dummyRequest({ file, onSuccess }) {
    setTimeout(() => {
      onSuccess("ok");
    }, 0);
  }
  oncategoryTypeChange = (event) => {
    this.setState({ category: event });
  };
  onChange(event) {
    this.setState({ [event.target.name]: event.target.value });
  }
  handleChangeImageURL(event) {
    this.setState({
      image: event.target.value,
      imageUrl: event.target.value,
    });
    console.log("state changed", this.state);
  }
  handleChange(info) {
    console.log(info);
    if (info.file.status === "uploading") {
      return;
    }
    if (info.file.status === "done") {
      console.log(info.file.originFileObj);
      util.getBase64(info.file.originFileObj, (image) => {
        this.setState({
          image,
        });
      });
    }
  }
  onSubmit = (event) => {
    //   const query = ` mutation MyMutation {
    //       updateMenuItem(input: {actualPrice: ${this.state.actualPrice}, description: "${this.state.description}", discount: ${this.state.discount},category: ${this.state.category}, id: "${this.state.restaurantId}", menuItemName: "${this.state.menuItemName}", sortKey: "${this.state.menuItemId}", image: "${this.state.image}"}) {
    //         actualPrice
    //         description
    //         discount
    //         menuItemId
    //         menuItemName
    //         price
    //         restaurantId,
    //         image
    //       }
    //     }
    // `;
    const query = `mutation MyMutation {
    updateMenuItem(input: {id: "${this.state.restaurantId}", sortKey: "${this.state.menuItemId}", menuItemName: "${this.state.menuItemName}", discount: ${this.state.discount}, description: "${this.state.description}", actualPrice: ${this.state.actualPrice}, image: "${this.state.image}"}) {
      actualPrice
      category
      description
      discount
      image
      menuItemId
      menuItemName
      price
      restaurantId
    }
  }
  `
    console.log("query", query);
    this.props.updateMenuItem(query, this.props.props.history);
  };
  componentDidMount() {
    console.log(this.props.props);
    const menuItem = this.props.props.location.aboutProps.menuItem;
    this.setState({
      actualPrice: menuItem.actualPrice,
      description: menuItem.description,
      menuItemName: menuItem.menuItemName,
      discount: menuItem.discount,
      restaurantId: menuItem.restaurantId,
      menuItemId: menuItem.menuItemId,
      image: menuItem.image,
    });
  }
  render() {
    console.log(this.props.props);
    const menuItem = this.props.props.location.aboutProps.menuItem;
    return (
      <div>
        <section className=" p-5 bg-light">
          <div className="row d-flex justify-content-center align-items-center">
            <h5 className="form-title text-center ">Update Menu item</h5>
            <div class="card card-Registration ">
              <div className="row d-flex">
                <div className="col-6">
                  <div class="card-body p-md-5 text-black">
                    {/* start */}
                    <div className="updateMenuItem-content">
                      <div className="updateMenuItem-form">
                        <Form scrollToFirstError onFinish={this.onSubmit}>
                          <div class="row  d-flex justify-content-center align-items-center">
                            <div class="col-12 col-sm-6">
                              <Form.Item
                                name="menuItemName"
                                rules={[{ required: true }]}
                                initialValue={menuItem.menuItemName}
                              >
                                <Input
                                  type="text"
                                  name="menuItemName"
                                  id="menuItemName"
                                  placeholder="Item Name"
                                  onChange={this.onChange}
                                  value={this.state.menuItemName}
                                  // defaultValue={menuItem.menuItemName}
                                  prefix={
                                    <ShopOutlined className="site-form-item-icon" />
                                  }
                                />
                              </Form.Item>
                            </div>
                          </div>
                          <div class="row  d-flex justify-content-center align-items-center">
                            <div class="col-12 col-sm-6">
                              <Form.Item
                                name="description"
                                rules={[{ required: true }]}
                                initialValue={menuItem.description}
                              >
                                <Input
                                  type="text"
                                  name="description"
                                  id="description"
                                  placeholder="Item description"
                                  onChange={this.onChange}
                                  value={this.state.description}
                                  // defaultValue={menuItem.description}
                                  prefix={
                                    <ShopOutlined className="site-form-item-icon" />
                                  }
                                />
                              </Form.Item>
                            </div>
                          </div>
                          <div class="row  d-flex justify-content-center align-items-center">
                            <div class="col-12 col-sm-6">
                              <Form.Item
                                name="actualPrice"
                                initialValue={menuItem.actualPrice}
                                rules={[
                                  {
                                    required: true,
                                    message: "Please enter your  price!",
                                  },
                                  ({ getFieldValue }) => ({
                                    validator(_, value) {
                                      var hasAlphabets = /^\d*\.?\d*$/;
                                      if (
                                        parseInt(
                                          getFieldValue("actualPrice")
                                        ) &&
                                        hasAlphabets.test(
                                          getFieldValue("actualPrice")
                                        )
                                      ) {
                                        return Promise.resolve();
                                      }
                                      return Promise.reject(
                                        "Should contain numbers only!"
                                      );
                                    },
                                  }),
                                ]}
                              >
                                <Input
                                  type="text"
                                  prefix={
                                    <DollarOutlined className="site-form-item-icon" />
                                    // < className="fas fa-hotel" />
                                  }
                                  name="actualPrice"
                                  id="actualPrice"
                                  placeholder="Price"
                                  value={this.state.actualPrice}
                                  defaultValue={menuItem.actualPrice}
                                  onChange={this.onChange}
                                />
                              </Form.Item>
                            </div>
                          </div>
                          <div class="row  d-flex justify-content-center align-items-center">
                            <div class="col-12 col-sm-6">
                              <Form.Item
                                name="discount"
                                initialValue={menuItem.discount}
                                rules={[
                                  {
                                    required: true,
                                    message: "Please enter discount!",
                                  },
                                  ({ getFieldValue }) => ({
                                    validator(_, value) {
                                      var hasAlphabets = /^\d*\.?\d*$/;
                                      if (
                                        parseInt(getFieldValue("discount")) &&
                                        hasAlphabets.test(
                                          getFieldValue("discount")
                                        )
                                      ) {
                                        return Promise.resolve();
                                      }
                                      return Promise.reject(
                                        "Should contain numbers only!"
                                      );
                                    },
                                  }),
                                ]}
                              >
                                <Input
                                  type="text"
                                  prefix={
                                    <PercentageOutlined className="site-form-item-icon" />
                                    // < className="fas fa-hotel" />
                                  }
                                  name="discount"
                                  id="discount"
                                  placeholder="Discount"
                                  value={this.state.discount}
                                  defaultValue={menuItem.discount}
                                  onChange={this.onChange}
                                />
                              </Form.Item>
                              <Form.Item
                                name="category"
                                // label="Category"
                                showSearch
                                initialValue={menuItem.category}
                                rules={[
                                  {
                                    required: true,
                                    message: "Please select Type!",
                                  },
                                ]}
                              >
                                <Select
                                  placeholder="Select category"
                                  name="category"
                                  id="category"
                                  value={this.state.category}
                                  onChange={this.oncategoryTypeChange}
                                >
                                  <Option value="Dessert">Dessert</Option>
                                  <Option value="MainCourse">
                                    Main Course
                                  </Option>
                                  <Option value="ChineseFood">
                                    Chinese Food
                                  </Option>
                                  <Option value="PizzaandSandwich">
                                    Pizza and Sandwich
                                  </Option>
                                  <Option value="Drinks">Drinks</Option>
                                </Select>
                              </Form.Item>
                            </div>
                          </div>
                          {/* <div class="row  d-flex justify-content-center align-items-center">
                            <div class="col-12 col-sm-6">
                              <Form.Item
                                name="imageUrl"
                                // initialValue={menuItem.discount}
                              >
                                <Input
                                  type="text"
                                  name="imageUrl"
                                  id="imageUrl"
                                  placeholder="imageUrl"
                                  value={this.state.imageUrl}
                                  // defaultValue={menuItem.discount}
                                  onChange={this.onChange}
                                />
                              </Form.Item>
                            </div>
                          </div> */}
                          <br />
                          <div class="row  d-flex justify-content-center align-items-center">
                            <div class="col-12 col-sm-6">
                              <Button
                                type="primary"
                                htmlType="submit"
                                className=""
                              >
                                Save
                              </Button>
                            </div>
                          </div>
                        </Form>
                      </div>
                      <div className="createRestaurant-image-register"></div>
                    </div>
                    {/* end */}
                  </div>
                </div>
                <div className="col-3 mt-4">
                  <div className="row d-flex">
                    <div class="card-body text-black">
                      <Card
                        style={{ width: 175 }}
                        className="menu-item-card"
                        cover={
                          menuItem.image ? (
                            <img alt="example" src={this.state.image} />
                          ) : (
                            <Empty
                              description="No Image"
                              image={Empty.PRESENTED_IMAGE_SIMPLE}
                            />
                          )
                        }
                        actions={[
                          <Form.Item>
                            <ImgCrop aspect={7 / 7}>
                              <Upload
                                name="file"
                                className="avatar-uploader"
                                customRequest={this.dummyRequest}
                                onChange={this.handleChange}
                                multiple={false}
                              >
                                <span
                                  icon={<UploadOutlined />}
                                  className="btn edit-image"
                                >
                                  Edit Image
                                </span>
                              </Upload>
                            </ImgCrop>
                          </Form.Item>,
                        ]}
                      ></Card>
                    </div>
                  </div>
                  <div className="row d-flex align-items-center mx-5">
                    <b>OR</b>
                  </div>
                  <div className="row d-flex ">
                    <div class="card-body  text-black">
                      <Form.Item
                        name="imageUrl"
                      // initialValue={menuItem.discount}
                      >
                        <Input
                          type="text"
                          name="imageUrl"
                          id="imageUrl"
                          placeholder="imageUrl"
                          value={this.state.imageUrl}
                          // defaultValue={menuItem.discount}
                          onChange={this.handleChangeImageURL}
                        />
                      </Form.Item>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    );
  }
}
const mapStateToProps = (state) => ({
  errors: state.errors,
  updatedMenuItem: state,
});
UpdateMenuItem.propTypes = {
  updateMenuItem: PropTypes.func.isRequired,
};
export default connect(mapStateToProps, {
  updateMenuItem,
})(UpdateMenuItem);
