import React, { Component } from "react";
import { Form, Input, Button, Upload, Select } from "antd";
import {
  PercentageOutlined,
  ShopOutlined,
  DollarOutlined,
  EditOutlined,
  UploadOutlined,
} from "@ant-design/icons";
import { connect } from "react-redux";
import { createMenuItem } from "../../actions/restaurantAction";
import util from "../../util/util";
import ImgCrop from "antd-img-crop";
import CreateMenuItemByExcel from "./CreateMenuItemByExcel";
const { Option } = Select;
class CreateMenuItem extends Component {
  constructor(props) {
    super(props);
    const restaurant = JSON.parse(localStorage.getItem("restaurant"));
    this.state = {
      restaurant,
      actualPrice: "",
      description: "",
      discount: "",
      category: "",
      menuItemName: "",
      restaurantId: "",
      image: "",
      imageUrl: "",
    };
    this.onChange = this.onChange.bind(this);
    this.onSubmit = this.onSubmit.bind(this);
    this.handleChange = this.handleChange.bind(this);
    this.oncategoryTypeChange = this.oncategoryTypeChange.bind(this);
    this.handleChangeImageURL = this.handleChangeImageURL.bind(this);
  }
  handleChangeImageURL(event) {
    this.setState({
      image: event.target.value,
      imageUrl: event.target.value,
    });
    console.log("state changed", this.state);
  }
  oncategoryTypeChange = (event) => {
    this.setState({ category: event });
  };
  onChange(event) {
    this.setState({ [event.target.name]: event.target.value });
  }
  onSubmit(event) {
    console.log("crt mi", this.state);
    const query = `mutation MyMutation {
          createMenuItem(input: {actualPrice: ${this.state.actualPrice}, description: "${this.state.description}", discount: ${this.state.discount},category: ${this.state.category}, menuItemName: "${this.state.menuItemName}", restaurantId: "${this.state.restaurant.id}", image: "${this.state.image}"})
        {
            actualPrice
            description
            discount
            category
            menuItemId
            menuItemName
            price
            restaurantId
            image
        }
        }
    `;

    this.props.createMenuItem(query, this.props.props.history);
  }
  dummyRequest({ file, onSuccess }) {
    setTimeout(() => {
      onSuccess("ok");
    }, 0);
  }

  handleChange(info) {
    if (info.file.status === "uploading") {
      return;
    }
    if (info.file.status === "done") {
      util.getBase64(info.file.originFileObj, (image) => {
        this.setState({
          image,
        });
      });
    }
  }
  render() {
    return (
      <div>
        <section className="h-50 bg-light">
          <div className="row d-flex justify-content-center align-items-center">
            <h5 className="form-title text-center">Create Menu item</h5>
            <div className="col">
              <div class="card card-Registration my-4">
                <div>
                  <div className="row">
                    <div className="col"></div>
                    <div className="col-6">
                      <div class="card-body p-md-5 text-black">
                        {/* start */}
                        <div className="createRestaurant-content">
                          <div className="createRestaurant-form-register">
                            <Form
                              name="register"
                              scrollToFirstError
                              onFinish={this.onSubmit}
                            >
                              <Form.Item
                                name="Item Name"
                                className="CreateMenuItem-register-input"
                                rules={[{ required: true }]}
                              >
                                <Input
                                  prefix={
                                    <ShopOutlined className="site-form-item-icon" />
                                  }
                                  type="string"
                                  name="menuItemName"
                                  id="menuItemName"
                                  placeholder="Item Name"
                                  value={this.state.menuItemName}
                                  onChange={this.onChange}
                                />
                              </Form.Item>

                              <Form.Item
                                name="description"
                                className="CreateMenuItem-register-input"
                              >
                                <Input
                                  prefix={
                                    <EditOutlined className="site-form-item-icon" />
                                    // < className="fas fa-hotel" />
                                  }
                                  type="string"
                                  name="description"
                                  id="description"
                                  placeholder="Discription"
                                  value={this.state.description}
                                  onChange={this.onChange}
                                />
                              </Form.Item>

                              <Form.Item
                                name="actualPrice"
                                className="CreateMenuItem-register-input"
                                rules={[
                                  {
                                    required: true,
                                    message: "Please enter your price!",
                                  },

                                  ({ getFieldValue }) => ({
                                    validator(_, value) {
                                      var hasAlphabets = /^\d*\.?\d*$/;
                                      if (
                                        parseInt(
                                          getFieldValue("actualPrice")
                                        ) &&
                                        hasAlphabets.test(
                                          getFieldValue("actualPrice")
                                        )
                                      ) {
                                        return Promise.resolve();
                                      }
                                      return Promise.reject(
                                        "Should contain numbers only!"
                                      );
                                    },
                                  }),
                                ]}
                              >
                                <Input
                                  type="text"
                                  prefix={
                                    <DollarOutlined className="site-form-item-icon" />
                                    // < className="fas fa-hotel" />
                                  }
                                  name="actualPrice"
                                  id="actualPrice"
                                  placeholder="Price"
                                  value={this.state.actualPrice}
                                  onChange={this.onChange}
                                />
                              </Form.Item>

                              <Form.Item
                                name="discount"
                                className="CreateMenuItem-register-input"
                                rules={[
                                  {
                                    required: true,
                                    message: "Please enter discount!",
                                  },

                                  ({ getFieldValue }) => ({
                                    validator(_, value) {
                                      var hasAlphabets = /^\d*\.?\d*$/;
                                      if (
                                        parseInt(getFieldValue("discount")) &&
                                        hasAlphabets.test(
                                          getFieldValue("discount")
                                        )
                                      ) {
                                        return Promise.resolve();
                                      }
                                      return Promise.reject(
                                        "Should contain numbers only!"
                                      );
                                    },
                                  }),
                                ]}
                              >
                                <Input
                                  type="text"
                                  prefix={
                                    <PercentageOutlined className="site-form-item-icon" />
                                    // < className="fas fa-hotel" />
                                  }
                                  name="discount"
                                  id="discount"
                                  placeholder="Discount"
                                  value={this.state.discount}
                                  onChange={this.onChange}
                                />
                              </Form.Item>
                              <Form.Item
                                name="category"
                                // label="Category"
                                showSearch
                                rules={[
                                  {
                                    required: true,
                                    message: "Please select Type!",
                                  },
                                ]}
                              >
                                <Select
                                  placeholder="Select category"
                                  name="category"
                                  id="category"
                                  value={this.state.category}
                                  onChange={this.oncategoryTypeChange}
                                >
                                  <Option value="Dessert">Dessert</Option>
                                  <Option value="MainCourse">
                                    Main Course
                                  </Option>
                                  <Option value="ChineseFood">
                                    Chinese Food
                                  </Option>
                                  <Option value="PizzaandSandwich">
                                    Pizza and Sandwich
                                  </Option>
                                  <Option value="Drinks">Drinks</Option>
                                </Select>
                              </Form.Item>

                              <Form.Item>
                                <ImgCrop aspect={7 / 7}>
                                  <Upload
                                    name="file"
                                    className="avatar-uploader"
                                    customRequest={this.dummyRequest}
                                    onChange={this.handleChange}
                                    multiple={false}
                                  >
                                    <Button icon={<UploadOutlined />}>
                                      Upload Image
                                    </Button>
                                  </Upload>
                                </ImgCrop>
                              </Form.Item>
                              <div className="row  align-items-center mx-5">
                                <b>OR</b>
                              </div>
                              <div className="row d-flex ">
                                <div class="card-body  text-black">
                                  <Form.Item
                                    name="imageUrl"
                                    // initialValue={menuItem.discount}
                                  >
                                    <Input
                                      type="text"
                                      name="imageUrl"
                                      id="imageUrl"
                                      placeholder="Upload Image URL"
                                      value={this.state.imageUrl}
                                      onChange={this.handleChangeImageURL}
                                    />
                                  </Form.Item>
                                </div>
                              </div>
                              <Form.Item>
                                <Button type="primary" htmlType="submit">
                                  CreateMenuItem
                                </Button>
                              </Form.Item>
                            </Form>
                          </div>
                          <div className="createRestaurant-image-register"></div>
                        </div>
                      </div>
                      <CreateMenuItemByExcel props={this.props.props} />
                    </div>
                    <div className="col"></div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
      </div>
    );
  }
}
export default connect(null, {
  createMenuItem,
})(CreateMenuItem);
