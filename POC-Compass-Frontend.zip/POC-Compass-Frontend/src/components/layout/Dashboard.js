import React, { Component } from "react";
import { Redirect } from "react-router-dom";
import constant, { userType } from "../../util/constant";
import Login from "../authentication/Login";
import DeliveryDashboard from "../delivery/delivery-of-deliveryboy/DeliveryDashboard";
import RestaurantDashboard from "../restaurant/RestaurantDashboard";
import UserDashboard from "../user/UserDashboard";
import { isExpired, decodeToken } from "react-jwt";

class Dashboard extends Component {
  constructor(props) {
    super(props);
    const token = localStorage.getItem("token");

    let IsLoggedIn = false;
    let userType = null;
    console.log("token", token);

    if (token) {
      const decodedToken = decodeToken(token);
      const isTokenExpired = isExpired(token);
      if (
        !isTokenExpired &&
        decodedToken.userType === constant.userType.RESTAURANT_OWNER
      ) {
        IsLoggedIn = true;
        userType = decodedToken.userType;
      }
      if (!isTokenExpired && decodedToken.userType === constant.userType.USER) {
        IsLoggedIn = true;
        userType = decodedToken.userType;
      }
      if (
        !isTokenExpired &&
        decodedToken.userType === constant.userType.DELIVERY_BOY
      ) {
        IsLoggedIn = true;
        userType = decodedToken.userType;
      }
    }

    this.state = {
      IsLoggedIn,
      userType,
    };
  }

  render() {
    switch (this.state.userType) {
      case constant.userType.RESTAURANT_OWNER:
        return <RestaurantDashboard props={this.props} />;
      case constant.userType.USER:
        return <UserDashboard props={this.props} />;
      case constant.userType.DELIVERY_BOY:
        return <DeliveryDashboard props={this.props} />;
      default:
        return <Redirect to="/login" />;
    }
  }
}
export default Dashboard;
