import React, { Component } from "react";
import { Navbar, Container, NavDropdown } from "react-bootstrap";
import { Badge } from "antd";
import { ShoppingCartOutlined } from "@ant-design/icons";
import { BiHelpCircle } from "react-icons/bi";
import discount from "./../../assets/images/discount.png";
import { Link } from "react-router-dom";
import { decodeToken } from "react-jwt";
import { connect } from "react-redux";

class UserHeader extends Component {
  constructor(props) {
    super(props);
    const user = decodeToken(localStorage.getItem("token"));

    this.state = {
      user,
    };
    this.onClickHome = this.onClickHome.bind(this);
  }
  onClickHome() {
    this.props.props.history.push('/')
  }

  onLogoutClick(event) {
    localStorage.removeItem("token");
    window.location.href = "/";
  }
  render() {
    const { cartItems } = this.props;
    return (
      <Navbar
        className="user-header text-dark"
        collapseOnSelect
        expand="lg"
        variant="dark"
      >
        <Container className="text-dark">
          <img
            alt=""
            src={require("../../assets/images/logo.png")}
            width="47"
            height="47"
            className="d-inline-block align-top"
            onClick={this.onClickHome}
          />
          <Navbar.Brand className="text-dark " id="logo-text" onClick={this.onClickHome}>
            &nbsp;&nbsp;&nbsp;&nbsp;Food Delivery App
          </Navbar.Brand>
          <Navbar.Toggle aria-controls="responsive-navbar-nav" />
          <Navbar.Collapse className="justify-content-end">
            <div class="d-flex">
              <div class="mt-3 help-box">
                <Navbar.Brand href="#" className="text-dark " id="help">
                  <span>
                    <img
                      alt="example"
                      src={discount}
                      style={{ width: "20px" }}
                    />
                    &nbsp; Offers
                  </span>
                </Navbar.Brand>
              </div>
              <div class="mt-3 help-box">
                <Navbar.Brand href="#" className="text-dark " id="help">
                  <BiHelpCircle /> &nbsp;Help
                </Navbar.Brand>
              </div>
              <div class="p-2 ">
                <NavDropdown
                  title={`${this.state.user.firstName} ${this.state.user.lastName}`}
                  id="collasible-nav-dropdown-user"
                >
                  <NavDropdown.Item>
                    {" "}
                    <Link
                      className="profile-link"
                      to={{
                        pathname: `/my-account`,
                      }}
                    >
                      Profile
                    </Link>
                  </NavDropdown.Item>
                  <NavDropdown.Item>Orders</NavDropdown.Item>
                  <NavDropdown.Item onClick={this.onLogoutClick}>
                    Logout
                  </NavDropdown.Item>
                </NavDropdown>
              </div>
              <div class="p-2">
                {console.log(this.props)}
                <Link
                  to={{
                    pathname: `/checkout`,
                  }}
                  className="text-decoration-none"
                >
                  <Navbar.Brand href="#" id="cart">
                    <Badge size="default" count={cartItems.length}>
                      <ShoppingCartOutlined id="cart-icon" />
                    </Badge>
                  </Navbar.Brand>
                </Link>
              </div>
            </div>
          </Navbar.Collapse>
        </Container>
      </Navbar>
    );
  }
}

const mapStateToProps = (state) => ({
  cartItems: state.cartReducer.cartItems,
});
export default connect(mapStateToProps, {})(UserHeader);
