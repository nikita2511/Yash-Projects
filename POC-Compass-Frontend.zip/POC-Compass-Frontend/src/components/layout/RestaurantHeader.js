import React, { Component } from "react";
import { Navbar, Container, NavDropdown } from "react-bootstrap";
import { isExpired, decodeToken } from "react-jwt";

class RestaurantHeader extends Component {
  constructor(props) {
    super(props);
    const user = decodeToken(localStorage.getItem("token"));

    this.state = {
      user,
    };
  }

  onLogoutClick(event) {
    localStorage.removeItem("token");
    window.location.href = "/";
  }
  render() {
    return (
      <Navbar collapseOnSelect expand="lg" bg="dark" variant="dark">
        <Container className="text-light">
          <img
            alt=""
            src={require("../../assets/images/logo.png")}
            width="47"
            height="47"
            className="d-inline-block align-top"
          />
          <Navbar.Brand href="#" className="text-light">
            &nbsp;&nbsp;&nbsp;&nbsp;Food Delivery App
          </Navbar.Brand>

          <Navbar.Toggle aria-controls="responsive-navbar-nav" />
          <Navbar.Collapse className="justify-content-end">
            {/* <Navbar.Text> */}
            Signed in as:
            <NavDropdown
              title={`${this.state.user.firstName} ${this.state.user.lastName}`}
              id="collasible-nav-dropdown"
            >
              <NavDropdown.Item>Profile</NavDropdown.Item>
              <NavDropdown.Item>Notifications</NavDropdown.Item>
              <NavDropdown.Item onClick={this.onLogoutClick}>
                Logout
              </NavDropdown.Item>
            </NavDropdown>
            {/* </Navbar.Text> */}
          </Navbar.Collapse>
        </Container>
      </Navbar>
    );
  }
}
export default RestaurantHeader;
