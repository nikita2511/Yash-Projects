import  React, { Component } from "react";
import { Navbar, Container, Nav } from "react-bootstrap";
import { Link } from "react-router-dom";
export default class SignInUpHeader extends Component {
  render() {
    return (
    <Navbar collapseOnSelect expand="lg" bg="dark" variant="dark">
      <Container className="text-light">
      <img
          alt=""
          src={require('../../assets/images/logo.png')}
          width="47"
          height="47"
          className="d-inline-block align-top"
        />
        <Navbar.Brand href="#" className="text-light" >
        &nbsp;&nbsp;&nbsp;&nbsp;Food Delivery App
        </Navbar.Brand>

        <Navbar.Toggle aria-controls="navbarScroll" />
        <Navbar.Collapse className="justify-content-end">
          <Nav>
            <Nav.Link href="#action1">
              <Link to="/" className="nav-link text-light">
                Login
              </Link>
            </Nav.Link>
            <Nav.Link href="#action1">
              <Link to="/registration" className="nav-link text-light">
                Register
              </Link>
            </Nav.Link>
          </Nav>
        </Navbar.Collapse>
        </Container>
      </Navbar>
    );
  }
}
