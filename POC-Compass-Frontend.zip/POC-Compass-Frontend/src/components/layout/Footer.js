import React, { Component } from 'react';
import { Layout } from 'antd';


class Footer extends Component {
  render() {
    const { Footer } = Layout;
    return (
        <Footer style={{ textAlign: 'center' }}>Food Delivery App ©2022 Design & Created by Compass Team, YASH Technologies Pvt. Ltd.</Footer>
    )
  }
}
export default Footer;