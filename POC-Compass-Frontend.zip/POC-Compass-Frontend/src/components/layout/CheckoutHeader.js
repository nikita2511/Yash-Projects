import React, { Component } from "react";
import { Navbar, Container, NavDropdown } from "react-bootstrap";
import { Form, Input } from "antd";
import { ShoppingCartOutlined, SearchOutlined } from "@ant-design/icons";
import { BiHelpCircle } from "react-icons/bi";
import discount from "./../../assets/images/discount.png";
import { Link } from "react-router-dom";
import Checkout from "./../user/Checkout";
import { isExpired, decodeToken } from "react-jwt";

class UserHeader extends Component {
  constructor(props) {
    super(props);
    const user = decodeToken(localStorage.getItem("token"));

    this.state = {
      user,
    };
  }

  onLogoutClick(event) {
    localStorage.removeItem("token");
    window.location.href = "/";
  }
  render() {
    return (
      <Navbar
        className="user-header text-dark"
        collapseOnSelect
        expand="lg"
        variant="dark"
      >
        <Container className="text-dark">
          <img
            alt=""
            src={require("../../assets/images/logo.png")}
            width="47"
            height="47"
            className="d-inline-block align-top"
          />

          <Navbar.Brand href="#" className="text-dark fw-bold" id="logo-text">
            <span
              style={{
                fontFamily: "ProximaNova,arial,Helvetica Neue,sans-serif",
                fontSize: "80%",
                marginLeft: "20%",
              }}
            >
              SECURE CHECKOUT
            </span>
          </Navbar.Brand>
          <Navbar.Toggle aria-controls="responsive-navbar-nav" />
          <Navbar.Collapse className="justify-content-end">
            <div class="d-flex">
              <div class="mt-3 help-box">
                <Navbar.Brand href="#" className="text-dark " id="help">
                  <BiHelpCircle /> &nbsp;Help
                </Navbar.Brand>
              </div>
              <div class="p-2 ">
                <NavDropdown
                  title={`${this.state.user.firstName} ${this.state.user.lastName}`}
                  id="collasible-nav-dropdown-user"
                >
                  <NavDropdown.Item>Profile</NavDropdown.Item>
                  <NavDropdown.Item>Orders</NavDropdown.Item>
                  <NavDropdown.Item onClick={this.onLogoutClick}>
                    Logout
                  </NavDropdown.Item>
                </NavDropdown>
              </div>
            </div>

            {/* </Navbar.Text> */}
          </Navbar.Collapse>
        </Container>
      </Navbar>
    );
  }
}
export default UserHeader;
