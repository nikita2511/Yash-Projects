import React, { Component } from "react";
import { Row, Card } from "antd";
import { HomeOutlined } from "@ant-design/icons";
import { decodeToken } from "react-jwt";
class Addresses extends Component {
  constructor(props) {
    super(props);
    const user = decodeToken(localStorage.getItem("token"));
    this.state = {
      user,
      showHideToggle: true,
    };
  }
  render() {
    return (
      <div className="col-8 p-4 px-5">
        <div className="container bg-white border ">
          <div>
            <Row className="mt-4 fw-600">
              <h2>Address</h2>
            </Row>
            <div className="row p-5">
              <div className="col-6">
                {" "}
                <div
                  className="site-card-border-less-wrapper"
                  id="delivery-address-card"
                >
                  <Card
                    title={
                      <div>
                        <Row>
                          <HomeOutlined />

                          <span style={{ marginLeft: "6%" }}>Home</span>
                        </Row>
                      </div>
                    }
                    bordered={true}
                    style={{ width: 300, height: 200 }}
                  >
                    <Row>
                      <p
                        className="text-secondary"
                        style={{
                          fontFamily:
                            "ProximaNova,arial,Helvetica Neue,sans-serif",
                          fontSize: "90%",
                        }}
                      >
                        {this.state.user.address.location}&nbsp;
                        {this.state.user.address.city} &nbsp;
                        {this.state.user.address.state}&nbsp;
                        {this.state.user.address.pinCode}
                      </p>
                    </Row>
                  </Card>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default Addresses;
