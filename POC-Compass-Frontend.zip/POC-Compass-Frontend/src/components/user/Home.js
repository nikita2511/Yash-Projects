import React, { Component } from "react";
import { getRestaurants } from "../../actions/restaurantAction";
import { connect } from "react-redux";
import { Row, Empty, Spin } from "antd";
import RestaurantDetail from "./../restaurant/RestaurantDetail";
import FilterRestaurants from "../restaurant/FilterRestaurants";

class Home extends Component {
  constructor(props) {
    super(props);
    this.state = {
      loading: true,
    };
    this.loadingFalse = this.loadingFalse.bind(this);
  }
  loadingFalse() {
    this.setState({
      loading: false,
    });
  }
  componentDidMount() {
    console.log("inside CDM");
    const query = `
    query MyQuery {
    getRestaurantList {
    rating {
    currentRating
    sum
    totalNumberOfUser
    }
    image
    id
    category
    address {
    city
    lat
    lng
    location
    pinCode
    state
    }
    restaurantName
    sortKey
    userId
    }
    }
    `;
    this.props.getRestaurants(query, this.loadingFalse);
  }

  render() {
    const restaurants = this.props.restaurants;
    console.log(restaurants);
    return (
      <div className="bg-light restaurant-container">
        <div className="bg-light d-flex"></div>
        <FilterRestaurants props={this.props.props} />
        <div className="container d-flex align-items-start ">
          <Row gutter={{ sm: 80 }} className="restaurants">
            {(() => {
              if (this.state.loading) {
                return (
                  <div className="row w-100">
                    <div className="col-4"></div>
                    <div className="col-4 text-center">
                      <Spin size="large" className="spin" />
                    </div>
                    <div className="col-4"></div>
                  </div>
                );
              } else {
                return !restaurants.length ? (
                  <div className="">
                    <Empty description={<span>No Items</span>} />
                  </div>
                ) : (
                  restaurants.map((element) => {
                    return (
                      <RestaurantDetail
                        restaurant={element}
                        props={this.props.props}
                        key={element.id}
                      />
                    );
                  })
                );
              }
            })()}
          </Row>
        </div>
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  errors: state.errors,
  restaurants: state.restaurant.restaurants,
});

export default connect(mapStateToProps, {
  getRestaurants,
})(Home);
