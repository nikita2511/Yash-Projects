import React, { Component } from "react";
import UserHeader from "./../layout/UserHeader";
import Home from "./Home";
import Footer from "../../components/layout/Footer";
import ViewRestaurant from "../restaurant/ViewRestaurant";
import Checkout from "./Checkout";
import OrderTrack from "./../order/OrderTrack";
import Profile from "./Profile";

class UserDashboard extends Component {
  renderRoutes(pathname) {
    pathname = pathname.includes("/order-track") ? "/order-track" : pathname;
    switch (pathname) {
      case "/get-restaurant":
        return <ViewRestaurant props={this.props.props} />;
      case "/checkout":
        return <Checkout props={this.props.props} />;
      case "/order-track":
        return <OrderTrack props={this.props.props} />;
      case "/my-account":
        return <Profile props={this.props.props} />;
      case "/my-account/my-orders":
        return <Profile props={this.props.props} />;
      case "/my-account/addresses":
        return <Profile props={this.props.props} />;
      case "/my-account/payments":
        return <Profile props={this.props.props} />;
      case "/my-account/settings":
        return <Profile props={this.props.props} />;
      default:
        return <Home props={this.props.props} />;
    }
  }
  render() {
    const { pathname } = this.props.props.location;
    return (
      <div>
        <div className="user-header">
          {" "}
          <UserHeader props={this.props.props} />
        </div>

        {this.renderRoutes(pathname)}

        <Footer />
      </div>
    );
  }
}
export default UserDashboard;
