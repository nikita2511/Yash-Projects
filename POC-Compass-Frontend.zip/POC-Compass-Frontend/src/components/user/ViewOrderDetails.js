import React, { Component } from "react";
import { Row, Col } from "antd";
import {
  AiFillCheckCircle,
  AiOutlineHome,
  AiOutlineWarning,
} from "react-icons/ai";
import vegIcon from "./../../assets/images/veg-icon.png";
import { BiRupee } from "react-icons/bi";
import { MdDeliveryDining } from "react-icons/md";
import { GoLocation } from "react-icons/go";
import { decodeToken } from "react-jwt";
import constant from "../../util/constant";
class ViewOrderDetails extends Component {
  constructor(props) {
    super(props);
    const user = decodeToken(localStorage.getItem("token"));
    this.state = { visible: false, user };
  }
  hideModal = () => {
    this.setState({
      visible: false,
    });
  };
  render() {
    const { order } = this.props;
    let deliveryTime;
    if (order.orderStatus === constant.orderStatusString.Delivered) {
      deliveryTime = new Date(order.delivery.deliveredTime).toLocaleString();
    }
    return (
      <div>
        <div className="row">
          <div className="col-1 text-end">
            <GoLocation size={20} />
          </div>
          <div className="col-3">
            <span className="h6"> {order.restaurant.restaurantName}</span>
          </div>
        </div>
        <div className="row">
          <div className="col-1 "></div>
          <div className="col-3">
            <small>{order.restaurant.address.city}</small>
          </div>
        </div>
        <div className="row mt-4">
          <div className="col-1">
            <AiOutlineHome size={20} />
          </div>
          <div className="col-3">
            <span className="h6"> Home</span>
          </div>
        </div>
        <div className="row">
          <div className="col-1"></div>
          <div className="col-8">
            <small>
              {this.state.user.address.location},{this.state.user.address.city}{" "}
              ,{this.state.user.address.pinCode},{this.state.user.address.state}
            </small>
          </div>
        </div>
        <hr className="container" style={{ width: "95%", height: ".1px" }} />

        {order.orderStatus === "Failed" ? (
          <div className="row">
            <div className="col-8">
              <small>Order Failed/Rejected</small>&nbsp;
              <AiOutlineWarning className="text-danger" size={20} />
            </div>
          </div>
        ) : order.orderStatus === "Delivered" ? (
          <div className="row">
            {" "}
            <div className="col-8 ">
              <small>Delivered on {deliveryTime}</small>&nbsp;
              <AiFillCheckCircle className="text-success" size={20} />
            </div>
          </div>
        ) : (
          <div className="row">
            {" "}
            <div className="col-8 ">
              <small>Delivery In Progress</small>&nbsp;
              <MdDeliveryDining className="text-success" size={20} />
            </div>
          </div>
        )}
        <hr className="container" style={{ width: "95%", height: ".5px" }} />
        <hr className="container" style={{ width: "95%", height: ".5px" }} />
        {order.orderItem.map((item) => {
          return (
            <Row className="my-3">
              <Col span={1}>
                <span>
                  <img alt="example" src={vegIcon} style={{ width: "12px" }} />
                </span>
              </Col>
              <Col span={8}>
                <span className="cart-text">
                  {item.menuItem.menuItemName} x {item.quantity}
                </span>
              </Col>

              <Col span={8}>
                <span className="cart-text">
                  <BiRupee />
                  {item.menuItem.price}
                </span>
              </Col>
            </Row>
          );
        })}

        <hr className="container" style={{ width: "95%", height: ".5px" }} />
        <Row>
          <Col span={1}>
            <span></span>
          </Col>
          <Col span={8}>
            <span className="cart-text">Item Total</span>
          </Col>
          <Col span={8}>
            <span className="cart-text">
              <BiRupee />
              {order.totalPrice}
            </span>
          </Col>
        </Row>
        <Row>
          <Col span={1}>
            <span></span>
          </Col>
          <Col span={8}>
            <small className="cart-text">Delivery Partner fee</small>
          </Col>
          <Col span={8}>
            <small className="cart-text">
              <BiRupee />
              00
            </small>
          </Col>
        </Row>
        <Row>
          <Col span={1}>
            <span></span>
          </Col>
          <Col span={8}>
            <small className="cart-text">Taxes</small>
          </Col>
          <Col span={8}>
            <small className="cart-text">
              <BiRupee />
              00
            </small>
          </Col>
        </Row>
        <hr className="container" style={{ width: "95%", height: ".5px" }} />
        <Row>
          <Col span={1}>
            <span></span>
          </Col>
          <Col span={4}>
            <small className="cart-text">paid via cash</small>
          </Col>
          <Col span={4}>
            <span className=" h6 cart-text">Bill Total</span>
          </Col>
          <Col span={6}>
            <span className="cart-text">
              <BiRupee />
              {order.totalPrice}
            </span>
          </Col>
        </Row>
      </div>
    );
  }
}

export default ViewOrderDetails;
