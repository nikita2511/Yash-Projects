import React, { Component } from "react";
import { BiRupee } from "react-icons/bi";
import { Image, Space, Button, Modal } from "antd";
import { AiFillCheckCircle, AiOutlineWarning } from "react-icons/ai";
import { MdOutlineCardGiftcard } from "react-icons/md";
import { Link } from "react-router-dom";
import ViewOrderDetails from "./ViewOrderDetails";
import constant from "../../util/constant";
import { updateOrderStatusByPusher } from "../../actions/orderActions";
import { connect } from "react-redux";

class Order extends Component {
  state = { visible: false };
  showModal = () => {
    this.setState({
      visible: true,
    });
  };

  hideModal = () => {
    this.setState({
      visible: false,
    });
  };
  dispatchOrder(order) {
    console.log("dispatched order", order);
    this.props.updateOrderStatusByPusher(order);
  }
  render() {
    const { order } = this.props;
    var orderDate = new Date(order.orderDate).toString();
    let deliveryTime;
    orderDate = orderDate.split(" ", 5).join(" ");
    orderDate = orderDate.slice(0, -3);
    if (order.orderStatus === constant.orderStatusString.Delivered) {
      deliveryTime = new Date(order.delivery.deliveredTime).toLocaleString();
    }

    return (
      <div className="border my-3">
        <div className="container mt-3 p-3 ">
          <div className="row">
            <div className="col-2">
              {" "}
              <Image width={120} src={order.restaurant.image} />
            </div>
            <div className="col-5">
              {" "}
              <div className="row">
                {" "}
                <span className="">{order.restaurant.restaurantName}</span>
              </div>
              <div className="row">
                {" "}
                <span className="small-text">
                  {order.restaurant.address.city} city
                </span>
              </div>
              <div className="row">
                <span className="small-text">
                  {order.orderId} | {orderDate}PM
                </span>
              </div>
              <div className="row">
                <div className="text-success">
                  <a>
                    <span
                      className="fw-bold text-danger mt-3"
                      onClick={this.showModal}
                    >
                      View Details
                    </span>
                  </a>
                </div>
              </div>
            </div>
            {order.orderStatus === constant.orderStatusString.Failed ||
            order.orderStatus === constant.orderStatusString.Reject ? (
              <div className="col-5 text-end">
                <small>Order Canceled/Rejected</small>&nbsp;
                <AiOutlineWarning className="text-danger" size={20} />
              </div>
            ) : order.orderStatus === constant.orderStatusString.Delivered ? (
              <div className="col-5 text-end">
                <small>Delivered at {deliveryTime}</small>&nbsp;
                <AiFillCheckCircle className="text-success" size={20} />
              </div>
            ) : (
              <div className="col-5 text-end">
                <small>Order Confirmed</small>
                &nbsp;
                <MdOutlineCardGiftcard size={20} style={{ color: "#4DB6AC" }} />
              </div>
            )}
          </div>
          <hr className="container" style={{ width: "95%", height: ".5px" }} />
          <div className="row" style={{ fontWeight: "350" }}>
            <div className="col-6">
              {order.orderItem.map((item, index) => {
                return (
                  <span>
                    {item.menuItem.menuItemName} x {item.quantity}
                    {index === order.orderItem.length - 1 ? (
                      <span></span>
                    ) : (
                      <span>,</span>
                    )}
                  </span>
                );
              })}
            </div>
            <div className="col-6">
              <span className="small-text float-end">
                Total Paid: <BiRupee />
                {order.totalPrice}
              </span>
            </div>
          </div>
          <div className="row mt-2">
            <Space>
              {order.orderStatus === constant.orderStatusString.Delivered ||
              order.orderStatus === constant.orderStatusString.Failed ||
              order.orderStatus === constant.orderStatusString.Reject ? (
                <Button type="primary" className="px-5" danger size="large">
                  Reorder
                </Button>
              ) : (
                <Button
                  type="primary"
                  className="px-5"
                  danger
                  size="large"
                  onClick={() => this.dispatchOrder(order)}
                >
                  <Link
                    to={`/order-track/${order.orderId}`}
                    className="link-deocration"
                  >
                    Track
                  </Link>
                </Button>
              )}

              <Button danger className="px-5" size="large">
                Help
              </Button>
            </Space>
          </div>
        </div>
        <Modal
          title={order.orderId}
          visible={this.state.visible}
          onCancel={this.hideModal}
          cancelText="close"
        >
          <ViewOrderDetails order={order} />
        </Modal>
      </div>
    );
  }
}

export default connect(null, {
  updateOrderStatusByPusher,
})(Order);
