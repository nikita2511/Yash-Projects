import React, { Component } from "react";
import { MdOutlinePayments, MdAddLocation } from "react-icons/md";
import CartItem from "../cart/CartItem";
import { BiRupee } from "react-icons/bi";
import { decodeToken } from "react-jwt";
import { connect } from "react-redux";
import { TiTick } from "react-icons/ti";
import Payment from "../payment/Payment";
import { Row, Card, Button } from "antd";
import { HomeOutlined } from "@ant-design/icons";
import EmptyCart from "../cart/EmptyCart";

class Checkout extends Component {
  constructor(props) {
    super(props);
    const user = decodeToken(localStorage.getItem("token"));
    this.state = {
      user,
      showHideToggle: true,
    };
    this.showPayment = this.showPayment.bind(this);
  }
  showPayment = () => {
    this.setState({ showHideToggle: false });
  };
  render() {
    const { cartItems } = this.props;
    var totalPrice = 0;
    cartItems.map((element) => {
      totalPrice = totalPrice + element.totalPrice;
    });

    return (
      <div>
        {cartItems.length === 0 ? (
          <EmptyCart />
        ) : (
          <div className="checkout-container">
            <div className="row">
              {this.state.showHideToggle ? (
                <div className="col-8 p-4 px-5">
                  <div className="container bg-white border ">
                    <div>
                      <Row className="mt-4 fw-600">
                        <h2>Choose a delivery address</h2>
                      </Row>
                      <div className="row p-5">
                        <div className="col-6">
                          {" "}
                          <div
                            className="site-card-border-less-wrapper"
                            id="delivery-address-card"
                          >
                            <Card
                              title={
                                <div>
                                  <Row>
                                    <HomeOutlined />

                                    <span style={{ marginLeft: "6%" }}>
                                      Home
                                    </span>
                                  </Row>
                                </div>
                              }
                              bordered={true}
                              style={{ width: 300, height: 200 }}
                            >
                              <Row>
                                <div
                                  className="text-secondary"
                                  style={{
                                    fontFamily:
                                      "ProximaNova,arial,Helvetica Neue,sans-serif",
                                    fontSize: "90%",
                                  }}
                                >
                                  <div className="row">
                                    <small>
                                      {this.state.user.address.location}
                                    </small>
                                  </div>
                                  <div className="row">
                                    <small>
                                      {this.state.user.address.city}
                                    </small>
                                  </div>
                                  <div className="row">
                                    <small>
                                      {this.state.user.address.state},{" "}
                                      {this.state.user.address.pinCode}
                                    </small>
                                  </div>
                                </div>
                              </Row>

                              <Row className="mt-3">
                                <Button
                                  type="success"
                                  size="large"
                                  className="fw-bold mb-2 "
                                  id="deliver-here-btn"
                                  onClick={this.showPayment}
                                >
                                  Deliver Here
                                </Button>
                              </Row>
                            </Card>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div className="container bg-white border mt-2 ">
                    <div style={{ marginLeft: "-3%" }}>
                      <Row>
                        <span className="text-secondary h3 ">
                          <span>
                            <MdOutlinePayments />
                          </span>
                          &nbsp; Payment
                        </span>
                      </Row>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="col-8 p-4 px-5">
                  <div className="container bg-white border p-5">
                    <Row id="location-icon">
                      <MdAddLocation size={40} />
                    </Row>
                    <Row>
                      <span className="h2">Delivery address</span>
                      <TiTick
                        color="white"
                        style={{
                          backgroundColor: "#40b040",
                          width: "4%",
                          borderRadius: "20px",
                          marginLeft: "3%",
                          marginTop: "2%",
                        }}
                      />
                    </Row>
                    <Row className="mt-2">
                      <span className="h6">Home</span>
                    </Row>
                    <Row>
                      <small
                        className="text-secondary"
                        style={{
                          fontFamily:
                            "ProximaNova,arial,Helvetica Neue,sans-serif",
                          fontSize: "90%",
                        }}
                      >
                        {this.state.user.address.location}&nbsp;
                      </small>
                      <small
                        className="text-secondary"
                        style={{
                          fontFamily:
                            "ProximaNova,arial,Helvetica Neue,sans-serif",
                          fontSize: "90%",
                        }}
                      >
                        {this.state.user.address.city} &nbsp;
                      </small>
                      <small
                        className="text-secondary"
                        style={{
                          fontFamily:
                            "ProximaNova,arial,Helvetica Neue,sans-serif",
                          fontSize: "90%",
                        }}
                      >
                        {this.state.user.address.state}&nbsp;
                        {this.state.user.address.pinCode}
                      </small>
                    </Row>
                  </div>
                  <div className="container bg-white border mt-2 ">
                    <div>
                      <Payment toPay={totalPrice} props={this.props} />
                    </div>
                  </div>
                </div>
              )}

              <div className="col-4 p-4">
                {" "}
                <div className="container bg-white border ">
                  <div className="row p-2">
                    <div className="col-3">
                      <img
                        width={70}
                        src="https://burst.shopifycdn.com/photos/berries-granola.jpg?width=925&exif=1&iptc=1&attachment=berries-granola.jpg"
                        alt="Snow"
                      />
                    </div>
                    <div className="col-6">
                      <span className="h6" style={{ fontSize: "90%" }}>
                        {this.props.restaurantDetails.restaurantName}
                      </span>
                      <div style={{ fontSize: "80%" }}>
                        {this.props.restaurantDetails.address.city},{" "}
                        {this.props.restaurantDetails.address.state}
                      </div>
                    </div>
                  </div>
                  <div
                    className="row p-2"
                    style={{ height: "250px", overflow: "auto" }}
                  >
                    {cartItems.map((element) => {
                      return (
                        <CartItem cartItem={element} key={element.cartItemId} />
                      );
                    })}
                    <div className="row">
                      <div className="col-6">Bill Details</div>
                      <div className="col-6"></div>
                    </div>
                    <div className="row" id="billing-details">
                      <div className="col-8">Item Totals</div>
                      <div className="col-4">
                        <BiRupee />
                        {totalPrice}
                      </div>
                    </div>
                    <div className="row" id="billing-details">
                      <div className="col-8">Delivery Partner fee</div>
                      <div className="col-4">
                        <BiRupee />0
                      </div>
                    </div>
                    <hr
                      className="container"
                      style={{ width: "80%", height: ".3px" }}
                    />
                    <div className="row" id="billing-details">
                      <div className="col-8">Taxes and Charges</div>
                      <div className="col-4">
                        <BiRupee />0
                      </div>
                    </div>
                  </div>
                  <div className="row p-2">
                    <div className="col-7 h6">To Pay</div>
                    <div className="col-5 h6">
                      <BiRupee />
                      <span>{totalPrice}</span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }
}
const mapStateToProps = (state) => ({
  errors: state.errors,
  restaurantDetails: state.restaurant.restaurantDetails,
  cartItems: state.cartReducer.cartItems,
});
export default connect(mapStateToProps, {})(Checkout);
