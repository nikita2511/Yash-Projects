import React, { Component } from "react";
import { Row, Col, Card, Affix } from "antd";
import MyOrders from "./MyOrders";
import { Link } from "react-router-dom";
import Addresses from "./Addresses";
import Settings from "./Settings";
import { MdOutlineCardGiftcard } from "react-icons/md";
import { GrLocation } from "react-icons/gr";
import { AiOutlineSetting } from "react-icons/ai";
import { RiSecurePaymentFill } from "react-icons/ri";
import Payments from "./Payments";

class Profile extends Component {
  constructor(props) {
    super(props);

    this.state = {
      collapsed: false,
    };
  }

  renderRoutes(pathname) {
    switch (pathname) {
      case "/my-account/my-orders":
        return <MyOrders props={this.props.props} />;
      case "/my-account/addresses":
        return <Addresses props={this.props.props} />;
      case "/my-account/settings":
        return <Settings props={this.props.props} />;
      case "/my-account/payments":
        return <Payments props={this.props.props} />;
      default:
        return <MyOrders props={this.props.props} />;
    }
  }
  defaultSelectedMenu(pathname) {
    var value = "";
    switch (pathname) {
      case "/my-account/my-orders":
        value = "1";
        break;
      case "/my-account/addresses":
        value = "2";
        break;
      case "/my-account/payments":
        value = "3";
        break;
      case "/my-account/settings":
        value = "3";
        break;
      default:
        value = "1";
        break;
    }
    return value;
  }
  render() {
    const { pathname } = this.props.props.location;
    return (
      <div className="profile-main-container">
        <Affix>
          <Row id="profile-header">
            <Col span={12} className="p-5">
              <Row>
                <h3 className="text-white fw-bold">Nikita Jaiswal</h3>
              </Row>
              <Row className="text-white">
                <Col span={4}>9926319695</Col>
                <Col span={1}>|</Col>
                <Col span={4}>jaiswalnikita@gmail.com</Col>
              </Row>
            </Col>
            <Col span={9}></Col>
            <Col span={3} className="p-3 mt-5 w-100">
              <Row>
                {/* <Button className="edit-profile-btn ">Edit Profile</Button> */}
              </Row>
            </Col>
          </Row>
        </Affix>

        <div className="bg-white profile-inner-container ">
          <div className="row">
            <div
              className="col-3 "
              style={{
                backgroundColor: "#ECEFF1",
              }}
            >
              <Card
                bordered={true}
                style={{
                  width: 270,
                  color: "#455A64",
                  backgroundColor: "#ECEFF1",
                  fontSize: "100%",
                }}
                className="px-5 fw-bold ml-1"
              >
                <div className="row p-2">
                  <Link
                    to="/my-account/my-orders"
                    className="link-deocration "
                    style={{ color: "#455A64" }}
                  >
                    <MdOutlineCardGiftcard />
                    &nbsp; Orders
                  </Link>
                </div>
                <div className="row  mt-3 p-2">
                  {" "}
                  <Link
                    to="/my-account/addresses"
                    className="link-deocration"
                    style={{ color: "#455A64" }}
                  >
                    <GrLocation />
                    &nbsp; Addresses
                  </Link>
                </div>
                <div className="row  mt-3 p-2">
                  {" "}
                  <Link
                    to="/my-account/payments"
                    className="link-deocration"
                    style={{ color: "#455A64" }}
                  >
                    <RiSecurePaymentFill />
                    &nbsp; Payments
                  </Link>
                </div>
                <div className="row  mt-3 p-2">
                  {" "}
                  <Link
                    to="/my-account/settings"
                    className="link-deocration"
                    style={{ color: "#455A64" }}
                  >
                    <AiOutlineSetting />
                    &nbsp; settings
                  </Link>
                </div>
              </Card>
            </div>

            <div className="col-9 site-layout-background ">
              <div className="container ">
                {" "}
                <div className="">{this.renderRoutes(pathname)}</div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }
}
export default Profile;
