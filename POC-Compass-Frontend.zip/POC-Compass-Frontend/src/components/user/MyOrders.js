import React, { Component } from "react";
import { Empty, Spin } from "antd";
import { decodeToken } from "react-jwt";
import { getOrdersByUserId } from "./../../actions/orderActions";
import { connect } from "react-redux";
import Order from "./Order";
import constant from "../../util/constant";

class MyOrders extends Component {
  constructor(props) {
    super(props);
    this.state = { loading: true };
    this.loadingFalse = this.loadingFalse.bind(this);
  }
  loadingFalse() {
    this.setState({ loading: false });
  }

  componentDidMount() {
    const user = decodeToken(localStorage.getItem("token"));
    console.log(user);
    this.setState({
      user,
    });
    if (user) {
      const query = `query MyQuery {
        getOrderListUserId(userId: "${user.userId}") {
          isPaid
          orderDate
          orderId
          orderStatus
          paymentMode
          restaurantId
          totalPrice
          userId
          restaurant {
            category
            id
            image
            restaurantName
            sortKey
            userId
            rating {
              currentRating
              sum
              totalNumberOfUser
            }
            address {
              city
              lat
              lng
              location
              pinCode
              state
            }
          }
          orderItem {
            orderId
            orderItemId
            quantity
            totalPrice
            menuItem {
              actualPrice
              category
              description
              image
              discount
              menuItemId
              menuItemName
              price
              restaurantId
            }
          }
          delivery {
            deliveredTime
            deliveryBoyId
            deliveryStatus
            orderId
            pickUpTime
            userId
          }
        }
      }
      
      `;
      this.props.getOrdersByUserId(query, this.loadingFalse);
    }
  }

  render() {
    const { orders } = this.props;
    console.log("inside myorders", orders);
    var activeOrders = [];
    var pastOrders = [];
    orders.forEach((order) => {
      if (
        order.orderStatus === constant.orderStatusString.Delivered ||
        order.orderStatus === constant.orderStatusString.Failed ||
        order.orderStatus === constant.orderStatusString.Reject
      ) {
        pastOrders.push(order);
      } else {
        activeOrders.push(order);
      }
    });

    if (this.state.loading) {
      return (
        <div className="row w-100 mt-5">
          <div className="col-4"></div>
          <div className="col-4 text-center">
            <Spin size="large" className="spin" />
          </div>
          <div className="col-4"></div>
        </div>
      );
    } else
      return (
        <div>
          <div>
            {!activeOrders.length ? (
              <span></span>
            ) : (
              <div>
                <div className="row">
                  <span className="h3 mt-5 ">Active Orders</span>
                </div>
                {activeOrders.map((order) => {
                  return <Order order={order} />;
                })}
              </div>
            )}
          </div>
          <div>
            {!pastOrders.length ? (
              <div className="">
                <Empty description={<span>No Orders</span>} />
              </div>
            ) : (
              <div>
                <div className="row">
                  <span className="h3 mt-5 ">Past Orders</span>
                </div>
                {pastOrders.map((order) => {
                  return <Order order={order} />;
                })}
              </div>
            )}
          </div>
        </div>
      );
  }
}
const mapStateToProps = (state) => ({
  errors: state.errors,
  orders: state.orderReducer.userOrders,
});

export default connect(mapStateToProps, {
  getOrdersByUserId,
})(MyOrders);
