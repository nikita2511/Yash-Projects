import React, { Component } from "react";

class Payments extends Component {
  render() {
    return <div>Payments</div>;
  }
}

export default Payments;
