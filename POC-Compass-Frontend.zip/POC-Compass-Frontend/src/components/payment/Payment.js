import React, { Component } from "react";
import { Row, Card, Button } from "antd";
import { MdOutlinePayments } from "react-icons/md";
import { TiTick } from "react-icons/ti";
import cashOnDelivery from "../../assets/images/cash-on-delivery.png";
import { BiRupee } from "react-icons/bi";
import { Link } from "react-router-dom";
import OrderPlaced from "../order/OrderPlaced";

class Payment extends Component {
  render() {
    return (
      <div>
        <Row>
          <span className="text-secondary h3 ">
            <span>
              <MdOutlinePayments color="black" style={{ marginLeft: "-3%" }} />
            </span>
            <Row className="mt-4 fw-600">
              <h2>Choose a Payment Method</h2>
            </Row>
          </span>
        </Row>
        <div className="row">
          <div className="col-6">
            {" "}
            <div className="site-card-border-less-wrapper ">
              <Card
                className=""
                bordered={false}
                style={{ width: 300, backgroundColor: "#E0E0E0" }}
                id="payment-card"
              >
                <Row
                  className="p-2 text-white pay-on-delivery fw-bold"
                  id="payment-option-row"
                >
                  <div className=" p-2">Pay On Delivery </div>
                </Row>
                <Row
                  className="p-2 text-secondary fw-bold"
                  id="payment-option-row"
                >
                  <div className="p-2"> Net Banking</div>
                </Row>
                <Row
                  className="p-2 text-secondary fw-bold"
                  id="payment-option-row"
                >
                  <div className="p-2"> Credit/Debit cards</div>
                </Row>
                <Row
                  className="p-2 text-secondary fw-bold"
                  id="payment-option-row"
                >
                  <div className="p-2"> UPI</div>
                </Row>
              </Card>
            </div>
          </div>
          <div className="col-6">
            <div className="site-card-border-less-wrapper ">
              <Card className="" bordered={false} style={{ width: 300 }}>
                <img alt="" src={cashOnDelivery} width={100} />
                <div className="text-secondary fw-bold">Cash</div>
                <small class="text-muted">
                  Online payment recommended to reduce contact between you and
                  delivery partner
                </small>

                <OrderPlaced toPay={this.props.toPay} props={this.props} />
              </Card>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default Payment;
