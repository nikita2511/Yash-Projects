import React, { Component } from "react";
import { Form, Input, Select, Button, Modal } from "antd";
import { Link } from "react-router-dom";
import image from "../../assets/images/food.jpg";
import { connect } from "react-redux";
import { register } from "../../actions/userActions";
import PropTypes from "prop-types";
import { State } from "country-state-city";
import GoogleMapReact from "google-map-react";
import Marker from "../layout/Marker";
import {
  UserOutlined,
  LockOutlined,
  PhoneOutlined,
  MailOutlined,
} from "@ant-design/icons";
import {
  FaLocationArrow,
  FaCity,
  FaMapPin,
  FaSearchLocation,
  FaHotel,
} from "react-icons/fa";
import SignInUpHeader from "../layout/SignInUpHeader";
import Geocode from "react-geocode";
import Footer from "../layout/Footer";
// const indState = state.State();
const { Option } = Select;
class Registration extends Component {
  constructor(props) {
    super(props);
    this.state = {
      firstName: "",
      lastName: "",
      email: "",
      password: "",
      confirmPassword: "",
      phoneNumber: "",
      location: "",
      city: "",
      state: "",
      pinCode: "",
      userType: "",
      visible: false,
      lat: "",
      lng: "",
      center: {},
      zoom: 15,
    };
    this.onChange = this.onChange.bind(this);
    this.onSubmit = this.onSubmit.bind(this);
    this.onUserTypeChange = this.onUserTypeChange.bind(this);
    this.onStateChange = this.onStateChange.bind(this);
    this.openModal = this.openModal.bind(this);
    this.onMapOKclick = this.onMapOKclick.bind(this);
    this.onMapClick = this.onMapClick.bind(this);
  }
  onMapClick(event) {
    this.setState({
      lat: event.lat,
      lng: event.lng,
    });
  }
  onMapOKclick(event) {
    this.setState({ visible: false });
    console.log("on map ok click", this.state.lat, this.state.lng);
    Geocode.setApiKey("AIzaSyA6ywgoC5KvkIAvAZspMfh9R7_cWnSNqQ8");
    Geocode.setLocationType("ROOFTOP");
    Geocode.fromLatLng(this.state.lat, this.state.lng).then(
      (response) => {
        const address = response.results[0].formatted_address;
        console.log("address", address);
        var commaAddeess = address.split(",");
        var lcoality = commaAddeess[commaAddeess.length - 4];
        var city = commaAddeess[commaAddeess.length - 3];
        var StatePin = commaAddeess[commaAddeess.length - 2].trim().split(" ");
        const pinCode = StatePin.pop();
        const state = StatePin.toString();
        console.log("commaAddress", lcoality, city, state, pinCode);
        this.setState({
          city,
          state,
          pinCode,
          location: lcoality,
        });
      },
      (error) => {
        console.error(error);
      }
    );
  }
  async openModal(event) {
    this.setState({ visible: true });
    let promise = new Promise(function (resolve, reject) {
      navigator.geolocation.getCurrentPosition(resolve, reject);
    });

    let pos = await promise;
    const center = {
      lat: pos.coords.latitude,
      lng: pos.coords.longitude,
    };
    this.setState({
      center,
      lat: pos.coords.latitude,
      lng: pos.coords.longitude,
    });
    console.log("k", center);
  }
  closeModal = () => this.setState({ visible: false });
  onChange(event) {
    this.setState({ [event.target.name]: event.target.value });
  }

  onUserTypeChange = (event) => {
    this.setState({ userType: event });
  };
  onStateChange = (event) => {
    this.setState({ state: event });
  };
  async onSubmit(event) {
    const query = `mutation MyMutation {
      createUser(input: {address: {city: "${this.state.city}", location: "${this.state.location}", pinCode: "${this.state.pinCode}", state: "${this.state.state}", lat: "${this.state.lat}", lng: "${this.state.lng}"}, email: "${this.state.email}", firstName: "${this.state.firstName}", lastName: "${this.state.lastName}", password: "${this.state.password}", phoneNumber: "${this.state.phoneNumber}", userType: ${this.state.userType}}) {
      email
      firstName
      lastName
      userType
      }
      }
    `;
    this.props.register(query, this.props.history);
  }
  render() {
    const indState = State.getStatesOfCountry("IN");
    const { visible } = this.state;
    return (
      <div>
        <SignInUpHeader />
        <section className="h-50 bg-light">
          <div className="container py-5 ">
            <div className="row d-flex justify-content-center align-items-center">
              <h2 className="form-title text-center">Register</h2>
              <div className="col">
                <div class="card card-registration my-4">
                  <div className="row g-0">
                    <div className="col-xl-6 pt-5 p-3">
                      <img src={image} alt="Sample photo" class="img-fluid" />
                    </div>
                    <div class="col-xl-6">
                      <div class="card-body p-md-5 text-black">
                        {/* start */}
                        <div className="signup-content">
                          <div className="signup-form-register">
                            <Form
                              name="register"
                              scrollToFirstError
                              onFinish={this.onSubmit}
                            >
                              <div class=" row row g-0">
                                <div className=" col col-xl-6">
                                  <div className=" col col-xl-11">
                                    <Form.Item
                                      className="signup-register-input"
                                      name="firstName"
                                      rules={[
                                        {
                                          required: true,
                                          message:
                                            "Please enter your First Name!",
                                        },
                                        ({ getFieldValue }) => ({
                                          validator(_, value) {
                                            var hasNumber = /^[A-Za-z]+$/;
                                            if (
                                              !parseInt(
                                                getFieldValue("firstName")
                                              ) &&
                                              hasNumber.test(
                                                getFieldValue("firstName")
                                              )
                                            ) {
                                              return Promise.resolve();
                                            }
                                            return Promise.reject(
                                              "Should contain alphabets!"
                                            );
                                          },
                                        }),
                                      ]}
                                    >
                                      <Input
                                        prefix={
                                          <UserOutlined className="site-form-item-icon" />
                                        }
                                        type="text"
                                        name="firstName"
                                        id="firstName"
                                        placeholder="First Name"
                                        value={this.state.firstName}
                                        onChange={this.onChange}
                                      />
                                    </Form.Item>
                                  </div>
                                </div>
                                <div className=" col col-xl-6">
                                  <Form.Item
                                    name="lastName"
                                    rules={[
                                      {
                                        required: true,
                                        message: "Please enter your Last Name!",
                                      },
                                      ({ getFieldValue }) => ({
                                        validator(_, value) {
                                          var hasNumber = /^[A-Za-z]+$/;
                                          if (
                                            !parseInt(
                                              getFieldValue("lastName")
                                            ) &&
                                            hasNumber.test(
                                              getFieldValue("lastName")
                                            )
                                          ) {
                                            return Promise.resolve();
                                          }
                                          return Promise.reject(
                                            "Should contain alphabets!"
                                          );
                                        },
                                      }),
                                    ]}
                                  >
                                    <Input
                                      prefix={
                                        <UserOutlined className="site-form-item-icon" />
                                      }
                                      type="text"
                                      name="lastName"
                                      id="lastName"
                                      placeholder="Last Name"
                                      value={this.state.lastName}
                                      onChange={this.onChange}
                                    />
                                  </Form.Item>
                                </div>
                              </div>
                              <Form.Item
                                name="email"
                                className="signup-register-input"
                              >
                                <Input
                                  prefix={
                                    <MailOutlined className="site-form-item-icon" />
                                  }
                                  type="string"
                                  name="email"
                                  id="email"
                                  placeholder="Email"
                                  value={this.state.email}
                                  onChange={this.onChange}
                                />
                              </Form.Item>
                              <Form.Item
                                name="mobile"
                                rules={[
                                  {
                                    required: true,
                                    message:
                                      "Please enter your  Mobile Number!",
                                  },
                                  {
                                    min: 10,
                                    message: "Mobile must be 10-digits!",
                                  },
                                  {
                                    max: 10,
                                    message: "Mobile must be 10-digits!",
                                  },
                                  ({ getFieldValue }) => ({
                                    validator(_, value) {
                                      var hasAlphabets = /^[0-9]+$/;
                                      if (
                                        parseInt(getFieldValue("mobile")) &&
                                        hasAlphabets.test(
                                          getFieldValue("mobile")
                                        )
                                      ) {
                                        return Promise.resolve();
                                      }
                                      return Promise.reject(
                                        "Should contain numbers!"
                                      );
                                    },
                                  }),
                                ]}
                              >
                                <Input
                                  prefix={
                                    <PhoneOutlined className="site-form-item-icon" />
                                  }
                                  type="string"
                                  name="phoneNumber"
                                  id="phoneNumber"
                                  placeholder="Phone Number"
                                  value={this.state.phoneNumber}
                                  onChange={this.onChange}
                                />
                              </Form.Item>

                              <div className="row row g-0 ">
                                <div className="col col-xl-6">
                                  <div className=" col col-xl-11">
                                    <Form.Item
                                      className="signup-register-input"
                                      name="password"
                                      rules={[
                                        {
                                          required: true,
                                          message:
                                            "Please enter your password!",
                                        },
                                        {
                                          min: 8,
                                          message: "Min 8 characters required!",
                                        },
                                        {
                                          max: 20,
                                          message:
                                            "Max 20 characters required!",
                                        },
                                      ]}
                                      hasFeedback
                                    >
                                      <Input.Password
                                        prefix={
                                          <LockOutlined className="site-form-item-icon" />
                                        }
                                        placeholder="Password"
                                        name="password"
                                        id="password"
                                        value={this.state.password}
                                        onChange={this.onChange}
                                      />
                                    </Form.Item>
                                  </div>
                                </div>
                                <div className="col col-xl-6">
                                  <Form.Item
                                    name="confirmPassword"
                                    dependencies={["password"]}
                                    hasFeedback
                                    rules={[
                                      {
                                        required: true,
                                        message:
                                          "Please confirm your password!",
                                      },
                                      {
                                        min: 8,
                                        message: "Min 8 characters required!",
                                      },
                                      {
                                        max: 20,
                                        message: "Max 20 characters required!",
                                      },
                                      ({ getFieldValue }) => ({
                                        validator(_, value) {
                                          if (
                                            !value ||
                                            getFieldValue("password") === value
                                          ) {
                                            return Promise.resolve();
                                          }

                                          return Promise.reject(
                                            new Error("Passwords do not match!")
                                          );
                                        },
                                      }),
                                    ]}
                                  >
                                    <Input.Password
                                      prefix={
                                        <LockOutlined className="site-form-item-icon" />
                                      }
                                      placeholder="Confirm Password"
                                      name="confirmPassword"
                                      id="confirmPassword"
                                      value={this.state.confirmPassword}
                                      onChange={this.onChange}
                                    />
                                  </Form.Item>
                                </div>
                              </div>
                              <Form.Item
                                name="Mark Location"
                                className="createRestaurant-register-input"
                              >
                                <Button onClick={this.openModal}>
                                  Mark Locaiton
                                </Button>
                              </Form.Item>
                              <Modal
                                visible={visible}
                                title="Mark Location"
                                // style={{ top: 20 }}
                                onOk={this.onMapOKclick}
                                onCancel={this.closeModal}
                                okText="Ok"
                                width={1000}
                              >
                                {console.log(
                                  "inside modal",
                                  this.state.lat,
                                  this.state.lng
                                )}
                                <div style={{ height: "50vh", width: "100%" }}>
                                  <GoogleMapReact
                                    bootstrapURLKeys={{
                                      key: "AIzaSyA6ywgoC5KvkIAvAZspMfh9R7_cWnSNqQ8",
                                    }}
                                    defaultCenter={this.state.center}
                                    defaultZoom={this.state.zoom}
                                    yesIWantToUseGoogleMapApiInternals
                                    onClick={this.onMapClick}
                                  >
                                    <Marker
                                      // text={this.state.address}
                                      lat={this.state.lat}
                                      lng={this.state.lng}
                                    />
                                  </GoogleMapReact>
                                </div>
                              </Modal>
                              {/* address1 */}
                              <div class=" row row g-0">
                                <div className=" col col-xl-6">
                                  <div className=" col col-xl-11">
                                    <Form.Item
                                      className="signup-register-input"
                                      name="location"
                                    >
                                      <div></div>
                                      <Input
                                        prefix={
                                          <FaLocationArrow className="site-form-item-icon" />
                                        }
                                        type="text"
                                        name="location"
                                        id="location"
                                        placeholder="Street Location"
                                        value={this.state.location}
                                        onChange={this.onChange}
                                      />
                                    </Form.Item>
                                  </div>
                                </div>
                                <div className=" col col-xl-6">
                                  <Form.Item name="city">
                                    <div></div>
                                    <Input
                                      prefix={
                                        <FaCity className="site-form-item-icon" />
                                      }
                                      type="text"
                                      name="city"
                                      id="city"
                                      placeholder="City"
                                      value={this.state.city}
                                      onChange={this.onChange}
                                    />
                                  </Form.Item>
                                </div>
                              </div>
                              {/* address2 */}
                              <div class=" row row g-0">
                                <div className=" col col-xl-6">
                                  <div className=" col col-xl-11">
                                    <Form.Item
                                      className="signup-register-input"
                                      name="state"
                                    >
                                      <div></div>
                                      <Input
                                        prefix={
                                          <FaSearchLocation className="site-form-item-icon" />
                                        }
                                        type="text"
                                        name="state"
                                        id="state"
                                        placeholder="State"
                                        value={this.state.state}
                                        onChange={this.onChange}
                                      />
                                    </Form.Item>
                                  </div>
                                </div>
                                <div className=" col col-xl-6">
                                  <Form.Item
                                    name="pinCode"
                                    id="pinCode"
                                    // rules={[
                                    //   {
                                    //     required: true,
                                    //     message: "Please enter your Pincode!",
                                    //   },
                                    //   ({ getFieldValue }) => ({
                                    //     validator(_, value) {
                                    //       var hasNumber = /^[1-9][0-9]{5}$/;
                                    //       if (
                                    //         hasNumber.test(
                                    //           getFieldValue("pinCode")
                                    //         )
                                    //       ) {
                                    //         return Promise.resolve();
                                    //       }
                                    //       return Promise.reject(
                                    //         "Please enter correct pincode"
                                    //       );
                                    //     },
                                    //   }),
                                    // ]}
                                  >
                                    <div></div>
                                    <Input
                                      prefix={
                                        <FaMapPin className="site-form-item-icon" />
                                      }
                                      type="text"
                                      name="pinCode"
                                      id="pinCode"
                                      placeholder="Pincode"
                                      value={this.state.pinCode}
                                      onChange={this.onChange}
                                    />
                                  </Form.Item>
                                </div>
                              </div>

                              <Form.Item
                                name="userType"
                                showSearch
                                rules={[
                                  {
                                    required: true,
                                    message: "Please select Type!",
                                  },
                                ]}
                              >
                                <Select
                                  placeholder="Select User Type"
                                  name="userType"
                                  id="userType"
                                  value={this.state.userType}
                                  onChange={this.onUserTypeChange}
                                >
                                  <Option value="User">User</Option>
                                  <Option value="DeliveryBoy">
                                    Delivery Boy
                                  </Option>
                                  <Option value="RestaurantOwner">
                                    Restaurant Owner
                                  </Option>
                                </Select>
                              </Form.Item>
                              <Form.Item>
                                <Button type="primary" htmlType="submit">
                                  Register
                                </Button>

                                <Link to="/login" className="p-3">
                                  Sign in to an existing account
                                </Link>
                              </Form.Item>
                            </Form>
                          </div>
                          <div className="signup-image-register"></div>
                        </div>
                        {/* end */}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        <Footer />
      </div>
    );
  }
}

const mapStateToProps = (state) => ({
  errors: state.errors,
  user: state.user,
});

Registration.propTypes = {
  register: PropTypes.func.isRequired,
};

export default connect(mapStateToProps, {
  register,
})(Registration);
