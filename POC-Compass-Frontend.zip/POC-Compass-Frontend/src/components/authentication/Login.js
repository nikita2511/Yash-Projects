import React, { Component } from "react";
import { Form, Input, Button, Spin } from "antd";
import { connect } from "react-redux";
import PropTypes from "prop-types";
import { login } from "../../actions/userActions";
import {
  LockOutlined,
  MailOutlined,
  Loading3QuartersOutlined,
} from "@ant-design/icons";
import SignInUpHeader from "../layout/SignInUpHeader";
import Footer from "../layout/Footer";
import { Redirect } from "react-router-dom";
import { isExpired } from "react-jwt";
const antIcon = <Loading3QuartersOutlined style={{ fontSize: 24 }} spin />;

class Login extends Component {
  constructor(props) {
    super(props);
    let isLoggedIn = false;
    const token = localStorage.getItem("token");
    // const token = JSON.parse(localStorage.getItem("token"));

    if (token && !isExpired(token)) {
      isLoggedIn = true;
    }

    this.state = {
      email: "",
      password: "",
      errors: {},
      isLoggedIn,
      loading: false,
    };

    this.onChange = this.onChange.bind(this);
    this.onSubmitLogin = this.onSubmitLogin.bind(this);
    this.loadingFalse = this.loadingFalse.bind(this);
  }

  onChange(event) {
    this.setState({ [event.target.name]: event.target.value });
  }

  loadingFalse() {
    this.setState({
      loading: false,
    });
  }

  onSubmitLogin(event) {
    // event.preventDefault();

    // creating GraphQl query
    this.setState({
      loading: true,
    });
    const query = `mutation MyMutation {
            userLogin(input: {email: "${this.state.email}", password: "${this.state.password}"}) {
              address {
                location
                city
                state
                pinCode
              }
              email
              firstName
              lastName
              password
              phoneNumber
              userId
              userType
              jwtToken
            }
          }
          `;
    this.props.login(query, this.props.history, this.loadingFalse);
  }

  render() {
    if (this.state.isLoggedIn) {
      return <Redirect to="/" />;
    }
    return (
      <div>
        <SignInUpHeader />
        <section className="h-50 bg-light">
          <div className="container py-5 ">
            <div className="row d-flex justify-content-center align-items-center">
              <h2 className="form-title text-center">Login</h2>
              <div className="col">
                <div className="card card-registration my-4">
                  <div className="row g-0">
                    <div className="col-xl-6 pt-5 p-3">
                      <img
                        src={require("../../assets/images/plated-smoked-salmon.jpg")}
                        alt="Sample photo"
                        className="img-fluid"
                      />
                    </div>
                    <div className="col-xl-6">
                      <div className="card-body p-md-5 text-black">
                        {/* start */}
                        <div className="signup-content">
                          <div className="signup-form-register">
                            <Form name="register" scrollToFirstError>
                              <Form.Item
                                name="email"
                                className="signup-register-input"
                                rules={[
                                  {
                                    required: true,
                                    message: "Please enter your Email!",
                                  },
                                  {
                                    type: "email",
                                    message: "The input is not a valid E-mail!",
                                  },
                                ]}
                              >
                                <Input
                                  prefix={
                                    <MailOutlined className="site-form-item-icon" />
                                  }
                                  type="string"
                                  name="email"
                                  id="email"
                                  value={this.state.email}
                                  onChange={this.onChange}
                                  placeholder="Email"
                                />
                              </Form.Item>
                              <Form.Item
                                className="signup-register-input"
                                name="password"
                                rules={[
                                  {
                                    required: true,
                                    message: "Please enter your password!",
                                  },
                                ]}
                                hasFeedback
                              >
                                <Input.Password
                                  prefix={
                                    <LockOutlined className="site-form-item-icon" />
                                  }
                                  placeholder="Password"
                                  name="password"
                                  id="password"
                                  value={this.state.password}
                                  onChange={this.onChange}
                                />
                              </Form.Item>
                              <Form.Item>
                                {this.state.loading ? (
                                  <Spin indicator={antIcon} className="spin" />
                                ) : (
                                  <Button
                                    type="primary"
                                    htmlType="submit"
                                    onClick={this.onSubmitLogin}
                                  >
                                    Login
                                  </Button>
                                )}
                              </Form.Item>
                            </Form>
                          </div>
                          <div className="signup-image-register"></div>
                        </div>
                        {/* end */}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>
        <Footer />
      </div>
    );
  }
}
Login.propTypes = {
  login: PropTypes.func.isRequired,
};
const mapStateToProps = (state) => ({
  errors: state.errors,
});

export default connect(mapStateToProps, { login })(Login);
