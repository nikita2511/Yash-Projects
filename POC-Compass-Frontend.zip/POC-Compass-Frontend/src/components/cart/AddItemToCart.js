import React, { Component } from "react";
import { connect } from "react-redux";
import {
  addItemToCart,
  updateCartItem,
  deleteCartItem,
} from "../../actions/cartActions";
import { PlusOutlined, MinusOutlined } from "@ant-design/icons";

class AddItemToCart extends Component {
  constructor(props) {
    super(props);
    this.addItemToCart = this.addItemToCart.bind(this);
    // this.updateCartItemOnClick = this.updateCartItemOnClick.bind(this);
  }
  updateCartItemOnClick(cartItem, flag) {
    console.log('update click', this.props);
    this.props.loadingTrue();
    const { cartId } = this.props;
    let quantity;

    // delete cart item
    if (flag === "decrement" && cartItem.quantity === 1) {
      console.log("inside if");
      const query = `mutation MyMutation {
        deleteCartItem(input: {cartId: "${cartId}", cartItemId: "${cartItem.cartItemId}"}) {
          menuItem {
            actualPrice
            description
            discount
            image
            menuItemId
            menuItemName
            price
            restaurantId
          }
          menuItemId
          quantity
          totalPrice
          cartItemId
          cartId
        }
      }
      `;
      this.props.deleteCartItem(query, cartItem.cartItemId, this.props.loadingFalse);
    }
    // update cart item
    else {
      console.log("inside else");
      if (flag === "increment") {
        quantity = cartItem.quantity + 1;
      } else {
        quantity = cartItem.quantity - 1;
      }
      console.log("update click", cartItem, flag);
      const query = `mutation MyMutation {
        updateCartItem(input: {cartId: "${cartId}", quantity: ${quantity}, cartItemId: "${cartItem.cartItemId}"}) {
          cartId
          cartItemId
          menuItemId
          quantity
          totalPrice
          menuItem {
            actualPrice
            description
            discount
            image
            menuItemId
            menuItemName
            price
            restaurantId
          }
        }
      }
      `;
      this.props.updateCartItem(query, this.props.loadingFalse);
    }
  }
  returnButton() {
    const { cartItems, item } = this.props;
    if (!cartItems.length) {
      console.log("inside if length", cartItems);
      return (
        <button class="btn btn-sm add-btn" onClick={this.addItemToCart}>
          Add
        </button>
      );
    }
    for (var i = 0; i < cartItems.length; i++) {
      console.log("loop", cartItems[i].menuItemId);
      if (cartItems[i].menuItemId === item.menuItemId) {
        console.log("inside loop if");
        return (
          <div id="add-cart-item-counter-btn" className="border bg-light px-1 ">
            <MinusOutlined
              id="counter-icon-on-menu-item"
              onClick={() =>
                this.updateCartItemOnClick(cartItems[i], "decrement")
              }
            />

            <span id="counter-icon-on-menu-item" className="px-1 text-dark">
              {cartItems[i].quantity}
            </span>
            <PlusOutlined
              id="counter-icon-on-menu-item"
              onClick={() =>
                this.updateCartItemOnClick(cartItems[i], "increment")
              }
            />
          </div>
        );
      }
    }
    return (
      <button class="btn btn-sm" onClick={this.addItemToCart}>
        Add
      </button>
    );
  }
  addItemToCart(event) {
    this.props.loadingTrue();
    const { item, cartId } = this.props;
    const query = `mutation MyMutation {
            addItemToCart(input: {cartId: "${cartId}", restaurantId: "${item.restaurantId}", menuItemId: "${item.menuItemId}", quantity: 1}) {
              cartId
              cartItemId
              menuItemId
              quantity
              totalPrice
              menuItem {
                actualPrice
                description
                discount
                image
                menuItemId
                price
                menuItemName
                restaurantId
              }
            }
          }
          `;
    this.props.addItemToCart(query, this.props.loadingFalse);
  }
  render() {
    console.log('this.props', this.props);
    return <div>{this.returnButton()}</div>;
  }
}
const mapStateToProps = (state) => ({
  errors: state.errors,
  cartItems: state.cartReducer.cartItems,
  cartId: state.cartReducer.cartId,
});
export default connect(mapStateToProps, {
  addItemToCart,
  updateCartItem,
  deleteCartItem,
})(AddItemToCart);
