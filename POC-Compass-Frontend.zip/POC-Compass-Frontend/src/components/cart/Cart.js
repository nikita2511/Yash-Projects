import React, { Component } from "react";
import { PlusOutlined, MinusOutlined } from "@ant-design/icons";
import { Row, Col, Button, Empty } from "antd";
import vegIcon from "./../../assets/images/veg-icon.png";
import nonVegIcon from "./../../assets/images/non-veg-icon.png";
import { FaLongArrowAltRight } from "react-icons/fa";
import { BiRupee } from "react-icons/bi";
import { Link } from "react-router-dom";
import { getCartItems } from "../../actions/cartActions";
import { decodeToken } from "react-jwt";
import { connect } from "react-redux";
import CartItem from "./CartItem";
import FilterRestaurants from "../restaurant/FilterRestaurants";
import { Link } from "react-router-dom";

class Cart extends Component {
  constructor(props) {
    super(props);
    this.state = {
      subTotal: 0,
    };
  }

  componentDidMount() {
    console.log("inside CDM");
    const user = decodeToken(localStorage.getItem("token"));
    const query = `query MyQuery {
      getCartlist(userId: "${user.userId}") {
        cartItems {
          cartId
          cartItemId
          menuItemId
          quantity
          totalPrice
          menuItem {
            actualPrice
            description
            discount
            image
            menuItemId
            menuItemName
            restaurantId
            price
          }
        }
        cartId
      }
    }
    
    `;
    this.props.getCartItems(query, this.props.history);

    // let subtotal;
    // if (this.props.cartItems.length !== 0) {
    //   this.props.cartItems.forEach((element) => {
    //     subtotal = subtotal + element.totalPrice;
    //   });
    //   this.setState({ subTotal: subtotal });
    //   console.log(this.state.subTotal);
    // }
  }

  render() {
    const { cartItems } = this.props;
    var totalPrice = 0;
    console.log("-------------cart Items---------in render", cartItems);
    return (
      <div id="cart-widget w-100" className=" ">
        {cartItems.length !== 0 ? (
          <div>
            <Row>
              {" "}
              <h3>Cart</h3>
            </Row>
            <Row className="text-secondary"> Item</Row>
            {cartItems.map((element) => {
              totalPrice = totalPrice + element.totalPrice;
              return <CartItem cartItem={element} key={element.cartItemId} />;
            })}
            {console.log("TotalPrice---------", totalPrice)}
            <Row className="mt-4">
              <Col span={18}>Subtotal</Col>
              <Col span={6}>
                <BiRupee /> {totalPrice}
              </Col>
            </Row>
            <Row className="text-secondary cart-text">
              Extra charges may apply
            </Row>
            <Row className="mt-3">
              <Link to="/checkout">
                <Button type="danger" size="large" className="fw-bold" block>
                  Checkout &nbsp; <FaLongArrowAltRight />
                </Button>
              </Link>
            </Row>
          </div>
        ) : (
          <div>
            <Row>
              <h3
                className="text-secondary fw-bold"
                style={{
                  fontFamily: " ProximaNova,arial,Helvetica Neue,sans-serif",
                }}
              >
                Cart Empty
              </h3>
            </Row>
            <Empty />
            <div className="p-3" style={{ color: "#93959f" }}>
              Good food is always cooking! Go ahead, order some yummy items from
              the menu.
            </div>
          </div>
        )}
      </div>
    );
  }
}
const mapStateToProps = (state) => ({
  errors: state.errors,
  cartItems: state.cartReducer.cartItems,
});
export default connect(mapStateToProps, { getCartItems })(Cart);
