import React, { Component } from "react";
import { PlusOutlined, MinusOutlined } from "@ant-design/icons";
import vegIcon from "./../../assets/images/veg-icon.png";
import { BiRupee } from "react-icons/bi";
import { Row, Col } from "antd";
import { deleteCartItem, updateCartItem } from "../../actions/cartActions";
import { connect } from "react-redux";

class CartItem extends Component {
  constructor(props) {
    super(props);
    this.state = {};
    this.deleteCartItem = this.deleteCartItem.bind(this);
  }
  updateCartItemOnClick(cartItem, flag) {
    const { cartId } = this.props;
    let quantity;
    console.log("cartId", cartId);
    // delete cart item
    if (flag === "decrement" && cartItem.quantity === 1) {
      console.log("inside if");
      const query = `mutation MyMutation {
        deleteCartItem(input: {cartId: "${cartId}", cartItemId: "${cartItem.cartItemId}"}) {
          menuItem {
            actualPrice
            description
            discount
            image
            menuItemId
            menuItemName
            price
            restaurantId
          }
          menuItemId
          quantity
          totalPrice
          cartItemId
          cartId
        }
      }
      `;
      this.props.deleteCartItem(query, cartItem.cartItemId);
    }
    // update cart item
    else {
      console.log("inside else");
      if (flag === "increment") {
        quantity = cartItem.quantity + 1;
      } else {
        quantity = cartItem.quantity - 1;
      }
      console.log("update click", cartItem, flag);
      const query = `mutation MyMutation {
        updateCartItem(input: {cartId: "${cartId}", quantity: ${quantity}, cartItemId: "${cartItem.cartItemId}"}) {
          cartId
          cartItemId
          menuItemId
          quantity
          totalPrice
          menuItem {
            actualPrice
            description
            discount
            image
            menuItemId
            menuItemName
            price
            restaurantId
          }
        }
      }
      `;
      this.props.updateCartItem(query);
    }
  }
  deleteCartItem = () => {
    if (this.props.cartItem.quantity === 1) {
      const { cartItem } = this.props;
      const query = `mutation MyMutation {
        deleteCartItem(input: {cartId: "${cartItem.cartId}", cartItemId: "${cartItem.cartItemId}"}) {
          cartId
          cartItemId
          menuItemId
          quantity
          totalPrice
        }
      }`;
      this.props.deleteCartItem(query, cartItem.cartItemId, this.props.history);
    } else {
    }
  };
  render() {
    const { cartItem } = this.props;
    console.log("-------------cartItem---------from cartitem", cartItem);
    return (
      <Row className="my-3">
        <Col span={2}>
          <span>
            <img alt="example" src={vegIcon} style={{ width: "12px" }} />
          </span>
          &nbsp;
        </Col>
        <Col span={8}>
          <span className="cart-text">{cartItem.menuItem.menuItemName}</span>
        </Col>
        <Col span={8} className="px-3 ">
          <div className="bg-light px-2 border border-secondary">
            <span className="cart-text">
              <MinusOutlined
                id="counter-icon"
                onClick={() =>
                  this.updateCartItemOnClick(cartItem, "decrement")
                }
              />
            </span>

            <span className="cart-text px-2">{cartItem.quantity}</span>

            <span className="cart-text ">
              <PlusOutlined
                id="counter-icon"
                className="pb-2"
                onClick={() =>
                  this.updateCartItemOnClick(cartItem, "increment")
                }
              />
            </span>
          </div>
        </Col>

        <Col span={6}>
          <span className="cart-text">
            <BiRupee />
            {cartItem.totalPrice}
          </span>
        </Col>
      </Row>
    );
  }
}

const mapStateToProps = (state) => (
  console.log("--------state------", state),
  {
    errors: state.errors,
    cartItems: state.cartReducer.cartItems,
    cartId: state.cartReducer.cartId,
    deletedCartItem: state,
    cartId: state.cartReducer.cartId,
  }
);

export default connect(mapStateToProps, {
  deleteCartItem,
  updateCartItem,
})(CartItem);
