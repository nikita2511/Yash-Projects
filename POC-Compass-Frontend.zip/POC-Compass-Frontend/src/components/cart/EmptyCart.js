import React, { Component } from "react";
import { Link } from "react-router-dom";
import { Row } from "antd";
class EmptyCart extends Component {
  render() {
    return (
      <div className="container p-5 bg-light ">
        <Row className=" justify-content-center text-center">
          <img
            alt=""
            src="https://res.cloudinary.com/swiggy/image/upload/fl_lossy,f_auto,q_auto/2xempty_cart_yfxml0"
            width={300}
          />
        </Row>

        <Row className=" justify-content-center text-center">
          <p>Your cart is Empty</p>
        </Row>
        <Row className=" justify-content-center text-center">
          <Link
            to={{
              pathname: `/`,
            }}
            className="text-decoration-none btn btn-danger"
          >
            Explore Restaurants
          </Link>
        </Row>
      </div>
    );
  }
}

export default EmptyCart;
