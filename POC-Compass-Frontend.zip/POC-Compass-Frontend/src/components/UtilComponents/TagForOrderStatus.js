import React, { Component } from 'react'
import { Tag, Divider } from 'antd';
import constant from '../../util/constant';
import {
    CheckCircleOutlined,
    SyncOutlined,
    CloseCircleOutlined,
    ClockCircleOutlined,
    LogoutOutlined,
} from '@ant-design/icons';
class TagForOrderStatus extends Component {
    render() {
        const { orderStatus } = this.props
        switch (orderStatus) {
            case constant.orderStatusString.InProgress:
                return (
                    <Tag icon={<ClockCircleOutlined />} color="default">
                        {orderStatus}
                    </Tag>)
            case constant.orderStatusString.Accept:
                return (
                    <Tag icon={<CheckCircleOutlined />} color="success">
                        {orderStatus}
                    </Tag>)
            case constant.orderStatusString.Reject:
                return (
                    <Tag icon={<CloseCircleOutlined />} color="error">
                        {orderStatus}
                    </Tag>)
            case constant.orderStatusString.Preparing:
                return (
                    <Tag icon={<SyncOutlined spin />} color="processing">
                        {orderStatus}
                    </Tag>)
            case constant.orderStatusString.OutForDelivery:
                return (
                    <Tag icon={<LogoutOutlined />} color="warning">
                        {orderStatus}
                    </Tag>)
            case constant.orderStatusString.Failed:
                return (
                    <Tag icon={<CloseCircleOutlined />} color="error">
                        {orderStatus}
                    </Tag>)
            case constant.orderStatusString.Delivered:
                return (
                    <Tag icon={<CheckCircleOutlined />} color="success">
                        {orderStatus}
                    </Tag>)
            default:
        }
    }
}
export default TagForOrderStatus;