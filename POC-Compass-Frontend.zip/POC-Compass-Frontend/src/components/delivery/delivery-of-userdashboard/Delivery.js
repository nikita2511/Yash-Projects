import React, { Component } from "react";
import { Row, Card, Button } from "antd";
import { HomeOutlined } from "@ant-design/icons";
import { decodeToken } from "react-jwt";
class Delivery extends Component {
  constructor(props) {
    super(props);
    const user = decodeToken(localStorage.getItem("token"));

    this.state = {
      user,
    };
  }
  render() {
    return (
      <div>
        <Row className="mt-4">
          <h2>Choose a delivery address</h2>
        </Row>
        <div className="row p-5">
          <div className="col-6">
            {" "}
            <div
              className="site-card-border-less-wrapper"
              id="delivery-address-card"
            >
              <Card
                title={
                  <div>
                    <Row>
                      <HomeOutlined />

                      <span style={{ marginLeft: "6%" }}>Home</span>
                    </Row>
                  </div>
                }
                bordered={true}
                style={{ width: 300, height: 200 }}
              >
                <Row>
                  <p
                    className="text-secondary"
                    style={{
                      fontFamily: "ProximaNova,arial,Helvetica Neue,sans-serif",
                      fontSize: "90%",
                    }}
                  >
                    {this.state.user.address.location}&nbsp;
                    {this.state.user.address.city} &nbsp;
                    {this.state.user.address.state}&nbsp;
                    {this.state.user.address.pinCode}
                  </p>
                </Row>

                <Row className="mt-3">
                  <Button
                    type="success"
                    size="large"
                    className="fw-bold mb-2 "
                    id="deliver-here-btn"
                  >
                    Deliver Here
                  </Button>
                </Row>
              </Card>
            </div>
          </div>
        </div>
      </div>
    );
  }
}

export default Delivery;
