import React, { Component } from 'react';
import constant from '../../util/constant';
import { Redirect } from "react-router-dom";

class DeliveryDashboard extends Component {
  constructor(props) {
    super(props);
    const token = localStorage.getItem("token");
    let IsLoggedIn = false;

    if (token === constant.userType.DELIVERY_BOY) {
      IsLoggedIn = true;
    }

    this.state = {
      IsLoggedIn
    };
  }
  render() {
    if (this.state.IsLoggedIn === false) {
      return <Redirect to="/" />;
    }
    return <div>DeliveryDashboard</div>;
  }
}
export default DeliveryDashboard;