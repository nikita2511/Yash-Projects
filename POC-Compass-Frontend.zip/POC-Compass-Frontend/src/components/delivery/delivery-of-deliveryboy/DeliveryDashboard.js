import React, { Component } from "react";
import constant from "../../../util/constant";
import { Redirect } from "react-router-dom";
import { decodeToken, isExpired } from "react-jwt";
import DeliveryHeader from "./DeliveryHeader";
import Orders from "../../delivery/delivery-of-deliveryboy/Orders";
import { Divider } from "antd";

class DeliveryDashboard extends Component {
  constructor(props) {
    super(props);
    const token = localStorage.getItem("token");
    const decodedToken = decodeToken(token);
    let IsLoggedIn = false;

    if (
      !isExpired(token) &&
      decodedToken.userType === constant.userType.DELIVERY_BOY
    ) {
      IsLoggedIn = true;
    }

    this.state = {
      IsLoggedIn,
    };
  }
  render() {
    if (this.state.IsLoggedIn === false) {
      return <Redirect to="/" />;
    }
    return (
      <div className="">
        <DeliveryHeader />
        <Divider />
        <Orders props={this.props.props} />
      </div>
    );
  }
}
export default DeliveryDashboard;
