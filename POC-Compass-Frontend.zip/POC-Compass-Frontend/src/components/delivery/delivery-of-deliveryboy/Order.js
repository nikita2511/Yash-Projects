import React, { Component } from "react";
import { SaveOutlined, UserOutlined } from "@ant-design/icons";
import { FcCallback } from "react-icons/fc";
import { FaDirections } from "react-icons/fa";
import { IoLocationSharp } from "react-icons/io5";
import { BiRupee } from "react-icons/bi";
import { updateDeliveryStatus } from "./../../../actions/deliveryActions";
import { connect } from "react-redux";
import {
  Row,
  Col,
  Button,
  Card,
  Avatar,
  Image,
  Collapse,
  Select,
  Popconfirm,
  message,
} from "antd";
import { Navbar } from "react-bootstrap";
import { Redirect } from "react-router-dom";
import DeliveryDashboard from "./DeliveryDashboard";
const { Panel } = Collapse;
const { Option } = Select;
const success = () => {
  message.success("Status updated");
};
const error = () => {
  message.error("something went wrong");
};
class Order extends Component {
  constructor(props) {
    super(props);
    this.state = {
      deliveryStatus: "",
    };
    this.onChange = this.onChange.bind(this);
  }

  onChange = (event) => {
    this.setState({ deliveryStatus: event });
    const query = ` mutation MyMutation {
      updateDeliveryDetails(input: {deliveryStatus: ${event}, orderId: "${this.props.order.order.orderId}"}) {
        deliveredTime
        deliveryBoyId
        deliveryStatus
        orderId
        userId
        pickUpTime
      }
    }
    
`;
    console.log("----------props---------", this.props);
    this.props.updateDeliveryStatus(query, this.props.props.history);
    console.log("-------updated---", this.props.updatedDeliveryObj);
    if (!this.props.updatedDeliveryObj) {
      error();
    } else {
      success();
    }
  };
  render() {
    const { order } = this.props;
    const { orderItem } = this.props.order.order;
    return (
      <Collapse onChange={this.callback} className="my-2">
        <Panel
          showArrow={false}
          destroyInactivePanel={false}
          header={
            <span>
              <small>{order.order.orderId}</small>&nbsp;|
              <span className="ml-5">
                {" "}
                {order.deliveryStatus === "Processing" ? (
                  <span className="text-warning">{order.deliveryStatus}</span>
                ) : (
                  <span className="text-success">{order.deliveryStatus}</span>
                )}
              </span>
            </span>
          }
          key="1"
        >
          <Row className="">
            <Card>
              <div className="row">
                <div className="col-4">
                  <Row>
                    <span className="h6">
                      <small>{order.orderId}</small>
                    </span>
                  </Row>
                  <Row>
                    <Col span={4}>
                      <span className="h6">
                        <Avatar
                          style={{ backgroundColor: "#87d068" }}
                          icon={<UserOutlined />}
                        />
                      </span>
                    </Col>
                    <Col span={15} className=" h5 fw-bold">
                      {" "}
                      {order.user.firstName} &nbsp; {order.user.lastName}
                    </Col>
                  </Row>
                  <Row>
                    <hr
                      className="container"
                      style={{ width: "100%", height: ".3px" }}
                    />
                    <Col span={4}>
                      <span className="h6">
                        <FcCallback />
                      </span>
                    </Col>
                    <Col span={15}> {order.user.phoneNumber} </Col>
                  </Row>
                  <Row>
                    <Col span={4}>
                      <span className="h6">
                        <IoLocationSharp />
                      </span>
                    </Col>
                    <Col span={15}>
                      <small> {order.user.address.location} </small>
                      <small> {order.user.address.city} </small>
                      <small> {order.user.address.pinCode} </small>
                      <small> {order.user.address.state} </small>
                    </Col>
                  </Row>

                  <Row className="mt-3">
                    <hr
                      className="container"
                      style={{ width: "100%", height: ".3px" }}
                    />
                    <Col span={4}>
                      <span>Status</span>
                    </Col>
                    <Col span={10}>
                      {order.deliveryStatus === "Processing" ? (
                        <span className="text-success">
                          {order.deliveryStatus}
                        </span>
                      ) : (
                        <span className="text-success">
                          {order.deliveryStatus}
                        </span>
                      )}
                    </Col>
                    <Col span={10}>
                      <div className="">
                        <Button type="danger">
                          Direction &nbsp;
                          <FaDirections />
                        </Button>
                      </div>
                    </Col>
                  </Row>
                  {order.deliveryStatus === "Processing" ||
                  order.deliveryStatus === "OnTheWay" ? (
                    <Row className="mt-3">
                      <Col span={10}>
                        <Select
                          defaultValue="status"
                          style={{ width: 100 }}
                          bordered={false}
                          onChange={this.onChange}
                        >
                          <Option value="Pending">Processing</Option>
                          <Option value="Failed">Failed</Option>
                          <Option value="Delivered">Delivered</Option>
                        </Select>
                        {/* <Button
                          type="danger"
                          shape="circle"
                          icon={<SaveOutlined />}
                          onClick={this.updateDeliveryStatus}
                        /> */}
                      </Col>
                      <Col span={10}></Col>
                    </Row>
                  ) : (
                    ""
                  )}
                </div>
                <div className="col-8">
                  <Collapse defaultActiveKey={["1"]} onChange={this.callback}>
                    <Panel
                      header={<span>{orderItem.length} Items</span>}
                      key="1"
                    >
                      <div id="delivery-order-items" className="mx-2">
                        {orderItem.map((element) => {
                          return (
                            <div className="row p-2 mt-1">
                              <div className="col-1">
                                {" "}
                                <Avatar
                                  src={
                                    <Image
                                      src="https://burst.shopifycdn.com/photos/scrumptious-brunch-setting.jpg?width=746&format=pjpg&exif=1&iptc=1"
                                      style={{ width: 32 }}
                                    />
                                  }
                                />
                              </div>
                              <div className="col-3">
                                {element.menuItem.menuItemName}
                              </div>
                              <div className="col-3">
                                {" "}
                                <small>
                                  {" "}
                                  <BiRupee />
                                  {element.menuItem.price}
                                </small>
                              </div>
                            </div>
                          );
                        })}
                      </div>
                    </Panel>
                  </Collapse>
                  <div className="">
                    <div className="row p-1 ">
                      <div className="col-4 fw-bold">Total Bill</div>
                      <div className="col-3">
                        <BiRupee /> {order.order.totalPrice}
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </Card>
          </Row>
        </Panel>
      </Collapse>
    );
  }
}

const mapStateToProps = (state) => (
  console.log("---------------state from order----------", state),
  {
    errors: state.errors,
    updatedDeliveryObj: state,
  }
);

export default connect(mapStateToProps, {
  updateDeliveryStatus,
})(Order);
