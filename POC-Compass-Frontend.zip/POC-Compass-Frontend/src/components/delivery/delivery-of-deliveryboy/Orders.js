import React, { Component } from "react";
import { Row, Empty, Badge } from "antd";
import { Tabs, Space } from "antd";
import Order from "./Order";
import { connect } from "react-redux";
import { getAllDeliveryOrders } from "./../../../actions/deliveryActions";
import { decodeToken } from "react-jwt";
const { TabPane } = Tabs;

class Orders extends Component {
  constructor(props) {
    super(props);
    this.callback = this.callback.bind(this);
  }
  callback(key) {
    console.log(key);
  }
  componentDidMount() {
    const user = decodeToken(localStorage.getItem("token"));
    console.log(user);
    this.setState({
      user,
    });
    if (user) {
      const query = `query MyQuery {
        getDeliveryDetailsByDeliveryBoyId(deliveryBoyId: "${user.userId}") {
          deliveredTime
          deliveryBoyId
          deliveryStatus
          pickUpTime
          user {
            email
            firstName
            jwtToken
            lastName
            password
            phoneNumber
            userId
            userType
            address {
              city
              lat
              lng
              pinCode
              location
              state
            }
          }
          order {
            isPaid
            orderDate
            orderId
            orderStatus
            paymentMode
            restaurantId
            totalPrice
            userId
            orderItem {
              orderId
              orderItemId
              quantity
              totalPrice
              menuItem {
                actualPrice
                category
                description
                discount
                image
                menuItemId
                menuItemName
                price
                restaurantId
              }
            }
          }
          restaurant {
            category
            id
            image
            restaurantName
            sortKey
            userId
            rating {
              currentRating
              sum
              totalNumberOfUser
            }
            address {
              city
              lng
              lat
              location
              pinCode
              state
            }
          }
        }
      }
      
      `;
      this.props.getAllDeliveryOrders(query, this.props.history);
    }
  }
  render() {
    const { orders } = this.props;
    let processingOrdersCount = 0;
    let onGoingOrdersCount = 0;
    let completedOrdersCount = 0;

    console.log(this.props);
    return (
      <div className="delivery-orders container">
        {orders.map((order) => {
          if (order.deliveryStatus === "Delivered") {
            completedOrdersCount = completedOrdersCount + 1;
          }
          if (order.deliveryStatus === "Processing") {
            processingOrdersCount = processingOrdersCount + 1;
          }
          if (order.deliveryStatus === "OnTheWay") {
            onGoingOrdersCount = onGoingOrdersCount + 1;
          }
          return "";
        })}
        <Row className=" align-content-between">
          <div className="container">
            <Tabs type="card">
              <TabPane
                tab={
                  <span>
                    All Orders &nbsp;{" "}
                    <Space>
                      <Badge
                        className="site-badge-count-109"
                        count={orders.length}
                        style={{ backgroundColor: "#52c41a" }}
                      />
                    </Space>
                  </span>
                }
                key="1"
              >
                {!orders.length ? (
                  <div className="">
                    <Empty description={<span>No Items</span>} />
                  </div>
                ) : (
                  orders.map((element) => {
                    return <Order order={element} props={this.props} />;
                  })
                )}
              </TabPane>
              <TabPane
                tab={
                  <span>
                    Processing &nbsp;{" "}
                    <Space>
                      <Badge
                        className="site-badge-count-109"
                        count={processingOrdersCount}
                        style={{ backgroundColor: "#52c41a" }}
                      />
                    </Space>
                  </span>
                }
                key="2"
              >
                {!orders.length ? (
                  <div className="">
                    <Empty description={<span>No Items</span>} />
                  </div>
                ) : (
                  orders.map((element) => {
                    if (element.deliveryStatus === "Processing")
                      return <Order order={element} props={this.props} />;
                    return "";
                  })
                )}
              </TabPane>
              <TabPane
                tab={
                  <span>
                    On Going &nbsp;{" "}
                    <Space>
                      <Badge
                        className="site-badge-count-109"
                        count={onGoingOrdersCount}
                        style={{ backgroundColor: "#52c41a" }}
                      />
                    </Space>
                  </span>
                }
                key="3"
              >
                {!orders.length ? (
                  <div className="">
                    <Empty description={<span>No Items</span>} />
                  </div>
                ) : (
                  orders.map((element) => {
                    if (element.deliveryStatus === "OnTheWay")
                      return <Order order={element} props={this.props} />;
                    return "";
                  })
                )}
              </TabPane>

              <TabPane
                tab={
                  <span>
                    Completed &nbsp;{" "}
                    <Space>
                      <Badge
                        className="site-badge-count-109"
                        count={completedOrdersCount}
                        style={{ backgroundColor: "#52c41a" }}
                      />
                    </Space>
                  </span>
                }
                key="4"
              >
                {!orders.length ? (
                  <div className="">
                    <Empty description={<span>No Items</span>} />
                  </div>
                ) : (
                  orders.map((element) => {
                    if (element.deliveryStatus === "Delivered")
                      return <Order order={element} props={this.props} />;
                    return "";
                  })
                )}
              </TabPane>
            </Tabs>
          </div>
        </Row>
      </div>
    );
  }
}

const mapStateToProps = (state) => (
  console.log("--------------------state-------", state),
  {
    errors: state.errors,
    orders: state.deliveryReducer.deliveryOrders,
  }
);

export default connect(mapStateToProps, {
  getAllDeliveryOrders,
})(Orders);
