import React, { Component } from "react";
import { Navbar, Container, NavDropdown } from "react-bootstrap";
import { Badge } from "antd";
import { AiFillCheckCircle } from "react-icons/ai";
import { BsCircleFill } from "react-icons/bs";
import { BiHelpCircle } from "react-icons/bi";
import { IoIosNotifications } from "react-icons/io";
import { Link } from "react-router-dom";
import { decodeToken } from "react-jwt";
import { connect } from "react-redux";

class DeliveryHeader extends Component {
  constructor(props) {
    super(props);
    const user = decodeToken(localStorage.getItem("token"));

    this.state = {
      user,
    };
  }

  onLogoutClick(event) {
    localStorage.removeItem("token");
    window.location.href = "/";
  }
  render() {
    const { cartItems } = this.props;
    console.log(this.state.user.deliveryBoyStatus);
    return (
      <Navbar
        className="user-header text-dark"
        collapseOnSelect
        expand="lg"
        variant="dark"
      >
        <Container className="text-dark">
          <img
            alt=""
            src={require("../../../assets/images/logo.png")}
            width="47"
            height="47"
            className="d-inline-block align-top"
          />
          <Navbar.Brand href="#" className="text-dark " id="logo-text">
            &nbsp;&nbsp;&nbsp;&nbsp;Food Delivery App
          </Navbar.Brand>

          <Navbar.Toggle aria-controls="responsive-navbar-nav" />
          <Navbar.Collapse className="justify-content-end">
            <div class="d-flex">
              <div class="mt-3 help-box">
                <Navbar.Brand href="#" className="text-dark " id="help">
                  <BiHelpCircle /> &nbsp;Help
                </Navbar.Brand>
              </div>
              <div class="p-2 ">
                <NavDropdown
                  title={`${this.state.user.firstName} ${this.state.user.lastName}`}
                  id="collasible-nav-dropdown-user"
                >
                  <NavDropdown.Item>Profile</NavDropdown.Item>
                  <NavDropdown.Item>Orders</NavDropdown.Item>
                  <NavDropdown.Item onClick={this.onLogoutClick}>
                    Logout
                  </NavDropdown.Item>
                </NavDropdown>
              </div>
              <div class="mt-3">
                <Navbar.Brand href="#" className="text-dark " id="help">
                  {this.state.user.deliveryBoyStatus === "Busy" ? (
                    <BsCircleFill className="text-danger" size={10} />
                  ) : (
                    <AiFillCheckCircle className="text-success" size={12} />
                  )}
                  &nbsp;
                  <span style={{ fontSize: "90%" }}>
                    {this.state.user.deliveryBoyStatus}
                  </span>
                </Navbar.Brand>
              </div>
            </div>
          </Navbar.Collapse>
        </Container>
      </Navbar>
    );
  }
}

const mapStateToProps = (state) => ({
  cartItems: state.cartReducer.cartItems,
});
export default connect(mapStateToProps, {})(DeliveryHeader);
