import React, { useEffect } from "react";
import LandingBar from "./utils/LandingBar";
import ImageStepper from "./components/azure/onboarding/ImageStepper";
import { Card, Typography, Stack } from "@mui/material";
import azureLogo from "./assets/azure-logo.png";
import githubLogo from "./assets/gitHub-logo.png";
import { useNavigate } from "react-router-dom";
import axios from "axios";
import { constants } from "./utils/Constants";
import ProgressBar from "./utils/ProgressBar";
import ErrorAlert from "./components/error/ErrorAlert";

export default function DevOpsPlatformSelector() {
  const navigate = useNavigate();
  const [isVisible, setIsVisible] = React.useState(false);
  const [progressBarMessage, setProgressBarMessage] =
    React.useState("Please wait!");
  const [isErrorVisible, setIsErrorVisible] = React.useState(false);
  const [errorAlertCallback, setErrorAlertCallback] = React.useState({
    navigate: -1,
    navigateData: {
      state: {},
    },
    message: "Something unexpected happend! Please try again",
  });
  /**
   *
   * @param {*} message String value to be shown with Progress Bar
   * JS method called to make the Progress Bar visible along with the message
   */
  const showProgressBar = (message) => {
    setIsVisible(true);
    setProgressBarMessage(message);
  };
  /**
   *
   * JS method called to hide the Progress Bar
   */
  const hideProgressBar = () => {
    setIsVisible(false);
    setProgressBarMessage("");
  };
  /**
    *
    * @param {*} value boolean value to change visiblity of Alert Dialog
     JS method to update the boolean state value isErrorVisible
    */
  const handleErrorAlert = (value) => {
    setIsErrorVisible(value);
  };
  const handleAzureDevOpsPlatformRedirect = () => {
    navigate("/azure");
  };
  const handleGitHubPlatformRedirect = () => {
    if (!localStorage.getItem("accessToken")) {
      const githubClientInfo = JSON.parse(
        localStorage.getItem("primaryGithubClientInfo")
      );
      if (githubClientInfo &&
        githubClientInfo.hasOwnProperty("applicationClientId") &&
        githubClientInfo.applicationClientId.length > 0
      ) {
        const gitConfig = {
          auth: {
            clientId: githubClientInfo.applicationClientId,
            redirectUri: githubClientInfo.redirectUri,
            scope: githubClientInfo.scopes,
          },
        };
        window.location.href = `https://github.com/login/oauth/authorize?client_id=${gitConfig.auth.clientId}&redirect_uri=${gitConfig.auth.redirectUri}&scope=${gitConfig.auth.scope}`;
      } else {
        handleErrorAlert(true);
        setErrorAlertCallback({
          navigate: "/github/clientInfo",
          message: `Client Info not found! Please add Github Client Info to proceed further`,
        });
      }
    } else {
      navigate("/gitHubAllOragnization");
    }
  };
  /**
   *
   * JS method to call GET REST Endpoint for retrieving availble client info for github
   */
  const callGetClientInfoAPI = () => {
    axios
      .get(constants.BASE_URL + constants.GET_GITHUB_CLIENT_INFO)
      .then((response) => {
        if (response.data.body.githubClientDetails.length > 0) {
          localStorage.setItem(
            "primaryGithubClientInfo",
            JSON.stringify(response.data.body.githubClientDetails[0])
          );
        } else {
          localStorage.removeItem("primaryGithubClientInfo");
        }
      })
      .catch((error) => {
        console.log("Error-callGetActiveDirectories=========>", error);
      });
  };
  /**
   *
   * JS method to call GET REST Endpoint for retrieving availble ADs
   */
  const callGetADInfoAPI = () => {
    axios
      .get(constants.BASE_URL + constants.GET_ACTIVE_DIRECTORY)
      .then((response) => {
        console.log(
          "Response-callGetActiveDirectories========>",
          response.data.body.activeDirectories
        );
        if (response.data.body.activeDirectories.length) {
          const primaryAD = response.data.body.activeDirectories.find(
            (item) => item.isActiveDirectoryPrimary
          );
          if (primaryAD) {
            localStorage.setItem("primaryADInfo", JSON.stringify(primaryAD));
          } else {
            localStorage.removeItem("primaryADInfo");
          }
        } else {
          localStorage.removeItem("primaryADInfo");
        }
      })
      .catch((error) => {
        console.log("Error-callGetActiveDirectories=========>", error);
      });
  };

  useEffect(() => {
    callGetADInfoAPI();
    callGetClientInfoAPI();
    // eslint-disable-next-line
  }, []);
  return (
    <div className="landing-dashboard">
      <LandingBar />
      <ProgressBar
        isVisible={isVisible}
        progressBarMessage={progressBarMessage}
      />
      <ErrorAlert
        isErrorVisible={isErrorVisible}
        callback={() => {
          setIsErrorVisible(false);
          if (
            errorAlertCallback.hasOwnProperty("navigate") &&
            errorAlertCallback.hasOwnProperty("navigateData")
          ) {
            navigate(
              errorAlertCallback.navigate,
              errorAlertCallback.navigateData
            );
          } else if (errorAlertCallback.hasOwnProperty("navigate")) {
            navigate(errorAlertCallback.navigate);
          }
        }}
        message={errorAlertCallback.message}
      />
      <ImageStepper />
      <div className="main-container">
        <Typography
          className="imageStepper-typography1"
          variant="h5"
          gutterBottom
        >
          Welcome to DevOps PlatForm Engineering!
        </Typography>
        <Typography
          className="imageStepper-typography2"
          variant="body2"
          gutterBottom
        >
          Login using your official credentials to access the platform.
        </Typography>
        <Stack direction="row" spacing={2} mb={2} p={1}>
          <Card
            className="imageStepper-card imageStepper-card:hover"
            raised={true}
            onClick={handleAzureDevOpsPlatformRedirect}
          >
            <img
              className="imageStepper-image"
              src={azureLogo}
              alt={"Could not load media"}
              loading="lazy"
            />
          </Card>
          <Card
            className="imageStepper-card imageStepper-card:hover"
            raised={true}
            onClick={handleGitHubPlatformRedirect}
          >
            <img
              className="imageStepper-image"
              src={githubLogo}
              alt={"Could not load media"}
              loading="lazy"
            />
          </Card>
        </Stack>
      </div>
    </div>
  );
}
