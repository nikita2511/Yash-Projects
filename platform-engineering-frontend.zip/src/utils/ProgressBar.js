import "./utils.css";
import { Backdrop, LinearProgress, Typography } from "@mui/material";
import React from "react";
/**
 *
 * @param {*} isVisible boolean value to toggle visibility of Backdrop component
 * @param {*} progressBarMessage string value rendered with LinearProgess to brief about the ongoing process
 * @returns React Functional Component (ProgressBar) which is rendered when the REST API call is made or any time taking process is initiated
 */
export default function ProgressBar({ isVisible, progressBarMessage }) {
  return (
    <div>
      <Backdrop
        sx={{
          zIndex: (theme) => theme.zIndex.drawer + 500,
          color: "white",
        }}
        open={isVisible}
      >
        <div className="progressBar-backDrop-div">
          <LinearProgress />
          <Typography mt={2}>{progressBarMessage}</Typography>
        </div>
      </Backdrop>
    </div>
  );
}
