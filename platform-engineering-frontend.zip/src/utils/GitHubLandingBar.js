import "./utils.css";
import React from "react";
import AppBar from "@mui/material/AppBar";
import Box from "@mui/material/Box";
import Toolbar from "@mui/material/Toolbar";
import Typography from "@mui/material/Typography";
import Container from "@mui/material/Container";
import { ArrowDropDown, Person2Outlined } from "@mui/icons-material";
import { Avatar, CssBaseline, IconButton } from "@mui/material";
import { stringAvatar } from "../utils/helper";
import { Stack } from "@mui/system";

import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";
import ListItemIcon from "@mui/material/ListItemIcon";
import Logout from "@mui/icons-material/Logout";
import { useNavigate } from "react-router-dom";
import { DrawerHeader } from "../components/azure/dashboard/Header";
import { default as YashIcon } from "../assets/Yashicon.svg";
import axios from "axios";
import { constants } from "./Constants";

export default function GitHubLandingBar() {
  const navigate = useNavigate();

  const [anchorEl, setAnchorEl] = React.useState(null);
  const open = Boolean(anchorEl);
  const [authenticatedUser, setAuthenticatedUser] = React.useState({
    login: "",
  });
  /**
   *
   * @param {*} event JS event returned by event listener
   * JS method to handle click listener of the Icon Button containing Avatar
   */
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  /**
   * JS method to handle onClose callback from Menu component in MUI.
   */
  const handleClose = () => {
    setAnchorEl(null);
  };
  /**
   * JS method used to navigate to '/profile' route from current component
   */
  const navigateToProfile = () => {
    setAnchorEl(null);
    navigate("/azure/profile");
  };
  /**
   * JS method called when logout MenuItem is clicked to handle logout request using '@azure/msal-react' dependency
   */
  const handleLogoutRedirect = () => {
    localStorage.removeItem("accessToken");
    navigate("/");
  };

  const callGetAuthenticatedUser = () => {
    let config = {
      headers: {
        authorization: "Bearer " + localStorage.getItem("accessToken"),
      },
    };
    axios
      .get(constants.GET_GITHUB_AUTHENTICATED_USER, config)
      .then((response) => {
        localStorage.setItem("githubAuthenticatedUser", JSON.stringify(response.data));
        setAuthenticatedUser(response.data);
      })
      .catch((error) => {
        setAuthenticatedUser({
          login: "",
        });
      });
  };

  React.useEffect(() => {
    callGetAuthenticatedUser();
    // eslint-disable-next-line
  }, []);

  return (
    <Box>
      <CssBaseline />
      <AppBar position="fixed" className="landingBar-appBar">
        <Container maxWidth="xl">
          <Toolbar disableGutters className="landingBar-toolBar">
            <Box display={"flex"} alignItems={"center"}>
              <img
                src={YashIcon}
                alt={"Yash Technologies"}
                loading="lazy"
                className="landingBar-img-yashIcon"
              />
              <Typography
                className="header-typography"
                letterSpacing={2}
                variant="h6"
                noWrap
                component="a"
                href="/"
              >
                DevOps Platform Engineering
              </Typography>
            </Box>
            <Box
              flexGrow={0}
              flexDirection={"row"}
              display={"flex"}
              alignItems={"center"}
            >
              <Stack direction="row" spacing={1} alignItems="center">
                <Typography variant="body1">
                  Hi, {authenticatedUser.login}
                </Typography>
                <IconButton onClick={handleClick}>
                  <Avatar {...stringAvatar(authenticatedUser.login)} />
                  <ArrowDropDown className="landingBar-arrowDropDown" />
                </IconButton>
                <Menu
                  anchorEl={anchorEl}
                  id="account-menu"
                  open={open}
                  onClose={handleClose}
                  onClick={handleClose}
                  PaperProps={{
                    elevation: 0,
                    sx: {
                      overflow: "visible",
                      filter: "drop-shadow(0px 2px 8px rgba(0,0,0,0.32))",
                      mt: 1.5,
                      "& .MuiAvatar-root": {
                        width: 32,
                        height: 32,
                        ml: -0.5,
                        mr: 1,
                      },
                      "&:before": {
                        content: '""',
                        display: "block",
                        position: "absolute",
                        top: 0,
                        right: 14,
                        width: 10,
                        height: 10,
                        bgcolor: "background.paper",
                        transform: "translateY(-50%) rotate(45deg)",
                        zIndex: 0,
                      },
                    },
                  }}
                  transformOrigin={{ horizontal: "right", vertical: "top" }}
                  anchorOrigin={{ horizontal: "right", vertical: "bottom" }}
                >
                  <MenuItem onClick={navigateToProfile}>
                    <ListItemIcon>
                      <Person2Outlined fontSize="small" />
                    </ListItemIcon>
                    Profile
                  </MenuItem>
                  <MenuItem onClick={handleLogoutRedirect}>
                    <ListItemIcon>
                      <Logout fontSize="small" />
                    </ListItemIcon>
                    Logout
                  </MenuItem>
                </Menu>
              </Stack>
            </Box>
          </Toolbar>
        </Container>
      </AppBar>
      <DrawerHeader />
    </Box>
  );
}
