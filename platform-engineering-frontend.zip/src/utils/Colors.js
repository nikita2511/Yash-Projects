/**
 * JSON object for color hex codes
 */
export default {
    primary:"#005689",
    secondary:"#007CB9",
    tertiary:"#F6C667",
    base:"#F1F8FD"
}