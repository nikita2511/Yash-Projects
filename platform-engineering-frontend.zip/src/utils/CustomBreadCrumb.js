import './utils.css'
import React from "react";
import Typography from "@mui/material/Typography";
import Breadcrumbs from "@mui/material/Breadcrumbs";
import Link from "@mui/material/Link";
import { Box } from "@mui/material";
import { NavigateNext } from "@mui/icons-material";
import { useNavigate } from "react-router-dom";
/**
 * 
 * @param {*} routeList array of route pathnames upto current location(exclusive) 
 * @param {*} location string value of current pathname
 * @returns React Functional Component (CustomBreadCrumb) which renders all the route pathnames upto current location
 */
export default function CustomBreadCrumb({ routeList = [], location = "" }) {
  const navigate = useNavigate();
  /**
   * 
   * @param {*} s pathname value as string
   * @returns string value of pathname with capitalised first character
   */
  const capitalize = (s) => (s && s.charAt(0).toUpperCase() + s.slice(1)) || "";

  const getCurrentLocationName = (location) => {
    if (location.includes("/")) {
      const index = location.lastIndexOf("/");
      return location.substring(index+1);
    } else {
      return location;
    }
  }
  return (
    <Box>
      {routeList.length || location.length ? (
        <Breadcrumbs
          separator={<NavigateNext fontSize="small" />}
          aria-label="breadcrumb"
        >
          {routeList.map((route,index) => {
            return (
              <Link
                underline="hover"
                color="#007CB9"
                key={route}
                onClick={() => {
                  routeList.splice(routeList.indexOf(route), 1);
                  navigate(route, {
                    state: {
                      routeList,
                    },
                  });
                }}
                className="customBreadCrumb-link"
              >
                {(index===0) ? capitalize("organization") : capitalize(getCurrentLocationName(route))}
                 {/* capitalize(getCurrentLocationName(route)) */}
              </Link>
            );
          })}
          {location.length ? (
            <Typography color="#005689" fontWeight={"bold"}>
             {capitalize(getCurrentLocationName(location))}
            </Typography>
          ) : (
            <></>
          )}
        </Breadcrumbs>
      ) : (
        <></>
      )}
    </Box>
  );
}
