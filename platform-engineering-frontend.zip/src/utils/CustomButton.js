import Button from "@mui/material/Button";
import styled from "@emotion/styled";
/**
 * constant named ColorButton which returns MUI custom styled Button with mentioned style attributes
 */
export const ColorButton = styled(Button)(({ backgroundcolor, fontSize }) => ({
  color: "#F1F8FD",
  fontSize: fontSize ? fontSize : "16px",
  textTransform: "none",
  border: backgroundcolor ? "none" : "1px solid #F1F8FD",
  borderRadius: "8px",
  "&:hover": {
    backgroundColor: "#007CB9",
  },
  backgroundColor: backgroundcolor ? backgroundcolor : "#00000000",
}));
