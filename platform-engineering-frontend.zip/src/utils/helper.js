/**
 *
 * @param {*} string a string value
 * @returns hex code of a color generated using the provided string value
 */
function stringToColor(string) {
  let hash = 0;
  let i;

  /* eslint-disable no-bitwise */
  for (i = 0; i < string.length; i += 1) {
    hash = string.charCodeAt(i) + ((hash << 5) - hash);
  }

  let color = "#";

  for (i = 0; i < 3; i += 1) {
    const value = (hash >> (i * 8)) & 0xff;
    color += `00${value.toString(16)}`.slice(-2);
  }
  /* eslint-enable no-bitwise */

  return color;
}
/**
 *
 * @param {*} name a string value
 * @returns concated string of the first character of each string element in array after spliting the provided string using space(" ") characters in it
 */
export function stringAvatar(name) {
  return {
    sx: {
      bgcolor: stringToColor(name),
      fontWeight: "bold",
    },
    children:
      name.length && name.includes(" ")
        ? `${name.split(" ")[0][0]}${name.split(" ")[1][0]}`
        : name.charAt(0),
  };
}
