import {
    InteractionRequiredAuthError,
    InteractionStatus,
  } from "@azure/msal-browser";
/**
 * 
 * @param {*} instance instance from useMsal hook of "@azure/msal-react" provided by calling component
 * @param {*} inProgress inProgress from useMsal hook of "@azure/msal-react" provided by calling component
 * @param {*} accounts accounts from useMsal hook of "@azure/msal-react" provided by calling component
 * @param {*} getToken callback method called once token is retrieved using acquireTokenSilent method of instance
 * const named getTokenForAPI assigned value of unnamed JS method which retrieves token from MSAL and passes on to calling component using getToken callback method 
 */
export const getTokenForAPI = (instance, inProgress, accounts,getToken) => {
    const accessTokenRequest = {
      scopes: ["499b84ac-1321-427f-aa17-267ca6975798/user_impersonation"],
      account: accounts[0],
    };
    if (inProgress === InteractionStatus.None) {
      instance
        .acquireTokenSilent(accessTokenRequest)
        .then((accessTokenResponse) => {
          // Acquire token silent success
          let accessToken = accessTokenResponse.accessToken;
          // Call your API with token
          console.log("AccessTokenResponse========>", accessTokenResponse);
        //   setApiData(accessToken);
        getToken(accessToken)
        return accessToken;
        })
        .catch((error) => {
          if (error instanceof InteractionRequiredAuthError) {
            instance.acquireTokenRedirect(accessTokenRequest);
          }
          console.log("LogAfteracquireTokenRedirect==========>", error);
        });
    }
  };