import './App.css'
import React from "react";
import {
  BrowserRouter,
  Route,
  Routes,
} from "react-router-dom";
import SomethingWrong from "./components/error/SomethingWrong";
import DevOpsPlatformSelector from "./DevOpsPlatformSelector";
import AzureDevopsPlatform from "./components/azure/onboarding/AzureDevopsPlatform";
import AllOrganization from "./components/azure/organization/AllOrganization";
import CreateADInfo from "./components/azure/ActiveDirectoryInfo/CreateADInfo";
import Dashboard from "./components/azure/dashboard/Dashboard";
import CreateRules from "./components/azure/organization/rules/CreateRules";
import NotFound from './components/error/NotFound';
import UserProfile from './components/azure/onboarding/UserProfile';
import GitHubPlatform from './components/github/onboarding/GitHubPlatform';
import GitHubAllOrganization from './components/github/Organization/GitHubAllOrganization';
import GithubDashboard from "./components/github/dashboard/GithubDashboard";
import GithubCreateRules from './components/github/Organization/rules/GithubCreateRules';
import ClientInfo from './components/github/clientInfo/ClientInfo';

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route
          path={"/"}
          element={<DevOpsPlatformSelector />}
          errorElement={<SomethingWrong />}
        />
        <Route
          path={"/azure"}
          element={<AzureDevopsPlatform />}
          errorElement={<SomethingWrong />}
        >
          <Route
            path={""}
            element={<AllOrganization />}
            errorElement={<SomethingWrong />}
          />
          <Route
            path="project"
            element={<Dashboard />}
            errorElement={<SomethingWrong />}
          />
          <Route
            path="updateAdInfo"
            element={<Dashboard />}
            errorElement={<SomethingWrong />}
          />
          <Route
            path={"updateRule"}
            element={<Dashboard />}
            errorElement={<SomethingWrong />}
          />
          <Route
            path={"createProject"}
            element={<Dashboard />}
            errorElement={<SomethingWrong />}
          />
          <Route
            path={"profile"}
            element={<UserProfile />}
            errorElement={<SomethingWrong />}
          />
          <Route
            path={"projectInfo"}
            element={<Dashboard />}
            errorElement={<SomethingWrong />}
          />
            <Route
            path={"createReleasePipeline"}
            element={<Dashboard />}
            errorElement={<SomethingWrong />}
          />
          <Route
            path={"createRule"}
            element={<CreateRules />}
            errorElement={<SomethingWrong />}
          />
        </Route>
        <Route
          path={"/github"}
          element={<GitHubPlatform />}
          errorElement={<SomethingWrong />}
        ></Route>
        <Route
          path={"/createADInfo"}
          element={<CreateADInfo />}
          errorElement={<SomethingWrong />}
        />
        <Route
          path={"*"}
          element={<NotFound />}
          errorElement={<SomethingWrong />}
        />
        <Route
          path={"/gitHubAllOragnization"}
          element={<GitHubAllOrganization />}
          errorElement={<SomethingWrong />}
        />
        <Route
          path={"/github/repository"}
          element={<GithubDashboard />}
          errorElement={<SomethingWrong />}
        />
        <Route
          path={"/github/createRules"}
          element={<GithubCreateRules />}
          errorElement={<SomethingWrong />}
        />
        <Route
          path={"/github/repository/info"}
          element={<GithubDashboard />}
          errorElement={<SomethingWrong />}
        />
        <Route
          path={"/github/updateRules"}
          element={<GithubDashboard />}
          errorElement={<SomethingWrong />}
        />
         <Route
          path={"/github/organizationUser"}
          element={<GithubDashboard />}
          errorElement={<SomethingWrong />}
        />
         <Route
          path={"/github/createRepository"}
          element={<GithubDashboard />}
          errorElement={<SomethingWrong />}
        />
         <Route
          path={"/github/clientInfo"}
          element={<ClientInfo />}
          errorElement={<SomethingWrong />}
        />
      </Routes>
    </BrowserRouter>
  );
}
