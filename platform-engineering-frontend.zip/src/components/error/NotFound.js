import React from "react";
import "./error.css";
import {
  AuthenticatedTemplate,
  UnauthenticatedTemplate,
} from "@azure/msal-react";
import { Typography } from "@mui/material";
import { ColorButton } from "../../utils/CustomButton";
import { Link } from "react-router-dom";
/**
 * 
 * @returns React Functional Component (NotFound) which is used to handle route not found error
 */
export default function NotFound() {
  return (
    <div className="error-container">
      <div className="main-container">
        <div className="content">
          <UnauthenticatedTemplate>
            <Typography
              className="notFound-typography"
              variant="h4"
              gutterBottom
            >
              Not Found!
            </Typography>
            <Typography
              className="notFound-typography"
              variant="body1"
              gutterBottom
            >
              Your are not authorized for the requested URL.
            </Typography>
          </UnauthenticatedTemplate>
          <AuthenticatedTemplate>
            <Typography
              className="notFound-typography"
              variant="h4"
              gutterBottom
            >
              Not Found!
            </Typography>
            <Typography
              className="notFound-typography"
              variant="body1"
              gutterBottom
            >
              The requested URL is not available.
            </Typography>
            <div className="notFound-div">
              <ColorButton>
                <Link
                  className="somethingWrong-link"
                  to={"/organization"}
                >
                  Go to Organizations
                </Link>
              </ColorButton>
            </div>
          </AuthenticatedTemplate>
        </div>
      </div>
    </div>
  );
}
