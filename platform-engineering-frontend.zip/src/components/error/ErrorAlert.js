import React from 'react'
import "./error.css";
import Dialog from '@mui/material/Dialog';
import DialogActions from '@mui/material/DialogActions';
import DialogContent from '@mui/material/DialogContent';
import DialogContentText from '@mui/material/DialogContentText';
import DialogTitle from '@mui/material/DialogTitle';
import useMediaQuery from '@mui/material/useMediaQuery';
import { useTheme } from '@mui/material/styles';
import { Button, Divider } from '@mui/material';

/**
 * 
 * @param {isErrorVisible, callback, message} param passed as prop which are used in UI 
 * @returns React Functional Component (AlertDialog) with single action button which is used as Dialog component and alerts users in case of exceptions or warnings
 */
export default function ErrorAlert({ isErrorVisible, callback, message }) {
    const theme = useTheme();
    const fullScreen = useMediaQuery(theme.breakpoints.down('md'));

    return (
        <div>
            <Dialog
                fullScreen={fullScreen}
                open={isErrorVisible}
                aria-labelledby="responsive-dialog-title"
            >
                <DialogTitle id="responsive-dialog-title">
                    {"Alert!"}
                </DialogTitle>
                <Divider className="alertDialog-divider" />
                <DialogContent>
                    <DialogContentText>
                        {message}
                    </DialogContentText>
                </DialogContent>
                <DialogActions>
                    <Button onClick={callback} >
                        OK
                    </Button>
                </DialogActions>
            </Dialog>
        </div>
    )
}
