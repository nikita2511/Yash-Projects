import React from "react";
import "./error.css";
import {
  AuthenticatedTemplate,
  UnauthenticatedTemplate,
} from "@azure/msal-react";
import { ColorButton } from "../../utils/CustomButton";
import { Link } from "react-router-dom";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
/**
 * 
 * @returns React Functional Component (SomethingWrong) which is rendered when the exception or error occured in any of the components
 */
export default function SomethingWrong() {
  return (
    <div className="error-container">
      <div className="main-container">
        <div className="content-wrong">
          <Dialog
            open={true}
            aria-labelledby="alert-dialog-title"
            aria-describedby="alert-dialog-description"
          >
            <DialogTitle id="alert-dialog-title">{"Alert!"}</DialogTitle>
            <DialogContent className="somethingWrong-dialogContent">
              <DialogContentText id="alert-dialog-description">
                Something unexpected happened!
              </DialogContentText>
              <UnauthenticatedTemplate>
                <DialogActions>
                  <ColorButton
                    className="somethingWrong-colourButton"
                    backgroundcolor="#005689"                  >
                    <Link
                      className="somethingWrong-link"
                      to={"/"}
                    >
                      Go Back
                    </Link>
                  </ColorButton>
                </DialogActions>
              </UnauthenticatedTemplate>
              <AuthenticatedTemplate>
                <DialogActions>
                  <ColorButton
                    className="somethingWrong-colourButton"
                    backgroundcolor="#005689"
                  >
                    <Link
                      className="somethingWrong-link"
                      to={"/"}
                    >
                      Go to Dashboard
                    </Link>
                  </ColorButton>
                </DialogActions>
              </AuthenticatedTemplate>
            </DialogContent>
          </Dialog>
        </div>
      </div>
    </div>
  );
}
