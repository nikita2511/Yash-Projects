export const error_message = {

    UNIDENTIFIED_ERROR: "Something unexpected happend! Please try again",

    //Error messages for CreateRule.js 
    VALIDATE_BRANCH_INPUT: (model) => `Branch name is mandatory field. Please enter ${model.type} branch name`,
    VALIDATE_REVIEWERS_INPUT: (model) => `No. of reviewers is mandatory field. Please enter No. of reviewers for ${model.type} branch`,
    VALIDATE_MERGETYPE_INPUT: (model) => `Merge type is mandatory field. Please enter Merge type for ${model.type} branch`,
    VALIDATE_NAMING_CONVENTION_INPUT: "Naming convention is mandatory field. Please enter naming convention",
    ONSUCCESS_CREATE_RULE_API: "Organization rule created successfully!",
    ONFAILURE_CREATE_RULE_API: "Something went wrong while creating organization rule. Please try again!",

    //Error messages for UpdateRule.js 
    ONSUCCESS_UPDATE_RULE_API: "Organization rule updated successfully!",
    ONFAILURE_UPDATE_RULE_API: "Something went wrong while updating organization rule. Please try again!",

    //Error messages for AddUsersDialog.js 
    ONFAILURE_ADDUSER_API: "Something went wrong while Adding Users in project. Please try again!",

    //Error messages for AddVariablesDialog.js 
    VALIDATE_JSONFILE_REPEATED_INPUT: (duplicateVariables) => `Variables (${duplicateVariables.toString()}) already exist in variable group. Please delete previous one or modify your JSON file`,
    VALIDATE_JSONFILE_FORMATE: "Invalid file selected! Please select a valid JSON file",
    ONFAILURE_CREATE_VARIABLE_GROUP_API: "Something went wrong while creating variable group. Please try again!",
    ONFAILURE_UPDATE_VARIABLE_GROUP_API: "Something went wrong while updating variable group. Please try again!",

    //Error messages for CreatePipeline.js 
    ONFAILURE_CREATE_PIPELINE_API: "Something went wrong while creating CI Pipeline in project. Please try again!",

    //Error messages for CreateProject.js 
    ONFAILURE_CREATE_PROJECT_API: (projectName) => `Project ${projectName} created successfully!`,
    ONSUCCESS_CREATE_PROJECT_API: "Something went wrong while creating project. Please try again!",
    BRANHING_MODEL_MESSAGE: "Below Branching Modal is for reference purpose only",

    //Error messages for CreateRepoDialog.js 
    ONFAILURE_CREATE_REPO_API: "Something went wrong while creating repository. Please try again!",

    //Error messages for ExistingProject.js 
    ONFAILURE_DELETE_EXISTING_USERS_API: "Something went wrong while deleting user. Please try again!",
    ONFAILURE_GET_VARIABLE_GROUPS_API: "Something went wrong while fetching variable groups. Please try again!",
    ONFAILURE_GET_REPOS_API: "Something went wrong while fetching repositories. Please try again!",
    ONFAILURE_GET_PIPELINES_API: "Something went wrong while fetching pipelines. Please try again!",
    ONFAILURE_GET_EXISTING_USERS_API: "Something went wrong while fetching users. Please try again!",

    //Error messages for GetProjects.js 
    ORGANIZATION_NOT_FOUND: "Organization not found! Please select a valid organization",
}

export const info_message = {

    AUTHORISING_USER: "Please be patient! While user is authorised",
    GETTING_EXISTING_PROJECT_INFO: "Please be patient! while information related to existing projet are being fetched",

    //Info messages for CreateRule.js 
    GETTING_BRANCHING_MODELS: "Please be patient! while branching model are being fetched.",
    CALLING_CREATE_RULE_API: "Please be patient! while rule is being created.",

    //Info messages for UpdateRule.js 
    ORGANIZATION_RULE_NOT_FOUND: "Organization Rule is not created for the organization you are trying to access. Please create rule to proceed further.",
    CALLING_UPDATE_RULE_API: "Please be patient! while rule is being updated.",
    GETTING_RULES_BY_ORGANIZATOIN: "Please be patient! while organization rule is being fetched.",
    ON_UPDATE_RULE_POLICY_ALERT: "Updated Organization Rule will only be applicable on branches created now afterwards. Branches created in past will remain unchanged. Would you like to proceed?",

    //Info messages for AllOrganizatin.js
    GETTING_ALL_ORGANIZATIONS: "Please be patient! while organizations are being fetched.",
    PROCEEDING_TO_CREATE_RULE: "Organization Rule is not created for the organization you are trying to access. Please proceed to create rule before accessing the organization.",

    //Info messages for AddUsersDialog.js
    CALLING_ADDUSER_API: "Please be patient! While user is being added.",
    CALLING_ADDUSERS_API: "Please be patient! While users are being added.",
    CALLING_SEARCH_USERS_API: "Please be patient! While users are being fetched.",

    //Info messages for AddVariablesDialog.js 
    JSONFILE_FORMATE: "Upload a JSON file containing a JSON object of Name & Value pair for Variables",
    CALLING_CREATE_VARIABLE_GROUP_API: "Please be patient! While variable group is being created.",
    CALLING_UPDATE_VARIABLE_GROUP_API: "Please be patient! while variable group is being updated.",

    //Info messages for CreatePipeline.js 
    CALLING_CREATE_PIPELINE_API: "Please be patient! While CI pipeline is being created.",

    //Info messages for CreateProject.js 
    GETTING_ALL_PROCESSES: "Please be patient! While process are being fetched.",
    CALLING_CREATE_PROJECT_API: "Please be patient! While project is being created.",

    //Info messages for CreateRepoDialog.js 
    CALLING_CREATE_REPO_API: "Please be patient! While repository is being created.",
    REPO_NAME_VALIDATION: "A repository name cannot contain more than 64 characters, contain Unicode control characters or surrogate characters, contain any of the following characters: / :  ~ & % ; @ ' \" ? < > | # $ * } { , + = [ ], start with an underscore ( _ ), start or end with a period ( . ), or be a system reserved name",

    //Info messages for ExistingProject.js
    CALLING_DELETE_EXISTING_USERS_API: "Please be patient! While user is being deleted",

    //Info messages for GetProjects.js
    GETTING_ALL_PROJECTS: "Please be patient! while projects are being fetched.",
    NO_PROJECTS_AVAILABLE: "No projects available for selected organization!",
    SELECT_ORGANIZATION: "Please select organization to retrieve all available projects!",

    //Info message for ProjectTabs.js
    REPOSITORIES_NOT_CREATED: (project) => `Repositories are not created for the ${project.name} project yet`,
    PIPELINES_NOT_CREATED: (project) => `Pipelines are not created for the ${project.name} project yet`,
    VARIABLE_GROUP_NOT_CREATED: (project) => `Variable Groups are not created for the ${project.name} project yet`
}

