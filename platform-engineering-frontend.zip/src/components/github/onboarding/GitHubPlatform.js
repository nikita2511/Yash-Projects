import axios from "axios";
import React from "react";
import { useState } from "react";
import { useEffect } from "react";
import { useNavigate } from "react-router-dom";
import ProgressBar from "../../../utils/ProgressBar";
import { constants } from "../../../utils/Constants";

function GitHubPlatform(props) {
    const navigate = useNavigate()
    const [render, setRender] = useState(false)

    useEffect(() => {
        if (render) {
            navigate("/gitHubAllOragnization")
        }
        // eslint-disable-next-line
    }, [render])

    useEffect(() => {
        const searchParams = new URLSearchParams(window.location.search);
        const code = searchParams.get('code');
        console.log("MyCode===============>", code);
        if (code && localStorage.getItem('accessToken') === null) {
            axios.post(constants.BASE_URL + constants.POST_GITHUB_ACCESSCODE, {
                code
            }, {
                headers: {
                    'Accept': 'application/json'
                }
            })
                .then(response => {
                    console.log("response", response)
                    const accessToken = response.data.body.accessToken.access_token;
                    console.log("access_token", accessToken)
                    localStorage.setItem("accessToken", accessToken);
                    setRender(!render)
                })
                .catch(error => console.error(error));
        } else { navigate("/gitHubAllOragnization") }
        // eslint-disable-next-line
    }, []);
    return <div>
        <ProgressBar isVisible={true} progressBarMessage={"please Wait! While you are authenticated"} />
    </div>;
}
export default GitHubPlatform;