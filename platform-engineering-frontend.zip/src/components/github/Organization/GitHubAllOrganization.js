import React, { useEffect } from 'react'
import GitHubLandingBar from '../../../utils/GitHubLandingBar'
import { Avatar, Box, Button, Card, CardActions, CardContent, Grid, Stack, Typography } from '@mui/material'
import axios from 'axios';
import ProgressBar from '../../../utils/ProgressBar';
import ErrorAlert from '../../error/ErrorAlert';
import { useNavigate, useLocation } from 'react-router-dom';
import { Add } from '@mui/icons-material';
import NoOrganization from '../../azure/organization/NoOrganization';
import { constants } from '../../../utils/Constants';
import AlertDialog from '../../error/AlertDialog';

export default function GitHubAllOrganization() {
  const location = useLocation();
  const navigate = useNavigate();
  const [isVisible, setIsVisible] = React.useState(false);
  const [progressBarMessage, setProgressBarMessage] =
    React.useState("Please wait!");
  const [isErrorVisible, setIsErrorVisible] = React.useState(false);
  const [organizationList, setOrganizationList] = React.useState([]);
  const [isAlertVisible, setIsAlertVisible] = React.useState(false);
  const [alertData, setAlertData] = React.useState({
    positiveCallback: {
      navigate: -1,
      navigateData: {
        state: {},
      },
    },
    negativeCallback: {
      navigate: -1,
      navigateData: {
        state: {},
      },
    },
    message:
      "Organization Rule is not created for the organization you are trying to access. Please create rule to proceed further.",
  });

  const callAllorganizationAPI = () => {
    showProgressBar(
      "Please be patient! while organizations are being fetched."
    );
    let config = {
      headers: { authorization: "Bearer " + localStorage.getItem('accessToken') },
      params: {
        platform: "Github"
      },
    };
    axios
      .get(constants.BASE_URL + constants.GET_GITHUB_ORGANIZATION, config)
      .then((response) => {
        console.log(
          "Reponse-getAllOrganization=======>",
          response.data.body.organizations
        );
        hideProgressBar();
        setOrganizationList(response.data.body.organizations);
      })
      .catch((error) => {
        handleErrorAlert(true);
        hideProgressBar();
        console.log("Error-callAllorganizationAPI========>", error);
      });
  };


  useEffect(() => {
    showProgressBar("Please be patient! While user is authorised");
    /**
     * JS method called to retrieve token in getToken callback method
     */
    callAllorganizationAPI();
    // eslint-disable-next-line
  }, []);

  /**
   *
   * @param {*} message String value to be shown with Progress Bar
   * JS method called to make the Progress Bar visible along with the message
   */
  const showProgressBar = (message) => {
    setIsVisible(true);
    setProgressBarMessage(message);
  };
  /**
   *
   * JS method called to hide the Progress Bar
   */
  const hideProgressBar = () => {
    setIsVisible(false);
    setProgressBarMessage("");
  };

  /**
  *
  * @param {*} value boolean value to change visiblity of Alert Dialog
  * JS method to update the boolean state value isErrorVisible
  */
  const handleErrorAlert = (value) => {
    setIsErrorVisible(value);
  };
  /**
   *
   * @param {*} org Object of organization on which user has clicked
   * JS method called when user click on Organization's card component
   */
  const onClickOrganizationCard = (org) => {
    if (org.isRuleExists) {
      navigate("/github/repository", {
        state: {
          organization: org.login,
          routeList: [location.pathname],
        },
      });
    } else {
      setAlertData({
        positiveCallback: {
          navigate: "/github/createRules",
          navigateData: {
            state: {
              organization: org.login,
              routeList: [location.pathname],
            },
          },
        },
        message:
          `Organization Rule is not created for the ${org.login} organization. Please proceed to create rule before accessing the organization.`,
      });
      setIsAlertVisible(true);
    }

  };
  return (
    <Box>
      <ProgressBar
        isVisible={isVisible}
        progressBarMessage={progressBarMessage}
      />
      <ErrorAlert
        isErrorVisible={isErrorVisible}
        callback={() => {
          setIsErrorVisible(false);
          navigate(-1);
        }}
        message={"Something unexpected happend! Please try again"}
      />
      <AlertDialog
        isDialogVisible={isAlertVisible}
        message={alertData.message}
        negativeCallback={() => {
          setIsAlertVisible(false);
          if (
            alertData.hasOwnProperty("negativeCallback") &&
            alertData.negativeCallback.hasOwnProperty("navigate") &&
            alertData.negativeCallback.hasOwnProperty("navigateData")
          ) {
            navigate(
              alertData.negativeCallback.navigate,
              alertData.negativeCallback.navigateData
            );
          } else if (
            alertData.hasOwnProperty("negativeCallback") &&
            alertData.negativeCallback.hasOwnProperty("navigate")
          ) {
            navigate(alertData.negativeCallback.navigate);
          }
        }}
        positiveCallback={() => {
          setIsErrorVisible(false);
          if (
            alertData.hasOwnProperty("positiveCallback") &&
            alertData.positiveCallback.hasOwnProperty("navigate") &&
            alertData.positiveCallback.hasOwnProperty("navigateData")
          ) {
            navigate(
              alertData.positiveCallback.navigate,
              alertData.positiveCallback.navigateData
            );
          } else if (
            alertData.hasOwnProperty("positiveCallback") &&
            alertData.positiveCallback.hasOwnProperty("navigate")
          ) {
            navigate(alertData.positiveCallback.navigate);
          }
        }}
      />
      <GitHubLandingBar />
      <Stack
        direction="row"
        justifyContent="space-between"
        ml={3}
        mr={3}
        mt={3}
      >
        <Typography
          variant="h6"
          color={"#005689"}
          fontWeight={"bold"}
          p={"2px"}
        >
          Organizations
        </Typography>
        {/* <Button
          variant="contained"
          startIcon={
            <Add
              fontSize="30px"
            />
          }
          disabled
          size="small"
        >
          Create Organization
        </Button> */}
      </Stack>

      {organizationList.length > 0 ? (
        <Card
          variant="outlined"
          className="allOrganization-card-organizationList"
        >
          <Grid container>
            {organizationList.map((org, index) => (
              <Grid item xs={6} md={3} key={index}>
                <Card
                  raised={true}
                  onClick={() => {
                    localStorage.setItem(
                      "githubOrganizationName",
                      org.login
                    );
                    onClickOrganizationCard(org);
                  }}
                  className="allOrganization-card-organization allOrganization-button-viewOrganization"
                >
                  <CardContent>
                    <Stack direction="row" spacing={2}>
                      <Avatar
                        variant="square"
                        src={org.avatar_url}
                      />
                      <Typography
                        variant="h7"
                        component="div"
                        color={"#005689"}
                        fontWeight={"bold"}
                      >
                        {org.login}
                      </Typography>
                    </Stack>
                  </CardContent>
                  <CardActions>
                  </CardActions>
                </Card>
              </Grid>
            ))}
          </Grid>
        </Card>
      ) : (
        <NoOrganization />
      )}
    </Box>)
}
