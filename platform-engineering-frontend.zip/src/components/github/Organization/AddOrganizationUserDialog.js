import {
  Button,
  DialogActions,
  DialogContent,
  DialogTitle,
  Divider,
  Stack,
  TextField,
} from "@mui/material";
import Dialog from "@mui/material/Dialog";
import { Box } from "@mui/system";
import React from "react";
import axios from "axios";
import { constants } from "../../../utils/Constants";
import ProgressBar from "../../../utils/ProgressBar";
import ErrorAlert from "../../error/ErrorAlert";
import { useLocation, useNavigate } from "react-router-dom";
import { stringAvatar } from "../../../utils/helper";
import { ColorButton } from "../../../utils/CustomButton";
import { Add } from "@mui/icons-material";

/**
 *
 * @returns React Functional Component (CreateCIPipeline) which renders a dialog by which pipeline will be created for the project.
 */
export default function AddOrganizationUserDialog({
    handleOnOrganizationUserAdded
}) {
  const [open, setOpen] = React.useState(false);
  const { state } = useLocation();
  const [isVisible, setIsVisible] = React.useState(false);
  const [progressBarMessage, setProgressBarMessage] =
    React.useState("Please wait!");
  const [isErrorVisible, setIsErrorVisible] = React.useState(false);
  const [errorAlertCallback, setErrorAlertCallback] = React.useState({
    navigate: -1,
    navigateData: {
      state: {},
    },
    message: "Something unexpected happend! Please try again",
  });
  // eslint-disable-next-line
  const navigate = useNavigate();
  const [repoName, setRepoName] = React.useState("");
  const [technologyType, setTechnologyType] = React.useState("");
  const [isPublishArtifact, setPublishArtifact] = React.useState(false);
  const [userEmail, setUserEmail] = React.useState("");
  // eslint-disable-next-line
  const [selectedUserList, setSelectedUserList] = React.useState([]);
  const [noOfReviewers, setNoOfReviewers] = React.useState("");

  /**
   *
   * @returns JS method callback after dialog is opened.
   */
  const handleClickOpen = () => {
    setOpen(true);
  };

  /**
   *
   * @returns JS method callback after dialog is closed.
   */
  const handleCreateCIPipelineDialogClose = () => {
    setOpen(false);
    setUserEmail("");
  };

  /**
   *
   * JS method to call POST REST Endpoint for posting inputs for pipeline to be created for repository.
   */
  const callAddOrganizationUserAPI = () => {
    showProgressBar("Please be patient! While user is being added.");
    const data = {
      organizationName: localStorage.getItem("githubOrganizationName"),
      organizationMemberRole :"admin",
      memberEmailId: userEmail,
    };
    console.log("callAddOrganizationUserAPI============>", data);
    let config = {
      headers: {
        authorization: "Bearer " + localStorage.getItem("accessToken"),
      },
    };
    axios
      .post(
        constants.BASE_URL + constants.POST_GITHUB_ADD_ORGANIZATION_USER,
        data,
        config
      )
      .then((response) => {
        hideProgressBar();
        handleOnOrganizationUserAdded();
        handleCreateCIPipelineDialogClose();
        console.log("Response-callAddOrganizationUserAPI========>", response);
      })
      .catch((error) => {
        hideProgressBar(); // eslint-disable-next-line
        setErrorAlertCallback({
          message:
            "Something went wrong while adding user in organization. Please try again!",
        });
        handleErrorAlert(true);
        console.log("Error-callAddOrganizationUserAPI=========>", error.response);
      });
  };

  const handleClose = (event, reason) => {
    // eslint-disable-next-line
    if (reason && reason == "backdropClick") return;
    handleCreateCIPipelineDialogClose();
  };

  /**
   *
   * @param {*} value boolean value to change visiblity of Alert Dialog
   * JS method to update the boolean state value isErrorVisible
   */
  const handleErrorAlert = (value) => {
    setIsErrorVisible(value);
  };

  /**
   *
   * @param {*} message String value to be shown with Progress Bar
   * JS method called to make the Progress Bar visible along with the message
   */
  const showProgressBar = (message) => {
    setIsVisible(true);
    setProgressBarMessage(message);
  };

  /**
   *
   * JS method called to hide the Progress Bar
   */
  const hideProgressBar = () => {
    setIsVisible(false);
    setProgressBarMessage("");
  };

  /**
   *
   * @param {*} event method to handle repository name for pipeline.
   */
  const handleRepoNameChange = (event) => {
    setRepoName(event.target.value);
  };

  /**
   *
   * @param {*} event method to handle technology type for pipeline.
   */
  const handleTechnologyTypeChange = (event) => {
    setTechnologyType(event.target.value);
  };

  /**
   *
   * @param {*} event method to handle publishArtifact type for pipeline.
   */
  const handlePublishArtifactChange = (event) => {
    // eslint-disable-next-line
    setPublishArtifact(event.target.value == "true");
  };

  return (
    <Box>
      <ColorButton
        backgroundcolor="#005689"
        variant="contained"
        size="small"
        onClick={handleClickOpen}
        startIcon={<Add />}
      >
        New User
      </ColorButton>
      <Dialog open={open} onClose={handleClose}>
        <ProgressBar
          isVisible={isVisible}
          progressBarMessage={progressBarMessage}
        />
        <ErrorAlert
          isErrorVisible={isErrorVisible}
          callback={() => {
            setIsErrorVisible(false);
            if (
              errorAlertCallback.hasOwnProperty("navigate") &&
              errorAlertCallback.hasOwnProperty("navigateData")
            ) {
              navigate(
                errorAlertCallback.navigate,
                errorAlertCallback.navigateData
              );
            } else if (errorAlertCallback.hasOwnProperty("navigate")) {
              navigate(errorAlertCallback.navigate);
            }
          }}
          message={errorAlertCallback.message}
        />
        <DialogTitle className="createCIPipeline-dialogTitle">
          Add Organization User
        </DialogTitle>
        <Divider className="createCIPipeline-divider" />
        <DialogContent>
          <Stack direction={"column"} spacing={1} width={"350px"}>
            <TextField
              variant="outlined"
              fullWidth
              label="Organization Name"
              required
              value={localStorage.getItem("githubOrganizationName")}
              disabled
            />
            <TextField
              variant="outlined"
              fullWidth
              disabled
              label="Organization Member Role"
              required
              value={"Admin"}
              onChange={(event) => setUserEmail(event.target.value)}
            />
            <TextField
              variant="outlined"
              fullWidth
              label="User Email ID"
              required
              value={userEmail}
              onChange={(event) => setUserEmail(event.target.value)}
            />
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button
            className="createCIPipeline-button-cancel"
            onClick={handleClose}
          >
            Cancel
          </Button>
          <Button
            className="createCIPipeline-button-create"
            disabled={!userEmail.trim().length}
            onClick={callAddOrganizationUserAPI}
          >
            Add User
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
