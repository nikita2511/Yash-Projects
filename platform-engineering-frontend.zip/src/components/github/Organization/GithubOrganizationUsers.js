import {
  Avatar,
  Box,
  Card,
  Divider,
  Grid,
  Stack,
  Typography,
} from "@mui/material";
import React from "react";
import ProgressBar from "../../../utils/ProgressBar";
import ErrorAlert from "../../error/ErrorAlert";
import CustomBreadCrumb from "../../../utils/CustomBreadCrumb";
import { useLocation, useNavigate } from "react-router-dom";
import axios from "axios";
import { constants } from "../../../utils/Constants";
import AddOrganizationUserDialog from "./AddOrganizationUserDialog";

export default function GithubRepositoryUsers() {
  const location = useLocation();
  const { state } = location;
  const navigate = useNavigate();
  const [isVisible, setIsVisible] = React.useState(false);
  const [progressBarMessage, setProgressBarMessage] =
    React.useState("Please wait!");
  const [errorAlertCallback, setErrorAlertCallback] = React.useState({
    navigate: -1,
    navigateData: {
      state: {},
    },
    message: "Something unexpected happend! Please try again",
  });
  const [errorAlertMessage, setErrorAlertMessage] = React.useState(
    "Something unexpected happend! Please try again"
  );
  const [isErrorVisible, setIsErrorVisible] = React.useState(false);
  const [repoUsers, setRepoUsers] = React.useState([]);

  /**
   *
   * @param {*} message String value to be shown with Progress Bar
   * JS method called to make the Progress Bar visible along with the message
   */
  const showProgressBar = (message) => {
    setIsVisible(true);
    setProgressBarMessage(message);
  };

  /**
   *
   * JS method called to hide the Progress Bar
   */
  const hideProgressBar = () => {
    setIsVisible(false);
    setProgressBarMessage("");
  };

  const handleErrorAlert = (value, message) => {
    setIsErrorVisible(value);
    setErrorAlertMessage(message);
  };

  const callGetUserForOrganization = () => {
    showProgressBar(
      "Please be patient! while information related to existing repository are being fetched"
    );
    let config = {
      headers: {
        authorization: "Bearer " + localStorage.getItem("accessToken"),
      },
      params: {
        organizationName: localStorage.getItem("githubOrganizationName"),
      },
    };
    axios
      .get(constants.BASE_URL + constants.GET_GITHUB_ORGANIZATION_USER, config)
      .then((response) => {
        hideProgressBar();
        console.log(
          "callGetUserForOrganizationcallGetCollaboratorForRepo=======>",
          response.data.body.members
        );
        setRepoUsers(response.data.body.members);
      })
      .catch((error) => {
        hideProgressBar();
        console.log("Error-callGetUserForOrganization========>", error);
        handleErrorAlert(true);
        setErrorAlertCallback({
          message:
            "Something went wrong while fetching users. Please try again!",
        });
        setRepoUsers([]);
      });
  };

  React.useEffect(() => {
    callGetUserForOrganization();
  }, []);
  return (
    <Box>
      <ProgressBar
        isVisible={isVisible}
        progressBarMessage={progressBarMessage}
      />
      <ErrorAlert
        isErrorVisible={isErrorVisible}
        callback={() => {
          setIsErrorVisible(false);
          if (
            errorAlertCallback.hasOwnProperty("navigate") &&
            errorAlertCallback.hasOwnProperty("navigateData")
          ) {
            navigate(
              errorAlertCallback.navigate,
              errorAlertCallback.navigateData
            );
          } else if (errorAlertCallback.hasOwnProperty("navigate")) {
            navigate(errorAlertCallback.navigate);
          }
        }}
        message={errorAlertCallback.message}
      />
      <Box className="createProject-box1">
        <CustomBreadCrumb
          routeList={state.routeList}
          location={location.pathname}
        />
      </Box>
      <Box>
      <Stack
        direction="row"
        justifyContent="space-between"
        alignItems={"center"}
        mb={0.5}
      >
        <Typography className="createProject-typography1" variant="h6" mb={1}>
          Users in {state.organizationName}
        </Typography>
        <AddOrganizationUserDialog handleOnOrganizationUserAdded={callGetUserForOrganization}/>
        
        </Stack>
        <Divider />
        {repoUsers.length > 0 ? (
          <Box mt={2}>
            <Grid
              container
              spacing={{ xs: 2, md: 3 }}
              columns={{ xs: 4, sm: 8, md: 12 }}
            >
              {repoUsers.map((user, index) => (
                <Grid item xs={6} sm={3} md={3} key={index}>
                  <Card className="projectTabs-card-user">
                    <Stack
                      direction="row"
                      spacing={1}
                      alignItems="center"
                      m={1}
                    >
                      <Avatar src={user.avatar_url} />
                      <Box>
                        <Typography color={"#005689"} fontWeight={"bold"}>
                          {user.login}
                        </Typography>
                      </Box>
                    </Stack>
                  </Card>
                </Grid>
              ))}
            </Grid>
          </Box>
        ) : (
          <Typography
            variant="h6"
            gutterBottom
            color={"#005689"}
            textAlign={"center"}
            mt={2}
          >
            {`Users are not added for the ${state.organizationName} organization yet`}
          </Typography>
        )}
      </Box>
    </Box>
  );
}
