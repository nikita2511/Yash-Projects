import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Box,
  Button,
  Chip,
  Divider,
  Grid,
  Stack,
  Switch,
  TextField,
  Typography,
} from "@mui/material";
import React from "react";
import { useNavigate } from "react-router-dom";
import ProgressBar from "../../../utils/ProgressBar";
import ErrorAlert from "../../error/ErrorAlert";
import LandingBar from "../../../utils/LandingBar";
import { ColorButton } from "../../../utils/CustomButton";
import { ExpandMoreOutlined } from "@mui/icons-material";
import axios from "axios";
import { constants } from "../../../utils/Constants";

export default function ClientInfo() {
  const navigate = useNavigate();
  const [isVisible, setIsVisible] = React.useState(false);
  const [progressBarMessage, setProgressBarMessage] =
    React.useState("Please wait!");
  const [isErrorVisible, setIsErrorVisible] = React.useState(false);
  const [errorAlertCallback, setErrorAlertCallback] = React.useState({
    navigate: -1,
    navigateData: {
      state: {},
    },
    message: "Something unexpected happend! Please try again",
  });
  const [applicationName, setApplicationName] = React.useState("");
  const [clientId, setClientId] = React.useState("");
  const [clientSecret, setClientSecret] = React.useState("");
  const [scope, setScope] = React.useState("");
  const [redirectURI, setRedirectURI] = React.useState("");
  const [clientInfoList, setClientInfoList] = React.useState([]);
  /**
   *
   * @param {*} message String value to be shown with Progress Bar
   * JS method called to make the Progress Bar visible along with the message
   */
  const showProgressBar = (message) => {
    setIsVisible(true);
    setProgressBarMessage(message);
  };
  /**
   *
   * JS method called to hide the Progress Bar
   */
  const hideProgressBar = () => {
    setIsVisible(false);
    setProgressBarMessage("");
  };
  /**
      *
      * @param {*} value boolean value to change visiblity of Alert Dialog
       JS method to update the boolean state value isErrorVisible
      */
  const handleErrorAlert = (value) => {
    setIsErrorVisible(value);
  };

  const clearClientInfoFields = ()=>{
    setApplicationName("");
    setClientId("");
    setClientSecret("");
    setScope("");
    setRedirectURI("");
  }

  const callCreateClientInfoAPI = () => {
    showProgressBar("Please be patient! while client info is being saved.");
    const data = {
      applicationName: applicationName,
      applicationClientId: clientId,
      applicationClientSecret: clientSecret,
      scopes: scope,
      redirectUri: redirectURI,
    };
    axios
      .post(constants.BASE_URL + constants.POST_GITHUB_CREATE_CLIENT_INFO, data)
      .then((response) => {
        hideProgressBar();
        console.log("callCreateClientInfoAPI======>",response);
        callGetClientInfoAPI();
        clearClientInfoFields();
        setErrorAlertCallback({
          message: `Client Information for ${applicationName} saved successfully!`,
        });
        handleErrorAlert(true);
      })
      .catch((error) => {
        hideProgressBar();
        handleErrorAlert(true);
        console.log("Error-callCreateClientInfoAPI======>",error);
      });
  };
  /**
   *
   * JS method to call GET REST Endpoint for retrieving availble client info for github
   */
  const callGetClientInfoAPI = () => {
    showProgressBar(
      "Please be patient! while Active Directories are being fetched."
    );
    axios
      .get(constants.BASE_URL + constants.GET_GITHUB_CLIENT_INFO)
      .then((response) => {
        console.log("callGetClientInfoAPI=========>", response);
        hideProgressBar();
        setClientInfoList(response.data.body.githubClientDetails);
      })
      .catch((error) => {
        hideProgressBar();
        handleErrorAlert(true);
        console.log("Error-callGetClientInfoAPI=========>", error);
      });
  };

  React.useEffect(() => {
    callGetClientInfoAPI();
    // eslint-disable-next-line
  }, []);
  return (
    <Box>
      <ProgressBar
        isVisible={isVisible}
        progressBarMessage={progressBarMessage}
      />
      <ErrorAlert
        isErrorVisible={isErrorVisible}
        callback={() => {
          setIsErrorVisible(false);
          if (
            errorAlertCallback.hasOwnProperty("navigate") &&
            errorAlertCallback.hasOwnProperty("navigateData")
          ) {
            navigate(
              errorAlertCallback.navigate,
              errorAlertCallback.navigateData
            );
          } else if (errorAlertCallback.hasOwnProperty("navigate")) {
            navigate(errorAlertCallback.navigate);
          }
        }}
        message={errorAlertCallback.message}
      />
      <Box ml={3} mr={3}>
        <LandingBar />
        <Typography
          variant="h6"
          color={"#005689"}
          fontWeight={"bold"}
          mt={1.4}
          gutterBottom
        >
          Github Client Info
        </Typography>
        <Divider />

        <Stack direction={"row"} spacing={2} mt={4}>
          <Stack direction={"column"} spacing={1.5} width={"50%"}>
            <TextField
              variant="outlined"
              fullWidth
              label="Application Name"
              size="medium"
              value={applicationName}
              required
              helperText={
                applicationName.trim().length ? "" : "Please enter company name"
              }
              //   error={!applicationName.trim().length}
              onChange={(event) => setApplicationName(event.target.value)}
            />
            <TextField
              variant="outlined"
              fullWidth
              label="Registered Client Secret"
              size="medium"
              value={clientSecret}
              required
              helperText={
                clientSecret.trim().length ? "" : "Please enter Client Secret"
              }
              //   error={!clientId.trim().length}
              onChange={(event) => setClientSecret(event.target.value)}
            />
            <TextField
              variant="outlined"
              fullWidth
              label="Redirect URI for Application"
              size="medium"
              value={redirectURI}
              required
              helperText={
                redirectURI.trim().length ? "" : "Please enter redirect URI"
              }
              //   error={!scope.trim().length}
              onChange={(event) => setRedirectURI(event.target.value)}
            />
          </Stack>

          <Stack direction={"column"} spacing={1.5} width={"50%"}>
            <TextField
              variant="outlined"
              fullWidth
              label="Registered Application Id/ Client Id"
              size="medium"
              value={clientId}
              required
              helperText={
                clientId.trim().length
                  ? ""
                  : "Please enter ApplicationId / ClientId"
              }
              //   error={!clientId.trim().length}
              onChange={(event) => setClientId(event.target.value)}
            />
            <TextField
              variant="outlined"
              fullWidth
              label="Scope for Application"
              size="medium"
              value={scope}
              required
              helperText={scope.trim().length ? "" : "Please enter Scope "}
              //   error={!scope.trim().length}
              onChange={(event) => setScope(event.target.value)}
            />
          </Stack>
        </Stack>
        <Stack direction="row" justifyContent="flex-end" mt={2} spacing={2}>
          <ColorButton
            backgroundcolor="#005689"
            variant="contained"
            size="small"
            onClick={() => navigate(-1)}
          >
            BACK
          </ColorButton>
          <ColorButton
            backgroundcolor="#005689"
            variant="contained"
            size="small"
            onClick={callCreateClientInfoAPI}
            disabled={
              !(
                applicationName.trim().length &&
                clientSecret.trim().length &&
                clientId.trim().length &&
                scope.trim().length &&
                redirectURI.trim().length
              )
            }
          >
            Save Client Information
          </ColorButton>
        </Stack>
        <Typography
          variant="h6"
          color={"#005689"}
          fontWeight={"bold"}
          mt={1.4}
          gutterBottom
        >
          Saved Client Information
        </Typography>
        <Divider />
        {clientInfoList.length > 0 ? (
          <Grid container spacing={2} mt={1} mb={1}>
            {clientInfoList.map((info, index) => (
              <Grid item xs={12} md={6} key={index}>
                <Accordion>
                  <AccordionSummary
                    expandIcon={<ExpandMoreOutlined />}
                    aria-controls="panel1a-content"
                    id="panel1a-header"
                  >
                    <Typography
                      variant="subtitle1"
                      color={"#005689"}
                      fontWeight={"bold"}
                      mr={3}
                    >
                      {info.applicationName}
                    </Typography>
                  </AccordionSummary>
                  <AccordionDetails>
                    <Stack direction={"row"} spacing={2}>
                      <Stack direction={"column"} spacing={1.5} width={"50%"}>
                        <TextField
                          className="ADInfo-Text"
                          variant="outlined"
                          fullWidth
                          label="Application Name"
                          size="medium"
                          value={info.applicationName}
                          required
                          disabled={!info.isActive}
                        />
                        <TextField
                          className="ADInfo-Text"
                          variant="outlined"
                          fullWidth
                          label="Registered Client Secret"
                          size="medium"
                          value={info.applicationClientSecret}
                          required
                          disabled={!info.isActive}
                        />
                        <TextField
                          className="ADInfo-Text"
                          variant="outlined"
                          fullWidth
                          label="Redirect URI for Application"
                          size="medium"
                          value={info.redirectUri}
                          required
                          disabled={!info.isActive}
                        />
                      </Stack>

                      <Stack direction={"column"} spacing={1.5} width={"50%"}>
                        <TextField
                          variant="outlined"
                          fullWidth
                          label="Registered Client Id"
                          size="medium"
                          value={info.applicationClientId}
                          required
                          disabled={!info.isActive}
                        />
                        <TextField
                          variant="outlined"
                          fullWidth
                          label="Scope for Application"
                          size="medium"
                          value={info.scopes}
                          required
                          disabled={!info.isActive}
                        />
                      </Stack>
                    </Stack>
                    <Stack
                      justifyContent={"flex-end"}
                      display={"flex"}
                      direction={"row"}
                      mt={2}
                      spacing={2}
                    >
                      <Button
                        variant="outlined"
                        disabled
                        onClick={() => {
                          //   handleOnADInfoEditClick(info._id);
                        }}
                      >
                        {!info.isActive ? "Edit" : "Save"} Client Info
                      </Button>
                      <Button
                        variant="outlined"
                        color="error"
                        disabled
                        onClick={() => {
                          //   callDeleteADInfoAPI(info);
                        }}
                      >
                        Delete Client Info
                      </Button>
                    </Stack>
                  </AccordionDetails>
                </Accordion>
              </Grid>
            ))}
          </Grid>
        ) : (
          <Typography
            variant="h6"
            gutterBottom
            color={"#005689"}
            textAlign={"center"}
            mt={2}
          >
            {`Client Information is not added yet!`}
          </Typography>
        )}
      </Box>
    </Box>
  );
}
