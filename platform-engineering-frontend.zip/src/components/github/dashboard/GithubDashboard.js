import React from "react";
import { Box } from "@mui/material";
import { useLocation } from "react-router-dom";
import GithubHeader from "./GithubHeader";
import SomethingWrong from "../../error/SomethingWrong";
import GithubRepositories from "../repository/GithubRepositories";
import ExistingRepositories from "../repository/ExistingRepositories";
import GithubUpdateRules from "../Organization/rules/GithubUpdateRules";
import GithubOrganizationUsers from "../Organization/GithubOrganizationUsers";
import CreateRepository from "../repository/CreateRepository";

export default function GithubDashboard() {
  let location = useLocation();
  /**
   *
   * @param {*} route current pathname or route name
   * @returns the component as per current pathname or route name
   */
  const GetComponentToRender = ({ route }) => {
    switch (route) {
      case "/github/repository":
        return <GithubRepositories />;
      case "/github/repository/info":
        return <ExistingRepositories />;
      case "/github/updateRules":
        return <GithubUpdateRules />;
      case "/github/organizationUser":
        return <GithubOrganizationUsers />;
      case "/github/createRepository":
        return <CreateRepository />;
      default:
        return <SomethingWrong />;
    }
  };
  return (
    <Box>
      <GithubHeader>
        <GetComponentToRender route={location.pathname} />
      </GithubHeader>
    </Box>
  );
}
