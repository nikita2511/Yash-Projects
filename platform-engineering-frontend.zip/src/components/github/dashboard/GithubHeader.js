import * as React from "react";
import { styled, useTheme } from "@mui/material/styles";
import Box from "@mui/material/Box";
import Drawer from "@mui/material/Drawer";
import CssBaseline from "@mui/material/CssBaseline";
import MuiAppBar from "@mui/material/AppBar";
import Toolbar from "@mui/material/Toolbar";
import List from "@mui/material/List";
import Typography from "@mui/material/Typography";
import Divider from "@mui/material/Divider";
import IconButton from "@mui/material/IconButton";
import MenuIcon from "@mui/icons-material/Menu";
import ChevronLeftIcon from "@mui/icons-material/ChevronLeft";
import ChevronRightIcon from "@mui/icons-material/ChevronRight";
import ListItem from "@mui/material/ListItem";
import ListItemButton from "@mui/material/ListItemButton";
import ListItemIcon from "@mui/material/ListItemIcon";
import ListItemText from "@mui/material/ListItemText";
import { NavLink } from "react-router-dom";
import {
  LogoutOutlined,
  FormatListBulletedOutlined,
  LocalPoliceOutlined,
} from "@mui/icons-material";
/**
 * constant for drawer width
 */
const drawerWidth = 240;
/**
 * custom container compnent to host other components as childern
 */
const Main = styled("main", {
  shouldForwardProp: (prop) => prop !== "open",
})(({ theme, open }) => ({
  flexGrow: 1,
  padding: theme.spacing(3),
  transition: theme.transitions.create("margin", {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  marginLeft: `-${drawerWidth}px`,
  ...(open && {
    transition: theme.transitions.create("margin", {
      easing: theme.transitions.easing.easeOut,
      duration: theme.transitions.duration.enteringScreen,
    }),
    marginLeft: 0,
  }),
}));
/**
 * custom MUI AppBar component
 */
const AppBar = styled(MuiAppBar, {
  shouldForwardProp: (prop) => prop !== "open",
})(({ theme, open }) => ({
  transition: theme.transitions.create(["margin", "width"], {
    easing: theme.transitions.easing.sharp,
    duration: theme.transitions.duration.leavingScreen,
  }),
  ...(open && {
    width: `calc(100% - ${drawerWidth}px)`,
    marginLeft: `${drawerWidth}px`,
    transition: theme.transitions.create(["margin", "width"], {
      easing: theme.transitions.easing.easeOut,
      duration: theme.transitions.duration.enteringScreen,
    }),
  }),
}));
/**
 * custom container component which is used as header in side drawer
 */
export const DrawerHeader = styled("div")(({ theme }) => ({
  display: "flex",
  alignItems: "center",
  padding: theme.spacing(0, 1),
  // necessary for content to be below app bar
  ...theme.mixins.toolbar,
  justifyContent: "flex-end",
}));
/**
 *  
 * @param {*} props
 * @returns React Functional Component (Header) which is used as Toolbar in other components in flow
 */
export default function GithubHeader(props) {
  const theme = useTheme();
  const [open, setOpen] = React.useState(false);
  /**
   * callback method called when drawer open icon is clicked
   * changes drawer visiblity state
   */
  const handleDrawerOpen = () => {
    setOpen(true);
  };
  /**
   * callback method called when drawer close icon is clicked.
   * Also, called when drawer is closed due to any other reason
   * changes drawer visiblity state
   */
  const handleDrawerClose = () => {
    setOpen(false);
  };
  /**
   * constant userNavMenuList assigned array of routes in the flow with their icon and route history array
   */
  const userNavMenuList = [
    {
      title: "Projects",
      icon: <FormatListBulletedOutlined />,
      linkTo: "/github/repository",
      routeList: ["/github"]
    },
    {
      title: "Organization Rules",
      icon: <LocalPoliceOutlined />,
      linkTo: "/github/updateRules",
      routeList: ["/github"]
    },
  ];
  const userActionList = [];
  /**
   * callback to handle logout
   */
  const handleLogoutRedirect = () => {
  };
  return (
    <Box className="header-box">
      <CssBaseline />
      <AppBar className="header-appBar"
        position="fixed"
        open={open}
      >
        <Toolbar>
          <IconButton
            className={open ? "header-iconButton-menu" : ""}
            color="inherit"
            aria-label="open drawer"
            onClick={handleDrawerOpen}
            edge="start"
            mr={2}
          >
            <MenuIcon />
          </IconButton>
          <Typography
            className="header-typography"
            letterSpacing={2}
            variant="h6"
            noWrap
            component="a"
            href="/"
          >
            DevOps Platform Engineering
          </Typography>
        </Toolbar>
      </AppBar>
      <Drawer
        className="header-drawer"
        variant="persistent"
        anchor="left"
        open={open}
      >
        <DrawerHeader>
          <IconButton onClick={handleDrawerClose}>
            {theme.direction === "ltr" ? (
              <ChevronLeftIcon />
            ) : (
              <ChevronRightIcon />
            )}
          </IconButton>
        </DrawerHeader>
        <Divider />
        <List>
          {userNavMenuList.map((item, index) => (
            <ListItem key={index} disablePadding>
              <NavLink
                className="nav-links header-navlink"
                activeclassname="active"
                to={item.linkTo}
                state={{
                  routeList: item.routeList
                }}
              >
                <ListItemButton onClick={handleDrawerClose}>
                  <ListItemIcon>{item.icon}</ListItemIcon>
                  <ListItemText
                    primary={item.title}
                  />
                </ListItemButton>
              </NavLink>
            </ListItem>
          ))}
        </List>
        <Divider />
        <List>
          {userActionList.map((item, index) => (
            <ListItem key={index} disablePadding>
              <NavLink
                className="nav-links header-navlink "
                activeclassname="active"
                to={item.linkTo}
              >
                <ListItemButton>
                  <ListItemIcon>{item.icon}</ListItemIcon>
                  <ListItemText
                    primary={item.title}
                  />
                </ListItemButton>
              </NavLink>
            </ListItem>
          ))}
          <ListItem key={"logout"} disablePadding onClick={handleLogoutRedirect}>
            <Box className="header-listItem-box">
              <ListItemButton>
                <ListItemIcon>
                  <LogoutOutlined />
                </ListItemIcon>
                <ListItemText
                  primary={"Logout"}
                />
              </ListItemButton>
            </Box>
          </ListItem>
        </List>
      </Drawer>
      <Main open={open}>
        <DrawerHeader />
        {props.children}
      </Main>
    </Box>
  );
}
