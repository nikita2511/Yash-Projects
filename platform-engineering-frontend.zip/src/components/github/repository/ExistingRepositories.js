import React from "react";
import { constants } from "../../../utils/Constants";
import axios from "axios";
import { useEffect } from "react";
import {
  Box,
  Button,
  Card,
  Dialog,
  DialogActions,
  DialogContent,
  DialogContentText,
  DialogTitle,
  Divider,
  Stack,
  Typography,
} from "@mui/material";
import ProgressBar from "../../../utils/ProgressBar";
import ErrorAlert from "../../error/ErrorAlert";
import { useLocation, useNavigate } from "react-router-dom";
import RepositoryTab from "./RepositoryTab";
import { useState } from "react";
import CustomBreadCrumb from "../../../utils/CustomBreadCrumb";
import { ColorButton } from "../../../utils/CustomButton";
import { Add } from "@mui/icons-material";
import AddCollaboratorsDialog from "./AddCollaboratorsDialog";
import CreatePipelineDialog from "./CreatePipelineDialog";
import AddEnviromentDialog from "./AddEnviromentDialog";
import AddEnvVariableDialog from "./AddEnvVariableDialog";
// import RepositoryTab from './RepositoryTab';
export default function ExistingRepositories() {
  const [isVisible, setIsVisible] = React.useState(false);
  const [progressBarMessage, setProgressBarMessage] =
    React.useState("Please wait!");
  const [isErrorVisible, setIsErrorVisible] = React.useState(false);
  const [errorAlertMessage, setErrorAlertMessage] = React.useState(
    "Something unexpected happend! Please try again"
  );
  const location = useLocation();
  const navigate = useNavigate();
  const [tabId, setTabId] = useState(0);
  const { state } = location;
  const [repoBranches, SetRepoBranches] = React.useState([]);
  const [repoVariables, SetRepoVariables] = React.useState([]);
  const [repoSecretVariables, SetRepoSecretVariables] = React.useState([]);
  const [repoPipelines, SetRepoPipeliness] = React.useState([]);
  const [repoCollaborators, setRepoCollaborators] = React.useState([]);
  const [errorAlertCallback, setErrorAlertCallback] = React.useState({
    navigate: -1,
    navigateData: {
      state: {},
    },
    message: "Something unexpected happend! Please try again",
  });
  const [existingUserToDelete, setExistingUserToDelete] = React.useState({});
  const [isConfirmDeleteOpen, setIsConfirmDeleteOpen] = React.useState(false);
  const [variableGroupDialogIsOpen, setVariableGroupDialogIsOpen] =
    useState(false);

  const callGetBranchesForRepository = () => {
    showProgressBar(
      "Please be patient! while information related to existing repository are being fetched"
    );
    let config = {
      headers: {
        authorization: "Bearer " + localStorage.getItem("accessToken"),
      },
      params: {
        repositoryName: state.repository.name,
        organizationName: localStorage.getItem("githubOrganizationName"),
      },
    };
    axios
      .get(
        constants.BASE_URL + constants.GET_GITHUB_REPOSITORY_BRANCHES,
        config
      )
      .then((response) => {
        hideProgressBar();
        console.log(
          "Reponse-callGetBranchesForRepository=======>",
          response.data.body.branches
        );
        console.log("state", state);
        SetRepoBranches(response.data.body.branches);
      })
      .catch((error) => {
        hideProgressBar();
        console.log("Error-callGetBranchesForRepository========>", error);
        handleErrorAlert(true);
        setErrorAlertCallback({
          message:
            "Something went wrong while fetching branches. Please try again!",
        });
        SetRepoBranches([]);
      });
  };

  const callGetVariablesForRepository = () => {
    showProgressBar(
      "Please be patient! while information related to existing repository are being fetched"
    );
    let config = {
      headers: {
        authorization: "Bearer " + localStorage.getItem("accessToken"),
      },
      params: {
        organizationName: localStorage.getItem("githubOrganizationName"),
        RepoName: state.repository.name,
        RepoId: state.repository.id,
      },
    };
    axios
      .get(constants.BASE_URL + constants.GET_GITHUB_VARIABLES, config)
      .then((response) => {
        hideProgressBar();
        console.log(
          "callGetVariablesForRepository=======>",
          response.data.body.result
        );
        SetRepoVariables(response.data.body.result);
      })
      .catch((error) => {
        hideProgressBar();
        console.log("Error-callGetVariablesForRepository========>", error);
        handleErrorAlert(true);
        setErrorAlertCallback({
          message:
            "Something went wrong while fetching variables. Please try again!",
        });
        SetRepoVariables([]);
      });
  };

  const callGetSecretVariablesForRepository = () => {
    showProgressBar(
      "Please be patient! while information related to existing repository are being fetched"
    );
    let config = {
      headers: {
        authorization: "Bearer " + localStorage.getItem("accessToken"),
      },
      params: {
        organizationName: localStorage.getItem("githubOrganizationName"),
        RepoName: state.repository.name,
        RepoId: state.repository.id,
      },
    };
    axios
      .get(constants.BASE_URL + constants.GET_GITHUB_SECRETVARIABLES, config)
      .then((response) => {
        hideProgressBar();
        console.log(
          "callGetSecretVariablesForRepository=======>",
          response.data.body.result
        );
        SetRepoSecretVariables(response.data.body.result);
      })
      .catch((error) => {
        hideProgressBar();
        console.log("Error-callGetSecretVariablesForRepository========>", error);
        handleErrorAlert(true);
        setErrorAlertCallback({
          message:
            "Something went wrong while fetching variables. Please try again!",
        });
        SetRepoSecretVariables([]);
      });
  };

  const callGetPipelineForRepository = () => {
    showProgressBar(
      "Please be patient! while information related to existing repository are being fetched"
    );
    let config = {
      headers: {
        authorization: "Bearer " + localStorage.getItem("accessToken"),
      },
      params: {
        organizationName: localStorage.getItem("githubOrganizationName"),
        repository: state.repository.name,
      },
    };
    axios
      .get(constants.BASE_URL + constants.GET_GITHUB_PIPELINES, config)
      .then((response) => {
        hideProgressBar();
        console.log(
          "callGetPipelineForRepository=======>",
          response.data.body.pipelines.workflows
        );
        SetRepoPipeliness(response.data.body.pipelines.workflows);
      })
      .catch((error) => {
        hideProgressBar();
        console.log("Error-callGetPipelineForRepository========>", error);
        handleErrorAlert(true);
        setErrorAlertCallback({
          message:
            "Something went wrong while fetching pipelines. Please try again!",
        });
        SetRepoPipeliness([]);
      });
  };

  const callGetCollaboratorForRepo = () => {
    showProgressBar(
      "Please be patient! while information related to existing repository are being fetched"
    );
    let config = {
      headers: {
        authorization: "Bearer " + localStorage.getItem("accessToken"),
      },
      params: {
        organizationName: localStorage.getItem("githubOrganizationName"),
        repositoryName: state.repository.name,
      },
    };
    axios
      .get(constants.BASE_URL + constants.GET_GITHUB_REPO_COLLABORATORS, config)
      .then((response) => {
        hideProgressBar();
        console.log(
          "callGetCollaboratorForRepo=======>",
          response.data.body.repositoryCollaborators
        );
        setRepoCollaborators(response.data.body.repositoryCollaborators);
      })
      .catch((error) => {
        hideProgressBar();
        console.log("Error-callGetCollaboratorForRepo========>", error);
        handleErrorAlert(true);
        if (error.response.status === 403) {
          setErrorAlertCallback({
            message: error.response.data.body.message,
          });
        } else {
          setErrorAlertCallback({
            message:
              "Something went wrong while fetching collaborators. Please try again!",
          });
        }
        setRepoCollaborators([]);
      });
  };

  const onProjectTabChange = (id) => {
    setTabId(id);
  };

  useEffect(() => {
    setTabId(state.tabId);
    // eslint-disable-next-line
  }, [state.tabId]);

  useEffect(() => {
    showProgressBar(
      "Please be patient! while information related to existing Repositories are being fetched"
    );
    /**
     * JS method called to retrieve token in getToken.... callback method
     */
    callGetBranchesForRepository();
    callGetVariablesForRepository();
    callGetSecretVariablesForRepository();
    callGetPipelineForRepository();
    callGetCollaboratorForRepo();
  }, []);

  const handleErrorAlert = (value, message) => {
    setIsErrorVisible(value);
    setErrorAlertMessage(message);
  };

  /**
   * JS method to handle add new pipeline
   */
  const onNewPipelineAdded = () => {
    callGetPipelineForRepository();
    callGetBranchesForRepository();
    setTabId(0);
  };
  /**
   * JS method called to retrieve token in getToken.... callback method
   */
  const onNewUserAdded = () => {
    callGetCollaboratorForRepo();
    setTabId(3);
  };
  /**
   *
   * @param {*} message String value to be shown with Progress Bar
   * JS method called to make the Progress Bar visible along with the message
   */
  const showProgressBar = (message) => {
    setIsVisible(true);
    setProgressBarMessage(message);
  };

  /**
   *
   * JS method called to hide the Progress Bar
   */
  const hideProgressBar = () => {
    setIsVisible(false);
    setProgressBarMessage("");
  };

  /**
   *
   * @param {*} user alredy exist in project
   * @returns set new user list
   */
  const onDeleteExistingCollaborator = (user) => {
    console.log("onDeleteExistingCollaborator==========>", user);
    setExistingUserToDelete(user);
    setIsConfirmDeleteOpen(true);
  };

  /**
  *
  * @param {*} user alredy exist in project
  * @returns set new user list
  */
  const onDeleteExistingVariable = (variable, variables) => {
    console.log("variable", variable);
    console.log("variables", variables);

    const data = {
      repository_id: state.repository.id,
      environment_name: variables.environmentName,
      variablename: variable.name,
    };
    let config = {
      headers: {
        authorization: "Bearer " + localStorage.getItem("accessToken"),
      },
    };
    // console.log("onTokenForDeleteExistingUser==========>", config);
    axios
      .delete(
        constants.BASE_URL + constants.DELETE_GITHUB_VARIABLE + `?repository_id=${state.repository.id}&environment_name=${variables.environmentName}&variablename=${variable.name}`,
        config
      )
      .then((response) => {
        console.log(
          "onDeleteExistingVariable============>",
          response
        );
        // hideProgressBar();
        // setIsConfirmDeleteOpen(false);
        // callGetCollaboratorForRepo();
        callGetVariablesForRepository();
        callGetSecretVariablesForRepository();
      })
      .catch((error) => {
        hideProgressBar();
        console.log("onDeleteExistingVariable-Error============>", error);
        handleErrorAlert(true);
        setErrorAlertCallback({
          message:
            "Something went wrong while deleting variable. Please try again!",
        });
      });
  };


  /**
  *
  * @param {*} user alredy exist in project
  * @returns set new user list
  */
  const onDeleteExistingSecretVariable = (secretVar, variables) => {
    console.log("onDeleteExistingSecretVariable==========>", secretVar);
    console.log("onDeleteExistingSecretVariable==========>", variables);
    const data = {
      repositoryId: state.repository.id,
      environmentName: variables.environmentName,
      secretName: secretVar.name,
    };
    let config = {
      headers: {
        authorization: "Bearer " + localStorage.getItem("accessToken"),
      },
    };
    // console.log("onTokenForDeleteExistingUser==========>", config);
    axios
      .delete(
        constants.BASE_URL + constants.DELETE_GITHUB_SECRET_VARIABLE + `?repositoryId=${state.repository.id}&environmentName=${variables.environmentName}&secretName=${secretVar.name}`,
        config
      )
      .then((response) => {
        console.log(
          "onDeleteExistingSecretVariable============>",
          response
        );
        // hideProgressBar();
        // setIsConfirmDeleteOpen(false);
        // callGetCollaboratorForRepo();
        callGetVariablesForRepository();
        callGetSecretVariablesForRepository();
      })
      .catch((error) => {
        hideProgressBar();
        console.log("callDeleteExistingUserAPI-Error============>", error);
        handleErrorAlert(true);
        setErrorAlertCallback({
          message:
            "Something went wrong while deleting secret variable. Please try again!",
        });
      });
    // setExistingUserToDelete(user);
    // setIsConfirmDeleteOpen(true);
  };

  const callRemoveRepositoryCollaborator = () => {
    showProgressBar("Please be patient! While collaborator is being removed");
    const data = {
      organizationname: localStorage.getItem("githubOrganizationName"),
      repoName: state.repository.name,
      users: [existingUserToDelete.login],
    };
    let config = {
      headers: {
        authorization: "Bearer " + localStorage.getItem("accessToken"),
      },
      data,
    };
    console.log("onTokenForDeleteExistingUser==========>", config);
    axios
      .delete(
        constants.BASE_URL + constants.DELETE_GITHUB_COLLABORATORS,
        config
      )
      .then((response) => {
        console.log(
          "callDeleteExistingUserAPI-Response============>",
          response
        );
        hideProgressBar();
        setIsConfirmDeleteOpen(false);
        callGetCollaboratorForRepo();
      })
      .catch((error) => {
        hideProgressBar();
        console.log("callDeleteExistingUserAPI-Error============>", error);
        handleErrorAlert(true);
        setErrorAlertCallback({
          message:
            "Something went wrong while removing collaborators. Please try again!",
        });
      });
  };

  const ConfirmDeleteUserAlert = () => {
    return (
      <Dialog
        open={isConfirmDeleteOpen}
        onClose={() => {
          setIsConfirmDeleteOpen(false);
        }}
      >
        <DialogTitle color={"#005689"} fontWeight={"bold"}>
          Alert
        </DialogTitle>
        <DialogContent>
          <DialogContentText>
            {existingUserToDelete.hasOwnProperty("login")
              ? `Are you sure you want to remove ${existingUserToDelete.login} from ${state.repository.name}? `
              : ""}
            <br />
            Click Remove to confirm else click cancel.
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button
            onClick={() => {
              setIsConfirmDeleteOpen(false);
            }}
            className="existingProject-deleteUserDialog-cancel-button"
          >
            Cancel
          </Button>
          <Button
            onClick={callRemoveRepositoryCollaborator}
            className="existingProject-deleteUserDialog-remove-button"
          >
            Remove
          </Button>
        </DialogActions>
      </Dialog>
    );
  };

  const handleNewEnviromentCreated = () => {
    callGetVariablesForRepository();
    callGetSecretVariablesForRepository();
    setTabId(1);
  };

  /**
   *
   * @returns boolean to rendering dialog conditionally.
   */
  const handleVariableGroupDialogOpen = () =>
    setVariableGroupDialogIsOpen(true);

  /**
   * JS method called just after the closing dialog, updating states of  atributes
   */
  const handleVariableGroupDialogClose = () => {
    setVariableGroupDialogIsOpen(false);
    // setIsVariableEdit(false);
    // setVariableGroupToEdit({});
  };

  const onNewVariableGroupAdded = () => {
    callGetVariablesForRepository();
    callGetSecretVariablesForRepository();
    setTabId(1);
  };
  return (
    <Box>
      <ProgressBar
        isVisible={isVisible}
        progressBarMessage={progressBarMessage}
      />
      <ErrorAlert
        isErrorVisible={isErrorVisible}
        callback={() => {
          setIsErrorVisible(false);
          if (
            errorAlertCallback.hasOwnProperty("navigate") &&
            errorAlertCallback.hasOwnProperty("navigateData")
          ) {
            navigate(
              errorAlertCallback.navigate,
              errorAlertCallback.navigateData
            );
          } else if (errorAlertCallback.hasOwnProperty("navigate")) {
            navigate(errorAlertCallback.navigate);
          }
        }}
        message={errorAlertCallback.message}
      />
      <Box mr={1} mb={1}>
        <CustomBreadCrumb
          routeList={state.routeList}
          location={location.pathname}
        />
      </Box>
      <ConfirmDeleteUserAlert />

      <Stack direction="row" justifyContent="space-between">
        <Typography variant="h6" color={"#005689"} fontWeight={"bold"}>
          {state.repository.name}
        </Typography>
      </Stack>
      <RepositoryTab
        repoSecretVariables={repoSecretVariables}
        repoBranches={repoBranches}
        repoVariables={repoVariables}
        repoPipelines={repoPipelines}
        repoCollaborators={repoCollaborators}
        onProjectTabChange={onProjectTabChange}
        tabId={tabId}
        repository={state.repository}
        onDeleteExistingCollaborator={onDeleteExistingCollaborator}
        onDeleteExistingVariable={onDeleteExistingVariable}
        onDeleteExistingSecretVariable={onDeleteExistingSecretVariable}
      />
      <Divider />
      <Box position="fixed" bottom="0px" width={"100vw"} ml={-3}>
        <Card raised>
          <Stack direction="row" spacing={2} p={1}>
            <AddEnviromentDialog
              handleNewEnviromentCreated={handleNewEnviromentCreated}
              repository={state.repository}
            />
            <ColorButton
              backgroundcolor="#005689"
              variant="contained"
              size="small"
              onClick={handleVariableGroupDialogOpen}
              startIcon={<Add />}
            >
              New Variables Group
            </ColorButton>
            <CreatePipelineDialog
              project={state.repository.name}
              onNewPipelineAdded={onNewPipelineAdded}
              repoBranches={repoBranches}
              eligibleUsers={repoCollaborators}
            />
            <AddCollaboratorsDialog
              project={state.repository.name}
              onNewUserAdded={onNewUserAdded}
            />
            {/*                         <AddVariablesDialog
                            onNewVariableGroupAdded={onNewVariableGroupAdded}
                            project={state.project}
                            variableGroupToEdit={variableGroupToEdit}
                            isVariableEdit={isVariableEdit}
                            variableGroupDialogIsOpen={variableGroupDialogIsOpen}
                            handleVariableGroupDialogClose={handleVariableGroupDialogClose}
                        /> */}
            <AddEnvVariableDialog
              repository={state.repository}
              enviromentList={repoVariables}
              variableGroupDialogIsOpen={variableGroupDialogIsOpen}
              onNewVariableGroupAdded={onNewVariableGroupAdded}
              handleVariableGroupDialogClose={handleVariableGroupDialogClose} />
          </Stack>
        </Card>
      </Box>
    </Box>
  );
}
