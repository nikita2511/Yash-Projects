import * as React from "react";
import PropTypes from "prop-types";
import Tabs from "@mui/material/Tabs";
import Tab from "@mui/material/Tab";
import Typography from "@mui/material/Typography";
import Box from "@mui/material/Box";
import {
  Accordion,
  AccordionSummary,
  AccordionDetails,
  Avatar,
  Card,
  Grid,
  Stack,
  IconButton,
  Divider,
  Button,
} from "@mui/material";
import { stringAvatar } from "../../../utils/helper";
import { Delete, ExpandMoreOutlined } from "@mui/icons-material";

/**
 *
 * @returns React Functional Component (TabPanel) which renders tabs dynamically based on conditional rendering
 */
function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && (
        <Box p={3} mb={3}>
          {children}
        </Box>
      )}
    </div>
  );
}

TabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.number.isRequired,
  value: PropTypes.number.isRequired,
};

function a11yProps(index) {
  return {
    id: `simple-tab-${index}`,
    "aria-controls": `simple-tabpanel-${index}`,
  };
}
export default function RepositoryTab({
  repoBranches,
  repoVariables,
  repoPipelines,
  tabId,
  onProjectTabChange,
  repoCollaborators,
  repository,
  onDeleteExistingCollaborator,
  onDeleteExistingVariable,
  onDeleteExistingSecretVariable,
  repoSecretVariables,
  onEditVariableGroup,
}) {
  const handleChange = (event, newValue) => {
    onProjectTabChange(newValue);
  };
  return (
    <Box>
      <Box borderBottom={1} borderColor={"divider"}>
        <Tabs
          value={tabId}
          onChange={handleChange}
          variant="scrollable"
          allowScrollButtonsMobile
          aria-label="basic tabs example"
        >
          <Tab label="Branches" {...a11yProps(0)} />
          <Tab label="Variable Groups" {...a11yProps(1)} />
          <Tab label="Pipelines" {...a11yProps(2)} />
          <Tab label="Collaborators" {...a11yProps(3)} />
        </Tabs>
      </Box>
      <TabPanel value={tabId} index={0}>
        {repoBranches.length > 0 ? (
          <Grid container spacing={2}>
            {repoBranches.map((repo, index) => (
              <Grid item xs={6} sm={3} md={3} key={index}>
                <Card raised={true}>
                  <Stack
                    direction="row"
                    spacing={1}
                    p={1}
                    alignItems={"center"}
                  >
                    <Avatar {...stringAvatar(repo.name)} variant="rounded" />
                    <Stack direction="column">
                      <Typography
                        variant="subtitle2"
                        color={"#005689"}
                        fontWeight={"bold"}
                      >
                        {repo.name}
                      </Typography>
                    </Stack>
                  </Stack>
                </Card>
              </Grid>
            ))}
          </Grid>
        ) : (
          <Typography
            variant="h6"
            gutterBottom
            color={"#005689"}
            textAlign={"center"}
          >
            {`Branches are not created for the repository yet`}
          </Typography>
        )}
      </TabPanel>
      <TabPanel value={tabId} index={1}>
        {repoVariables.length > 0 ? (
          <Grid container spacing={2}>
            {repoVariables.map((variables, index) => (
              <Grid item xs={12} md={6} key={index}>
                <Accordion>
                  <AccordionSummary
                    expandIcon={<ExpandMoreOutlined />}
                    aria-controls="panel1a-content"
                    id="panel1a-header"
                  >
                    <Typography
                      variant="subtitle1"
                      color={"#005689"}
                      //   fontWeight={"bold"}
                      width={"33%"}
                      mr={2}
                    >
                      Environment Name
                    </Typography>
                    <Typography
                      variant="subtitle1"
                      color={"#005689"}
                      fontWeight={"bold"}
                      width={"33%"}
                      mr={2}
                    >
                      {variables.environmentName}
                    </Typography>
                  </AccordionSummary>

                  <AccordionDetails>
                    {variables.environmentVariables.length > 0 ? (
                      <>
                        <Typography color={"#005689"} mt={1}>
                          Variables
                        </Typography>
                        <Stack spacing={2} direction={"row"} ml={1} mt={1}>
                          <Typography
                            width={"100%"}
                            variant="body2"
                            color={"#005689"}
                          >
                            {"Name"}
                          </Typography>
                          <Typography
                            width={"100%"}
                            variant="body2"
                            color={"#005689"}
                          >
                            {"Value"}
                          </Typography>
                          <IconButton disabled>
                            <Delete className="addVariableDialog-delete" />
                          </IconButton>
                        </Stack>
                        {variables.environmentVariables.map((variable, index) => (
                          <Stack
                            spacing={2}
                            direction={"row"}
                            ml={1}
                            flex={1}
                            alignItems={"center"}
                            key={index}
                          >
                            <Typography
                              variant="body2"
                              width={"50%"}
                              flexWrap={"wrap"}
                              noWrap
                            >
                              {variable.name}
                            </Typography>
                            <Typography
                              variant="body2"
                              width={"50%"}
                              flexWrap={"wrap"}
                              noWrap
                            >
                              {variable.value}
                            </Typography>
                            <IconButton
                              onClick={() => {
                                onDeleteExistingVariable(variable, variables);
                              }}
                            >
                              <Delete
                                fontSize="26px"
                                className="projectTabs-icon-deleteUser"
                              />
                            </IconButton>
                          </Stack>
                        ))}
                      </>
                    ) : (
                      <Typography
                        gutterBottom
                        color={"#005689"}
                        textAlign={"center"}
                      >
                        {`Variable are not created for the environment yet`}
                      </Typography>
                    )}
                    <Divider sx={{
                      width: "90%",
                      mt: "8px"
                    }} />

                    {repoSecretVariables.map((variable, index) => (
                      <Box>
                        {variable.environmentSecrets.length > 0 ? (
                          <>
                            <Typography color={"#005689"} mt={1}>
                              Secret Variables
                            </Typography>
                            <Stack spacing={2} direction={"row"} ml={1} mt={1}>
                              <Typography
                                width={"100%"}
                                variant="body2"
                                color={"#005689"}
                              >
                                {"Name"}
                              </Typography>
                              <Typography
                                width={"100%"}
                                variant="body2"
                                color={"#005689"}
                              >
                                {"Value"}
                              </Typography>
                              <IconButton disabled>
                                <Delete className="addVariableDialog-delete" />
                              </IconButton>
                            </Stack>
                            {variable.environmentSecrets.map((secretVar, index) => (
                              <Stack
                                spacing={2}
                                direction={"row"}
                                ml={1}
                                flex={1}
                                alignItems={"center"}
                                key={index}
                              >
                                <Typography
                                  variant="body2"
                                  width={"50%"}
                                  flexWrap={"wrap"}
                                  noWrap
                                >
                                  {secretVar.name}
                                </Typography>
                                <Typography
                                  variant="body2"
                                  width={"50%"}
                                  flexWrap={"wrap"}
                                  noWrap
                                >
                                  ******
                                </Typography>
                                <IconButton
                                  onClick={() => {
                                    onDeleteExistingSecretVariable(secretVar, variables);
                                  }}
                                >
                                  <Delete
                                    fontSize="26px"
                                    className="projectTabs-icon-deleteUser"
                                  />
                                </IconButton>
                              </Stack>
                            ))}
                          </>
                        ) : (
                          <></>
                        )}

                      </Box>

                    ))}
                    <Box
                      width={"100%"}
                      justifyContent={"flex-end"}
                      display={"flex"}
                    >
                    </Box>
                  </AccordionDetails>
                </Accordion>
              </Grid>
            ))}
          </Grid>
        ) : (
          <Typography
            variant="h6"
            gutterBottom
            color={"#005689"}
            textAlign={"center"}
          >
            {`Environments Variables are not created for the repositroy yet`}
          </Typography>
        )}
      </TabPanel>
      <TabPanel value={tabId} index={2}>
        {repoPipelines.length > 0 ? (
          <Grid container spacing={2}>
            {repoPipelines.map((pipeline, index) => (
              <Grid item xs={6} sm={3} md={3} key={index}>
                <Card raised={true}>
                  <Stack
                    direction="row"
                    spacing={2}
                    p={1}
                    alignItems={"center"}
                  >
                    <Avatar
                      {...stringAvatar(pipeline.name)}
                      variant="rounded"
                    />
                    <Typography
                      variant="subtitle1"
                      color={"#005689"}
                      fontWeight={"bold"}
                    >
                      {pipeline.name}
                    </Typography>
                  </Stack>
                </Card>
              </Grid>
            ))}
          </Grid>
        ) : (
          <Typography
            variant="h6"
            gutterBottom
            color={"#005689"}
            textAlign={"center"}
          >
            {`Pipelines are not created for the repository yet`}
          </Typography>
        )}
      </TabPanel>
      <TabPanel value={tabId} index={3}>
        {repoCollaborators.length > 0 ? (
          <Grid
            container
            spacing={{ xs: 2, md: 3 }}
            columns={{ xs: 4, sm: 8, md: 12 }}
          >
            {repoCollaborators.map((user, index) => (
              <Grid item xs={6} sm={3} md={3} key={index}>
                <Card className="projectTabs-card-user">
                  <Stack direction="row" spacing={1} alignItems="center" m={1}>
                    <Avatar src={user.avatar_url} />
                    <Box>
                      <Typography color={"#005689"} fontWeight={"bold"}>
                        {user.login}
                      </Typography>
                      <Typography
                        variant="body1"
                        fontSize={"14px"}
                        color={"#005689"}
                      >
                        {user.role_name}
                      </Typography>
                    </Box>
                  </Stack>
                  <IconButton
                    onClick={() => {
                      onDeleteExistingCollaborator(user);
                    }}
                  >
                    <Delete
                      fontSize="26px"
                      className="projectTabs-icon-deleteUser"
                    />
                  </IconButton>
                </Card>
              </Grid>
            ))}
          </Grid>
        ) : (
          <Typography
            variant="h6"
            gutterBottom
            color={"#005689"}
            textAlign={"center"}
          >
            {`Collaborators are not added for the ${repository.name} repository yet`}
          </Typography>
        )}
      </TabPanel>
    </Box>
  );
}
