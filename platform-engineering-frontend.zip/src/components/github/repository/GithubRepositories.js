import '../../azure/projects/projects.css'
import React from "react";
import Paper from "@mui/material/Paper";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TablePagination from "@mui/material/TablePagination";
import TableRow from "@mui/material/TableRow";
import ProgressBar from "../../../utils/ProgressBar";
import { useNavigate } from "react-router-dom";
import {
  Avatar,
  Card,
  Divider,
  Stack,
  Typography,
  Box,
  Tooltip,
  IconButton,
} from "@mui/material";
import { useEffect } from "react";
import axios from "axios";
import { constants } from "../../../utils/Constants";
import ErrorAlert from "../../error/ErrorAlert";
import { ColorButton } from "../../../utils/CustomButton";
import { stringAvatar } from "../../../utils/helper";
import CustomBreadCrumb from "../../../utils/CustomBreadCrumb";
import { useLocation } from "react-router-dom";
import azureRepo from "../../../assets/azure-repo.png";
import azureCIPipeline from "../../../assets/azure-pipeline.png";
import azureVariable from "../../../assets/azure-variable.png";
import azureUser from "../../../assets/azure-user.png";
import AltRouteRoundedIcon from '@mui/icons-material/AltRouteRounded';
/**
 *
 * @returns React Functional Component (GetProjects) which renders all the available projects associated with the organization.
 */
const columns = [
  { id: "name", label: "Repository Name", minWidth: 100 },
  { id: "description", label: "Description", minWidth: 100 },
  {
    id: "updated_at",
    label: "Last Update Time",
    minWidth: 100,
    format: (value) => new Date(value).toLocaleString(),
  },
  {
    id: "action",
    label: "",
    minWidth: 100,
  },
];
export default function GithubRepositories() {
  const location = useLocation();
  const navigate = useNavigate();
  const { state } = location;
  const [page, setPage] = React.useState(0);
  const [rowsPerPage, setRowsPerPage] = React.useState(10);
  const [repositoryList, setRepositoryList] = React.useState([]);
  const [placeholderMessage, setPlaceholderMessage] = React.useState(
    "Please select organization to retrieve all available projects!"
  );
  const [isVisible, setIsVisible] = React.useState(false);
  const [progressBarMessage, setProgressBarMessage] =
    React.useState("Please wait!");
  const [isErrorVisible, setIsErrorVisible] = React.useState(false);
  const [errorAlertMessage, setErrorAlertMessage] = React.useState(
    "Something unexpected happend! Please try again"
  );

  /**
   *
   * JS method to call GET REST Endpoint for retrieving user's all repositories associated with the selected organization
   */
  const getAllRepositoriesByOrganizationName = () => {
    showProgressBar("Please be patient! while repositories are being fetched.");
    let config = {
      headers: {
        authorization: "Bearer " + localStorage.getItem("accessToken"),
      },
      params: {
        organizationName: localStorage.getItem("githubOrganizationName"),
      },
    };
    axios
      .get(constants.BASE_URL + constants.GET_GITHUB_REPOSITORIES, config)
      .then((response) => {
        console.log(
          "Reponse-getAllRepositoriesByOrganizationName=======>",
          response.data.body.repositories
        );
        hideProgressBar();
        if (response.data.body.repositories.length < 1) {
          setPlaceholderMessage(
            "No repositories available for selected organization!"
          );
        }
        setRepositoryList(response.data.body.repositories);
      })
      .catch((error) => {
        console.log(
          "Error-getAllRepositoriesByOrganizationName========>",
          error
        );
        setRepositoryList([]);
        hideProgressBar();
        if (error.response.status === 404) {
          setPlaceholderMessage(
            "Organization not found! Please select a valid organization"
          );
        } else {
          handleErrorAlert(true);
          setPlaceholderMessage("Oops! Something went wrong");
        }
      });
  };

  useEffect(() => {
    /**
     * JS method called to retrieve list of repositories in an organization
     */
    getAllRepositoriesByOrganizationName();
    // eslint-disable-next-line
  }, []);

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(+event.target.value);
    setPage(0);
  };
  /**
   *
   * @param {*} value boolean value to change visiblity of Alert Dialog
   * JS method to update the boolean state value isErrorVisible
   */
  const handleErrorAlert = (value, message) => {
    setIsErrorVisible(value);
    setErrorAlertMessage(message);
  };

  /**
   *
   * JS method to handle the data of avilable project.
   */
  const GetTableRowData = ({ column, row }) => {
    const value = row[column.id];
    if (column.format && column.id === "updated_at") {
      return <Typography variant="body2">{column.format(value)}</Typography>;
    } else if (column.id === "name") {
      return (
        <Stack direction={"row"} spacing={2} alignItems={"center"}>
          <Avatar variant="rounded" {...stringAvatar(value)} />
          <Typography variant="body2">{value}</Typography>
        </Stack>
      );
    } else if (column.id === "action") {
      return (
        <Stack direction={"row"}>
          <Tooltip title="Branches" arrow>
            <IconButton
              onClick={() => {
                navigate("/github/repository/info", {
                  state: {
                    repository: row,
                    routeList: [...state.routeList, location.pathname],
                    tabId: 0,
                  },
                });
              }}
            >
              <img
                src={azureRepo}
                alt={"Repository"}
                loading="lazy"
                className="getProject-icon-img"
              />
            </IconButton>
          </Tooltip>

          <Tooltip title="Variable Groups" arrow>
            <IconButton
              onClick={() => {
                navigate("/github/repository/info", {
                  state: {
                    repository: row,
                    routeList: [...state.routeList, location.pathname],
                    tabId: 1,
                  },
                });
              }}
            >
              <img
                src={azureVariable}
                alt={"Variable Groups"}
                loading="lazy"
                className="getProject-icon-img"
              />
            </IconButton>
          </Tooltip>
          <Tooltip title="CI Pipeline" arrow>
            <IconButton
              onClick={() => {
                navigate("/github/repository/info", {
                  state: {
                    repository: row,
                    routeList: [...state.routeList, location.pathname],
                    tabId: 2,
                  },
                });
              }}
            >
              <img
                src={azureCIPipeline}
                alt={"CI Pipeline"}
                loading="lazy"
                className="getProject-icon-img"
              />
            </IconButton>
          </Tooltip>
          <Tooltip title="Collaborators" arrow>
            <IconButton
              onClick={() => {
                navigate("/github/repository/info", {
                  state: {
                    repository: row,
                    routeList: [...state.routeList, location.pathname],
                    tabId: 3,
                  },
                });
              }}
            >
              <img
                src={azureUser}
                alt={"Users"}
                loading="lazy"
                className="getProject-icon-img"
              />
            </IconButton>
          </Tooltip>
        </Stack>
      );
    } else {
      return <Typography variant="body2">{value}</Typography>;
    }
  };

  /**
   *
   * @param {*} message String value to be shown with Progress Bar
   * JS method called to make the Progress Bar visible along with the message
   */
  const showProgressBar = (message) => {
    setIsVisible(true);
    setProgressBarMessage(message);
  };

  /**
   *
   * JS method called to hide the Progress Bar
   */
  const hideProgressBar = () => {
    setIsVisible(false);
    setProgressBarMessage("");
  };
  return (
    <div>
      <ProgressBar
        isVisible={isVisible}
        progressBarMessage={progressBarMessage}
      />
      <ErrorAlert
        isErrorVisible={isErrorVisible}
        callback={() => {
          setIsErrorVisible(false);
          navigate(-1);
        }}
        message={errorAlertMessage}
      />
      <Box mr={1} mb={1}>
        <CustomBreadCrumb
          routeList={state.routeList}
          location={location.pathname}
        />
      </Box>
      <Stack
        direction={"row"}
        justifyContent={"space-between"}
        mb={1}
        alignItems={"center"}
      >
        <Typography variant="h6" color={"#005689"} fontWeight={"bold"}>
          {localStorage.getItem("githubOrganizationName")}
        </Typography>
        <Stack spacing={1} direction={"row"}>
          <ColorButton
            backgroundcolor="#005689"
            variant="contained"
            size="small"
            onClick={() =>
              navigate("/github/organizationUser", {
                state: {
                  routeList: [...state.routeList, location.pathname],
                  organizationName: localStorage.getItem(
                    "githubOrganizationName"
                  ),
                },
              })
            }
          >
            Organization Users
          </ColorButton>
          <ColorButton
            backgroundcolor="#005689"
            variant="contained"
            size="small"
            onClick={() =>
              navigate("/github/createRepository", {
                state: {
                  routeList: [...state.routeList, location.pathname],
                  organizationName: localStorage.getItem(
                    "githubOrganizationName"
                  ),
                },
              })
            }
          >
            Create Repository
          </ColorButton>
        </Stack>
      </Stack>
      <Card className="getProject-card-project" raised={true}>
        <Typography variant="body1" color={"#005689"}>
          Available Repositories
        </Typography>
        <Divider />
        <div>
          {repositoryList.length > 0 ? (
            <Paper className="getProject-paper-project">
              <TableContainer className="getProject-tableContainer">
                <Table stickyHeader aria-label="sticky table">
                  <TableHead>
                    <TableRow>
                      {columns.map((column) => (
                        <TableCell
                          key={column.id}
                          align={column.align}
                          size="medium"
                        >
                          <Typography variant="body2" color={"#007CB9"}>
                            {column.label}
                          </Typography>
                        </TableCell>
                      ))}
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {repositoryList
                      .slice(
                        page * rowsPerPage,
                        page * rowsPerPage + rowsPerPage
                      )
                      .map((row, index) => {
                        return (
                          <TableRow
                            hover
                            role="checkbox"
                            tabIndex={-1}
                            key={index}
                          >
                            {columns.map((column) => {
                              return (
                                <TableCell
                                  key={column.id}
                                  align={column.align}
                                  size="small"
                                  onClick={() => {
                                    if (column.id === "action") {
                                      return;
                                    }
                                    navigate("/github/repository/info", {
                                      state: {
                                        repository: row,
                                        routeList: [
                                          ...state.routeList,
                                          location.pathname,
                                        ],
                                        tabId: 0,
                                      },
                                    });
                                  }}
                                  className="getProject-tableCell"
                                >
                                  <GetTableRowData column={column} row={row} />
                                </TableCell>
                              );
                            })}
                          </TableRow>
                        );
                      })}
                  </TableBody>
                </Table>
              </TableContainer>
              <TablePagination
                rowsPerPageOptions={[5, 10, 25]}
                component="div"
                count={repositoryList.length}
                rowsPerPage={rowsPerPage}
                page={page}
                onPageChange={handleChangePage}
                onRowsPerPageChange={handleChangeRowsPerPage}
              />
            </Paper>
          ) : (
            <Typography
              textAlign={"center"}
              color={"#005689"}
              fontWeight={"bold"}
              mt={2}
              variant="body1"
            >
              {placeholderMessage}
            </Typography>
          )}
        </div>
      </Card>
    </div>
  );
}
