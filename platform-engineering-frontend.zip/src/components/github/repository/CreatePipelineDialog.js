import {
  Avatar,
  Button,
  ButtonBase,
  Chip,
  DialogActions,
  DialogContent,
  DialogTitle,
  Divider,
  FormControl,
  FormControlLabel,
  FormLabel,
  Grid,
  InputLabel,
  List,
  ListSubheader,
  MenuItem,
  Paper,
  Radio,
  RadioGroup,
  Select,
  Stack,
  Switch,
  TextField,
  Typography,
  IconButton,
} from "@mui/material";
import { useTheme } from "@mui/material/styles";
import Dialog from "@mui/material/Dialog";
import React from "react";
import axios from "axios";
import { constants } from "../../../utils/Constants";
import ProgressBar from "../../../utils/ProgressBar";
import ErrorAlert from "../../error/ErrorAlert";
import { useLocation, useNavigate } from "react-router-dom";
import { stringAvatar } from "../../../utils/helper";
import { ColorButton } from "../../../utils/CustomButton";
import { Add, } from "@mui/icons-material";
import AddEnviromentDialog from "./AddEnviromentDialog";
import { useState } from "react";
import Box from '@mui/material/Box';

import ListItem from '@mui/material/ListItem';
import ListItemText from '@mui/material/ListItemText';
import DeleteIcon from '@mui/icons-material/Delete';

/**
 *
 * @returns React Functional Component (CreateCIPipeline) which renders a dialog by which pipeline will be created for the project.
 */
export default function CreatePipelineDialog({
  project,
  onNewPipelineAdded,
  repoBranches,
  eligibleUsers,
}) {
  const [open, setOpen] = React.useState(false);
  const { state } = useLocation();
  const [isVisible, setIsVisible] = React.useState(false);
  const [progressBarMessage, setProgressBarMessage] =
    React.useState("Please wait!");
  const [dense, setDense] = React.useState(false);
  const [secondary, setSecondary] = React.useState(false);
  const [isErrorVisible, setIsErrorVisible] = React.useState(false);
  const [errorAlertCallback, setErrorAlertCallback] = React.useState({
    navigate: -1,
    navigateData: {
      state: {},
    },
    message: "Something unexpected happend! Please try again",
  });
  const theme = useTheme();
  // eslint-disable-next-line
  const navigate = useNavigate();
  // eslint-disable-next-line
  const [repoName, setRepoName] = React.useState("");
  const [technologyType, setTechnologyType] = React.useState("");
  const [isPublishArtifact, setPublishArtifact] = React.useState(false);
  // eslint-disable-next-line
  const [repoVariables, SetRepoVariables] = React.useState([]);
  // eslint-disable-next-line
  const [tabId, setTabId] = useState(0);
  // eslint-disable-next-line
  const [technologyTypeList, setTechnologyTypeList] = React.useState([
    {
      id: "0",
      name: "Java",
      value: "java",
    },
    {
      id: "1",
      name: ".Net",
      value: "dotNet",
    },
  ]);
  const [pipelineName, setPipelineName] = React.useState("");
  // eslint-disable-next-line
  const [addUserList, setAddUserList] = React.useState([...eligibleUsers]);
  const [selectedUserList, setSelectedUserList] = React.useState([]);
  const [filteredUserList, setFilteredUserList] = React.useState([
    ...eligibleUsers,
  ]);
  const [noOfReviewers, setNoOfReviewers] = React.useState("");
  const [isDeploy, setIsDeploy] = React.useState(false);
  const [isWorkflowDispatch, setIsWorkflowDispatch] = React.useState(false);
  const [platformToDeployType, setPlatformToDeployType] = React.useState("");
  const [selectedEnvironmentList, setSelectedEnvironmentList] = React.useState([]);
  const [selectedDeploymentList, setSelectedDeploymentList] = React.useState([]);
  const [environment, setEnvironment] = React.useState("");
  const [platformToDeploy, setPlatformToDeploy] = React.useState("");
  const [platformToDeployList, setPlatformToDeployList] = React.useState([
    {
      id: "0",
      name: "ECS",
      value: "ECS",
    },
    {
      id: "1",
      name: "EKS",
      value: "EKS",
    },
    {
      id: "2",
      name: "TOMCAT",
      value: "TOMCAT",
    },
  ]);
  const [deploymentEnvironments, setDeploymentEnvironments] = React.useState([]);
  const [availableDeploymentEnvironments, setAvailableDeploymentEnvironment,
  ] = React.useState([]);

  React.useEffect(() => {
    setAddUserList(eligibleUsers);
    setFilteredUserList(eligibleUsers);
    callGetAvailableEnvironment();
  }, [eligibleUsers]);

  /**
   *
   * @param {*} token Access token retrieved to call Azure REST APIs using backend endpoints
   * JS method to call GET REST Endpoint for retrieving organization rule.
   */
  const callGetOrganizationRule = (token) => {
    showProgressBar(
      "Please be patient! while information related to existing projet are being fetched"
    );
    let config = {
      // headers: { authorization: "Bearer " + token },
      params: {
        organizationName: localStorage.getItem("githubOrganizationName"),
        platform: "Github",
      },
    };
    axios
      .get(constants.BASE_URL + constants.GET_RULES_BY_ORGANIZTION, config)
      .then((response) => {
        hideProgressBar();
        console.log(
          "Response-getRulesByOrganization==============>",
          response.data.body.projectCreationRules
        );
        const rules = response.data.body.projectCreationRules;
        setNoOfReviewers(
          rules.branchingModel.branches.find(
            // eslint-disable-next-line
            (branch) => branch.type == "default"
          ).noOfReviewers
        );
      })
      .catch((error) => {
        // handleErrorAlert(true);
        hideProgressBar();
      });
  };

  const callGetAvailableEnvironment = (token) => {
    showProgressBar(
      "Please be patient! while information related to existing projet are being fetched"
    );
    let config = {
      headers: {
        authorization: "Bearer " + localStorage.getItem("accessToken"),
      },
      params: {
        organizationName: localStorage.getItem("githubOrganizationName"),
        RepoName: project,
      },
    };
    axios
      .get(constants.BASE_URL + constants.GET_AVAILABLE_ENVIRONMENTS, config)
      .then((response) => {
        hideProgressBar();
        console.log(
          "Response-callGetAvailableEnvironment==============>",
          response.data.body.EnvironmentList
        );
        setAvailableDeploymentEnvironment(response.data.body.EnvironmentList);
        // const rules = response.data.body.projectCreationRules;
        // setNoOfReviewers(
        //   rules.branchingModel.branches.find(
        //     // eslint-disable-next-line
        //     (branch) => branch.type == "default"
        //   ).noOfReviewers
        // );
      })
      .catch((error) => {
        // handleErrorAlert(true);
        hideProgressBar();
      });
  };

  /**
   *
   * @returns JS method callback after dialog is opened.
   */
  const handleClickOpen = () => {
    callGetOrganizationRule();
    setOpen(true);
  };

  /**
   *
   * @returns JS method callback after dialog is closed.
   */
  const handleCreateCIPipelineDialogClose = () => {
    setOpen(false);
    setRepoName("");
    setTechnologyType("");
    setPublishArtifact(false);
    setSelectedUserList([]);
    setPlatformToDeployType("");
    setDeploymentEnvironments([]);
    setIsWorkflowDispatch(false);
    setIsDeploy(false);
    setSelectedEnvironmentList([]);
  };

  /**
   *
   * JS method to call POST REST Endpoint for posting inputs for pipeline to be created for repository.
   */
  const callCreatePipelineAPI = () => {
    showProgressBar("Please be patient! While pipeline is being created.");
    const data = {
      organizationName: localStorage.getItem("githubOrganizationName"),
      repositoryName: project,
      applicationType: technologyType,
      publishArtifacts: isPublishArtifact,
      usernameInitials: stringAvatar(
        JSON.parse(localStorage.getItem("githubAuthenticatedUser")).login
      ).children,
      name: pipelineName,
      reviewers: selectedUserList,
      toBeDeployed: isDeploy,
      deploymentEnvironments: deploymentEnvironments,
      existingPipeline: false
    };
    console.log("callCreatePipelineAPI============>", data);
    let config = {
      headers: {
        authorization: "Bearer " + localStorage.getItem("accessToken"),
      },
    };
    axios
      .post(
        constants.BASE_URL + constants.POST_GITHUB_CREATE_PIPELINE,
        data,
        config
      )
      .then((response) => {
        hideProgressBar();
        console.log("Response-callCreatePipelineAPI========>", response.data.body.createdSourceFiles.environmentVariables);
        handleErrorAlert(true);
        if (response.data.body.createdSourceFiles.environmentVariables.length > 0) {
          setErrorAlertCallback({
            // navigate: "/github/repository",
            message: <Box>
              <Typography variant="body1">pipeline {pipelineName} created successfully! </Typography>
              <Typography
                variant="body1"
                color={"#005689"}> Please add the following variables in your environment </Typography>
              <Typography variant="body1"
                color={"#005689"}>
                {response.data.body.createdSourceFiles.environmentVariables.map((varr) => <>{varr}<br></br></>)}</Typography>
              <Typography variant="body1"
                color={"#005689"}>to configure your Pipeline{pipelineName}</Typography>
            </Box>,
            navigateData: {
              state: {
                organization: state.organizationName,
                routeList: ["/github"],
              },
            },
          });
          handleCreateCIPipelineDialogClose();
          onNewPipelineAdded();
        } else {
          setErrorAlertCallback({
            // navigate: "/github/repository",
            message: <Box>
              <Typography variant="body1">pipeline {pipelineName} created successfully! </Typography>
            </Box>,
            navigateData: {
              state: {
                organization: state.organizationName,
                routeList: ["/github"],
              },
            },
          });
          handleCreateCIPipelineDialogClose();
          onNewPipelineAdded();
        }
        // handleCreateCIPipelineDialogClose();
        // onNewPipelineAdded();
      })
      .catch((error) => {
        hideProgressBar(); // eslint-disable-next-line
        setErrorAlertCallback({
          message:
            "Something went wrong while creating Pipeline in project. Please try again!",
        });
        handleErrorAlert(true);
        console.log("Error-callCreatePipelineAPI=========>", error.response);
      });
  };

  const handleClose = (event, reason) => {
    // eslint-disable-next-line
    if (reason && reason == "backdropClick") return;
    handleCreateCIPipelineDialogClose();
  };

  /**
   *
   * @param {*} value boolean value to change visiblity of Alert Dialog
   * JS method to update the boolean state value isErrorVisible
   */
  const handleErrorAlert = (value) => {
    setIsErrorVisible(value);
  };

  /**
   *
   * @param {*} message String value to be shown with Progress Bar
   * JS method called to make the Progress Bar visible along with the message
   */
  const showProgressBar = (message) => {
    setIsVisible(true);
    setProgressBarMessage(message);
  };

  /**
   *
   * JS method called to hide the Progress Bar
   */
  const hideProgressBar = () => {
    setIsVisible(false);
    setProgressBarMessage("");
  };

  /**
   *
   * @param {*} event method to handle repository name for pipeline.
   */
  const handleRepoNameChange = (event) => {
    setRepoName(event.target.value);
  };

  /**
   *
   * @param {*} event method to handle technology type for pipeline.
   */
  const handleTechnologyTypeChange = (event) => {
    setTechnologyType(event.target.value);
  };

  /**
  *
  * @param {*} event method to handle technology type for pipeline.
  */
  const handleplatformToDeployChange = (event) => {
    setPlatformToDeployType(event.target.value);
    console.log("platformToDeploy", event.target.value)
  };

  /**
   *
   * @param {*} event method to handle publishArtifact type for pipeline.
   */
  const handlePublishArtifactChange = (event) => {
    // eslint-disable-next-line
    setPublishArtifact(event.target.value == "true");
  };

  const handleDeploymentEnvironments = (event) => {
    const {
      target: { value },
    } = event;
    setDeploymentEnvironments(
      // On autofill we get a stringified value.
      typeof value === "string" ? value.split(",") : value
    );
  };

  function getStyles(name, personName, theme) {
    return {
      fontWeight:
        personName.indexOf(name) === -1
          ? theme.typography.fontWeightRegular
          : theme.typography.fontWeightMedium,
    };
  }

  const ITEM_HEIGHT = 48;
  const ITEM_PADDING_TOP = 8;
  const MenuProps = {
    PaperProps: {
      style: {
        maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
        width: 250,
      },
    },
  };

  const handleNewEnviromentCreated = () => {
    callGetVariablesForRepository();
    setTabId(1);
  };

  const callGetVariablesForRepository = () => {
    showProgressBar(
      "Please be patient! while information related to existing repository are being fetched"
    );
    let config = {
      headers: {
        authorization: "Bearer " + localStorage.getItem("accessToken"),
      },
      params: {
        organizationName: localStorage.getItem("githubOrganizationName"),
        RepoName: state.repository.name,
        RepoId: state.repository.id,
      },
    };
    axios
      .get(constants.BASE_URL + constants.GET_GITHUB_VARIABLES, config)
      .then((response) => {
        hideProgressBar();
        console.log(
          "callGetVariablesForRepository=======>",
          response.data.body.result
        );
        SetRepoVariables(response.data.body.result);
        callGetAvailableEnvironment();
      })
      .catch((error) => {
        hideProgressBar();
        console.log("Error-callGetVariablesForRepository========>", error);
        handleErrorAlert(true);
        setErrorAlertCallback({
          message:
            "Something went wrong while fetching variables. Please try again!",
        });
        SetRepoVariables([]);
      });
  };

  return (
    <Box>
      <ColorButton
        backgroundcolor="#005689"
        variant="contained"
        size="small"
        onClick={handleClickOpen}
        startIcon={<Add />}
      >
        New Pipeline
      </ColorButton>
      <ErrorAlert
        isErrorVisible={isErrorVisible}
        callback={() => {
          setIsErrorVisible(false);
          if (
            errorAlertCallback.hasOwnProperty("navigate") &&
            errorAlertCallback.hasOwnProperty("navigateData")
          ) {
            navigate(
              errorAlertCallback.navigate,
              errorAlertCallback.navigateData
            );
          } else if (errorAlertCallback.hasOwnProperty("navigate")) {
            navigate(errorAlertCallback.navigate);
          }
        }}
        message={errorAlertCallback.message}
      />
      <Dialog open={open} onClose={handleClose}>
        <ProgressBar
          isVisible={isVisible}
          progressBarMessage={progressBarMessage}
        />

        <DialogTitle className="createCIPipeline-dialogTitle">
          Create Pipeline
        </DialogTitle>
        <Divider className="createCIPipeline-divider" />
        <DialogContent>
          <Box variant="outlined">
            <Grid container spacing={2}>
              <Grid item xs={6}>
                <TextField
                  variant="outlined"
                  fullWidth
                  label="Repository Name"
                  required
                  value={project}
                  disabled
                />
              </Grid>
              <Grid item xs={6}>
                <TextField
                  variant="outlined"
                  fullWidth
                  label="Pipeline Name"
                  required
                  onChange={(event) => setPipelineName(event.target.value)}
                />
              </Grid>
              <Grid item xs={6}>
                <FormControl fullWidth>
                  <InputLabel id="demo-simple-select-label" required>
                    Technology Type
                  </InputLabel>
                  <Select
                    labelId="demo-simple-select-label"
                    id="demo-simple-select"
                    value={technologyType}
                    label="Technology Type"
                    onChange={handleTechnologyTypeChange}
                  >
                    {technologyTypeList.map((type) => (
                      <MenuItem value={type.value} key={type.id}>
                        {type.name}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Grid>
              <Grid item xs={6}>
                <FormControl >
                  <FormLabel id="demo-row-radio-buttons-group-label">
                    Publist Artifacts
                  </FormLabel>
                  <RadioGroup
                    className="createCIPipeline-radioGroup"
                    row
                    aria-labelledby="demo-row-radio-buttons-group-label"
                    name="row-radio-buttons-group"
                    onChange={handlePublishArtifactChange}
                    value={isPublishArtifact}
                  >
                    <Stack spacing={8} direction={"row"}>
                      <FormControlLabel
                        className="createCIPipeline-formControlLevel"
                        value={true}
                        control={<Radio />}
                        label="Yes"
                      />
                      <FormControlLabel
                        className="createCIPipeline-formControlLevel"
                        value={false}
                        control={<Radio />}
                        label="No"
                      />
                    </Stack>
                  </RadioGroup>
                </FormControl>
              </Grid>
            </Grid>
            <Box className="createCIPipeline-box1" variant="outlined">
              {pipelineName.trim().length &&
                technologyType.trim().length ? (
                <Box>
                  <Stack direction={"row"} spacing={2}>
                    <Box>
                      {filteredUserList.length > 0 ? (
                        <Paper
                          className="createCIPipeline-paper"
                          variant="outlined"
                        >
                          <ListSubheader>Available Reviewers</ListSubheader>
                          <Divider />
                          <List className="createCIPipeline-list">
                            {filteredUserList.map((user, index) => (
                              <Box key={index}>
                                <ButtonBase
                                  focusRipple
                                  onClick={() => {
                                    console.log(user.login);
                                    if (
                                      selectedUserList.filter((e) => {
                                        return e === user.login;
                                      }).length > 0 || // eslint-disable-next-line
                                      selectedUserList.length == noOfReviewers
                                    ) {
                                      return;
                                    }
                                    setSelectedUserList([
                                      ...selectedUserList,
                                      user.login,
                                    ]);
                                  }}
                                >
                                  <Stack
                                    direction="row"
                                    spacing={1}
                                    alignItems="center"
                                    m={1}
                                  >
                                    <Avatar {...stringAvatar(user.login)} />
                                    <Typography>{user.login}</Typography>
                                  </Stack>
                                </ButtonBase>
                                {
                                  // eslint-disable-next-line
                                  index != filteredUserList.length - 1 ? (
                                    <Divider />
                                  ) : (
                                    <></>
                                  )
                                }
                              </Box>
                            ))}
                          </List>
                        </Paper>
                      ) : (
                        <></>
                      )}
                    </Box>
                    <Box>
                      {selectedUserList.length > 0 ? (
                        <Box>
                          <Typography
                            className="createCIPipeline-typography1"
                            variant="h6"
                            fontSize={14}
                          >
                            Selected Reviewers
                          </Typography>
                          <Divider />
                          <Box className="createCIPipeline-box2">
                            {selectedUserList.map((user, index) => (
                              <Chip
                                className="createCIPipeline-chip"
                                key={index}
                                label={user}
                                onDelete={() => {
                                  setSelectedUserList(
                                    selectedUserList.filter((e) => e !== user)
                                  );
                                }}
                              />
                            ))}
                          </Box>
                        </Box>
                      ) : (
                        <></>
                      )}
                    </Box>
                  </Stack>
                  <Typography
                    variant="body1"
                    color="#007CB9"
                    fontSize={13}
                    fontWeight={"bold"}
                    mt={1}
                  >
                    Your organization policy require to review every commit.
                    Please add {noOfReviewers} reviewers for initial pipeline
                    commit to default branch. Also, you need to add user in the
                    project to make them reviewer if already not present.
                  </Typography>
                  <Typography
                    variant="body1"
                    color="#007CB9"
                    fontSize={13}
                    fontWeight={"bold"}
                    mt={1}
                  >
                    Also, you need to add user in the project to make them
                    reviewer if already not present.
                  </Typography>
                </Box>
              ) : (
                <></>
              )}
            </Box>
            <Divider />
            <Stack direction={"row"} alignItems={"center"}>
              <Typography
                color={"#007CB9"}
                fontWeight={"bold"}
                fontSize={"14px"}
                mt={0.5}
                mr={2}
              >
                Deploy
              </Typography>
              <Stack direction={"row"} alignItems={"center"} mt={0.5}>
                <Typography
                  color={"#007CB9"}
                  // fontWeight={"bold"}
                  fontSize={"14px"}
                >
                  No
                </Typography>
                <Switch
                  sx={{
                    "& .MuiSwitch-switchBase.Mui-checked": {
                      color: "#005689",
                    },
                    "& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track": {
                      backgroundColor: "#005689",
                    },
                  }}
                  checked={isDeploy}
                  onChange={(event) => {
                    setIsDeploy(event.target.checked);
                    console.log("switch", isDeploy)
                  }}
                />
                <Typography
                  color={"#007CB9"}
                  // fontWeight={"bold"}
                  fontSize={"14px"}
                >
                  Yes
                </Typography>
              </Stack>
            </Stack>
            {isDeploy ? (<Box>
              <Stack direction={"row"} spacing={2}>
                <Box>
                  <Paper
                    className="createCIPipeline-paper"
                    variant="outlined"
                  >
                    {availableDeploymentEnvironments.length > 0 ? (
                      <Box>
                        <ListSubheader>Available Environments</ListSubheader>
                        <Divider />
                        <List
                          className="createCIPipeline-list">
                          {availableDeploymentEnvironments.map((user, index) => (
                            <Box key={index}>
                              <ButtonBase
                                focusRipple
                                onClick={() => {
                                  if (deploymentEnvironments.filter(x => x.environment === user.name).length === 0) {
                                    if (
                                      selectedEnvironmentList.filter((e) => {
                                        return (
                                          e ===
                                          user.name
                                        );
                                      }).length > 0 ||  // eslint-disable-next-line
                                      selectedEnvironmentList.length == 1
                                    ) {
                                      return;
                                    }
                                    setSelectedEnvironmentList([
                                      ...selectedEnvironmentList,
                                      user.name,
                                    ]);
                                    setEnvironment(user.name)
                                  }
                                }
                                }
                              >
                                <Stack
                                  direction="row"
                                  spacing={1}
                                  alignItems="center"
                                  m={1}
                                >
                                  <Typography>
                                    {user.name}
                                    <Divider />
                                  </Typography>

                                </Stack>
                              </ButtonBase>
                            </Box>
                          ))}

                        </List>
                      </Box>

                    ) : (
                      <></>
                    )}
                    <AddEnviromentDialog
                      handleNewEnviromentCreated={handleNewEnviromentCreated}
                      repository={state.repository}
                    />
                  </Paper>
                  <Box>
                    {platformToDeployList.length > 0 ? (
                      <Paper
                        sx={{ width: "210px" }}
                        className="createCIPipeline-paper"
                        variant="outlined"
                      >
                        <ListSubheader>Available Deployments</ListSubheader>
                        <Divider />
                        <List
                          className="createCIPipeline-list">
                          {platformToDeployList.map((user, index) => (
                            <Box key={index}>
                              <ButtonBase
                                focusRipple
                                onClick={() => {
                                  setPlatformToDeploy(user.name)
                                  console.log("list", user.name)

                                  const v = [...deploymentEnvironments];
                                  console.log("list", platformToDeploy)
                                  if (environment.trim().length > 0 && (!v.includes(environment))) {
                                    v.push({
                                      environment: environment,
                                      platformToDeploy: user.name,
                                    });
                                    setDeploymentEnvironments(v);
                                    setSelectedEnvironmentList([]);
                                    setEnvironment("");
                                    console.log("list", v)
                                    console.log("list", v.includes(Object.hasOwnProperty("PROD")))
                                  }
                                }}
                              >
                                <Stack
                                  direction="row"
                                  spacing={1}
                                  alignItems="center"
                                  m={1}
                                >
                                  <Typography>
                                    {user.name}
                                  </Typography>
                                </Stack>
                              </ButtonBase>
                            </Box>
                          ))}
                        </List>
                      </Paper>
                    ) : (
                      <></>
                    )}
                  </Box>
                </Box>
                <Box>
                  {selectedEnvironmentList.length ? (<Box>
                    {selectedEnvironmentList.map((user, index) => (
                      <Box>
                        <Typography
                          className="createCIPipeline-typography1"
                          variant="h6"
                          fontSize={14}
                        >
                          Selected Environment
                        </Typography>
                        <Chip
                          className="createCIPipeline-chip"
                          key={index}
                          label={user}
                          onDelete={() => {
                            setSelectedEnvironmentList(
                              selectedEnvironmentList.filter(
                                (e) =>
                                  e !==
                                  user
                              )
                            );
                          }}
                        />
                        <Typography
                          color={"#007CB9"}
                          fontSize={"14px"}
                        >
                          Please select the Deployment from list for the {user}!!!
                        </Typography>
                      </Box>

                    ))}
                  </Box>) : (<><Typography
                    color={"#007CB9"}
                    fontSize={"14px"}
                    mb={1}
                  >
                    Please Select Environment and then Deployment from the list!!!
                  </Typography></>)}


                  <Divider></Divider>
                  {deploymentEnvironments.length > 0 ? (
                    (deploymentEnvironments.map((list) => (
                      // <Box> <Divider/><Box/>
                      <Box sx={{ flexGrow: 1, maxWidth: 752 }}>
                        <Grid container spacing={2}>
                          <Grid item xs={12} md={6}>
                            <Typography fontSize={"14px"} color={"#007CB9"} mt={1} component="div">
                              {list.environment}
                            </Typography>
                            <List dense={dense}>
                              <ListItem
                                secondaryAction={
                                  <IconButton edge="end" aria-label="delete"
                                    onClick={() => {
                                      setDeploymentEnvironments(
                                        deploymentEnvironments.filter(
                                          (e) =>
                                            e.environment !==
                                            list.environment
                                        )
                                      );
                                      console.log("List environment", list.environment);
                                    }}>
                                    <DeleteIcon />
                                  </IconButton>
                                }
                              >
                                <ListItemText><Typography sx={{
                                  margin: "-14px"
                                }}>{list.platformToDeploy}</Typography></ListItemText>
                              </ListItem>
                            </List>
                          </Grid>
                        </Grid>
                        <Divider ></Divider>
                      </Box>
                    )))
                  ) : (
                    <></>
                  )}
                </Box>
              </Stack>
              <Stack direction={"row"} spacing={4}>
                <Box>

                </Box>
                <Box>
                  {selectedDeploymentList.length > 0 ? (
                    <Box>
                      <Typography
                        className="createCIPipeline-typography1"
                        variant="h6"
                        fontSize={14}
                      >
                        Selected Deployments
                      </Typography>
                      <Divider />
                      <Box className="createCIPipeline-box2">
                        {selectedDeploymentList.map((user, index) => (
                          <Chip
                            className="createCIPipeline-chip"
                            key={index}
                            label={user}
                            onDelete={() => {
                              setSelectedDeploymentList(
                                selectedDeploymentList.filter(
                                  (e) =>
                                    e !==
                                    user
                                )
                              );
                            }}
                          />
                        ))}
                      </Box>
                    </Box>
                  ) : (
                    <></>
                  )}
                </Box>
              </Stack>
            </Box>) : (
              <></>
            )}
            <Divider />
          </Box>
        </DialogContent>
        <DialogActions>
          <Button
            className="createCIPipeline-button-cancel"
            onClick={handleClose}
          >
            Cancel
          </Button>
          <Button
            className="createCIPipeline-button-create"
            disabled={
              !(
                technologyType.trim().length && // eslint-disable-next-line
                selectedUserList.length == noOfReviewers &&
                pipelineName.trim().length
              )
            }
            onClick={callCreatePipelineAPI}
          >
            Create Pipeline
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
