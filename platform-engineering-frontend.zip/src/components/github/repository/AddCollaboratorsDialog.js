import {
    Avatar,
    Button,
    ButtonBase,
    Chip,
    DialogActions,
    DialogContent,
    DialogTitle,
    Divider,
    ListSubheader,
    Paper,
    TextField,
    Typography,
    debounce,
  } from "@mui/material";
  import "../../azure/projects/projects.css";
  import Dialog from "@mui/material/Dialog";
  import { Box, Stack } from "@mui/system";
  import React, { useEffect, useState } from "react";
  import axios from "axios";
  import { constants } from "../../../utils/Constants";
  import ProgressBar from "../../../utils/ProgressBar";
  import ErrorAlert from "../../error/ErrorAlert";
  import { useLocation, useNavigate } from "react-router-dom";
  import List from "@mui/material/List";
  import { getTokenForAPI } from "../../../utils/RetrieveToken";
  import { useMsal } from "@azure/msal-react";
  import { stringAvatar } from "../../../utils/helper";
  import { useMemo } from "react";
  import { useRef } from "react";
  import { ColorButton } from "../../../utils/CustomButton";
  import { Add } from "@mui/icons-material";
  
  /**
   *
   * @returns React Functional Component (AddUsersDialog) which renders a dialog by which multiple users can be added to the project.
   * 
   */
  export default function AddCollaboratorsDialog({ onNewUserAdded, project }) {
    const [open, setOpen] = React.useState(false);
    const { state } = useLocation();
    const { instance, inProgress, accounts } = useMsal();
    const [isVisible, setIsVisible] = React.useState(false);
    const [progressBarMessage, setProgressBarMessage] =
      React.useState("Please wait!");
    const [isErrorVisible, setIsErrorVisible] = React.useState(false);
    const [errorAlertCallback, setErrorAlertCallback] = React.useState({
      navigate: -1,
      navigateData: {
        state: {},
      },
      message: "Something unexpected happend! Please try again",
    });
    // eslint-disable-next-line
    const [msalToken, setMsalToken] = useState("");
    const navigate = useNavigate();
    const [searchUser, setSearchUser] = React.useState("");
    const [addUserList, setAddUserList] = React.useState([]);
    const [selectedUserList, setSelectedUserList] = React.useState([]);
    const [filteredUserList, setFilteredUserList] = React.useState([]);

    /**
     * JS method to open dialog onclick.
     */
    const handleClickOpen = () => {
      callGetUserForOrganization();
      setOpen(true);
    };

    /**
     * JS method to close dialog onclick.
     */
    const handleAddUsersDialogClose = () => {
      setOpen(false);
      setSearchUser("");
      setFilteredUserList(addUserList);
      setSelectedUserList([]);
    };

    /**
     *
     * callback method called after users has been selected to be added in project.
     */
    const handleAddUsersDialog = () => {
      callAddCollaboratorAPI();
      console.log("Selected User List", selectedUserList);
    };

    /**
     *
     * @returns JS method to get mailAddress of selected users.
     */
    const getUsersToAdd = () => {
      const users = [];
      for (const user of selectedUserList) {
        users.push(user.mailAddress);
      }
      return users;
    };

    /**
     *
     * @param {*} token Access token retrieved to call Azure REST APIs using backend endpoints
     * JS method to call POST REST Endpoint for posting selected users list to be added in project.
     */
    const callAddCollaboratorAPI = () => {
      showProgressBar("Please be patient! While collaborator is being added.");
      const data = {
        organizationName: localStorage.getItem("githubOrganizationName"),
        repositoryName: project,
        permission:"admin",
        collaborators: selectedUserList,
      };
      console.log("callAddUserAPI==========>", data);
      let config = {
        headers: { authorization: "Bearer " + localStorage.getItem('accessToken') },
      };
      axios
        .post(
          constants.BASE_URL + constants.POST_GITHUB_ADD_COLLABORATORS,
          data,
          config
        )
        .then((response) => {
          hideProgressBar();
          handleAddUsersDialogClose();
          onNewUserAdded();
          console.log("Response-callAddUserAPI========>", response);
        })
        .catch((error) => {
          hideProgressBar();
          handleErrorAlert(true);
          setErrorAlertCallback({
            message:
              "Something went wrong while Adding Users in project. Please try again!",
          });
          console.log("Error-callAddUserAPI=========>", error);
        });
    };

    const handleClose = (event, reason) => {
      // eslint-disable-next-line
      if (reason && reason == "backdropClick") return;
      handleAddUsersDialogClose();
    };

    /**
     *
     * @param {*} value boolean value to change visiblity of Alert Dialog
     * JS method to update the boolean state value isErrorVisible
     */
    const handleErrorAlert = (value) => {
      setIsErrorVisible(value);
    };

    /**
     *
     * @param {*} token Access token retrieved to call Azure REST APIs using backend endpoints
     * callback method called after token is retrieved from @azure/msal-browser dependency
     */
    const getToken = (token) => {
      hideProgressBar();
      setMsalToken(token);
    };

    /**
     *
     * callback method called token retrived to get available users for project.
     */
    const callTokenForGetUser = () => {
      showProgressBar("Please be patient. While user is authorised");
      getTokenForAPI(instance, inProgress, accounts, callSearchUserAPI);
    };

    /**
     *
     * @param {*} callback method to restrict the calling of a time-consuming function frequently
     * @returns
     */
    const useDebounce = (callback) => {
      const ref = useRef();

      useEffect(() => {
        ref.current = callback;
      }, [callback]);

      const debouncedCallback = useMemo(() => {
        const func = () => {
          ref.current?.();
        };

        return debounce(func, 1000);
      }, []);

      return debouncedCallback;
    };

    /**
     *
     * @param {*} callback method to restrict the calling of a time-consuming function frequently
     * @returns
     */
    const debouncedRequest = useDebounce(() => {
      console.log(searchUser);
      // console.log(userSearchQuery);
      const filterList = addUserList.filter((user) =>
        user.login.toLowerCase().includes(searchUser.toLowerCase())
      );
      console.log("debouncedRequest========>", filterList);
      setFilteredUserList(filterList.length > 0 ? filterList : addUserList);
      // callTokenForGetUser();
    });

    /**
     * JS method called to handle the query input for searching the user to be added.
     */
    const retrieveTokenSearchUserAPI = (event) => {
      const userQuery = event.target.value;
      setSearchUser(userQuery);
      debouncedRequest();
    };

    /**
     *
     * @param {*} token Access token retrieved to call Azure REST APIs using backend endpoints
     * JS method to call GET REST Endpoint for retrieving all avialble users for organizations
     */
    const callSearchUserAPI = async (token) => {
      console.log("Searching User", searchUser);
      showProgressBar("Please be patient! While users are being fetched.");
      let config = {
        headers: { authorization: "Bearer " + token },
        params: {
          organizationName: localStorage.getItem("organizationName"),
          name: "",
        },
      };
      console.log("config ", config);
      axios
        .get(constants.BASE_URL + constants.GET_ADDUSER_LIST, config)
        .then((response) => {
          hideProgressBar();
          setAddUserList(response.data.body.users);
          setFilteredUserList(response.data.body.users);
          console.log("AddUser List", response.data.body.users);
        })
        .catch((error) => {
          console.log("Error-callSearchUserAPI==========>", error);
          hideProgressBar();
          // eslint-disable-next-line
          if (error && error.response && error.response.status == 404) {
            setErrorAlertCallback({
              message: error.response.data.body.message,
            });
            handleErrorAlert(true);
          }
        });
    };

    const callGetUserForOrganization = () => {
      showProgressBar(
        "Please be patient! while information related to existing repository are being fetched"
      );
      let config = {
        headers: {
          authorization: "Bearer " + localStorage.getItem("accessToken"),
        },
        params: {
          organizationName: localStorage.getItem("githubOrganizationName"),
        },
      };
      axios
        .get(
          constants.BASE_URL + constants.GET_GITHUB_ORGANIZATION_USER,
          config
        )
        .then((response) => {
          hideProgressBar();
          console.log(
            "callGetUserForOrganizationcallGetCollaboratorForRepo=======>",
            response.data.body.members
          );
          setAddUserList(response.data.body.members);
          setFilteredUserList(response.data.body.members);
        })
        .catch((error) => {
          hideProgressBar();
          console.log("Error-callGetUserForOrganization========>", error);
          handleErrorAlert(true);
          setErrorAlertCallback({
            message:
              "Something went wrong while fetching users. Please try again!",
          });
        });
    };

    useEffect(() => {
      // eslint-disable-next-line
    }, []);

    /**
     *
     * @param {*} message String value to be shown with Progress Bar
     * JS method called to make the Progress Bar visible along with the message
     */
    const showProgressBar = (message) => {
      setIsVisible(true);
      setProgressBarMessage(message);
    };

    /**
     *
     * JS method called to hide the Progress Bar
     */
    const hideProgressBar = () => {
      setIsVisible(false);
      setProgressBarMessage("");
    };

    return (
      <Box>
        <ColorButton
          backgroundcolor="#005689"
          variant="contained"
          size="small"
          onClick={handleClickOpen}
          startIcon={<Add />}
        >
          New Collaborators
        </ColorButton>
        <Dialog open={open} onClose={handleClose}>
          <ProgressBar
            isVisible={isVisible}
            progressBarMessage={progressBarMessage}
          />
          <ErrorAlert
            isErrorVisible={isErrorVisible}
            callback={() => {
              setIsErrorVisible(false);
              if (
                errorAlertCallback.hasOwnProperty("navigate") &&
                errorAlertCallback.hasOwnProperty("navigateData")
              ) {
                navigate(
                  errorAlertCallback.navigate,
                  errorAlertCallback.navigateData
                );
              } else if (errorAlertCallback.hasOwnProperty("navigate")) {
                navigate(errorAlertCallback.navigate);
              }
            }}
            message={errorAlertCallback.message}
          />
          <DialogTitle className="addUserDialog-dialogTitle">
            Add User
          </DialogTitle>
          <Divider className="addUserDialog-divider" />
          <DialogContent>
            <Box className="addUserDialog-box1" variant="outlined">
              <Stack direction={"row"} spacing={2}>
                <Box>
                  <TextField
                    variant="outlined"
                    fullWidth
                    label="Search User"
                    placeholder="Please enter user name to search"
                    onChange={retrieveTokenSearchUserAPI}
                  />
                  {filteredUserList.length > 0 ? (
                    <Paper className="addUserDialog-paper" variant="outlined">
                      <ListSubheader>Available Users</ListSubheader>
                      <Divider />
                      <List className="addUserDialog-list">
                        {filteredUserList.map((user, index) => (
                          <Box key={index}>
                            <ButtonBase
                              focusRipple
                              onClick={() => {
                                console.log(user.login);
                                if (
                                  selectedUserList.filter((e) => {
                                    return (
                                      e === user.login
                                    );
                                  }).length > 0
                                ) {
                                  return;
                                }
                                setSelectedUserList([
                                  ...selectedUserList,
                                  user.login,
                                ]);
                              }}
                            >
                              <Stack
                                direction="row"
                                spacing={1}
                                alignItems="center"
                                m={1}
                              >
                                <Avatar
                                  {...stringAvatar(user.login)}
                                />
                                <Typography>{user.login}</Typography>
                              </Stack>
                            </ButtonBase>
                            <Divider />
                          </Box>
                        ))}
                      </List>
                    </Paper>
                  ) : (
                    <></>
                  )}
                </Box>
                <Box>
                  {selectedUserList.length > 0 ? (
                    <Box>
                      <Typography
                        variant="h6"
                        fontSize={14}
                        className="addUserDialog-typography"
                      >
                        Selected Users
                      </Typography>
                      <Divider />
                      <Box className="addUserDialog-box2">
                        {selectedUserList.map((user, index) => (
                          <Chip
                            className="addUserDialog-chip"
                            key={index}
                            label={user}
                            onDelete={() => {
                              setSelectedUserList(
                                selectedUserList.filter(
                                  (e) => e !== user
                                )
                              );
                            }}
                          />
                        ))}
                      </Box>
                    </Box>
                  ) : (
                    <></>
                  )}
                </Box>
              </Stack>
            </Box>
          </DialogContent>
          <DialogActions>
            <Button className="addUserDialog-button1" onClick={handleClose}>
              Cancel
            </Button>
            <Button
              className="addUserDialog-button2"
              disabled={!selectedUserList.length}
              onClick={handleAddUsersDialog}
            >
              Add Collaborator
            </Button>
          </DialogActions>
        </Dialog>
      </Box>
    );
  }
  