import React, { useEffect, useState } from "react";
import {
  Box,
  Divider,
  FormControl,
  IconButton,
  InputLabel,
  MenuItem,
  Select,
  Stack,
  Switch,
  Tooltip,
  Typography,
  tooltipClasses,
} from "@mui/material";
import AddCircleOutlineSharpIcon from "@mui/icons-material/AddCircleOutlineSharp";
import { Delete, LockOpenOutlined, LockOutlined } from "@mui/icons-material";
import { ColorButton } from "../../../utils/CustomButton";
import { useNavigate } from "react-router-dom";
import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import axios from "axios";
import { constants } from "../../../utils/Constants";
import { useMsal } from "@azure/msal-react";
import { getTokenForAPI } from "../../../utils/RetrieveToken";
import ProgressBar from "../../../utils/ProgressBar";
import ErrorAlert from "../../error/ErrorAlert";
import styled from "@emotion/styled";

/**
 *
 * @returns React Functional Component (AddVariablesDialog) which renders a dialog by which variables will be added to project.
 */
export default function AddEnvVariableDialog({
  project,
  onNewVariableGroupAdded,
  variableGroupToEdit,
  isVariableEdit = false,
  variableGroupDialogIsOpen,
  handleVariableGroupDialogClose,
  enviromentList,
  repository
}) {
  const navigate = useNavigate();
  const { instance, inProgress, accounts } = useMsal();
  const [variableGroupName, setVariableGroupName] = useState("");
  const [variableGroupDescription, setVariableGroupDescription] = useState("");
  const [addedVariable, setAddedVariable] = useState({});
  const [variableKey, setVariableKey] = useState("");
  const [variableValue, setVariableValue] = useState("");
  const [progressBarMessage, setProgressBarMessage] =
    React.useState("Please wait!");
  const [isVisible, setIsVisible] = React.useState(false);
  const [isJsonSelected, setIsJsonSelected] = React.useState(false);
  const [isErrorVisible, setIsErrorVisible] = React.useState(false);
  // const [isVariableLock, setIsVariableLock] = React.useState(false);
  const [errorAlertCallback, setErrorAlertCallback] = React.useState({
    navigate: -1,
    navigateData: {
      state: {},
    },
    message: "Something unexpected happend! Please try again",
  });
  const [jsonButtonError, setJsonButtonError] = React.useState(
    "Upload a JSON file containing a JSON object of Name & Value pair for Variables"
  );
  const [isVariableLock, setIsVariableLock] = React.useState(false);
  const [selectedEnviroment, setSelectedEnviroment] = React.useState("");

  /**
   * 
   * @param {*} e handles the JSON file input
   */
  const handleChangejsonFile = (e) => {
    const fileReader = new FileReader();
    fileReader.readAsText(e.target.files[0], "UTF-8");
    console.log("e.target.result", e.target.files[0].type);
    // eslint-disable-next-line
    if (e.target.files[0].type == "application/json") {
      fileReader.onload = (e) => {
        console.log("Result====>", typeof e.target.result);
        console.log("Parsed Result====>", JSON.parse(e.target.result));
        const duplicateVariables = [];
        for (const variable of Object.keys(JSON.parse(e.target.result))) {
          if (Object.keys(addedVariable).includes(variable)) {
            duplicateVariables.push(variable);
          }
        }
        if (duplicateVariables.length) {
          setJsonButtonError(
            `Variables (${duplicateVariables.toString()}) already exist in variable group. Please delete previous one or modify your JSON file`
          );
        } else {
          setAddedVariable({
            ...addedVariable,
            ...JSON.parse(e.target.result),
          });
          setJsonButtonError("");
        }
      };
    } else {
      console.log("not a file type");
      setJsonButtonError(
        "Invalid file selected! Please select a valid JSON file"
      );
    }
  };

  /**
     * JS method called just after the closing dialog, clearing states of atributes
     */
  const onVariableGroupDialogClose = (event, reason) => {
    // eslint-disable-next-line
    if (reason && reason == "backdropClick") return;
    clearVariableGroupValues();
    handleVariableGroupDialogClose();
  };

  /**
  *
  * @param {*} value boolean value to change visiblity of Alert Dialog
  * JS method to update the boolean state value isErrorVisible
  */
  const handleErrorAlert = (value) => {
    setIsErrorVisible(value);
  };

  /**
   * JS method to manage states of attribute associated with variable.
   */
  const clearVariableGroupValues = () => {
    setVariableGroupName("");
    setVariableGroupDescription("");
    setAddedVariable({});
    setVariableKey("");
    setVariableValue("");
    setSelectedEnviroment("");
    setJsonButtonError(
      "Upload a JSON file containing a JSON object of Name & Value pair for Variables"
    );
    setIsJsonSelected(false);
  };


  const AddSingleVariables = () => {
    const variable = { ...addedVariable };
    if (variableKey.trim().length > 0) {
      variable[variableKey] = {
        value: variableValue,
        isSecret: isVariableLock
      };
      setAddedVariable(variable);
      setVariableKey("");
      setVariableValue("");
      setIsVariableLock(false);
    }
    return variable
  }

  const getFormattedVariableList = () => {
    const variableList = [];
    if (Object.keys(addedVariable).length > 0) {
      var singleVariables = AddSingleVariables();
      setAddedVariable(singleVariables);
      console.log("singleVariables", singleVariables)
      for (const key in singleVariables) {
        if (Object.hasOwnProperty.call(singleVariables, key)) {
          const element = singleVariables[key];
          variableList.push({
            name: key,
            value: element.value,
            isSecret: element.isSecret
          })
        }
      }
    } else {
      let singleVariable = AddSingleVariables();
      console.log("singleVariable", singleVariable)
      for (const key in singleVariable) {
        if (Object.hasOwnProperty.call(singleVariable, key)) {
          const element = singleVariable[key];
          variableList.push({
            name: key,
            value: element.value,
            isSecret: element.isSecret
          })
        }
      }
    }
    return filterVariables(variableList);
  }


  const filterVariables = (variableList) => {
    return normalVariable(variableList);
  }

  const normalVariable = (variableList) => {
    const final = {
      secrets: "",
      variables: ""
    }
    const normVariablesList = [];
    for (const key in variableList) {
      const element = variableList[key];
      if (element.isSecret == false) {
        normVariablesList.push({
          name: element.name,
          value: element.value
        })
      }
    }
    console.log("Norm", normVariablesList);
    final.variables = normVariablesList;

    const secretVariables = [];
    for (const key in variableList) {
      const element = variableList[key];
      if (element.isSecret == true) {
        secretVariables.push({
          secretName: element.name,
          secretValue: element.value
        });
      }
    }
    console.log("Secret", secretVariables)
    final.secrets = secretVariables;
    return final;
  }


  /**
    *
    * @param {*} token Access token retrieved to call Azure REST APIs using backend endpoints
    * JS method to call POST REST Endpoint for posting input of add variables to be created for project.
    */
  const callCreateSecretsVariableGroupAPI = (token) => {
    const formatVar = getFormattedVariableList();
    showProgressBar(
      "Please be patient! While variable group is being created."
    );
    let config = {
      headers: { authorization: "Bearer " + localStorage.getItem("accessToken") },
    };
    const data = {
      repositoryName: repository.name,
      organizationName: localStorage.getItem("githubOrganizationName"),
      environmentName: selectedEnviroment,
      secrets: formatVar.secrets,
    };
    console.log("callCreateSecretsVariableGroupAP==========>", data);
    console.log("callCreateSecretsVariableGroupAP==========>", variableKey, variableValue);
    axios
      .post(constants.BASE_URL + constants.POST_GITHUB_SECRETVARIABLES, data, config)
      .then((response) => {
        hideProgressBar();
        clearVariableGroupValues();
        handleVariableGroupDialogClose();
        console.log(
          "callCreateSecretsVariableGroupAP-Response============>",
          response
        );
        onNewVariableGroupAdded();
      })
      .catch((error) => {
        hideProgressBar();
        setErrorAlertCallback({
          // eslint-disable-next-line
          message:
            error.response.status === 409
              ? error.response.data.body.message
              : "Something went wrong while creating secrets variable group. Please try again!",
        });
        handleErrorAlert(true);
        console.log("callCreateSecretsVariableGroupAP-Error============>", error);
      });
  };

  /**
   *
   * @param {*} token Access token retrieved to call Azure REST APIs using backend endpoints
   * JS method to call POST REST Endpoint for posting input of add variables to be created for project.
   */
  const callCreateVariableGroupAPI = (token) => {
    const formatVar = getFormattedVariableList();
    showProgressBar(
      "Please be patient! While variable group is being created."
    );
    let config = {
      headers: { authorization: "Bearer " + localStorage.getItem("accessToken") },
    };
    const data = {
      repository_id: repository.id,
      environment_name: selectedEnviroment,
      variables: formatVar.variables,
    };
    console.log("callCreateVariableGroupAPI==========>", data);
    console.log("callCreateVariableGroupAPI==========>", variableKey, variableValue);
    axios
      .post(constants.BASE_URL + constants.POST_GITHUB_ADD_VARIABLE, data, config)
      .then((response) => {
        hideProgressBar();
        clearVariableGroupValues();
        handleVariableGroupDialogClose();
        console.log(
          "callCreateVariableGroupAPI-Response============>",
          response
        );
        callCreateSecretsVariableGroupAPI();
        onNewVariableGroupAdded();
      })
      .catch((error) => {
        hideProgressBar();
        setErrorAlertCallback({
          // eslint-disable-next-line
          message:
            error.response.status === 409
              ? error.response.data.body.message
              : "Something went wrong while creating variable group. Please try again!",
        });
        handleErrorAlert(true);
        console.log("callCreateVariableGroupAPI-Error============>", error);
      });
  };

  /**
   *
   * @param {*} token Access token retrieved to call Azure REST APIs using backend endpoints
   * JS method to call UPDATE REST Endpoint for posting new input of add variables to be created for project.
   */
  const callUpdateVariableGroupAPI = (token) => {
    showProgressBar(
      "Please be patient! while variable group is being updated."
    );
    let config = {
      headers: { authorization: "Bearer " + token },
    };
    const data = {
      projectName: project.name,
      organizationName: localStorage.getItem("organizationName"),
      variableGroupName: variableGroupName,
      description: variableGroupDescription,
      variables: addedVariable,
      // variables: (() => {
      //   const variables = {};
      //   Object.keys(addedVariable).forEach((name, index) => {
      //     variables[name] =
      //       typeof addedVariable[name] == "object"
      //         ? addedVariable[name].value
      //         : addedVariable[name];
      //   });
      //   return variables;
      // })(),
      groupId: variableGroupToEdit.id,
    };
    console.log("callUpdateVariableGroupAPI==========>", data);
    axios
      .put(constants.BASE_URL + constants.GET_VARIABLE_GROUP, data, config)
      .then((response) => {
        hideProgressBar();
        clearVariableGroupValues();
        handleVariableGroupDialogClose();
        console.log(
          "callUpdateVariableGroupAPI-Response============>",
          response
        );
        clearVariableGroupValues();
        onNewVariableGroupAdded();
      })
      .catch((error) => {
        hideProgressBar();
        setErrorAlertCallback({
          // eslint-disable-next-line
          message:
            error.response.status === 409
              ? error.response.data.body.message
              : "Something went wrong while creating variable group. Please try again!",
        });
        handleErrorAlert(true);
        console.log("callUpdateVariableGroupAPI-Error============>", error);
      });
  };

  /**
     * JS method called to retrieve token in getToken callback method
     */
  const onTokenForVariableGroupCreation = () => {
    isVariableEdit
      ? callUpdateVariableGroupAPI("token")
      : callCreateVariableGroupAPI();
  };

  /**
   * JS method to intialize variables added.
   */
  const initiateCreateVariableGroup = () => {
    showProgressBar(
      "Please be patient! While variable group is being created."
    );
    getTokenForAPI(
      instance,
      inProgress,
      accounts,
      onTokenForVariableGroupCreation
    );
  };

  useEffect(() => {
    setVariableGroupDataToEdit(variableGroupToEdit);
    // eslint-disable-next-line
  }, [variableGroupToEdit]);

  /**
   * 
   * @param {*} variableGroup existing variable group
   * @returns update variable gruop
   */
  const setVariableGroupDataToEdit = (variableGroup) => {
    if (!isVariableEdit) {
      return;
    }
    setVariableGroupName(variableGroup.name);
    setVariableGroupDescription(variableGroup.description);
    setAddedVariable(variableGroup.variables);
  };

  /**
  *
  * @param {*} message String value to be shown with Progress Bar
  * JS method called to make the Progress Bar visible along with the message
  */
  const showProgressBar = (message) => {
    setIsVisible(true);
    setProgressBarMessage(message);
  };

  /**
   *
   * JS method called to hide the Progress Bar
   */
  const hideProgressBar = () => {
    setIsVisible(false);
    setProgressBarMessage("");
  };


  /**
     *
     * JS method to show message on mouse hover
     */
  const SecretVariable = `lock variable`
  const HtmlTooltip = styled(({ className, ...props }) => (
    <Tooltip {...props} classes={{ popper: className }} color="#005689" />
  ))(({ theme }) => ({
    [`& .${tooltipClasses.tooltip}`]: {
      backgroundColor: "#005689",
      border: "1px solid #dadde9",
      fontSize: "14px",
    },
  }));

  const handleLockChange = () => {
    setIsVariableLock((prev) => !prev)
    console.log("lock", isVariableLock)
  }

  return (
    <Box>
      <Dialog
        open={variableGroupDialogIsOpen}
        onClose={onVariableGroupDialogClose}
      >
        <ProgressBar
          isVisible={isVisible}
          progressBarMessage={progressBarMessage}
        />
        <ErrorAlert
          isErrorVisible={isErrorVisible}
          callback={() => {
            setIsErrorVisible(false);
            if (
              errorAlertCallback.hasOwnProperty("navigate") &&
              errorAlertCallback.hasOwnProperty("navigateData")
            ) {
              navigate(
                errorAlertCallback.navigate,
                errorAlertCallback.navigateData
              );
            } else if (errorAlertCallback.hasOwnProperty("navigate")) {
              navigate(errorAlertCallback.navigate);
            }
          }}
          message={errorAlertCallback.message}
        />
        <DialogTitle className="addVariableDialog-dialogTitle">
          {isVariableEdit ? "Edit" : "Add"} Variable Group
        </DialogTitle>
        <DialogContent>
          <DialogContentText>
            To {isVariableEdit ? "edit" : "create"} variable group, please enter
            below details
          </DialogContentText>
          <Box className="addVariableDialog-box1">
            <FormControl fullWidth>
              <InputLabel id="demo-simple-select-label" required>
                Enviroment Name
              </InputLabel>
              <Select
                labelId="demo-simple-select-label"
                id="demo-simple-select"
                value={selectedEnviroment}
                label="Enviroment Name"
                onChange={(event) => {
                  setSelectedEnviroment(event.target.value);
                }}
              >
                {enviromentList.map((env, index) => (
                  <MenuItem
                    value={env.environmentName}
                    key={env.environmentName}
                  >
                    {env.environmentName}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>

            <Stack
              direction={"row"}
              justifyContent={"space-between"}
              mt={1}
              alignItems={"center"}
            >
              <Typography color={"#005689"}>Variables</Typography>
              <Stack direction={"row"} alignItems={"center"}>
                <Switch
                  onChange={(event) => {
                    setIsJsonSelected(event.target.checked);
                  }}
                />
                <Typography color={"#005689"}>Upload JSON</Typography>
              </Stack>
            </Stack>

            <Stack spacing={2} direction={"row"} ml={1} mt={1}>
              <Typography width={"100%"} variant="body2" color={"#007CB9"}>
                {"Name"}
              </Typography>
              <Typography width={"100%"} variant="body2" color={"#007CB9"}>
                {"Value"}
              </Typography>
              <IconButton disabled>
                <Delete className="addVariableDialog-delete" />
              </IconButton>
            </Stack>
            <Divider className="addVariableDialog-divider" />
            {Object.keys(addedVariable).map((name, index) => (
              <Stack
                spacing={2}
                direction={"row"}
                ml={1}
                flex={1}
                alignItems={"center"}
                key={index}
              >
                <Typography width={"50%"} flexWrap={"wrap"} noWrap>
                  {name}
                </Typography>
                <Typography width={"50%"} flexWrap={"wrap"} noWrap>
                  {addedVariable[name].isSecret
                    ? "****"
                    : addedVariable[name].value}
                </Typography>
                <IconButton
                  onClick={() => {
                    const variable = { ...addedVariable };
                    delete variable[name];
                    setAddedVariable(variable);
                  }}
                >
                  <Delete />
                </IconButton>
              </Stack>
            ))}
            {!isJsonSelected ? (
              <Box className="addVariableDialog-box2">
                <Stack spacing={1} direction={"row"} mt={1} mb={1} ml={1}>
                  <TextField
                    variant="standard"
                    fullWidth
                    size="small"
                    label="Variable Name"
                    name="variableKey"
                    value={variableKey}
                    error={Object.keys(addedVariable).includes(
                      variableKey
                    )}
                    helperText={
                      Object.keys(addedVariable).includes(variableKey)
                        ? `${variableKey} already exists in variable group`
                        : ""
                    }
                    onChange={(event) =>
                      setVariableKey(event.target.value)
                    }
                  />

                  <TextField
                    variant="standard"
                    fullWidth
                    size="small"
                    type={"text"}
                    label="Variable Value"
                    name="variableValue"
                    value={variableValue}
                    onChange={(event) =>
                      setVariableValue(event.target.value)
                    }
                  />
                  <HtmlTooltip title={SecretVariable} >
                    <IconButton
                      onClick={handleLockChange}
                    >
                      {isVariableLock ? <LockOutlined /> : <LockOpenOutlined />}
                    </IconButton>
                  </HtmlTooltip>
                  <IconButton
                    disabled={
                      !(
                        variableKey.trim().length &&
                        variableValue.trim().length &&
                        !Object.keys(addedVariable).includes(variableKey)
                      )
                    }
                    onClick={() => {
                      const variable = { ...addedVariable };
                      variable[variableKey] = {
                        value: variableValue,
                        isSecret: isVariableLock
                      };
                      setAddedVariable(variable);
                      setVariableKey("");
                      setVariableValue("");
                      setIsVariableLock(false);
                    }}
                  >
                    <AddCircleOutlineSharpIcon className="createProject-addCircleOutlined" />
                  </IconButton>
                </Stack>
              </Box>
            ) : (
              <Box className="addVariableDialog-box2">
                <ColorButton
                  backgroundcolor="#005689"
                  variant="contained"
                  fontSize="14px"
                  component="label"
                  className="addVariableDialog-colourButton"
                  disabled={
                    !(
                      selectedEnviroment.length
                    )
                  }
                  onChange={handleChangejsonFile}
                >
                  Upload JSON
                  <input hidden multiple type="file" value={""} />
                </ColorButton>
                <Typography
                  variant="subtitle2"
                  className={
                    jsonButtonError.includes("Invalid") ||
                      jsonButtonError.includes("delete")
                      ? "addVariableDialog-typography-red"
                      : "addVariableDialog-typography-blue"
                  }
                >
                  {variableGroupName.length && variableGroupDescription.length
                    ? jsonButtonError
                    : "Please enter Variable Group Name & Description first"}
                </Typography>
              </Box>
            )}
          </Box>
        </DialogContent>
        <DialogActions>
          <Button
            className="addVariableDialog-button-cancel"
            onClick={() => {
              handleVariableGroupDialogClose();
              clearVariableGroupValues();
            }}
          >
            Cancel
          </Button>
          <Button
            className="addVariableDialog-button-create"
            onClick={onTokenForVariableGroupCreation}
            disabled={
              !(
                (JSON.stringify(addedVariable).length > 2 || (variableKey.trim().length > 0 && variableValue.trim().length > 0)) &&
                selectedEnviroment.length
              )
            }
          >
            {isVariableEdit ? "Update" : "Create"}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
