import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Avatar,
  Box,
  Button,
  ButtonBase,
  Card,
  CardContent,
  Chip,
  Dialog,
  DialogActions,
  DialogContent,
  DialogTitle,
  Divider,
  FormControl,
  FormControlLabel,
  FormLabel,
  Grid,
  IconButton,
  InputLabel,
  List,
  ListSubheader,
  MenuItem,
  Paper,
  Radio,
  RadioGroup,
  Select,
  Stack,
  Switch,
  TextField,
  Tooltip,
  Typography,
  tooltipClasses,
} from "@mui/material";
import React, { useState } from "react";
import ProgressBar from "../../../utils/ProgressBar";
import ErrorAlert from "../../error/ErrorAlert";
import CustomBreadCrumb from "../../../utils/CustomBreadCrumb";
import { useLocation, useNavigate } from "react-router-dom";
import AddCircleOutlineSharpIcon from "@mui/icons-material/AddCircleOutlineSharp";
import {
  Add,
  Delete,
  ExpandMoreOutlined,
  LockOpenOutlined,
  LockOutlined,
} from "@mui/icons-material";
import styled from "@emotion/styled";
import InfoOutlinedIcon from "@mui/icons-material/InfoOutlined";
import axios from "axios";
import { constants } from "../../../utils/Constants";
import { ColorButton } from "../../../utils/CustomButton";
import { stringAvatar } from "../../../utils/helper";
import ListItem from '@mui/material/ListItem';
import ListItemText from '@mui/material/ListItemText';
import DeleteIcon from '@mui/icons-material/Delete';

export default function CreateRepository() {
  const location = useLocation();
  const { state } = location;
  const navigate = useNavigate();
  const [isVisible, setIsVisible] = React.useState(false);
  const [progressBarMessage, setProgressBarMessage] =
    React.useState("Please wait!");
  const [errorAlertCallback, setErrorAlertCallback] = React.useState({
    navigate: -1,
    navigateData: {
      state: {},
    },
    message: "Something unexpected happend! Please try again",
  });
  const [errorAlertMessage, setErrorAlertMessage] = React.useState(
    "Something unexpected happend! Please try again"
  );
  const [isErrorVisible, setIsErrorVisible] = React.useState(false);
  const [pipelineVariables, setPipelineVariables] = React.useState([]);
  const [isVariableLock, setIsVariableLock] = React.useState(false);
  const [organizationRules, setOrganizationRules] = React.useState({
    _id: "",
    organizationName: "",
    namingStandard: "",
    createdBy: "",
    branchingModel: {
      _id: "",
      name: "",
      numberOfBranches: 0,
      branches: [],
      created_at: "",
      updated_at: "",
      __v: 0,
    },
    created_at: "",
    updated_at: "",
    __v: 0,
  });
  const [repositoryName, setRepositoryName] = React.useState("");
  const [repositoryDescription, setRepositoryDescription] = React.useState("");
  const [repositoryVisibility, setRepositoryVisibility] =
    React.useState("private");
  const [noOfReviewers, setNoOfReviewers] = React.useState("");
  const [pipelineName, setPipelineName] = React.useState("");
  const [applicationType, setApplicationType] = React.useState("");
  const [publishArtifacts, setPublishArtifacts] = React.useState(false);
  // eslint-disable-next-line
  const [applicationTypeList, setapplicationTypeList] = React.useState([
    {
      id: "0",
      name: "Java",
      value: "java",
    },
    {
      id: "1",
      name: ".Net",
      value: "dotNet",
    },
  ]);
  const [addUserList, setAddUserList] = React.useState([]);
  const [selectedReviewerList, setSelectedReviewerList] = React.useState([]);
  const [isJsonSelected, setIsJsonSelected] = React.useState(false);
  const [addedVariable, setAddedVariable] = React.useState({});
  const [variableKey, setVariableKey] = React.useState("");
  const [variableValue, setVariableValue] = React.useState("");
  const [jsonButtonError, setJsonButtonError] = React.useState(
    "Upload a JSON file containing a JSON object of Name & Value pair for Variables"
  );
  const [isPublishArtifact, setPublishArtifact] = React.useState(false);
  const [isDeploy, setIsDeploy] = React.useState(false);
  const [isWorkflowDispatch, setIsWorkflowDispatch] = React.useState(false);
  const [platformToDeployType, setPlatformToDeployType] = React.useState("");
  const [selectedEnvironmentList, setSelectedEnvironmentList] = React.useState([]);
  const [selectedDeploymentList, setSelectedDeploymentList] = React.useState([]);
  const [environment, setEnvironment] = React.useState("");
  const [platformToDeploy, setPlatformToDeploy] = React.useState("");
  const [platformToDeployList, setPlatformToDeployList] = React.useState([]);
  const [dense, setDense] = React.useState(false);
  const [deploymentEnvironments, setDeploymentEnvironments] = React.useState([]);
  const [availableDeploymentEnvironments, setAvailableDeploymentEnvironment,
  ] = React.useState([]);
  const [repoVariables, SetRepoVariables] = useState([]);
  const [tabId, setTabId] = useState(0);
  const [enviromentName, setEnviromentName] = useState("");
  const [open, setOpen] = React.useState(false);

  /**
   *
   * @param {*} message String value to be shown with Progress Bar
   * JS method called to make the Progress Bar visible along with the message
   */
  const showProgressBar = (message) => {
    setIsVisible(true);
    setProgressBarMessage(message);
  };

  /**
   *
   * JS method called to hide the Progress Bar
   */
  const hideProgressBar = () => {
    setIsVisible(false);
    setProgressBarMessage("");
  };

  const handleErrorAlert = (value, message) => {
    setIsErrorVisible(value);
    setErrorAlertMessage(message);
  };

  /**
   *
   * @param {*} event method to handle repository visibility type for repository.
   */
  const handleRepositoryVisibilityChange = (event) => {
    setRepositoryVisibility(event.target.value);
  };

  /**
   *
   * @param {*} event method to handle technology type for pipeline.
   */
  const handleApplicationTypeChange = (event) => {
    setApplicationType(event.target.value);
  };

  /**
   *
   * @param {*} event method to handle publishArtifact type for pipeline.
   */
  const handlePublishArtifactTypeChange = (event) => {
    // eslint-disable-next-line
    // setPublishArtifacts(event.target.value == "true");
  };

  /**
   * display information about branching modal
   */
  const BranchMessage = `Below Branching Modal is for reference purpose only`;
  const SecretVariable = `lock variable`
  const HtmlTooltip = styled(({ className, ...props }) => (
    <Tooltip {...props} classes={{ popper: className }} color="#005689" />
  ))(({ theme }) => ({
    [`& .${tooltipClasses.tooltip}`]: {
      backgroundColor: "#005689",
      border: "1px solid #dadde9",
      fontSize: "14px",
    },
  }));

  /**
   *
   * @param {*} e handles the JSON file input
   */
  const handleChangejsonFile = (e) => {
    const fileReader = new FileReader();
    fileReader.readAsText(e.target.files[0], "UTF-8");
    console.log("e.target.result", e.target.files[0].type);
    // eslint-disable-next-line
    if (e.target.files[0].type == "application/json") {
      fileReader.onload = (e) => {
        console.log("Result====>", typeof e.target.result);
        console.log("Parsed Result====>", JSON.parse(e.target.result));
        const duplicateVariables = [];
        for (const variable of Object.keys(JSON.parse(e.target.result))) {
          if (Object.keys(addedVariable).includes(variable)) {
            duplicateVariables.push(variable);
          }
        }
        if (duplicateVariables.length) {
          setJsonButtonError(
            `Variables (${duplicateVariables.toString()}) already exist in variable group. Please delete previous one or modify your JSON file`
          );
        } else {
          setAddedVariable({
            ...addedVariable,
            ...JSON.parse(e.target.result),
          });
          setJsonButtonError("");
        }
      };
    } else {
      console.log("not a file type");
      setJsonButtonError(
        "Invalid file selected! Please select a valid JSON file"
      );
    }
  };

  /**
   *
   * @param {*} token Access token retrieved to call Azure REST APIs using backend endpoints
   * JS method to call GET REST Endpoint for retrieving organization rule.
   */
  const getRulesByOrganization = () => {
    showProgressBar(
      "Please be patient! While organization rule are being fetched."
    );
    let config = {
      params: {
        organizationName: localStorage.getItem("githubOrganizationName"),
        platform: "Github",
      },
    };
    axios
      .get(constants.BASE_URL + constants.GET_RULES_BY_ORGANIZTION, config)
      .then((response) => {
        hideProgressBar();
        console.log(
          "Response-getRulesByOrganization==============>",
          response.data.body.projectCreationRules
        );

        setNoOfReviewers(
          response.data.body.projectCreationRules.branchingModel.branches.find(
            // eslint-disable-next-line
            (branch) => branch.type == "default"
          ).noOfReviewers
        );

        const rules = response.data.body.projectCreationRules;
        setOrganizationRules(rules);
      })
      .catch((error) => {
        hideProgressBar();
      });
  };



  const callGetDeploymentPlatform = () => {
    showProgressBar(
      "Please be patient! while deployment platform are being fetched"
    );
    let config = {
      headers: {
        authorization: "Bearer " + localStorage.getItem("accessToken"),
      },
    };
    axios
      .get(constants.BASE_URL + constants.GET_DEPLOYMENT_PLATFORMS, config)
      .then((response) => {
        hideProgressBar();
        console.log(
          "callGetDeploymentPlatform=======>",
          response.data.body.availableDeploymentPlatforms
        );
        setPlatformToDeployList(response.data.body.availableDeploymentPlatforms);
      })
      .catch((error) => {
        hideProgressBar();
        console.log("Error-callGetDeploymentPlatform", error);
        handleErrorAlert(true);
        setErrorAlertCallback({
          message:
            "Something went wrong while fetching users. Please try again!",
        });
        // setAddUserList([]);
      });
  };


  const callGetUserForOrganization = () => {
    showProgressBar(
      "Please be patient! while information related to existing repository are being fetched"
    );
    let config = {
      headers: {
        authorization: "Bearer " + localStorage.getItem("accessToken"),
      },
      params: {
        organizationName: localStorage.getItem("githubOrganizationName"),
      },
    };
    axios
      .get(constants.BASE_URL + constants.GET_GITHUB_ORGANIZATION_USER, config)
      .then((response) => {
        hideProgressBar();
        console.log(
          "callGetUserForOrganizationcallGetCollaboratorForRepo=======>",
          response.data.body.members
        );
        setAddUserList(response.data.body.members);
      })
      .catch((error) => {
        hideProgressBar();
        console.log("Error-callGetUserForOrganization========>", error);
        handleErrorAlert(true);
        setErrorAlertCallback({
          message:
            "Something went wrong while fetching users. Please try again!",
        });
        setAddUserList([]);
      });
  };

  React.useEffect(() => {
    getRulesByOrganization();
    callGetUserForOrganization();
    callGetDeploymentPlatform();
    console.log("ORGNAME", state.organizationName)
    // callGetAvailableEnvironment(); 
  }, []);

  // const getVariableList = (addedVariable) => {
  //   console.log("getVariableList====>", Object.keys(addedVariable));
  //   const listOfVariables = [];
  //   for (const key in addedVariable) {
  //     const variable = {
  //       name: key,
  //       value: addedVariable[key].value,
  //     };
  //     listOfVariables.push(variable);
  //   }
  //   return listOfVariables;
  // };

  const AddSingleVariables = () => {
    const variable = { ...addedVariable };
    if (variableKey.trim().length > 0) {
      variable[variableKey] = {
        value: variableValue,
        isSecret: isVariableLock

      };
      setAddedVariable(variable);
      setVariableKey("");
      setVariableValue("");
      setIsVariableLock(false);
    }
    return variable
  }

  const getFormattedVariableList = () => {
    const variableList = [];
    if (Object.keys(addedVariable).length > 0) {
      var singleVariables = AddSingleVariables();
      setAddedVariable(singleVariables);
      console.log("singleVariables", singleVariables)
      for (const key in singleVariables) {
        if (Object.hasOwnProperty.call(singleVariables, key)) {
          const element = singleVariables[key];
          variableList.push({
            name: key,
            value: element.value,
            isSecret: element.isSecret
          })
        }
      }
    } else {
      let singleVariable = AddSingleVariables();
      console.log("singleVariable", singleVariable)
      for (const key in singleVariable) {
        if (Object.hasOwnProperty.call(singleVariable, key)) {
          const element = singleVariable[key];
          variableList.push({
            name: key,
            value: element.value,
            isSecret: element.isSecret
          })
        }
      }
    }
    return filterVariables(variableList);
  }

  const normalVariable = (variableList) => {
    const final = {
      secrets: "",
      variables: ""
    }
    const normVariablesList = [];
    for (const key in variableList) {
      const element = variableList[key];
      if (element.isSecret == false) {
        normVariablesList.push({
          name: element.name,
          value: element.value
        })
      }
    }
    console.log("Norm", normVariablesList);
    final.variables = normVariablesList;

    const secretVariables = [];
    for (const key in variableList) {
      const element = variableList[key];
      if (element.isSecret == true) {
        secretVariables.push({
          secretName: element.name,
          secretValue: element.value
        });
      }
    }
    console.log("Secret", secretVariables)
    final.secrets = secretVariables;
    return final;
  }

  const filterVariables = (variableList) => {
    return normalVariable(variableList);
  }

  /**
   *
   * JS method to call POST REST Endpoint to be create Github Repository
   */
  const callCreateRepository = () => {
    const formatVar = getFormattedVariableList();
    showProgressBar("Please be patient! While repository is being created.");
    const data = {
      organizationName: state.organizationName,
      repositoryName: `${organizationRules.namingStandard}${repositoryName}`,
      description: repositoryDescription,
      isPrivate: repositoryVisibility === "private",
      visibility: "public",
    };
    if (
      pipelineName.length &&
      applicationType.length &&
      selectedReviewerList.length
    ) {
      data["pipeline"] = {
        name: pipelineName,
        applicationType: applicationType,
        publishArtifacts: publishArtifacts,
        usernameInitials: stringAvatar(
          JSON.parse(localStorage.getItem("githubAuthenticatedUser")).login
        ).children,
        reviewers: selectedReviewerList,
        toBeDeployed: isDeploy,
        deploymentEnvironments: deploymentEnvironments,
        existingPipeline: false
      };
    }

    if (Object.keys(addedVariable).length || variableKey.trim().length > 0) {
      data["variables"] = formatVar.variables;
      data["secrets"] = formatVar.secrets;
    }
    console.log("callCreateRepository==========>", data);
    let config = {
      headers: {
        authorization: "Bearer " + localStorage.getItem("accessToken"),
      },
    };
    axios
      .post(
        constants.BASE_URL + constants.POST_GITHUB_CREATE_ORGANIZATION,
        data,
        config
      )
      .then((response) => {
        hideProgressBar();
        console.log("callCreateRepository=======>", response.data.body.createdRepository.environmentVariables);
        setPipelineVariables(response.data.body.createdRepository.environmentVariables)
        handleErrorAlert(true);
        if (response.data.body.createdRepository.hasOwnProperty('environmentVariables') && response.data.body.createdRepository.environmentVariables.length > 0) {
          setErrorAlertCallback({
            navigate: "/github/repository",
            message: <Box>
              <Typography variant="body1">Repository {repositoryName} created successfully! </Typography>
              <Typography
                variant="body1"
                color={"#005689"}> Please add the following variables in your environment {enviromentName} </Typography>
              <Typography variant="body1"
                color={"#005689"}>
                {response.data.body.createdRepository.environmentVariables.map((varr) => <>{varr}<br></br></>)}</Typography>
              <Typography variant="body1"
                color={"#005689"}>to configure your Pipeline{pipelineName}</Typography>
            </Box>,
            navigateData: {
              state: {
                organization: state.organizationName,
                routeList: ["/github"],
              },
            },
          });
        } else {
          setErrorAlertCallback({
            navigate: "/github/repository",
            message: <Box>
              <Typography variant="body1">Repository {repositoryName} created successfully! </Typography>
            </Box>,
            navigateData: {
              state: {
                organization: state.organizationName,
                routeList: ["/github"],
              },
            },
          });
        }

      })
      .catch((error) => {
        hideProgressBar();
        if (error.response.status === 403) {
          setErrorAlertCallback({
            message: error.response.data.body.message,
          });
        }
        else if (error.response.status === 409) {
          setErrorAlertCallback({
            message:
              "Repository already exist. please try with different name",
          });
        } else {
          setErrorAlertCallback({
            message:
              "Something went wrong while creating project. Please try again!",
          });
        }
        handleErrorAlert(true);
        console.log("callCreateRepository=======>", error);
      });
  };

  const handleTechnologyTypeChange = (event) => {
    setApplicationType(event.target.value);
  };

  /**
  *
  * @param {*} event method to handle publishArtifact type for pipeline.
  */
  const handlePublishArtifactChange = (event) => {
    // eslint-disable-next-line
    setPublishArtifact(event.target.value == "true");
  };

  const handleNewEnviromentCreated = () => {
    callGetVariablesForRepository();
    setTabId(1);
  };

  const callGetVariablesForRepository = () => {
    showProgressBar(
      "Please be patient! while information related to existing repository are being fetched"
    );
    let config = {
      headers: {
        authorization: "Bearer " + localStorage.getItem("accessToken"),
      },
      params: {
        organizationName: localStorage.getItem("githubOrganizationName"),
        RepoName: state.repository.name,
        RepoId: state.repository.id,
      },
    };
    axios
      .get(constants.BASE_URL + constants.GET_GITHUB_VARIABLES, config)
      .then((response) => {
        hideProgressBar();
        console.log(
          "callGetVariablesForRepository=======>",
          response.data.body.result
        );
        SetRepoVariables(response.data.body.result);
        callGetAvailableEnvironment();
      })
      .catch((error) => {
        hideProgressBar();
        console.log("Error-callGetVariablesForRepository========>", error);
        handleErrorAlert(true);
        setErrorAlertCallback({
          message:
            "Something went wrong while fetching variables. Please try again!",
        });
        // SetRepoVariables([]);
      });
  };


  const callGetAvailableEnvironment = (token) => {
    showProgressBar(
      "Please be patient! while information related to existing projet are being fetched"
    );
    let config = {
      headers: {
        authorization: "Bearer " + localStorage.getItem("accessToken"),
      },
      params: {
        organizationName: localStorage.getItem("githubOrganizationName"),
        RepoName: repositoryName
      },
    };
    axios
      .get(constants.BASE_URL + constants.GET_AVAILABLE_ENVIRONMENTS, config)
      .then((response) => {
        hideProgressBar();
        console.log(
          "Response-callGetAvailableEnvironment==============>",
          response.data.body.EnvironmentList
        );
        setAvailableDeploymentEnvironment(response.data.body.EnvironmentList);
        // const rules = response.data.body.projectCreationRules;
        // setNoOfReviewers(
        //   rules.branchingModel.branches.find(
        //     // eslint-disable-next-line
        //     (branch) => branch.type == "default"
        //   ).noOfReviewers
        // );
      })
      .catch((error) => {
        // handleErrorAlert(true);
        hideProgressBar();
      });
  };

  const handleCreateCIPipelineDialogClose = () => {
    setOpen(false);
    setEnviromentName("");
  };

  const handleClose = (event, reason) => {
    // eslint-disable-next-line
    if (reason && reason == "backdropClick") return;
    handleCreateCIPipelineDialogClose();
  };

  const callAddOrganizationUserAPI = () => {
    const env = [...availableDeploymentEnvironments];
    env.push({
      name: enviromentName,
    });
    setAvailableDeploymentEnvironment(env);
    handleCreateCIPipelineDialogClose();
  }
  const handleClickOpen = () => {
    setOpen(true);
  };

  const handleLockChange = () => {
    setIsVariableLock((prev) => !prev)
    console.log("lock", isVariableLock)
  }

  return (
    <Box>
      <Dialog open={open} onClose={handleClose}>
        <ProgressBar
          isVisible={isVisible}
          progressBarMessage={progressBarMessage}
        />
        <DialogTitle className="createCIPipeline-dialogTitle">
          Add Enviroment
        </DialogTitle>
        <Divider className="createCIPipeline-divider" />
        <DialogContent>
          <Stack direction={"column"} spacing={1} width={"350px"}>
            <TextField
              variant="outlined"
              fullWidth
              label="Enviroment Name"
              required
              value={enviromentName}
              onChange={(event) => setEnviromentName(event.target.value)}
            />
          </Stack>
        </DialogContent>
        <DialogActions>
          <Button
            className="createCIPipeline-button-cancel"
            onClick={handleClose}
          >
            Cancel
          </Button>
          <Button
            className="createCIPipeline-button-create"
            disabled={!enviromentName.trim().length}
            onClick={callAddOrganizationUserAPI}
          >
            Add Enviroment
          </Button>
        </DialogActions>
      </Dialog>
      <ProgressBar
        isVisible={isVisible}
        progressBarMessage={progressBarMessage}
      />
      <ErrorAlert
        isErrorVisible={isErrorVisible}
        callback={() => {
          setIsErrorVisible(false);
          if (
            errorAlertCallback.hasOwnProperty("navigate") &&
            errorAlertCallback.hasOwnProperty("navigateData")
          ) {
            navigate(
              errorAlertCallback.navigate,
              errorAlertCallback.navigateData
            );
          } else if (errorAlertCallback.hasOwnProperty("navigate")) {
            navigate(errorAlertCallback.navigate);
          }
        }}
        message={errorAlertCallback.message}
      />
      <Box className="createProject-box1">
        <CustomBreadCrumb
          routeList={state.routeList}
          location={location.pathname}
        />
      </Box>
      <Box>
        <Typography className="createProject-typography1" variant="h6" mb={1}>
          Create Repository for {state.organizationName}
        </Typography>
        <Divider />
        <Stack direction={"row"} spacing={2} mt={3}>
          <Stack direction={"column"} spacing={1} width={"50%"}>
            <Box>
              <TextField
                variant="outlined"
                fullWidth
                label="Repository Name"
                required
                maxRows={4}
                // error={getProjectNameValidation()}
                // helperText={
                //   !getProjectNameValidation()
                //     ? ""
                //     : "Please enter valid project name"
                // }
                value={repositoryName}
                onChange={(event) => setRepositoryName(event.target.value)}
              />
              <Stack direction="row" spacing={1} alignItems="center">
                <Typography variant="body1" color="grey" fontSize={13}>
                  Final Repository Name:
                </Typography>
                <Typography
                  variant="body1"
                  color="grey"
                  flexWrap={"wrap"}
                  noWrap
                >
                  {organizationRules.namingStandard}
                  {repositoryName}
                </Typography>
              </Stack>
            </Box>

            <TextField
              variant="outlined"
              fullWidth
              label="Description"
              maxRows={4}
              value={repositoryDescription}
              onChange={(event) => setRepositoryDescription(event.target.value)}
            />
            <Stack
              direction={"row"}
              spacing={2}
              alignItems={"flex-end"}
              pt={1.5}
            >
              <Stack direction={"column"} spacing={1} width={"50%"}>
                <Card variant="outlined">
                  <CardContent>
                    <Typography
                      mb={1}
                      mt={-0.5}
                      variant="body1"
                      color={"#005689"}
                    >
                      Repository Visibility
                    </Typography>

                    <RadioGroup
                      defaultValue="private"
                      name="radio-buttons-group"
                      onChange={handleRepositoryVisibilityChange}
                      value={repositoryVisibility}
                    >
                      <Stack direction={"column"} mt={-1} mb={-2}>
                        <FormControlLabel
                          value="public"
                          control={
                            <Radio className="createProject-radioGroup" />
                          }
                          label="Public"
                          disabled
                        />

                        <FormControlLabel
                          value="private"
                          control={
                            <Radio className="createProject-radioGroup" />
                          }
                          label="Private"
                        />
                      </Stack>
                    </RadioGroup>
                  </CardContent>
                </Card>
              </Stack>
            </Stack>
          </Stack>

          <Stack direction={"column"} spacing={2} width={"50%"}>
            <TextField
              variant="outlined"
              fullWidth
              label="Default Repository Name"
              disabled
              value={`${organizationRules.namingStandard}${repositoryName}`}
            />
            <Stack direction={"column"}>
              <Stack direction={"row"} mb={2}>
                <Typography
                  className="createProject-typography2"
                  variant="body1"
                  fontSize={20}
                >
                  Branching Modal
                </Typography>
                <HtmlTooltip title={BranchMessage} placement="right-start">
                  <InfoOutlinedIcon className="createProject-infoOutlined" />
                </HtmlTooltip>
              </Stack>
              <Divider />

              <Stack
                direction={"row"}
                justifyContent={"space-between"}
                mb={2}
                mt={1}
              >
                <Stack direction={"row"} mr={2}>
                  <Typography color={"#007CB9"} fontSize={16}>
                    Model Name:
                  </Typography>
                  <Typography
                    fontWeight={"bold"}
                    color={"#005689"}
                    fontSize={16}
                  >
                    {organizationRules.branchingModel.name}
                  </Typography>
                </Stack>
                <Stack direction={"row"}>
                  <Typography color={"#007CB9"} fontSize={16}>
                    Number Of Branches:
                  </Typography>
                  <Typography
                    fontWeight={"bold"}
                    color={"#005689"}
                    fontSize={16}
                  >
                    {organizationRules.branchingModel.numberOfBranches}
                  </Typography>
                </Stack>
              </Stack>

              {organizationRules.branchingModel.branches.length > 0 ? (
                organizationRules.branchingModel.branches.map(
                  (branch, index) => (
                    <Accordion key={index}>
                      <AccordionSummary
                        expandIcon={<ExpandMoreOutlined />}
                        aria-controls="panel1a-content"
                        id="panel1a-header"
                      >
                        <Typography className="createProject-typography3">
                          Branch {index + 1}
                        </Typography>
                        <Chip label={branch.type} />
                      </AccordionSummary>
                      <AccordionDetails>
                        <Grid container justifyContent={"space-between"}>
                          <Grid item>
                            <Stack direction={"row"} spacing={1}>
                              <Typography color={"#007CB9"} fontSize={16}>
                                Branch Name:
                              </Typography>
                              <Typography
                                fontWeight={"bold"}
                                color={"#005689"}
                                fontSize={16}
                              >
                                {branch.name}
                              </Typography>
                            </Stack>
                          </Grid>
                          <Grid item>
                            <Stack direction={"row"} spacing={1}>
                              <Typography color={"#007CB9"} fontSize={16}>
                                Reviewers:
                              </Typography>
                              <Typography
                                fontWeight={"bold"}
                                color={"#005689"}
                                fontSize={16}
                              >
                                {branch.noOfReviewers}
                              </Typography>
                            </Stack>
                          </Grid>
                          <Grid item>
                            <Stack direction={"row"} spacing={1}>
                              <Typography color={"#007CB9"} fontSize={16}>
                                Merge Type:
                              </Typography>
                              <Typography
                                fontWeight={"bold"}
                                color={"#005689"}
                                fontSize={16}
                              >
                                {branch.mergeType}
                              </Typography>
                            </Stack>
                          </Grid>
                        </Grid>
                      </AccordionDetails>
                    </Accordion>
                  )
                )
              ) : (
                <></>
              )}
            </Stack>
          </Stack>
        </Stack>
        <Divider className="createProject-divider1" />
        <Stack direction={"row"} spacing={2}>
          <Box className="createProject-box2">
            <Accordion>
              <AccordionSummary
                expandIcon={<ExpandMoreOutlined />}
                aria-controls="panel1a-content"
                id="panel1a-header"
              >
                <Typography color={"#005689"} fontWeight={"bold"}>
                  Add Variables
                </Typography>
              </AccordionSummary>
              <AccordionDetails>
                <Box className="createProject-box3">
                  <Stack
                    direction={"row"}
                    justifyContent={"space-between"}
                    mt={1}
                    alignItems={"center"}
                  >
                    <Typography color={"#005689"}>Variables</Typography>
                    <Stack direction={"row"} alignItems={"center"}>
                      <Switch
                        onChange={(event) => {
                          setIsJsonSelected(event.target.checked);
                        }}
                      />
                      <Typography color={"#005689"}>Upload JSON</Typography>
                    </Stack>
                  </Stack>

                  <Stack spacing={2} direction={"row"} ml={1} mt={1}>
                    <Typography width={"100%"} variant="body2" color={"#007CB9"}>
                      {"Name"}
                    </Typography>
                    <Typography width={"100%"} variant="body2" color={"#007CB9"}>
                      {"Value"}
                    </Typography>
                    <IconButton disabled>
                      <Delete className="addVariableDialog-delete" />
                    </IconButton>
                  </Stack>
                  <Divider className="addVariableDialog-divider" />
                  {Object.keys(addedVariable).map((name, index) => (
                    <Stack
                      spacing={2}
                      direction={"row"}
                      ml={1}
                      flex={1}
                      alignItems={"center"}
                      key={index}
                    >
                      <Typography width={"50%"} flexWrap={"wrap"} noWrap>
                        {name}
                      </Typography>
                      <Typography width={"50%"} flexWrap={"wrap"} noWrap>
                        {addedVariable[name].isSecret
                          ? "****"
                          : addedVariable[name].value}
                      </Typography>
                      <IconButton
                        onClick={() => {
                          const variable = { ...addedVariable };
                          delete variable[name];
                          setAddedVariable(variable);
                        }}
                      >
                        <Delete />
                      </IconButton>
                    </Stack>
                  ))}
                  {!isJsonSelected ? (
                    <Box className="addVariableDialog-box2">
                      <Stack spacing={1} direction={"row"} mt={1} mb={1} ml={1}>
                        <TextField
                          variant="standard"
                          fullWidth
                          size="small"
                          label="Variable Name"
                          name="variableKey"
                          value={variableKey}
                          error={Object.keys(addedVariable).includes(
                            variableKey
                          )}
                          helperText={
                            Object.keys(addedVariable).includes(variableKey)
                              ? `${variableKey} already exists in variable group`
                              : ""
                          }
                          onChange={(event) =>
                            setVariableKey(event.target.value)
                          }
                        />

                        <TextField
                          variant="standard"
                          fullWidth
                          size="small"
                          type={"text"}
                          label="Variable Value"
                          name="variableValue"
                          value={variableValue}
                          onChange={(event) =>
                            setVariableValue(event.target.value)
                          }
                        />
                        <HtmlTooltip title={SecretVariable} placement="right-start">
                          <IconButton
                            onClick={handleLockChange}
                          >
                            {isVariableLock ? <LockOutlined /> : <LockOpenOutlined />}
                          </IconButton>
                        </HtmlTooltip>
                        <IconButton
                          disabled={
                            !(
                              variableKey.trim().length &&
                              variableValue.trim().length &&
                              !Object.keys(addedVariable).includes(variableKey)
                            )
                          }
                          onClick={() => {
                            const variable = { ...addedVariable };
                            variable[variableKey] = {
                              value: variableValue,
                              isSecret: isVariableLock
                            };
                            setAddedVariable(variable);
                            setVariableKey("");
                            setVariableValue("");
                            setIsVariableLock(false);
                          }}
                        >
                          <AddCircleOutlineSharpIcon className="createProject-addCircleOutlined" />
                        </IconButton>
                      </Stack>
                    </Box>
                  ) : (
                    <Box className="addVariableDialog-box2">
                      <ColorButton
                        className="addVariableDialog-colourButton"
                        backgroundcolor="#005689"
                        variant="contained"
                        fontSize="14px"
                        component="label"
                        onChange={handleChangejsonFile}
                      >
                        Upload JSON
                        <input hidden multiple type="file" value={""} />
                      </ColorButton>
                      <Typography
                        className={
                          jsonButtonError.includes("Invalid") ||
                            jsonButtonError.includes("delete")
                            ? "addVariableDialog-typography-red"
                            : "addVariableDialog-typography-blue"
                        }
                        variant="subtitle2"
                      >
                        {jsonButtonError}
                      </Typography>
                    </Box>
                  )}
                </Box>
              </AccordionDetails>
            </Accordion>
          </Box>
          <Box className="createProject-box2">
            <Accordion>
              <AccordionSummary
                expandIcon={<ExpandMoreOutlined />}
                aria-controls="panel1a-content"
                id="panel1a-header"
              >
                <Typography color={"#005689"} fontWeight={"bold"}>
                  Add Pipeline
                </Typography>
              </AccordionSummary>
              <AccordionDetails>
                <Box variant="outlined">
                  <Grid container spacing={2}>
                    <Grid item xs={6}>
                      <TextField
                        variant="outlined"
                        fullWidth
                        label="Repository Name"
                        required
                        value={`${organizationRules.namingStandard}${repositoryName}`}
                        disabled
                      />
                    </Grid>
                    <Grid item xs={6}>
                      <TextField
                        variant="outlined"
                        fullWidth
                        label="Pipeline Name"
                        required
                        onChange={(event) => setPipelineName(event.target.value)}
                      />
                    </Grid>
                    <Grid item xs={6}>
                      <FormControl fullWidth>
                        <InputLabel id="demo-simple-select-label" required>
                          Technology Type
                        </InputLabel>
                        <Select
                          labelId="demo-simple-select-label"
                          id="demo-simple-select"
                          value={applicationType}
                          label="Technology Type"
                          onChange={handleTechnologyTypeChange}
                        >
                          {applicationTypeList.map((type) => (
                            <MenuItem value={type.value} key={type.id}>
                              {type.name}
                            </MenuItem>
                          ))}
                        </Select>
                      </FormControl>
                    </Grid>
                    <Grid item xs={6}>
                      <FormControl >
                        <FormLabel id="demo-row-radio-buttons-group-label">
                          Publish Artifacts
                        </FormLabel>
                        <RadioGroup
                          className="createCIPipeline-radioGroup"
                          row
                          aria-labelledby="demo-row-radio-buttons-group-label"
                          name="row-radio-buttons-group"
                          onChange={handlePublishArtifactChange}
                          value={isPublishArtifact}
                        >
                          <Stack spacing={8} direction={"row"}>
                            <FormControlLabel
                              className="createCIPipeline-formControlLevel"
                              value={true}
                              control={<Radio />}
                              label="Yes"
                            />
                            <FormControlLabel
                              className="createCIPipeline-formControlLevel"
                              value={false}
                              control={<Radio />}
                              label="No"
                            />
                          </Stack>
                        </RadioGroup>
                      </FormControl>
                    </Grid>
                  </Grid>
                  <Box className="createCIPipeline-box1" variant="outlined">
                    {pipelineName.trim().length &&
                      applicationType.trim().length ? (
                      <Box>
                        <Stack direction={"row"} spacing={2}>
                          <Box>
                            {addUserList.length > 0 ? (
                              <Paper
                                className="createCIPipeline-paper"
                                variant="outlined"
                              >
                                <ListSubheader>Available Reviewers</ListSubheader>
                                <Divider />
                                <List className="createCIPipeline-list">
                                  {addUserList.map((user, index) => (
                                    <Box key={index}>
                                      <ButtonBase
                                        focusRipple
                                        onClick={() => {
                                          console.log(user.login);
                                          if (
                                            selectedReviewerList.filter((e) => {
                                              return e === user.login;
                                            }).length > 0 || // eslint-disable-next-line
                                            selectedReviewerList.length == noOfReviewers
                                          ) {
                                            return;
                                          }
                                          setSelectedReviewerList([
                                            ...selectedReviewerList,
                                            user.login,
                                          ]);
                                        }}
                                      >
                                        <Stack
                                          direction="row"
                                          spacing={1}
                                          alignItems="center"
                                          m={1}
                                        >
                                          <Avatar {...stringAvatar(user.login)} />
                                          <Typography>{user.login}</Typography>
                                        </Stack>
                                      </ButtonBase>
                                      {
                                        // eslint-disable-next-line
                                        index != addUserList.length - 1 ? (
                                          <Divider />
                                        ) : (
                                          <></>
                                        )
                                      }
                                    </Box>
                                  ))}
                                </List>
                              </Paper>
                            ) : (
                              <></>
                            )}
                          </Box>
                          <Box>
                            {selectedReviewerList.length > 0 ? (
                              <Box>
                                <Typography
                                  className="createCIPipeline-typography1"
                                  variant="h6"
                                  fontSize={14}
                                >
                                  Selected Reviewers
                                </Typography>
                                <Divider />
                                <Box className="createCIPipeline-box2">
                                  {selectedReviewerList.map((user, index) => (
                                    <Chip
                                      className="createCIPipeline-chip"
                                      key={index}
                                      label={user}
                                      onDelete={() => {
                                        setSelectedReviewerList(
                                          selectedReviewerList.filter((e) => e !== user)
                                        );
                                      }}
                                    />
                                  ))}
                                </Box>
                              </Box>
                            ) : (
                              <></>
                            )}
                          </Box>
                        </Stack>
                        <Typography
                          variant="body1"
                          color="#007CB9"
                          fontSize={13}
                          fontWeight={"bold"}
                          mt={1}
                        >
                          Your organization policy require to review every commit.
                          Please add {noOfReviewers} reviewers for initial pipeline
                          commit to default branch. Also, you need to add user in the
                          project to make them reviewer if already not present.
                        </Typography>
                        <Typography
                          variant="body1"
                          color="#007CB9"
                          fontSize={13}
                          fontWeight={"bold"}
                          mt={1}
                        >
                          Also, you need to add user in the project to make them
                          reviewer if already not present.
                        </Typography>
                      </Box>
                    ) : (
                      <></>
                    )}
                  </Box>
                  {pipelineName.trim().length > 0 && applicationType.trim().length > 0 ? (<Box>
                    <Divider />
                    <Stack direction={"row"} alignItems={"center"}>
                      <Typography
                        color={"#007CB9"}
                        fontWeight={"bold"}
                        fontSize={"14px"}
                        mt={0.5}
                        mr={2}
                      >
                        Deploy
                      </Typography>
                      <Stack direction={"row"} alignItems={"center"} mt={0.5}>
                        <Typography
                          color={"#007CB9"}
                          // fontWeight={"bold"}
                          fontSize={"14px"}
                        >
                          No
                        </Typography>
                        <Switch
                          sx={{
                            "& .MuiSwitch-switchBase.Mui-checked": {
                              color: "#005689",
                            },
                            "& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track": {
                              backgroundColor: "#005689",
                            },
                          }}
                          checked={isDeploy}
                          onChange={(event) => {
                            setIsDeploy(event.target.checked);
                            console.log("switch", isDeploy)
                            if (event.target.checked) {
                              console.log("switch")
                              const env = [...availableDeploymentEnvironments];
                              env.push({
                                name: `${organizationRules.namingStandard}${repositoryName}`,
                              });
                              setAvailableDeploymentEnvironment(env);
                              console.log("switch", env)
                            }
                          }}
                        />
                        <Typography
                          color={"#007CB9"}
                          // fontWeight={"bold"}
                          fontSize={"14px"}
                        >
                          Yes
                        </Typography>
                      </Stack>
                    </Stack>
                    {isDeploy ? (<Box>
                      <Stack direction={"row"} spacing={2}>
                        <Box>
                          <Paper
                            className="createCIPipeline-paper"
                            variant="outlined"
                          >
                            {availableDeploymentEnvironments.length > 0 ? (
                              <Box>
                                <ListSubheader>Available Environments</ListSubheader>
                                <Divider />
                                <List
                                  className="createCIPipeline-list">
                                  {availableDeploymentEnvironments.map((user, index) => (
                                    <Box key={index}>
                                      <ButtonBase
                                        focusRipple
                                        onClick={() => {
                                          if (deploymentEnvironments.filter(x => x.environment === user.name).length === 0) {
                                            if (
                                              selectedEnvironmentList.filter((e) => {
                                                return (
                                                  e ===
                                                  user.name
                                                );
                                              }).length > 0 ||  // eslint-disable-next-line
                                              selectedEnvironmentList.length == 1
                                            ) {
                                              return;
                                            }
                                            setSelectedEnvironmentList([
                                              ...selectedEnvironmentList,
                                              user.name,
                                            ]);
                                            setEnvironment(user.name)
                                          }
                                        }
                                        }
                                      >
                                        <Stack
                                          direction="row"
                                          spacing={1}
                                          alignItems="center"
                                          m={1}
                                        >
                                          <Typography>
                                            {user.name}
                                          </Typography>
                                        </Stack>
                                      </ButtonBase>
                                    </Box>
                                  ))}

                                </List>
                              </Box>

                            ) : (
                              <><Typography
                                color={"#007CB9"}
                                fontSize={"14px"}
                              >
                                No Environment Available
                              </Typography></>
                            )}
                            <ColorButton
                              backgroundcolor="#005689"
                              variant="contained"
                              size="small"
                              onClick={handleClickOpen}
                              startIcon={<Add />}
                            >
                              New Enviroment
                            </ColorButton>
                          </Paper>
                          <Box>
                            {platformToDeployList.length > 0 ? (
                              <Paper
                                sx={{ width: "210px" }}
                                className="createCIPipeline-paper"
                                variant="outlined"
                              >
                                <ListSubheader>Available Deployments</ListSubheader>
                                <Divider />
                                <List
                                  className="createCIPipeline-list">
                                  {platformToDeployList.map((user, index) => (
                                    <Box key={index}>
                                      <ButtonBase
                                        focusRipple
                                        onClick={() => {
                                          setPlatformToDeploy(user)
                                          console.log("list", user)

                                          const v = [...deploymentEnvironments];
                                          console.log("list", platformToDeploy)
                                          if (environment.trim().length > 0 && (!v.includes(environment))) {
                                            v.push({
                                              environment: environment,
                                              platformToDeploy: user,
                                            });
                                            setDeploymentEnvironments(v);
                                            setSelectedEnvironmentList([]);
                                            setEnvironment("");
                                            console.log("list", v)
                                            console.log("list", v.includes(Object.hasOwnProperty("PROD")))
                                          }
                                        }}
                                      >
                                        <Stack
                                          direction="row"
                                          spacing={1}
                                          alignItems="center"
                                          m={1}
                                        >
                                          <Typography>
                                            {user}
                                          </Typography>
                                        </Stack>
                                      </ButtonBase>
                                    </Box>
                                  ))}
                                </List>
                              </Paper>
                            ) : (
                              <></>
                            )}
                          </Box>
                        </Box>
                        <Box>
                          {selectedEnvironmentList.length ? (<Box>
                            {selectedEnvironmentList.map((user, index) => (
                              <Box>
                                <Typography
                                  className="createCIPipeline-typography1"
                                  variant="h6"
                                  fontSize={14}
                                >
                                  Selected Environment
                                </Typography>
                                <Chip
                                  className="createCIPipeline-chip"
                                  key={index}
                                  label={user}
                                  onDelete={() => {
                                    setSelectedEnvironmentList(
                                      selectedEnvironmentList.filter(
                                        (e) =>
                                          e !==
                                          user
                                      )
                                    );
                                  }}
                                />
                                <Typography
                                  color={"#007CB9"}
                                  fontSize={"14px"}
                                >
                                  Please select the Deployment from list for the {user}!!!
                                </Typography>
                              </Box>

                            ))}
                          </Box>) :
                            (<>
                              <Typography
                                color={"#007CB9"}
                                fontSize={"14px"}
                                mb={1}
                              >
                                Please Select Environment and then Deployment from the list!!!
                              </Typography></>)}
                          <Divider></Divider>
                          {deploymentEnvironments.length > 0 ? (
                            (deploymentEnvironments.map((list) => (
                              // <Box> <Divider/><Box/>
                              <Box sx={{ flexGrow: 1, maxWidth: 752 }}>
                                <Grid container spacing={2}>
                                  <Grid item xs={12} md={6}>
                                    <Typography fontSize={"14px"} color={"#007CB9"} mt={1} component="div">
                                      {list.environment}
                                    </Typography>
                                    <List dense={dense}>
                                      <ListItem
                                        secondaryAction={
                                          <IconButton edge="end" aria-label="delete"
                                            onClick={() => {
                                              setDeploymentEnvironments(
                                                deploymentEnvironments.filter(
                                                  (e) =>
                                                    e.environment !==
                                                    list.environment
                                                )
                                              );
                                              console.log("List environment", list.environment);
                                            }}>
                                            <DeleteIcon />
                                          </IconButton>
                                        }
                                      >
                                        <ListItemText><Typography sx={{
                                          margin: "-14px"
                                        }}>{list.platformToDeploy}</Typography></ListItemText>
                                      </ListItem>
                                    </List>
                                  </Grid>
                                </Grid>
                                <Divider ></Divider>
                              </Box>
                            )))
                          ) : (
                            <></>
                          )}
                        </Box>
                      </Stack>
                      <Stack direction={"row"} spacing={4}>
                        <Box>

                        </Box>
                        <Box>
                          {selectedDeploymentList.length > 0 ? (
                            <Box>
                              <Typography
                                className="createCIPipeline-typography1"
                                variant="h6"
                                fontSize={14}
                              >
                                Selected Deployments
                              </Typography>
                              <Divider />
                              <Box className="createCIPipeline-box2">
                                {selectedDeploymentList.map((user, index) => (
                                  <Chip
                                    className="createCIPipeline-chip"
                                    key={index}
                                    label={user}
                                    onDelete={() => {
                                      setSelectedDeploymentList(
                                        selectedDeploymentList.filter(
                                          (e) =>
                                            e !==
                                            user
                                        )
                                      );
                                    }}
                                  />
                                ))}
                              </Box>
                            </Box>
                          ) : (
                            <></>
                          )}
                        </Box>
                      </Stack>
                    </Box>) : (
                      <></>
                    )}
                    <Divider />
                  </Box>) : (<></>)}



                </Box>
              </AccordionDetails>
            </Accordion>
          </Box>
        </Stack>
      </Box>
      <Stack direction="row" justifyContent="flex-end" padding={2}>
        <ColorButton
          backgroundcolor="#005689"
          variant="contained"
          onClick={() => navigate(-1)}
        >
          BACK
        </ColorButton>
        <ColorButton
          className="createProject-button-create"
          backgroundcolor="#005689"
          variant="contained"
          onClick={callCreateRepository}
          disabled={!repositoryName.length}
        >
          CREATE REPOSITORY
        </ColorButton>
      </Stack>
    </Box>
  );
}
