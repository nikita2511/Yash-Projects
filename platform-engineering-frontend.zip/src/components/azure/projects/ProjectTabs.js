import "./projects.css";
import * as React from "react";
import PropTypes from "prop-types";
import Tabs from "@mui/material/Tabs";
import Tab from "@mui/material/Tab";
import Typography from "@mui/material/Typography";
import Box from "@mui/material/Box";
import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Avatar,
  Button,
  Card,
  Grid,
  IconButton,
  Stack,
} from "@mui/material";
import { Delete, ExpandMoreOutlined } from "@mui/icons-material";
import { stringAvatar } from "../../../utils/helper";
/**
 *
 * @returns React Functional Component (TabPanel) which renders tabs dynamically based on conditional rendering
 */
function TabPanel(props) {
  const { children, value, index, ...other } = props;

  return (
    <div
      role="tabpanel"
      hidden={value !== index}
      id={`simple-tabpanel-${index}`}
      aria-labelledby={`simple-tab-${index}`}
      {...other}
    >
      {value === index && <Box p={3} mb={3}>{children}</Box>}
    </div>
  );
}

TabPanel.propTypes = {
  children: PropTypes.node,
  index: PropTypes.number.isRequired,
  value: PropTypes.number.isRequired,
};

function a11yProps(index) {
  return {
    id: `simple-tab-${index}`,
    "aria-controls": `simple-tabpanel-${index}`,
  };
}
/**
 *
 * @returns React Functional Component (ProjectTabs) which renders available information of existing project
 */
export default function ProjectTabs({
  project,
  projectRepositories,
  projectVariableGroups,
  existingProjectUsers,
  onDeleteExistingUser,
  onEditVariableGroup,
  projectPipelines,
  releasePipeline,
  tabId,
  onProjectTabChange,
}) {
  const handleChange = (event, newValue) => {
    onProjectTabChange(newValue);
  };

  return (
    <Box>
      <Box borderBottom={1} borderColor={"divider"}>
        <Tabs
          value={tabId}
          onChange={handleChange}
          variant="scrollable"
          allowScrollButtonsMobile
          aria-label="basic tabs example"
        >
          <Tab label="Source Code Repositories" {...a11yProps(0)} />
          <Tab label="CI Pipelines" {...a11yProps(1)} />
          <Tab label="Release Pipelines" {...a11yProps(2)} />
          <Tab label="Variable Groups" {...a11yProps(3)} />
          <Tab label="Users" {...a11yProps(4)} />
        </Tabs>
      </Box>
      <TabPanel value={tabId} index={0}>
        {projectRepositories.length > 0 ? (
          <Grid container spacing={2}>
            {projectRepositories.map((repo, index) => (
              <Grid item xs={6} sm={3} md={3} key={index}>
                <Card raised={true}>
                  <Stack
                    direction="row"
                    spacing={1}
                    p={1}
                    alignItems={"center"}
                  >
                    <Avatar {...stringAvatar(repo.name)} variant="rounded" />
                    <Stack direction="column">
                      <Typography
                        variant="subtitle2"
                        color={"#005689"}
                        fontWeight={"bold"}
                      >
                        {repo.name}
                      </Typography>
                      <Stack direction="row" spacing={1}>
                        <Typography variant="subtitle2" color={"#005689"}>
                          Default Branch:
                        </Typography>
                        <Typography
                          variant="body2"
                          color={"#005689"}
                          fontWeight={"bold"}
                        >
                          {repo.defaultBranch}
                        </Typography>
                      </Stack>
                    </Stack>
                  </Stack>
                </Card>
              </Grid>
            ))}
          </Grid>
        ) : (
          <Typography
            variant="h6"
            gutterBottom
            color={"#005689"}
            textAlign={"center"}
          >
            {`Repositories are not created for the ${project.name} project yet`}
          </Typography>
        )}
      </TabPanel>
      <TabPanel value={tabId} index={1}>
        {projectPipelines.length > 0 ? (
          <Grid container spacing={2}>
            {projectPipelines.map((pipeline, index) => (
              <Grid item xs={6} sm={3} md={3} key={index}>
                <Card raised={true}>
                  <Stack
                    direction="row"
                    spacing={2}
                    p={1}
                    alignItems={"center"}
                  >
                    <Avatar
                      {...stringAvatar(pipeline.name)}
                      variant="rounded"
                    />
                    <Typography
                      variant="subtitle1"
                      color={"#005689"}
                      fontWeight={"bold"}
                    >
                      {pipeline.name}
                    </Typography>
                  </Stack>
                </Card>
              </Grid>
            ))}
          </Grid>
        ) : (
          <Typography
            variant="h6"
            gutterBottom
            color={"#005689"}
            textAlign={"center"}
          >
            {`Pipelines are not created for the ${project.name} project yet`}
          </Typography>
        )}
      </TabPanel>
      <TabPanel value={tabId} index={2}>
        {releasePipeline.length > 0 ? (
          <Grid container spacing={2}>
            {releasePipeline.map((value, index) => (
              <Grid item xs={12} md={6} key={index}>
                <Accordion>
                  <AccordionSummary
                    expandIcon={<ExpandMoreOutlined />}
                    aria-controls="panel1a-content"
                    id="panel1a-header"
                  >
                    <Stack
                      direction="row"
                      spacing={5}
                      p={1}
                      alignItems={"center"}
                    >
                      <Stack
                        direction="row"
                        spacing={1}
                        alignItems={"center"}
                      >
                        <Avatar
                          {...stringAvatar(value.name)}
                          variant="rounded"
                        />
                        <Typography
                          variant="subtitle1"
                          color={"#005689"}
                          fontWeight={"bold"}
                        >
                          {value.name}
                        </Typography>
                      </Stack>
                      <Typography variant="subtitle1" color={"#005689"}>
                        Created By: {value.createdBy.displayName}
                      </Typography>
                    </Stack>
                  </AccordionSummary>

                  <AccordionDetails>
                    <Stack spacing={2} direction={"row"} ml={1} mt={1}>
                      <Typography
                        width={"100%"}
                        variant="body2"
                        color={"#005689"}
                      >
                        {"Created On"}
                      </Typography>
                      <Typography
                        width={"100%"}
                        variant="body2"
                        color={"#005689"}
                      >
                        {"Modified By"}
                      </Typography>
                      <Typography
                        width={"100%"}
                        variant="body2"
                        color={"#005689"}
                      >
                        {"Modified On"}
                      </Typography>
                    </Stack>
                    <Stack
                      spacing={2}
                      direction={"row"}
                      ml={1}
                      flex={1}
                      alignItems={"center"}
                    >
                      <Typography width={"50%"} flexWrap={"wrap"} noWrap>
                        {new Date(value.createdOn).toDateString()}
                        <br />
                        {new Date(value.createdOn).toLocaleTimeString()}
                      </Typography>
                      <Typography width={"50%"} flexWrap={"wrap"} noWrap>
                        {value.modifiedBy.displayName}
                      </Typography>
                      <Typography width={"50%"} flexWrap={"wrap"} noWrap>
                        {new Date(value.modifiedOn).toDateString()}
                        <br />
                        {new Date(value.modifiedOn).toLocaleTimeString()}
                      </Typography>
                    </Stack>
                  </AccordionDetails>
                </Accordion>
              </Grid>
            ))}
          </Grid>
        ) : (
          <Typography
            variant="h6"
            gutterBottom
            color={"#005689"}
            textAlign={"center"}
          >
            {`Release Pipelines are not created for the ${project.name} project yet`}
          </Typography>
        )}
      </TabPanel>
      <TabPanel value={tabId} index={3}>
        {projectVariableGroups.length > 0 ? (
          <Grid container spacing={2}>
            {projectVariableGroups.map((variable, index) => (
              <Grid item xs={12} md={6} key={index}>
                <Accordion>
                  <AccordionSummary
                    expandIcon={<ExpandMoreOutlined />}
                    aria-controls="panel1a-content"
                    id="panel1a-header"
                  >
                    <Typography
                      variant="subtitle1"
                      color={"#005689"}
                      fontWeight={"bold"}
                      width={"33%"}
                      mr={2}
                    >
                      {variable.name}
                    </Typography>
                    <Typography variant="subtitle1" color={"#005689"} mr={2}>
                      Created By: {variable.createdBy.displayName}
                    </Typography>
                  </AccordionSummary>

                  <AccordionDetails>
                    <Stack spacing={2} direction={"row"} ml={1} mt={1}>
                      <Typography
                        width={"100%"}
                        variant="body2"
                        color={"#005689"}
                      >
                        {"Created On"}
                      </Typography>
                      <Typography
                        width={"100%"}
                        variant="body2"
                        color={"#005689"}
                      >
                        {"Modified By"}
                      </Typography>
                      <Typography
                        width={"100%"}
                        variant="body2"
                        color={"#005689"}
                      >
                        {"Modified On"}
                      </Typography>
                    </Stack>
                    <Stack
                      spacing={2}
                      direction={"row"}
                      ml={1}
                      flex={1}
                      alignItems={"center"}
                    >
                      <Typography width={"50%"} flexWrap={"wrap"} noWrap>
                        {new Date(variable.createdOn).toDateString()}
                        <br />
                        {new Date(variable.createdOn).toLocaleTimeString()}
                      </Typography>
                      <Typography width={"50%"} flexWrap={"wrap"} noWrap>
                        {variable.modifiedBy.displayName}
                      </Typography>
                      <Typography width={"50%"} flexWrap={"wrap"} noWrap>
                        {new Date(variable.modifiedOn).toDateString()}
                        <br />
                        {new Date(variable.modifiedOn).toLocaleTimeString()}
                      </Typography>
                    </Stack>
                    <Typography color={"#005689"} mt={1}>
                      Variables
                    </Typography>
                    <Stack spacing={2} direction={"row"} ml={1} mt={1}>
                      <Typography
                        width={"100%"}
                        variant="body2"
                        color={"#005689"}
                      >
                        {"Name"}
                      </Typography>
                      <Typography
                        width={"100%"}
                        variant="body2"
                        color={"#005689"}
                      >
                        {"Value"}
                      </Typography>
                    </Stack>
                    {Object.keys(variable.variables).map((key, index) => (
                      <Stack
                        spacing={2}
                        direction={"row"}
                        ml={1}
                        flex={1}
                        alignItems={"center"}
                        key={index}
                      >
                        <Typography width={"50%"} flexWrap={"wrap"} noWrap>
                          {key}
                        </Typography>
                        <Typography width={"50%"} flexWrap={"wrap"} noWrap>
                          {variable.variables[key].isSecret
                            ? "****"
                            : variable.variables[key].value}
                        </Typography>
                      </Stack>
                    ))}
                    <Box
                      width={"100%"}
                      justifyContent={"flex-end"}
                      display={"flex"}
                    >
                      <Button
                        variant="outlined"
                        onClick={() => {
                          onEditVariableGroup(variable);
                        }}
                      >
                        Edit Variable Group
                      </Button>
                    </Box>
                  </AccordionDetails>
                </Accordion>
              </Grid>
            ))}
          </Grid>
        ) : (
          <Typography
            variant="h6"
            gutterBottom
            color={"#005689"}
            textAlign={"center"}
          >
            {`Variable Groups are not created for the ${project.name} project yet`}
          </Typography>
        )}
      </TabPanel>
      <TabPanel value={tabId} index={4}>
        {existingProjectUsers.length > 0 ? (
          <Grid
            container
            spacing={{ xs: 2, md: 3 }}
            columns={{ xs: 4, sm: 8, md: 12 }}
          >
            {existingProjectUsers.map((user, index) => (
              <Grid item xs={6} sm={3} md={3} key={index}>
                <Card className="projectTabs-card-user">
                  <Stack direction="row" spacing={1} alignItems="center" m={1}>
                    <Avatar {...stringAvatar(user.user.displayName)} />
                    <Box>
                      <Typography color={"#005689"} fontWeight={"bold"}>
                        {user.user.displayName}
                      </Typography>
                      <Typography
                        variant="body1"
                        fontSize={"14px"}
                        color={"#005689"}
                      >
                        {user.user.mailAddress}
                      </Typography>
                    </Box>
                  </Stack>
                  <IconButton
                    onClick={() => {
                      onDeleteExistingUser(user);
                    }}
                  >
                    <Delete
                      fontSize="26px"
                      className="projectTabs-icon-deleteUser"
                    />
                  </IconButton>
                </Card>
              </Grid>
            ))}
          </Grid>
        ) : (
          <Typography
            variant="h6"
            gutterBottom
            color={"#005689"}
            textAlign={"center"}
          >
            {`Users are not added for the ${project.name} project yet`}
          </Typography>
        )}
      </TabPanel>
    </Box>
  );
}
