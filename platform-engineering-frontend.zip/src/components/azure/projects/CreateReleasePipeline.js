import {
  Button,
  ButtonBase,
  Chip,
  DialogActions,
  DialogContent,
  DialogTitle,
  Divider,
  FormControl,
  Grid,
  InputLabel,
  ListSubheader,
  MenuItem,
  OutlinedInput,
  Paper,
  Select,
  TextField,
  Typography,
  debounce,
} from "@mui/material";
import "./projects.css";
import { useTheme } from "@mui/material/styles";
import Dialog from "@mui/material/Dialog";
import { Box, Stack } from "@mui/system";
import React, { useEffect, useState } from "react";
import axios from "axios";
import { constants } from "../../../utils/Constants";
import ProgressBar from "../../../utils/ProgressBar";
import ErrorAlert from "../../error/ErrorAlert";
import { useLocation, useNavigate } from "react-router-dom";
import List from "@mui/material/List";
import { getTokenForAPI } from "../../../utils/RetrieveToken";
import { useMsal } from "@azure/msal-react";
import { useMemo } from "react";
import { useRef } from "react";
import { ColorButton } from "../../../utils/CustomButton";
import CustomBreadCrumb from "../../../utils/CustomBreadCrumb";

function getStyles(name, personName, theme) {
  return {
    fontWeight:
      personName.indexOf(name) === -1
        ? theme.typography.fontWeightRegular
        : theme.typography.fontWeightMedium,
  };
}

const ITEM_HEIGHT = 48;
const ITEM_PADDING_TOP = 8;
const MenuProps = {
  PaperProps: {
    style: {
      maxHeight: ITEM_HEIGHT * 4.5 + ITEM_PADDING_TOP,
      width: 250,
    },
  },
};

/**
 *
 * @returns React Functional Component (AddUsersDialog) which renders a dialog by which multiple users can be added to the project.
 *
 */
export default function CreateReleasePipeline({
  onNewUserAdded,
  project,
  ciPipelines = [],
}) {
  const theme = useTheme();
  const [open, setOpen] = React.useState(false);
  const location = useLocation();
  const { state } = location;
  const { instance, inProgress, accounts } = useMsal();
  const [isVisible, setIsVisible] = React.useState(false);
  const [progressBarMessage, setProgressBarMessage] =
    React.useState("Please wait!");
  const [isErrorVisible, setIsErrorVisible] = React.useState(false);
  const [errorAlertCallback, setErrorAlertCallback] = React.useState({
    navigate: -1,
    navigateData: {
      state: {},
    },
    message: "Something unexpected happend! Please try again",
  });
  // eslint-disable-next-line
  const [msalToken, setMsalToken] = useState("");
  const navigate = useNavigate();
  const [repoDialogIsOpen, setRepoDialogIsOpen] = useState(false);
  const [searchUser, setSearchUser] = React.useState("");
  const [addUserList, setAddUserList] = React.useState([]);
  const [selectedTaskGroup, setSelectedTaskGroup] = React.useState([]);
  const [filteredUserList, setFilteredUserList] = React.useState([]);
  const [stageName, setStageName] = React.useState("");
  const [agentList, setAgentList] = React.useState([]);
  const [agentName, setAgentName] = React.useState("");
  const [availableTasksList, setAvailableTasksList] = React.useState([]);
  const [branchesForStageTrigger, setBranchesForStageTrigger] = React.useState(
    []
  );
  // const [selectedTaskGroup, setselectedTaskGroup] = React.useState([]);
  const [
    availableBranchesForStageTrigger,
    setAvailableBranchesForStageTrigger,
  ] = React.useState([]);
  const [branchesForArtifactTrigger, setBranchesForArtifactTrigger] =
    React.useState([]);
  const [
    availableBranchesForArtifactTrigger,
    setAvailableBranchesForArtifactTrigger,
  ] = React.useState([]);
  const [selectedCIPipeline, setSelectedCIPipeline] = React.useState("");
  const [pipelineName, setPipelineName] = React.useState("");
  const [pipelineDescription, setPipelineDescription] = React.useState("");
  const [jsonButtonError, setJsonButtonError] = React.useState("");
  const [organizationRules, setOrganizationRules] = useState({});
  const [ruleBranches, setRuleBranches] = useState([]);
  const [selectedTaskJson, setSelectedTaskJson] = useState({});
  const [selectedJsonFileName, setSelectedJsonFileName] = useState("");



  /**
   *
   * @param {*} value boolean value to change visiblity of Alert Dialog
   * JS method to update the boolean state value isErrorVisible
   */
  const handleErrorAlert = (value) => {
    setIsErrorVisible(value);
  };

  /**
   *
   * @param {*} token Access token retrieved to call Azure REST APIs using backend endpoints
   * callback method called after token is retrieved from @azure/msal-browser dependency
   */
  const getToken = (token) => {
    hideProgressBar();
    setMsalToken(token);
  };

  const handleCreateReleasePipeline = () => {
    retrieveTokenForCreateReleasePipelineAPI();
    console.log("Selected User List", selectedTaskGroup);
  };

  const retrieveTokenForCreateReleasePipelineAPI = () => {
    showProgressBar("Please be patient! While user is authorised");
    getTokenForAPI(instance, inProgress, accounts, callCreateReleasePipelineAPI);
  };



  /**
   * JS method to call GET REST Endpoint for retreiving the organization rule
   */
  const getRulesByOrganization = () => {
    showProgressBar(
      "Please be patient! while organization rule is being fetched."
    );
    let config = {
      // headers: { authorization: "Bearer " + token },
      params: {
        organizationName: localStorage.getItem("organizationName"),
        platform: "AzureDevops",
      },
    };
    axios
      .get(constants.BASE_URL + constants.GET_RULES_BY_ORGANIZTION, config)
      .then((response) => {
        hideProgressBar();
        console.log(
          "Response-getRulesByOrganization==============>",
          response.data.body.projectCreationRules
        );
        const rules = response.data.body.projectCreationRules;
        // setVersionName(rules.branchingModel.name);
        // setSelectedBranchingModel(rules.branchingModel);
        // setNamingConvention(rules.namingStandard);
        setAvailableBranchesForStageTrigger(rules.branchingModel.branches);
        setAvailableBranchesForArtifactTrigger(rules.branchingModel.branches);
        setOrganizationRules(rules);
      })
      .catch((error) => {
        handleErrorAlert(true);
        hideProgressBar();
      });
  };

  const getAgentList = (token) => {
    showProgressBar("Please be patient! while agent list is being fetched.");
    let config = {
      headers: { authorization: "Bearer " + token },
      params: {
        organizationName: localStorage.getItem("organizationName"),
        projectId: state.project.id,
      },
    };
    axios
      .get(constants.BASE_URL + constants.GET_AGENT_LIST, config)
      .then((response) => {
        hideProgressBar();
        console.log(
          "Response-getAgentList==============>",
          response.data.body.agentList
        );
        setAgentList(response.data.body.agentList);
      })
      .catch((error) => {
        handleErrorAlert(true);
        hideProgressBar();
      });
  };

  const onTokenForAgentList = (token) => {
    getAgentList(token);
  };

  const getTokenForAgentList = () => {
    getTokenForAPI(instance, inProgress, accounts, onTokenForAgentList);
  };

  const getTaskGroupList = (token) => {
    showProgressBar(
      "Please be patient! while task group list is being fetched."
    );
    let config = {
      headers: { authorization: "Bearer " + token },
      params: {
        organizationName: localStorage.getItem("organizationName"),
        projectName: state.project.name,
      },
    };
    axios
      .get(constants.BASE_URL + constants.GET_TASK_GROUP_LIST, config)
      .then((response) => {
        hideProgressBar();
        console.log(
          "Response-getTaskGroupList==============>",
          response.data.body.variables

        );
        setAvailableTasksList(response.data.body.taskGroups);
        if (response.data.body.variables.length > 0) {
          handleErrorAlert(true);
          setErrorAlertCallback({
            message: <Box>
              <Typography
                variant="body1"
                color={"#005689"}> Please add the following variables </Typography>
              <Typography variant="body1"
                color={"#005689"}>
                {response.data.body.variables.map((varr) => <>{varr}<br></br></>)}</Typography>
              <Typography variant="body1"
                color={"#005689"}>to configure your Pipeline{pipelineName}</Typography>
            </Box>,
          });
        }
      })
      .catch((error) => {
        handleErrorAlert(true);
        hideProgressBar();
      });
  };

  const onTokenForTaskGroup = (token) => {
    getTaskGroupList(token);
  };

  const getTokenForTaskGroup = () => {
    getTokenForAPI(instance, inProgress, accounts, onTokenForTaskGroup);
  };

  useEffect(() => {
    getRulesByOrganization();
    getTokenForAgentList();
    getTokenForTaskGroup();
    // eslint-disable-next-line
  }, [instance, inProgress, accounts]);

  const callCreateReleasePipelineAPI = (token) => {
    showProgressBar(
      "Please be patient! while release pipeline is being created."
    );
    let config = {
      headers: { authorization: "Bearer " + token },
    };
    const data = {
      organizationName: localStorage.getItem("organizationName"),
      projectName: state.project.name,
      projectId: state.project.id,
      name: pipelineName,
      description: pipelineDescription,
      stageName: stageName,
      CIPipelineName: selectedCIPipeline,
      CIPipelineId: state.ciPipelines.find((pipeline) => pipeline.name == selectedCIPipeline).id,
      tasks: getTasksToAdd(),
      agentName: agentName,
      queueId: agentList.find((agent) => agent.name == agentName).id,
      branchesForArtifactTrigger: branchesForArtifactTrigger,
      branchesForStageTrigger: branchesForStageTrigger,
    };
    console.log("callCreateReleasePipelineAPI", data)
    console.log("callCreateReleasePipelineAPI", selectedTaskGroup)
    axios
      .post(constants.BASE_URL + constants.POST_CREATE_RELEASE_PIPELINE, data, config)
      .then((response) => {
        hideProgressBar();
        handleErrorAlert(true);
        navigate('/azure/projectInfo', {
          state: {
            project: state.project,
            routeList: [...state.routeList],
            tabId: 2,
          }
        })
        setErrorAlertCallback({
          navigate: "/azure/projectInfo",
          message: `Release Pipeline ${pipelineName} created successfully!`,
          navigateData: {
            state: {
              routeList: [...state.routeList]
            },
          }
        });
        console.log("Response-callCreateReleasePipelineAPI========>", response);
      })
      .catch((error) => {
        hideProgressBar();
        if (error.response.status === 409) {
          setErrorAlertCallback({
            message: `Release Pipeline ${pipelineName} already exists`,
          });
        }
        else if (error.response.status === 422) {
          setErrorAlertCallback({
            message: "No builds found for this CI Pipeline, cannot create Release Pipeline",
          });
        } else {
          setErrorAlertCallback({
            message:
              "Something went wrong while creating project. Please try again!",
          });
        }
        handleErrorAlert(true);
        console.log("Error-callCreateReleasePipelineAPI=========>", error);
      });
  }

  /**
   *
   * @param {*} message String value to be shown with Progress Bar
   * JS method called to make the Progress Bar visible along with the message
   */
  const showProgressBar = (message) => {
    setIsVisible(true);
    setProgressBarMessage(message);
  };

  /**
   *
   * JS method called to hide the Progress Bar
   */
  const hideProgressBar = () => {
    setIsVisible(false);
    setProgressBarMessage("");
  };

  // const handleTasksChange = (event) => {
  //   const {
  //     target: { value },
  //   } = event;
  //   setSelectedTasksList(
  //     // On autofill we get a stringified value.
  //     typeof value === "string" ? value.split(",") : value
  //   );
  // };

  const handleBranchesForStageTriggerChange = (event) => {
    const {
      target: { value },
    } = event;
    setBranchesForStageTrigger(
      // On autofill we get a stringified value.
      typeof value === "string" ? value.split(",") : value
    );
  };

  const handleBranchesForArtifactTriggerChange = (event) => {
    const {
      target: { value },
    } = event;
    setBranchesForArtifactTrigger(
      // On autofill we get a stringified value.
      typeof value === "string" ? value.split(",") : value
    );
  };

  const handleRepoDialogClose = () => {
    setRepoDialogIsOpen(false);
    setSelectedTaskJson({});
    setSelectedJsonFileName("");

  };

  const handleRepoDialogOpen = () => {
    setRepoDialogIsOpen(true);
  };

  /**
  * 
  * @returns JS method to initialize task just after creation.
  */
  const initiateCreateTask = () => {
    showProgressBar("Please be patient! While task is being created");
    getTokenForAPI(instance, inProgress, accounts, onTokenForTaskCreation);
  };

  const onTokenForTaskCreation = (token) => {
    callCreateTask(token);
  };

  const callCreateTask = (token) => {
    showProgressBar("Please be patient! While Task is being created.");
    let config = {
      headers: { authorization: "Bearer " + token },
    };
    const data = {
      organizationName: localStorage.getItem("organizationName"),
      projectId: state.project.id,
      taskGroup: selectedTaskJson,
    }
    console.log("callcallCreateTask============>", data);
    axios
      .post(
        constants.BASE_URL + constants.POST_CREATE_TASK_GROUP, data, config)
      .then((response) => {
        hideProgressBar();
        handleRepoDialogClose();
        getTokenForTaskGroup();
        console.log("callcallCreateTask-Response============>", response);
      })
      .catch((error) => {
        hideProgressBar();
        handleErrorAlert(true);
        setErrorAlertCallback({
          message:
            "Something went wrong while creating task. Please try again!",
        });
        console.log("callcallCreateTaskPI-Error============>", error);
      });
  };


  const onRepoDialogClose = (event, reason) => {
    // eslint-disable-next-line
    if (reason && reason == "backdropClick") return;
    handleRepoDialogClose();
  };
  const handleChangejsonFile = (e) => {
    const fileReader = new FileReader();
    fileReader.readAsText(e.target.files[0], "UTF-8");
    console.log("e.target.result", e.target.files[0].type);
    console.log("e.target.result", e.target.files[0].name);
    setSelectedJsonFileName(e.target.files[0].name);
    // eslint-disable-next-line
    if (e.target.files[0].type == "application/json") {
      fileReader.onload = (e) => {
        console.log("Result====>", typeof e.target.result);
        console.log("Parsed Result====>", JSON.parse(e.target.result));
        setSelectedTaskJson(JSON.parse(e.target.result));
      };
    } else {
      console.log("not a file type");
      setJsonButtonError(
        "Invalid file selected! Please select a valid JSON file"
      );
    }
  };

  const getTasksToAdd = () => {
    const tasks = [];
    for (const task of selectedTaskGroup) {
      tasks.push(task);
    }
    return tasks;
  };
  return (
    <Box>

      <Dialog open={repoDialogIsOpen} onClose={onRepoDialogClose}>
        <ProgressBar
          isVisible={isVisible}
          progressBarMessage={progressBarMessage}
        />
        <ErrorAlert
          isErrorVisible={isErrorVisible}
          callback={() => {
            setIsErrorVisible(false);
            if (
              errorAlertCallback.hasOwnProperty("navigate") &&
              errorAlertCallback.hasOwnProperty("navigateData")
            ) {
              navigate(
                errorAlertCallback.navigate,
                errorAlertCallback.navigateData
              );
            } else if (errorAlertCallback.hasOwnProperty("navigate")) {
              navigate(errorAlertCallback.navigate);
            }
          }}
          message={errorAlertCallback.message}
        />
        <DialogTitle
          className="createCIPipeline-dialogTitle">
          Add New Task
        </DialogTitle>
        <Divider className="createCIPipeline-divider" />
        <DialogContent>
          <Box variant="outlined" >
            <FormControl fullWidth>
              <TextField
                variant="outlined"
                fullWidth
                label="Organization Name"
                size="small"
                disabled
                defaultValue={localStorage.getItem("organizationName")}
                required
              />
            </FormControl>

            <FormControl className="createCIPipeline-formControl1"
              fullWidth
            >
              <TextField
                variant="outlined"
                fullWidth
                label="Project Name"
                size="small"
                disabled
                defaultValue={state.project.name}
                required
              />
            </FormControl>
            <Stack direction="row" justifyContent="space-between">
              <ColorButton
                backgroundcolor="#005689"
                variant="contained"
                fontSize="14px"
                component="label"
                className="addVariableDialog-colourButton"
                onChange={handleChangejsonFile}
              >
                Upload JSON
                <input hidden multiple type="file" value={""} />
              </ColorButton>
              <Typography
                className="addVariableDialog-colourButton"
                mr={5}
                color={"#005689"}
                fontWeight={"small"}>
                {selectedJsonFileName}
              </Typography>
            </Stack>
          </Box>
        </DialogContent>
        <DialogActions>
          <Button className="createCIPipeline-button-cancel"
            onClick={handleRepoDialogClose}
          >
            Cancel
          </Button>
          <Button
            className="createCIPipeline-button-create"
            onClick={initiateCreateTask}
            disabled={
              !(
                JSON.stringify(selectedTaskJson).length > 1
              )
            }
          >
            Create Task
          </Button>
        </DialogActions>
      </Dialog>

      <ProgressBar
        isVisible={isVisible}
        progressBarMessage={progressBarMessage}
      />
      <ErrorAlert
        isErrorVisible={isErrorVisible}
        callback={() => {
          setIsErrorVisible(false);
          if (
            errorAlertCallback.hasOwnProperty("navigate") &&
            errorAlertCallback.hasOwnProperty("navigateData")
          ) {
            navigate(
              errorAlertCallback.navigate,
              errorAlertCallback.navigateData
            );
          } else if (errorAlertCallback.hasOwnProperty("navigate")) {
            navigate(errorAlertCallback.navigate);
          }
        }}
        message={errorAlertCallback.message}
      />
      <Box className="createProject-box1">
        <CustomBreadCrumb
          routeList={state.routeList}
          location={location.pathname}
        />
      </Box>
      <Typography className="createProject-typography1" variant="h6" mb={1}>
        Create Release Pipeline for {state.project.name}
      </Typography>
      <Divider />
      <Box variant="outlined" mt={3}>
        <Grid container spacing={2}>
          <Grid item xs={6}>
            <TextField
              variant="outlined"
              fullWidth
              label="Organization Name"
              size="small"
              disabled
              value={localStorage.getItem("organizationName")}
              required
            />
          </Grid>
          <Grid item xs={6}>
            <TextField
              variant="outlined"
              fullWidth
              label="Project Name"
              size="small"
              disabled
              value={state.project.name}
              required
            />
          </Grid>
          <Grid item xs={6}>
            <TextField
              variant="outlined"
              fullWidth
              label="Pipeline Name"
              size="medium"
              value={pipelineName}
              required
              // helperText={
              //   pipelineName.trim().length ? "" : " "
              // }
              //   error={!activeDirectoryName.trim().length}
              onChange={(event) => setPipelineName(event.target.value)}
            />
          </Grid>
          <Grid item xs={6}>
            <TextField
              variant="outlined"
              fullWidth
              label="Pipeline Description"
              size="medium"
              value={pipelineDescription}
              required
              // helperText={
              //   pipelineDescription.trim().length
              //     ? ""
              //     : ""
              // }
              //   error={!activeDirectoryName.trim().length}
              onChange={(event) => setPipelineDescription(event.target.value)}
            />
          </Grid>
          <Grid item xs={6}>
            <TextField
              variant="outlined"
              fullWidth
              label="Stage Name"
              size="medium"
              value={stageName}
              required
              // helperText={
              //   stageName.trim().length ? "" : ""
              // }
              //   error={!activeDirectoryName.trim().length}
              onChange={(event) => setStageName(event.target.value)}
            />
          </Grid>
          <Grid item xs={6}>
            <FormControl fullWidth>
              <InputLabel id="demo-simple-select-label" required>
                Agent Name
              </InputLabel>
              <Select
                labelId="demo-simple-select-label"
                id="demo-simple-select"
                value={agentName}
                label="Repository Name"
                onChange={(event) => {
                  setAgentName(event.target.value);
                }}
              >
                {agentList.map((agent, index) => (
                  <MenuItem value={agent.name} key={agent.name}>
                    {agent.name}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={6}>
            <FormControl fullWidth>
              <InputLabel id="demo-simple-select-label" required>
                CI Pipeline Name
              </InputLabel>
              <Select
                labelId="demo-simple-select-label"
                id="demo-simple-select"
                value={selectedCIPipeline}
                label="CI Pipeline Name"
                onChange={(event) => {
                  setSelectedCIPipeline(event.target.value);
                  console.log("pipline", event.target.value)
                }}
              >
                {state.ciPipelines.map((pipeline, index) => (
                  <MenuItem value={pipeline.name} key={pipeline.name}>
                    {pipeline.name}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={6}>
            <FormControl sx={{ width: "100%" }}>
              <InputLabel id="demo-multiple-name-label">
                Branches for stage trigger
              </InputLabel>
              <Select
                labelId="demo-multiple-name-label"
                id="demo-multiple-name"
                multiple
                value={branchesForStageTrigger}
                onChange={handleBranchesForStageTriggerChange}
                input={<OutlinedInput label="Branches for stage trigger" />}
                MenuProps={MenuProps}
              >
                {availableBranchesForStageTrigger.map((branch) => (
                  <MenuItem
                    key={branch._id}
                    value={branch.name}
                    style={getStyles(
                      branch.name,
                      branchesForStageTrigger,
                      theme
                    )}
                  >
                    {branch.name}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={6}>
            <Box>
              <Stack direction={"row"} spacing={4}>
                <Box>
                  <Typography className="createProject-typography1" mb={1}>
                    Add Task Groups for Pipeline
                  </Typography>
                  {availableTasksList.length > 0 ?
                    <Paper
                      className="addUserDialog-paper"
                      variant="outlined"
                    >
                      <ListSubheader>Available Task Groups</ListSubheader>
                      <Divider />
                      <List className="addUserDialog-list">
                        {availableTasksList.map((taskGroup) =>
                          taskGroup.tasks.map((task, index) => (
                            <Box key={index}>
                              <ButtonBase
                                focusRipple
                                onClick={() => {
                                  console.log("Clickek task group", task);
                                  if (
                                    selectedTaskGroup.filter((e) => {
                                      return (
                                        e.displayName === task.displayName
                                      );
                                    }).length > 0
                                  ) {
                                    return;
                                  }
                                  setSelectedTaskGroup([
                                    ...selectedTaskGroup,
                                    task,
                                  ]);
                                }}
                              >
                                <Stack
                                  direction="row"
                                  spacing={1}
                                  alignItems="center"
                                  m={1}
                                >
                                  <Typography>{task.displayName}</Typography>
                                </Stack>
                              </ButtonBase>
                              <Divider />
                            </Box>
                          )))}
                      </List>
                      <ColorButton
                        backgroundcolor="#005689"
                        onClick={handleRepoDialogOpen}
                        variant="contained"
                      >
                        Add Task Group
                      </ColorButton>
                    </Paper> : <>
                      <Stack direction="row" spacing={1}>
                        <Typography
                          className="createProject-typography1"
                          fontSize="small"
                          mt={1} >
                          No taskGroup available!
                        </Typography>
                        <ColorButton
                          backgroundcolor="#005689"
                          onClick={handleRepoDialogOpen}
                          variant="contained"
                        >
                          Add Task Group
                        </ColorButton>
                      </Stack>
                    </>
                  }
                </Box>
                <Box>
                  {selectedTaskGroup.length > 0 ? (
                    <Box>
                      <Typography
                        variant="h6"
                        fontSize={14}
                        className="addUserDialog-typography"
                      >
                        Selected Task Groups
                      </Typography>
                      <Divider />
                      <Box
                        className="addUserDialog-box2">
                        {selectedTaskGroup.map((task, index) => (
                          <Chip
                            className="addUserDialog-chip"
                            key={index}
                            label={task.displayName}
                            onDelete={() => {
                              setSelectedTaskGroup(
                                selectedTaskGroup.filter(
                                  (e) => e.displayName !== task.displayName
                                )
                              );
                            }}
                          />
                        ))}
                      </Box>
                    </Box>
                  ) : (
                    <></>
                  )}
                </Box>
              </Stack>
            </Box>
          </Grid>
          <Grid item xs={6}>
            <FormControl sx={{ width: "100%" }}>
              <InputLabel id="demo-multiple-name-label">
                Branches for continuous deployment trigger
              </InputLabel>
              <Select
                labelId="demo-multiple-name-label"
                id="demo-multiple-name"
                multiple
                value={branchesForArtifactTrigger}
                onChange={handleBranchesForArtifactTriggerChange}
                input={<OutlinedInput label="Branches for continuous deployment trigger" />}
                MenuProps={MenuProps}
              >
                {availableBranchesForArtifactTrigger.map((branch) => (
                  <MenuItem
                    key={branch._id}
                    value={branch.name}
                    style={getStyles(
                      branch.name,
                      branchesForArtifactTrigger,
                      theme
                    )}
                  >
                    {branch.name}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>
          </Grid>

        </Grid>
      </Box>
      <Stack direction="row" justifyContent="space-between" padding={1} spacing={1}>
        <Box>
          {/* <ColorButton
            backgroundcolor="#005689"
            onClick={handleRepoDialogOpen}
            variant="contained"
          >
            New Task Group
          </ColorButton> */}
        </Box>
        <Stack direction="row" spacing={1}>
          <ColorButton
            backgroundcolor="#005689"
            onClick={() => navigate(-1)}
            variant="contained"
          >
            Back
          </ColorButton>
          <ColorButton
            backgroundcolor="#005689"
            variant="contained"
            disabled={
              !(
                pipelineName.length &&
                pipelineDescription.length &&
                stageName.length &&
                selectedCIPipeline.length &&
                selectedTaskGroup.length &&
                agentName.length &&
                branchesForArtifactTrigger.length &&
                branchesForStageTrigger.length
              )
            }
            onClick={handleCreateReleasePipeline}
          >
            Create Release Pipeline
          </ColorButton>
        </Stack>
      </Stack>
    </Box>
  );
}
