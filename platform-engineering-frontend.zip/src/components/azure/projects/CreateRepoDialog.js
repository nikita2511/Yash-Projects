import React, { useState } from "react";
import {
  Avatar,
  Box,
  ButtonBase,
  Chip,
  Divider,
  FormControl,
  FormControlLabel,
  FormLabel,
  InputLabel,
  List,
  ListSubheader,
  MenuItem,
  Paper,
  Radio,
  RadioGroup,
  Select,
  Stack,
  Switch,
  Typography,
} from "@mui/material";
import "./projects.css";
import { useLocation } from "react-router-dom";
import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import axios from "axios";
import { constants } from "../../../utils/Constants";
import { useMsal } from "@azure/msal-react";
import { getTokenForAPI } from "../../../utils/RetrieveToken";
import ProgressBar from "../../../utils/ProgressBar";
import ErrorAlert from "../../error/ErrorAlert";
import { ColorButton } from "../../../utils/CustomButton";
import { Add } from "@mui/icons-material";
import { useNavigate } from "react-router-dom";
import { stringAvatar } from "../../../utils/helper";

/**
 *
 * @returns React Functional Component (CreateRepoDialog) which renders a dialog by which a repository will be created for the project.
 * 
 */
export default function CreateRepoDialog({
  onNewRepoAdded,
  eligibleUsers = [],
  onNewRepoAddedWithPipeline
}) {
  const location = useLocation();
  const navigate = useNavigate();
  const { state } = location;
  const { instance, inProgress, accounts } = useMsal();
  const repoNameRegex = /([`~!@#$%^&*()_+\-=[\]{}|;':",./\\<>?])/;
  const [repoData, setRepoData] = useState({
    repositoryName: "",
    organizationName: localStorage.getItem("organizationName"),
    projectId: state.project.id,
    initializeRepo: false,
  });
  const [isRepoNameValid, setIsRepoNameValid] = useState(false);
  const [repoDialogIsOpen, setRepoDialogIsOpen] = useState(false);
  const [organizationRules, setOrganizationRules] = useState({
    _id: "",
    organizationName: "",
    namingStandard: "",
    createdBy: "",
    branchingModel: {
      _id: "",
      name: "",
      numberOfBranches: 0,
      branches: [],
      created_at: "",
      updated_at: "",
      __v: 0,
    },
    created_at: "",
    updated_at: "",
    __v: 0,
  });
  const [isErrorVisible, setIsErrorVisible] = React.useState(false);
  const [isVisible, setIsVisible] = React.useState(false);
  const [progressBarMessage, setProgressBarMessage] =
    React.useState("Please wait!");
  const [errorAlertCallback, setErrorAlertCallback] = React.useState({
    navigate: -1,
    navigateData: {
      state: {},
    },
    message: "Something unexpected happend! Please try again",
  });
  const [shouldCreateCIPipeline, setShouldCreateCIPipeline] =
    React.useState(false);
  const [technologyType, setTechnologyType] = React.useState("");
  // eslint-disable-next-line
  const [technologyTypeList, setTechnologyTypeList] = React.useState([
    {
      id: "0",
      name: "Java",
      value: "java",
    },
    {
      id: "1",
      name: ".Net",
      value: "dotNet",
    },
  ]);
  const [pipelineName, setPipelineName] = React.useState("");
  const [isPublishArtifact, setPublishArtifact] = React.useState(false);
  // eslint-disable-next-line
  const [addUserList, setAddUserList] = React.useState([...eligibleUsers]);
  const [selectedUserList, setSelectedUserList] = React.useState([]);
  const [filteredUserList, setFilteredUserList] = React.useState([
    ...eligibleUsers,
  ]);
  const [noOfReviewers, setNoOfReviewers] = React.useState("");

  React.useEffect(() => {
    setAddUserList(eligibleUsers);
    setFilteredUserList(eligibleUsers);
  }, [eligibleUsers]);

  /**
   * JS method to handle the inputs of repository.
   */
  const handleRepoDialogClose = () => {
    setRepoDialogIsOpen(false);
    setRepoData({
      repositoryName: "",
      organizationName: localStorage.getItem("organizationName"),
      projectId: state.project.id,
      initializeRepo: false,
    });
    setIsRepoNameValid(false);
    setShouldCreateCIPipeline(false);
    setTechnologyType("");
    setPublishArtifact(false);
    setSelectedUserList([]);
  };

  /**
   * 
    * @returns JS method callback after dialog is closed. 
   */
  const onRepoDialogClose = (event, reason) => {
    // eslint-disable-next-line
    if (reason && reason == "backdropClick") return;
    handleRepoDialogClose();
  };

  /**
   *
   * @param {*} value boolean value to change visiblity of Alert Dialog
   * JS method to update the boolean state value isErrorVisible
   */
  const handleErrorAlert = (value) => {
    setIsErrorVisible(value);
  };

  /**
   * 
   * @param {*} event method to validate char length for repository.
   */
  const onRepoDataChange = (event) => {
    const repo = { ...repoData };
    // eslint-disable-next-line
    if (event.target.name == "repositoryName") {
      setIsRepoNameValid(
        repoNameRegex.test(event.target.value) || event.target.value.length > 64
      );
      repo[event.target.name] = event.target.value;
    } else {
      repo[event.target.name] = event.target.checked;
    }
    setRepoData(repo);
  };

  /**
     *
     * callback method called after token is retrieved from @azure/msal-browser dependency
     */
  const onTokenForRepoCreation = (token) => {
    callCreateRepoAPI(token);
  };

  /**
   * 
   * @param {*} event method to validate regex for repository.
   */
  const getRepoNameValidation = (repoName) => {
    setIsRepoNameValid(repoNameRegex.test(repoName) || repoName.length > 64);
    return repoNameRegex.test(repoName) || repoName.length > 64;
  };

  /**
   * 
   * @returns method to validate naming convention for repository.
   */
  const getDataForRepoCreation = () => {
    const repo = { ...repoData };
    repo[
      "repositoryName"
    ] = `${organizationRules.namingStandard}${repoData.repositoryName}`;
    return repo;
  };

  /**
   *
   * @param {*} token Access token retrieved to call Azure REST APIs using backend endpoints
   * JS method to call POST REST Endpoint for posting input to create repository for the project..
   */
  const callCreateRepoAPI = (token) => {
    showProgressBar("Please be patient! While repository is being created.");
    let config = {
      headers: { authorization: "Bearer " + token },
    };
    axios
      .post(
        constants.BASE_URL + constants.GET_REPOSITORIES,
        getDataForRepoCreation(),
        config
      )
      .then((response) => {
        hideProgressBar();
        if (shouldCreateCIPipeline) {
          handleCreateCIPipeline();
        } else {
          handleRepoDialogClose();
          console.log("callCreateRepoAPI-Response============>", response);
          setRepoData({
            repositoryName: "",
            organizationName: localStorage.getItem("organizationName"),
            projectId: state.project.id,
            initializeRepo: false,
          });
          onNewRepoAdded();
        }
      })
      .catch((error) => {
        hideProgressBar();
        handleErrorAlert(true);
        setErrorAlertCallback({
          message:
            "Something went wrong while creating repository. Please try again!",
        });
        console.log("callCreateRepoAPI-Error============>", error);
      });
  };

  /**
   * 
   * @returns JS method to initialize repository just after creation.
   */
  const initiateCreateRepo = () => {
    if (getRepoNameValidation(repoData.repositoryName)) {
      return false;
    }
    showProgressBar("Please be patient! While repository is being created");
    getTokenForAPI(instance, inProgress, accounts, onTokenForRepoCreation);
  };

  /**
   *
   * @param {*} token Access token retrieved to call Azure REST APIs using backend endpoints
   * JS method to call GET REST Endpoint for retrieving organization rule.
   */
  const callGetOrganizationRule = (token) => {
    showProgressBar(
      "Please be patient! while information related to existing projet are being fetched"
    );
    let config = {
      // headers: { authorization: "Bearer " + token },
      params: {
        organizationName: localStorage.getItem("organizationName"),
        platform: "AzureDevops"
      },
    };
    axios
      .get(constants.BASE_URL + constants.GET_RULES_BY_ORGANIZTION, config)
      .then((response) => {
        hideProgressBar();
        console.log(
          "Response-getRulesByOrganization==============>",
          response.data.body.projectCreationRules
        );
        const rules = response.data.body.projectCreationRules;
        setOrganizationRules(rules);
        setNoOfReviewers(
          rules.branchingModel.branches.find(
            // eslint-disable-next-line
            (branch) => branch.type == "default"
          ).noOfReviewers
        );
      })
      .catch((error) => {
        hideProgressBar();
      });
  };

  /**
   *
   * callback method called after token is retrieved from @azure/msal-browser dependency
   */
  const onTokenForOrganizationRule = (token) => {
    callGetOrganizationRule(token);
  };

  /**
   *
   * callback method called after token is retrieved from @azure/msal-browser dependency
   */
  const getTokenForOrganizationRule = () => {
    getTokenForAPI(instance, inProgress, accounts, onTokenForOrganizationRule);
  };

  /**
   *
   * @param {*} message String value to be shown with Progress Bar
   * JS method called to make the Progress Bar visible along with the message
   */
  const showProgressBar = (message) => {
    setIsVisible(true);
    setProgressBarMessage(message);
  };

  /**
   *
   * JS method called to hide the Progress Bar
   */
  const hideProgressBar = () => {
    setIsVisible(false);
    setProgressBarMessage("");
  };

  /**
   * method to handle Repository dialog rendering.
   */
  const handleRepoDialogOpen = () => {
    getTokenForOrganizationRule();
    setRepoDialogIsOpen(true);
  };

  /**
   * 
   * @param {*} event method to handle technology type for pipeline.
   */
  const handleTechnologyTypeChange = (event) => {
    setTechnologyType(event.target.value);
  };

  /**
   * 
   * @param {*} event method to handle publishArtifact type for pipeline.
   */
  const handlePublishArtifactChange = (event) => {
    // eslint-disable-next-line
    setPublishArtifact(event.target.value == "true");
  };

  /**
   * 
   * @returns JS method to add users as reviewers for the pipeline.
   */
  const getReviewersToAdd = () => {
    const users = [];
    for (const user of selectedUserList) {
      const reviewer = {
        id: user.id,
        isRequired: true,
      };
      users.push(reviewer);
    }
    return users;
  };

  /**
   *
   * @param {*} token Access token retrieved to call Azure REST APIs using backend endpoints
   * JS method to call POST REST Endpoint for posting inputs for CIpipeline to be created for project.
   */
  const callCreateCIPipelineAPI = (token) => {
    showProgressBar("Please be patient! While CI pipeline is being created.");
    const data = {
      organizationName: localStorage.getItem("organizationName"),
      projectName: state.project.name,
      repoName: `${organizationRules.namingStandard}${repoData.repositoryName}`,
      applicationType: technologyType,
      publishArtifacts: isPublishArtifact,
      userNameInitials: stringAvatar(
        instance.getActiveAccount() ? instance.getActiveAccount().name : ""
      ).children,
      pipelineName: pipelineName,
      reviewers: getReviewersToAdd(),
    };
    console.log("handleCreateCIPipeline============>", data);
    let config = {
      headers: { authorization: "Bearer " + token },
    };
    axios
      .post(
        constants.BASE_URL + constants.POST_CREATE_CI_PIPELINE,
        data,
        config
      )
      .then((response) => {
        hideProgressBar();
        handleRepoDialogClose();
        onNewRepoAddedWithPipeline();
        console.log("Response-callCreateCIPipelineAPI========>", response);
      })
      .catch((error) => {
        hideProgressBar(); // eslint-disable-next-line
        if (error.response.status == 409) {
          setErrorAlertCallback({
            message: error.response.data.body.errorMessage,
          });
        } else {
          setErrorAlertCallback({
            message:
              "Something went wrong while creating CI Pipeline in project. Please try again!",
          });
        }
        handleErrorAlert(true);
        console.log("Error-callCreateCIPipelineAPI=========>", error.response);
      });
  };

  /**
     *
     * callback method called after token is retrieved from @azure/msal-browser dependency
     */
  const retrieveTokenForCreateCIPipelineAPI = () => {
    showProgressBar("Please be patient! While user is authorised");
    getTokenForAPI(instance, inProgress, accounts, callCreateCIPipelineAPI);
  };

  /**
   * JS method to handle callback method 
   */
  const handleCreateCIPipeline = () => {
    retrieveTokenForCreateCIPipelineAPI();
  };

  return (
    <Box>
      <ColorButton
        backgroundcolor="#005689"
        variant="contained"
        size="small"
        onClick={handleRepoDialogOpen}
        startIcon={<Add />}
      >
        New Repositories
      </ColorButton>
      <Dialog open={repoDialogIsOpen} onClose={onRepoDialogClose} fullWidth>
        <ProgressBar
          isVisible={isVisible}
          progressBarMessage={progressBarMessage}
        />
        <ErrorAlert
          isErrorVisible={isErrorVisible}
          callback={() => {
            setIsErrorVisible(false);
            if (
              errorAlertCallback.hasOwnProperty("navigate") &&
              errorAlertCallback.hasOwnProperty("navigateData")
            ) {
              navigate(
                errorAlertCallback.navigate,
                errorAlertCallback.navigateData
              );
            } else if (errorAlertCallback.hasOwnProperty("navigate")) {
              navigate(errorAlertCallback.navigate);
            }
          }}
          message={errorAlertCallback.message}
        />
        <DialogTitle className="createRepoDialog-dialogTitle">
          Create Repository
        </DialogTitle>
        <DialogContent>
          <DialogContentText>
            To create repository, please enter below details
          </DialogContentText>
          <TextField
            autoFocus
            margin="dense"
            id="repoName"
            label="Repository Name"
            value={repoData.repositoryName}
            type="text"
            fullWidth
            error={isRepoNameValid}
            helperText={
              repoData.repositoryName.length
                ? "A repository name cannot contain more than 64 characters, contain Unicode control characters or surrogate characters, contain any of the following characters: / :  ~ & % ; @ ' \" ? < > | # $ * } { , + = [ ], start with an underscore ( _ ), start or end with a period ( . ), or be a system reserved name"
                : ""
            }
            variant="standard"
            name="repositoryName"
            onChange={onRepoDataChange}
          />
          {repoData.repositoryName.length ? (
            <Stack direction={"row"} justifyContent={"space-between"}>
              <Stack direction="row" spacing={1} alignItems="center">
                <Typography variant="body1" color="#007CB9" fontSize={13}>
                  Final Repository Name:
                </Typography>
                <Typography
                  variant="body1"
                  color="#005689"
                  flexWrap={"wrap"}
                  noWrap
                >
                  {organizationRules.namingStandard}
                  {repoData.repositoryName}
                </Typography>
              </Stack>
              <Stack direction={"row"} alignItems={"center"}>
                <Switch
                  onChange={(event) => {
                    setShouldCreateCIPipeline(event.target.checked);
                  }}
                />
                <Typography color={"#005689"}>Create CI Pipeline</Typography>
              </Stack>
            </Stack>
          ) : (
            <></>
          )}
          {shouldCreateCIPipeline ? (
            <Box className="createRepoDialog-box1"
              variant="outlined"
            >
              <TextField
                variant="outlined"
                fullWidth
                label="Default Repo Name"
                disabled
                value={`${organizationRules.namingStandard}${repoData.repositoryName}`}
              />
              <FormControl className="createCIPipeline-formControl1"
                fullWidth
              >
                <InputLabel id="demo-simple-select-label" required>
                  Technology Type
                </InputLabel>
                <Select
                  labelId="demo-simple-select-label"
                  id="demo-simple-select"
                  value={technologyType}
                  label="Technology Type"
                  onChange={handleTechnologyTypeChange}
                >
                  {technologyTypeList.map((type) => (
                    <MenuItem value={type.value} key={type.id}>
                      {type.name}
                    </MenuItem>
                  ))}
                </Select>
              </FormControl>

              <TextField
                variant="outlined"
                fullWidth
                label="Pipeline Name"
                required
                onChange={(event) => setPipelineName(event.target.value)}
              />

              <FormControl className="createCIPipeline-formControl2">
                <FormLabel id="demo-row-radio-buttons-group-label">
                  Publist Artifacts
                </FormLabel>
                <RadioGroup
                  className="createCIPipeline-radioGroup"
                  row
                  aria-labelledby="demo-row-radio-buttons-group-label"
                  name="row-radio-buttons-group"
                  onChange={handlePublishArtifactChange}
                  value={isPublishArtifact}
                >
                  <FormControlLabel
                    className="createCIPipeline-formControlLevel"
                    value={true}
                    control={<Radio />}
                    label="Yes"
                  />
                  <FormControlLabel
                    className="createCIPipeline-formControlLevel"
                    value={false}
                    control={<Radio />}
                    label="No"
                  />
                </RadioGroup>
              </FormControl>
              <Box
                className="createCIPipeline-box1"
                variant="outlined"
              >
                {pipelineName.trim().length && technologyType.trim().length ? (
                  <Box>
                    <Stack direction={"row"} spacing={2}>
                      <Box>
                        {filteredUserList.length > 0 ? (
                          <Paper className="createCIPipeline-paper"
                            variant="outlined"
                          >
                            <ListSubheader>Available Reviewers</ListSubheader>
                            <Divider />
                            <List className="createCIPipeline-list">
                              {filteredUserList.map((user, index) => (
                                <Box key={index}>
                                  <ButtonBase
                                    focusRipple
                                    onClick={() => {
                                      console.log(user.user.displayName);
                                      if (
                                        selectedUserList.filter((e) => {
                                          return (
                                            e.user.mailAddress ===
                                            user.user.mailAddress
                                          );
                                        }).length > 0 || // eslint-disable-next-line
                                        selectedUserList.length == noOfReviewers
                                      ) {
                                        return;
                                      }
                                      setSelectedUserList([
                                        ...selectedUserList,
                                        user,
                                      ]);
                                    }}
                                  >
                                    <Stack
                                      direction="row"
                                      spacing={1}
                                      alignItems="center"
                                      m={1}
                                    >
                                      <Avatar
                                        {...stringAvatar(user.user.displayName)}
                                      />
                                      <Typography>
                                        {user.user.displayName}
                                      </Typography>
                                    </Stack>
                                  </ButtonBase>
                                  {
                                    // eslint-disable-next-line
                                    index != filteredUserList.length - 1 ? (
                                      <Divider />
                                    ) : (
                                      <></>
                                    )
                                  }
                                </Box>
                              ))}
                            </List>
                          </Paper>
                        ) : (
                          <></>
                        )}
                      </Box>
                      <Box>
                        {selectedUserList.length > 0 ? (
                          <Box>
                            <Typography
                              className="createCIPipeline-typography1"
                              variant="h6"
                              fontSize={14}
                            >
                              Selected Reviewers
                            </Typography>
                            <Divider />
                            <Box className="createCIPipeline-box2">
                              {selectedUserList.map((user, index) => (
                                <Chip
                                  className="createCIPipeline-chip"
                                  key={index}
                                  label={user.user.displayName}
                                  onDelete={() => {
                                    setSelectedUserList(
                                      selectedUserList.filter(
                                        (e) =>
                                          e.user.mailAddress !==
                                          user.user.mailAddress
                                      )
                                    );
                                  }}
                                />
                              ))}
                            </Box>
                          </Box>
                        ) : (
                          <></>
                        )}
                      </Box>
                    </Stack>
                    <Typography
                      variant="body1"
                      color="#007CB9"
                      fontSize={13}
                      fontWeight={"bold"}
                      mt={1}
                    >
                      Your organization policy require to review every commit.
                      Please add {noOfReviewers} reviewers for initial pipeline
                      commit to default branch.
                    </Typography>
                    <Typography
                      variant="body1"
                      color="#007CB9"
                      fontSize={13}
                      fontWeight={"bold"}
                      mt={1}
                    >
                      Also, you need to add user in the project to make them
                      reviewer if already not present.
                    </Typography>
                  </Box>
                ) : (
                  <></>
                )}
              </Box>
            </Box>
          ) : (
            <></>
          )}
          <Typography
            variant="body1"
            color="#007CB9"
            fontSize={13}
            fontWeight={"800"}
            mt={1}
          >
            Repository will be initialized as per Organization Rules
          </Typography>
        </DialogContent>
        <DialogActions>
          <Button
            className="createCIPipeline-button-cancel "
            onClick={handleRepoDialogClose}
          >
            Cancel
          </Button>
          <Button className="createCIPipeline-button-create createCIPipeline-typography1"
            onClick={initiateCreateRepo}
            disabled={
              repoData.repositoryName.trim().length
                ? shouldCreateCIPipeline
                  ? !(technologyType.length && pipelineName.trim().length)
                  : shouldCreateCIPipeline
                : !repoData.repositoryName.trim().length
            }
          // disabled={shouldCreateCIPipeline && technologyType.length && pipelineName.trim().length}
          >
            Create
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
