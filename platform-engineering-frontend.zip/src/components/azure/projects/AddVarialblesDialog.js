import React, { useEffect, useState } from "react";
import {
  Box,
  Divider,
  IconButton,
  Stack,
  Switch,
  Typography,
} from "@mui/material";
import AddCircleOutlineSharpIcon from "@mui/icons-material/AddCircleOutlineSharp";
import { Delete, LockOpenOutlined, LockOutlined } from "@mui/icons-material";
import { ColorButton } from "../../../utils/CustomButton";
import { useNavigate } from "react-router-dom";
import Button from "@mui/material/Button";
import TextField from "@mui/material/TextField";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import axios from "axios";
import { constants } from "../../../utils/Constants";
import { useMsal } from "@azure/msal-react";
import { getTokenForAPI } from "../../../utils/RetrieveToken";
import ProgressBar from "../../../utils/ProgressBar";
import ErrorAlert from "../../error/ErrorAlert";

/**
 *
 * @returns React Functional Component (AddVariablesDialog) which renders a dialog by which variables will be added to project.
 */
export default function AddVariablesDialog({
  project,
  onNewVariableGroupAdded,
  variableGroupToEdit,
  isVariableEdit,
  variableGroupDialogIsOpen,
  handleVariableGroupDialogClose,
}) {
  const navigate = useNavigate();
  const { instance, inProgress, accounts } = useMsal();
  const [variableGroupName, setVariableGroupName] = useState("");
  const [variableGroupDescription, setVariableGroupDescription] = useState("");
  const [addedVariable, setAddedVariable] = useState({});
  const [variableKey, setVariableKey] = useState("");
  const [variableValue, setVariableValue] = useState("");
  const [progressBarMessage, setProgressBarMessage] =
    React.useState("Please wait!");
  const [isVisible, setIsVisible] = React.useState(false);
  const [isJsonSelected, setIsJsonSelected] = React.useState(false);
  const [isErrorVisible, setIsErrorVisible] = React.useState(false);
  const [errorAlertCallback, setErrorAlertCallback] = React.useState({
    navigate: -1,
    navigateData: {
      state: {},
    },
    message: "Something unexpected happend! Please try again",
  });
  const [jsonButtonError, setJsonButtonError] = React.useState(
    "Upload a JSON file containing a JSON object of Name & Value pair for Variables"
  );
  const [isVariableLock, setIsVariableLock] = React.useState(false);

  /**
   * 
   * @param {*} e handles the JSON file input
   */
  const handleChangejsonFile = (e) => {
    const fileReader = new FileReader();
    fileReader.readAsText(e.target.files[0], "UTF-8");
    console.log("e.target.result", e.target.files[0].type);
    // eslint-disable-next-line
    if (e.target.files[0].type == "application/json") {
      fileReader.onload = (e) => {
        console.log("Result====>", typeof e.target.result);
        console.log("Parsed Result====>", JSON.parse(e.target.result));
        const duplicateVariables = [];
        for (const variable of Object.keys(JSON.parse(e.target.result))) {
          if (Object.keys(addedVariable).includes(variable)) {
            duplicateVariables.push(variable);
          }
        }
        if (duplicateVariables.length) {
          setJsonButtonError(
            `Variables (${duplicateVariables.toString()}) already exist in variable group. Please delete previous one or modify your JSON file`
          );
        } else {
          setAddedVariable({
            ...addedVariable,
            ...JSON.parse(e.target.result),
          });
          setJsonButtonError("");
        }
      };
    } else {
      console.log("not a file type");
      setJsonButtonError(
        "Invalid file selected! Please select a valid JSON file"
      );
    }
  };

  /**
     * JS method called just after the closing dialog, clearing states of atributes
     */
  const onVariableGroupDialogClose = (event, reason) => {
    // eslint-disable-next-line
    if (reason && reason == "backdropClick") return;
    clearVariableGroupValues();
    handleVariableGroupDialogClose();
  };

  /**
  *
  * @param {*} value boolean value to change visiblity of Alert Dialog
  * JS method to update the boolean state value isErrorVisible
  */
  const handleErrorAlert = (value) => {
    setIsErrorVisible(value);
  };

  /**
   * JS method to manage states of attribute associated with variable.
   */
  const clearVariableGroupValues = () => {
    setVariableGroupName("");
    setVariableGroupDescription("");
    setAddedVariable({});
    setVariableKey("");
    setVariableValue("");
    setJsonButtonError(
      "Upload a JSON file containing a JSON object of Name & Value pair for Variables"
    );
    setIsJsonSelected(false);
  };


  const AddSingleVariables = () => {
    const variable = { ...addedVariable };
    if (variableKey.trim().length > 0) {
      variable[variableKey] = {
        value: variableValue,
        isSecret: isVariableLock,
      };
      setAddedVariable(variable);
      setVariableKey("");
      setVariableValue("");
      // setIsVariableLock(false);
    }
    return variable
  }

  const AddForEditVariables = () => {
    const variable = { ...addedVariable };
    if (variableKey.trim().length > 0) {
      variable[variableKey] = {
        value: variableValue,
        isSecret: isVariableLock,
      };
    }
    setAddedVariable(variable);
    setVariableKey("");
    setVariableValue("");
    // setIsVariableLock(false);
    return variable
  }


  /**
   *
   * @param {*} token Access token retrieved to call Azure REST APIs using backend endpoints
   * JS method to call POST REST Endpoint for posting input of add variables to be created for project.
   */
  const callCreateVariableGroupAPI = async (token) => {

    showProgressBar(
      "Please be patient! While variable group is being created."
    );
    let config = {
      headers: { authorization: "Bearer " + token },
    };
    if (Object.keys(addedVariable).length > 0) {
      var singleVariables = await AddSingleVariables();
      setAddedVariable(singleVariables);
      console.log("singleVariables", singleVariables)
      var data = {
        projectName: project.name,
        organizationName: localStorage.getItem("organizationName"),
        variableGroupName: variableGroupName,
        description: variableGroupDescription,
        variables: singleVariables,
      };
    } else {
      let singleVariable = await AddSingleVariables();
      console.log("singleVariable", singleVariable)
      var data = {
        projectName: project.name,
        organizationName: localStorage.getItem("organizationName"),
        variableGroupName: variableGroupName,
        description: variableGroupDescription,
        variables: singleVariable,
      };
    }
    console.log("callCreateVariableGroupAPI==========>", variableKey, variableValue);
    console.log("addedVariables", Object.keys(addedVariable).length);

    // const data = {
    //   projectName: project.name,
    //   organizationName: localStorage.getItem("organizationName"),
    //   variableGroupName: variableGroupName,
    //   description: variableGroupDescription,
    //   variables: addedVariable,
    // };
    console.log("callCreateVariableGroupAPI==========>", data);
    axios
      .post(constants.BASE_URL + constants.GET_VARIABLE_GROUP, data, config)
      .then((response) => {
        hideProgressBar();
        clearVariableGroupValues();
        handleVariableGroupDialogClose();
        console.log(
          "callCreateVariableGroupAPI-Response============>",
          response
        );
        clearVariableGroupValues();
        onNewVariableGroupAdded();
      })
      .catch((error) => {
        hideProgressBar();
        setErrorAlertCallback({
          // eslint-disable-next-line
          message:
            error.response.status === 409
              ? error.response.data.body.message
              : "Something went wrong while creating variable group. Please try again!",
        });
        handleErrorAlert(true);
        console.log("callCreateVariableGroupAPI-Error============>", error);
      });
  };

  /**
   *
   * @param {*} token Access token retrieved to call Azure REST APIs using backend endpoints
   * JS method to call UPDATE REST Endpoint for posting new input of add variables to be created for project.
   */
  const callUpdateVariableGroupAPI = async (token) => {
    showProgressBar(
      "Please be patient! while variable group is being updated."
    );
    if (Object.keys(addedVariable).length > 0) {
      var singleVariables = await AddForEditVariables();
      setAddedVariable(singleVariables);
      console.log("singleVariables", singleVariables)
      var data = {
        projectName: project.name,
        organizationName: localStorage.getItem("organizationName"),
        variableGroupName: variableGroupName,
        description: variableGroupDescription,
        variables: singleVariables,
        groupId: variableGroupToEdit.id,
      };
    } else {
      let singleVariable = await AddSingleVariables();
      console.log("singleVariable", singleVariable)
      var data = {
        projectName: project.name,
        organizationName: localStorage.getItem("organizationName"),
        variableGroupName: variableGroupName,
        description: variableGroupDescription,
        variables: singleVariable,
        groupId: variableGroupToEdit.id,
      };
    }

    let config = {
      headers: { authorization: "Bearer " + token },
    };

    console.log("callUpdateVariableGroupAPI==========>", data);
    axios
      .put(constants.BASE_URL + constants.GET_VARIABLE_GROUP, data, config)
      .then((response) => {
        hideProgressBar();
        clearVariableGroupValues();
        handleVariableGroupDialogClose();
        console.log(
          "callUpdateVariableGroupAPI-Response============>",
          response
        );
        clearVariableGroupValues();
        onNewVariableGroupAdded();
      })
      .catch((error) => {
        hideProgressBar();
        setErrorAlertCallback({
          // eslint-disable-next-line
          message:
            error.response.status === 409
              ? error.response.data.body.message
              : "Something went wrong while creating variable group. Please try again!",
        });
        handleErrorAlert(true);
        console.log("callUpdateVariableGroupAPI-Error============>", error);
      });
  };

  /**
     * JS method called to retrieve token in getToken callback method
     */
  const onTokenForVariableGroupCreation = (token) => {
    isVariableEdit
      ? callUpdateVariableGroupAPI(token)
      : callCreateVariableGroupAPI(token);
  };

  /**
   * JS method to intialize variables added.
   */
  const initiateCreateVariableGroup = () => {
    console.log("edit1", JSON.stringify(addedVariable))
    console.log("edi2t", Object.keys(addedVariable));
    showProgressBar(
      "Please be patient! While variable group is being created."
    );
    getTokenForAPI(
      instance,
      inProgress,
      accounts,
      onTokenForVariableGroupCreation
    );
  };

  useEffect(() => {
    setVariableGroupDataToEdit(variableGroupToEdit);
    // eslint-disable-next-line
  }, [variableGroupToEdit]);

  /**
   * 
   * @param {*} variableGroup existing variable group
   * @returns update variable gruop
   */
  const setVariableGroupDataToEdit = (variableGroup) => {
    if (!isVariableEdit) {
      return;
    }
    setVariableGroupName(variableGroup.name);
    setVariableGroupDescription(variableGroup.description);
    setAddedVariable(variableGroup.variables);
  };

  /**
  *
  * @param {*} message String value to be shown with Progress Bar
  * JS method called to make the Progress Bar visible along with the message
  */
  const showProgressBar = (message) => {
    setIsVisible(true);
    setProgressBarMessage(message);
  };

  /**
   *
   * JS method called to hide the Progress Bar
   */
  const hideProgressBar = () => {
    setIsVisible(false);
    setProgressBarMessage("");
  };

  return (
    <Box>
      <Dialog
        open={variableGroupDialogIsOpen}
        onClose={onVariableGroupDialogClose}
      >
        <ProgressBar
          isVisible={isVisible}
          progressBarMessage={progressBarMessage}
        />
        <ErrorAlert
          isErrorVisible={isErrorVisible}
          callback={() => {
            setIsErrorVisible(false);
            if (
              errorAlertCallback.hasOwnProperty("navigate") &&
              errorAlertCallback.hasOwnProperty("navigateData")
            ) {
              navigate(
                errorAlertCallback.navigate,
                errorAlertCallback.navigateData
              );
            } else if (errorAlertCallback.hasOwnProperty("navigate")) {
              navigate(errorAlertCallback.navigate);
            }
          }}
          message={errorAlertCallback.message}
        />
        <DialogTitle className="addVariableDialog-dialogTitle">
          {isVariableEdit ? "Edit" : "Add"} Variable Group
        </DialogTitle>
        <DialogContent>
          <DialogContentText>
            To {isVariableEdit ? "edit" : "create"} variable group, please enter
            below details
          </DialogContentText>
          <Box className="addVariableDialog-box1">
            <Stack direction={"row"} spacing={2}>
              <TextField
                variant="outlined"
                fullWidth
                size="small"
                label="Variable Group Name"
                required
                name="variableGroupName"
                value={variableGroupName}
                error={!variableGroupName.length}
                helperText={
                  variableGroupName.length
                    ? ""
                    : "Please enter variable group name"
                }
                onChange={(event) => setVariableGroupName(event.target.value)}
              />

              <TextField
                variant="outlined"
                fullWidth
                size="small"
                name="description"
                label="Variable Group Description"
                required
                value={variableGroupDescription}
                error={!variableGroupDescription.length}
                helperText={
                  variableGroupDescription.length
                    ? ""
                    : "Please enter variable group description"
                }
                onChange={(event) =>
                  setVariableGroupDescription(event.target.value)
                }
              />
            </Stack>

            <Stack
              direction={"row"}
              justifyContent={"space-between"}
              mt={1}
              alignItems={"center"}
            >
              <Typography color={"#005689"}>Variables</Typography>
              <Stack direction={"row"} alignItems={"center"}>
                <Switch
                  onChange={(event) => {
                    setIsJsonSelected(event.target.checked);
                  }}
                />
                <Typography color={"#005689"}>Upload JSON</Typography>
              </Stack>
            </Stack>

            <Stack spacing={2} direction={"row"} ml={1} mt={1}>
              <Typography width={"100%"} variant="body2" color={"#007CB9"}>
                {"Name"}
              </Typography>
              <Typography width={"100%"} variant="body2" color={"#007CB9"}>
                {"Value"}
              </Typography>
              <IconButton disabled>
                <Delete className="addVariableDialog-delete" />
              </IconButton>
            </Stack>
            <Divider className="addVariableDialog-divider" />
            {Object.keys(addedVariable).map((name, index) => (
              <Stack
                spacing={2}
                direction={"row"}
                ml={1}
                flex={1}
                alignItems={"center"}
                key={index}
              >
                <Typography width={"50%"} flexWrap={"wrap"} noWrap>
                  {name}
                </Typography>
                <Typography width={"50%"} flexWrap={"wrap"} noWrap>
                  {addedVariable[name].isSecret
                    ? "****"
                    : addedVariable[name].value}
                </Typography>
                <IconButton
                  onClick={() => {
                    const variable = { ...addedVariable };
                    delete variable[name];
                    setAddedVariable(variable);
                  }}
                >
                  <Delete />
                </IconButton>
              </Stack>
            ))}
            {!isJsonSelected ? (
              <Box className="addVariableDialog-box2">
                <Stack spacing={1} direction={"row"} mt={1} mb={1} ml={1}>
                  <TextField
                    variant="standard"
                    fullWidth
                    size="small"
                    label="Variable Name"
                    name="variableKey"
                    value={variableKey}
                    error={Object.keys(addedVariable).includes(variableKey)}
                    helperText={
                      Object.keys(addedVariable).includes(variableKey)
                        ? `${variableKey} already exists in variable group`
                        : ""
                    }
                    onChange={(event) => setVariableKey(event.target.value)}
                  />

                  <TextField
                    variant="standard"
                    fullWidth
                    size="small"
                    label="Variable Value"
                    name="variableValue"
                    type={isVariableLock ? "password" : "text"}
                    value={variableValue}
                    onChange={(event) => setVariableValue(event.target.value)}
                  />
                  <IconButton
                    disabled={
                      !(
                        variableKey.trim().length &&
                        variableValue.trim().length &&
                        variableGroupName.trim().length &&
                        variableGroupDescription.trim().length &&
                        !Object.keys(addedVariable).includes(variableKey)
                      )
                    }
                    onClick={() => {
                      const variable = { ...addedVariable };
                      variable[variableKey] = {
                        value: variableValue,
                        isSecret: isVariableLock,
                      };
                      setAddedVariable(variable);
                      setVariableKey("");
                      setVariableValue("");
                      setIsVariableLock(false);
                    }}
                  >
                    <AddCircleOutlineSharpIcon className="addVariableDialog-addCircleOutlined" />
                  </IconButton>
                  <IconButton
                    onClick={() => {
                      setIsVariableLock((prev) => !prev);
                    }}
                  >
                    {isVariableLock ? <LockOutlined /> : <LockOpenOutlined />}
                  </IconButton>
                </Stack>
              </Box>
            ) : (
              <Box className="addVariableDialog-box2">
                <ColorButton
                  backgroundcolor="#005689"
                  variant="contained"
                  fontSize="14px"
                  component="label"
                  className="addVariableDialog-colourButton"
                  disabled={
                    !(
                      variableGroupName.length &&
                      variableGroupDescription.length
                    )
                  }
                  onChange={handleChangejsonFile}
                >
                  Upload JSON
                  <input hidden multiple type="file" value={""} />
                </ColorButton>
                <Typography
                  variant="subtitle2"
                  className={
                    jsonButtonError.includes("Invalid") ||
                      jsonButtonError.includes("delete")
                      ? "addVariableDialog-typography-red"
                      : "addVariableDialog-typography-blue"
                  }
                >
                  {variableGroupName.length && variableGroupDescription.length
                    ? jsonButtonError
                    : "Please enter Variable Group Name & Description first"}
                </Typography>
              </Box>
            )}
          </Box>
        </DialogContent>
        <DialogActions>
          <Button
            className="addVariableDialog-button-cancel"
            onClick={() => {
              handleVariableGroupDialogClose();
              clearVariableGroupValues();
            }}
          >
            Cancel
          </Button>
          <Button
            className="addVariableDialog-button-create"
            onClick={initiateCreateVariableGroup}
            disabled={
              !(
                (JSON.stringify(addedVariable).length > 2 || (variableKey.trim().length > 0 && variableValue.trim().length > 0)) &&
                variableGroupName.length &&
                variableGroupDescription.length
              )
            }
          >
            {isVariableEdit ? "Update" : "Create"}
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
