import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Avatar,
  ButtonBase,
  Card,
  CardContent,
  Chip,
  Divider,
  FormControl,
  FormControlLabel,
  FormLabel,
  Grid,
  IconButton,
  InputLabel,
  ListSubheader,
  MenuItem,
  Paper,
  Radio,
  RadioGroup,
  Select,
  Switch,
  TextField,
  Tooltip,
  Typography,
  debounce,
  tooltipClasses,
} from "@mui/material";
import "./projects.css";
import InfoOutlinedIcon from "@mui/icons-material/InfoOutlined";
import AddCircleOutlineSharpIcon from "@mui/icons-material/AddCircleOutlineSharp";
import { Box, Stack } from "@mui/system";
import React, { useEffect, useState } from "react";
import axios from "axios";
import { constants } from "../../../utils/Constants";
import ProgressBar from "../../../utils/ProgressBar";
import ErrorAlert from "../../error/ErrorAlert";
import { useLocation, useNavigate } from "react-router-dom";
import { ColorButton } from "../../../utils/CustomButton";
import List from "@mui/material/List";
import { Delete, ExpandMoreOutlined, LockOpenOutlined, LockOutlined } from "@mui/icons-material";
import { getTokenForAPI } from "../../../utils/RetrieveToken";
import { useMsal } from "@azure/msal-react";
import { stringAvatar } from "../../../utils/helper";
import { useMemo } from "react";
import { useRef } from "react";
import styled from "@emotion/styled";
import CustomBreadCrumb from "../../../utils/CustomBreadCrumb";
//import useWebSocket from 'react-use-websocket';
//import { w3cwebsocket as W3CWebSocket } from "websocket";
/**
 *
 * @returns React Functional Component (CreateProject) which renders a form to create project for an organization.
 */
export default function CreateProject() {
  const projectNameRegex = /([`~!@#$%^&*()_+\-=[\]{}|;':",./\\<>?])/;
  const [organizationRules, setOrganizationRules] = useState({
    _id: "",
    organizationName: "",
    namingStandard: "",
    createdBy: "",
    branchingModel: {
      _id: "",
      name: "",
      numberOfBranches: 0,
      branches: [],
      created_at: "",
      updated_at: "",
      __v: 0,
    },
    created_at: "",
    updated_at: "",
    __v: 0,
  });
  const location = useLocation();
  const { state } = location;
  const { instance, inProgress, accounts } = useMsal();
  const [projectName, setProjectName] = useState("");
  const [noOfReviewers, setNoOfReviewers] = useState("");
  const [projectDescription, setProjectDescription] = useState("");
  const [projectVisibility, setProjectVisibility] = useState("private");
  const [scmType, setScmType] = useState("");
  const [processType, setProcessType] = useState("");
  const [isVisible, setIsVisible] = React.useState(false);
  const [progressBarMessage, setProgressBarMessage] =
    React.useState("Please wait!");
  const [isErrorVisible, setIsErrorVisible] = React.useState(false);
  const [isJsonSelected, setIsJsonSelected] = React.useState(false);
  const [errorAlertCallback, setErrorAlertCallback] = React.useState({
    navigate: -1,
    navigateData: {
      state: {},
    },
    message: "Something unexpected happend! Please try again",
  });
  // eslint-disable-next-line
  const [msalToken, setMsalToken] = useState("");
  const navigate = useNavigate();
  // eslint-disable-next-line
  const [scmTypeList, setScmTypeList] = React.useState([
    {
      id: "0",
      name: "Git",
    },
    {
      id: "1",
      name: "TFVC",
    },
  ]);
  // eslint-disable-next-line
  const [technologyTypeList, setTechnologyTypeList] = React.useState([
    {
      id: "0",
      name: "Java",
      value: "java",
    },
    {
      id: "1",
      name: ".Net",
      value: "dotNet",
    },
  ]);
  const [isVariableLock, setIsVariableLock] = React.useState(false);
  const [pipelineName, setPipelineName] = React.useState("");
  const [technologyType, setTechnologyType] = React.useState("");
  const [publishArtifacts, setPublishArtifacts] = React.useState(false);
  const [processList, setProcessList] = React.useState([]);
  const [addedVariable, setAddedVariable] = React.useState({});
  const [variableKey, setVariableKey] = React.useState("");
  const [variableValue, setVariableValue] = React.useState("");
  const [variableGroupName, setVariableGroupName] = React.useState("");
  const [variableGroupDescription, setVariableGroupDescription] =
    React.useState("");
  const [userSearchQuery, setUserSearchQuery] = React.useState("");
  const [addUserList, setAddUserList] = React.useState([]);
  const [filteredUserList, setFilteredUserList] = React.useState([]);
  const [selectedUserList, setSelectedUserList] = React.useState([]);
  const [selectedReviewerList, setSelectedReviewerList] = React.useState([]);
  const [jsonButtonError, setJsonButtonError] = React.useState(
    "Upload a JSON file containing a JSON object of Name & Value pair for Variables"
  );
  //const [callHook, setCallHook] = useState(false);

  /////////////////////////////////////////////////////////////////////////
  // useEffect(() => {
  //   async function websocketWork() {
  //     if (callHook) {
  //       console.log('WS url:',constants.WEB_SOCKET_URL);
  //       const client = await new W3CWebSocket(constants.WEB_SOCKET_URL);
  //       client.onopen = () => {

  //         client.send(JSON.stringify('WS connection opened==>'));

  //       };
  //       client.onmessage = (message) => {

  //         console.log('Received Message', message.data);
  //         showProgressBar(message.data);
  //       }
  //       client.onclose = (message) => {
  //         console.log("Connection closed: " + message.data, message);
  //         hideProgressBar();

  //       };
  //     }
  //   }
  //   websocketWork();
  // }, [callHook]);


  /**
   *
   * @param {*} value boolean value to change visiblity of Alert Dialog
   * JS method to update the boolean state value isErrorVisible
   */
  const handleErrorAlert = (value) => {
    setIsErrorVisible(value);
  };

  /**
   *
   * @param {*} token Access token retrieved to call Azure REST APIs using backend endpoints
   * callback method called after token is retrieved from @azure/msal-browser dependency
   */
  const getToken = (token) => {
    hideProgressBar();
    setMsalToken(token);
    getAllProcesses(token);
  };

  /**
   *
   * @param {*} token Access token retrieved to call Azure REST APIs using backend endpoints
   * JS method to call GET REST Endpoint for retrieving all processes.
   */
  const getAllProcesses = (token) => {
    showProgressBar("Please be patient! While process are being fetched.");
    let config = {
      headers: { authorization: "Bearer " + token },
      params: {
        organizationName: localStorage.getItem("organizationName"),
      },
    };
    axios
      .get(constants.BASE_URL + constants.GET_ALL_PROCESSES, config)
      .then((response) => {
        hideProgressBar();
        setProcessList(response.data.body.processes);
        console.log("All_Processes", response.data.body.processes);
      })
      .catch((error) => {
        handleErrorAlert(true);
        hideProgressBar();
      });
  };

  /**
   *
   * @param {*} token Access token retrieved to call Azure REST APIs using backend endpoints
   * JS method to call GET REST Endpoint for retrieving organization rule.
   */
  const getRulesByOrganization = () => {
    showProgressBar(
      "Please be patient! While organization rule are being fetched."
    );
    let config = {
      params: {
        organizationName: localStorage.getItem("organizationName"),
        platform: "AzureDevops"
      },
    };
    axios
      .get(constants.BASE_URL + constants.GET_RULES_BY_ORGANIZTION, config)
      .then((response) => {
        hideProgressBar();
        console.log(
          "Response-getRulesByOrganization==============>",
          response.data.body.projectCreationRules
        );

        setNoOfReviewers(
          response.data.body.projectCreationRules.branchingModel.branches.find(
            // eslint-disable-next-line
            (branch) => branch.type == "default"
          ).noOfReviewers
        );

        const rules = response.data.body.projectCreationRules;
        setOrganizationRules(rules);
      })
      .catch((error) => {
        hideProgressBar();
      });
  };

  /**
     * JS method called to retrieve token in getToken callback method
     */
  const retrieveTokenForCreateProjectAPI = () => {
    //setCallHook(true);
    showProgressBar("Please be patient. While user is authorised");
    getTokenForAPI(instance, inProgress, accounts, callCreateProjectAPI);
  };

  /**
     * JS method called to retrieve token in getToken callback method
     */
  const callTokenForGetUser = () => {
    showProgressBar("Please be patient. While user is authorised");
    getTokenForAPI(instance, inProgress, accounts, callSearchUserAPI);
  };

  /**
   * 
   * @param {*} callback method to restrict the calling of a time-consuming function frequently
   * @returns 
   */
  const useDebounce = (callback) => {
    const ref = useRef();

    useEffect(() => {
      ref.current = callback;
    }, [callback]);

    const debouncedCallback = useMemo(() => {
      const func = () => {
        ref.current?.();
      };

      return debounce(func, 500);
    }, []);

    return debouncedCallback;
  };

  /**
   * 
   * @param {*} callback method to restrict the calling of a time-consuming function frequently
   * @returns 
   */
  const debouncedRequest = useDebounce(() => {
    console.log(userSearchQuery);
    const filterList = addUserList.filter((user) =>
      user.user.displayName
        .toLowerCase()
        .includes(userSearchQuery.toLowerCase())
    );
    setFilteredUserList(filterList.length > 0 ? filterList : addUserList);
  });

  /**
     * JS method called to handle the query input for searching the user to be added.
     */
  const retrieveTokenSearchUserAPI = (event) => {
    const userQuery = event.target.value;
    setUserSearchQuery(userQuery);
    debouncedRequest();
  };

  /**
   *
   * @param {*} token Access token retrieved to call Azure REST APIs using backend endpoints
   * JS method to call GET REST Endpoint for retrieving all avialble users for organizations
   */
  const callSearchUserAPI = async (token) => {
    console.log("Searching User", userSearchQuery);
    showProgressBar("Please be patient! While users are being fetched.");
    let config = {
      headers: { authorization: "Bearer " + token },
      params: {
        organizationName: localStorage.getItem("organizationName"),
        name: "",
      },
    };
    console.log("config ", config);
    axios
      .get(constants.BASE_URL + constants.GET_ADDUSER_LIST, config)
      .then((response) => {
        hideProgressBar();
        setAddUserList(response.data.body.users);
        setFilteredUserList(response.data.body.users);
        console.log("AddUser List", response.data.body.users);
      })
      .catch((error) => {
        console.log("Error-callSearchUserAPI==========>", error);
        hideProgressBar();
        // eslint-disable-next-line
        if (error && error.response && error.response.status == 404) {
          setErrorAlertCallback({
            message: error.response.data.body.message,
          });
          handleErrorAlert(true);
        }
      });
  };

  /**
  * 
  * @returns JS method to get mailAddress of selected users.
  */
  const getUsersToAdd = () => {
    const users = [];
    for (const user of [
      ...new Set([...selectedUserList, ...selectedReviewerList]),
    ]) {
      users.push(user.user.mailAddress);
    }
    return users;
  };

  /**
     * 
     * @returns JS method to add users as reviewers for the pipeline.
     */
  const getReviewersToAdd = () => {
    const users = [];
    for (const user of selectedReviewerList) {
      const reviewer = {
        id: user.id,
        isRequired: true,
      };
      users.push(reviewer);
    }
    return users;
  };

  const AddSingleVariables = () => {
    const variable = { ...addedVariable };
    if (variableKey.trim().length > 0) {
      variable[variableKey] = {
        value: variableValue,
        isSecret: isVariableLock,
      };
      setAddedVariable(variable);
      setVariableKey("");
      setVariableValue("");
      // setIsVariableLock(false);
    }
    return variable
  }

  /**
   *
   * @param {*} token Access token retrieved to call Azure REST APIs using backend endpoints
   * JS method to call POST REST Endpoint for POST inputs project to be created
   */
  const callCreateProjectAPI = async (token) => {

    showProgressBar("Please be patient! While project is being created.");
    // if (Object.keys(addedVariable).length > 0) {
    //   var singleVariables = await AddSingleVariables();
    //   setAddedVariable(singleVariables);
    //   console.log("singleVariables", singleVariables)
    // } else {
    //   let singleVariable = await AddSingleVariables();
    //   console.log("singleVariable", singleVariable)
    // }
    const data = {
      name: `${organizationRules.namingStandard}${projectName}`,
      projectCreatedByUser: instance.getActiveAccount().name,
      description: projectDescription,
      capabilities: {
        versioncontrol: {
          sourceControlType: scmType,
        },
        processTemplate: {
          templateTypeId: processType,
        },
      },
      visibility: projectVisibility,
      organizationName: localStorage.getItem("organizationName"),
      users: getUsersToAdd(),
    };
    if (
      pipelineName.length &&
      technologyType.length &&
      selectedReviewerList.length
    ) {
      data["pipeline"] = {
        applicationType: technologyType,
        userNameInitials: stringAvatar(
          instance.getActiveAccount() ? instance.getActiveAccount().name : ""
        ).children,
        pipelineName: pipelineName,
        publishArtifacts: publishArtifacts,
        reviewers: getReviewersToAdd(),
      };
    }
    if (variableGroupName.trim().length > 0 && variableGroupDescription.trim().length > 0) {
      if (Object.keys(addedVariable).length > 0) {
        var singleVariables = await AddSingleVariables();
        setAddedVariable(singleVariables);
        console.log("singleVariables", singleVariables)
        data["variableGroups"] = {
          variableGroupName: variableGroupName,
          description: variableGroupDescription,
          variables: singleVariables,
        };
      } else {
        let singleVariable = await AddSingleVariables();
        console.log("singleVariable", singleVariable)
        data["variableGroups"] = {
          variableGroupName: variableGroupName,
          description: variableGroupDescription,
          variables: singleVariable,
        };
      }
    } else {
      data["variableGroups"] = null;
    }

    console.log("callCreateProjectAPI==========>", data);
    let config = {
      headers: {
        authorization: "Bearer " + token,

      },
    };
    axios
      .post(constants.BASE_URL + constants.POST_PROJECT, data, config)
      .then((response) => {
        hideProgressBar();
        handleErrorAlert(true);
        setErrorAlertCallback({
          navigate: "/azure/project",
          message: `Project ${projectName} created successfully!`,
          navigateData: {
            state: {
              routeList: ["/azure"]
            },
          }
        });
        console.log("Response-callCreateProjectAPI========>", response);
      })
      .catch((error) => {
        hideProgressBar();
        if (error.response.status === 409) {
          setErrorAlertCallback({
            message: `Project ${organizationRules.namingStandard}${projectName} already exists`,
          });
        } else {
          setErrorAlertCallback({
            message:
              "Something went wrong while creating project. Please try again!",
          });
        }
        handleErrorAlert(true);
        console.log("Error-callCreateProjectAPI=========>", error);
      });
  };

  /**
   * 
   * @param {*} event method to handle project visibility type for project.
   */
  const handleProjectVisibilityChange = (event) => {
    setProjectVisibility(event.target.value);
  };

  /**
  * 
  * @param {*} event method to handle scm type for project.
  */
  const handleScmTypeChange = (event) => {
    setScmType(event.target.value);
  };

  /**
  * 
  * @param {*} event method to handle technology type for pipeline.
  */
  const handleTechnologyTypeChange = (event) => {
    setTechnologyType(event.target.value);
  };

  /**
  * 
  * @param {*} event method to handle publishArtifact type for pipeline.
  */
  const handlePublishArtifactTypeChange = (event) => {
    // eslint-disable-next-line
    setPublishArtifacts(event.target.value == "true");
  };

  /**
   * 
   * @param {*} event method to handle process type change for pipeline.
   */
  const handleProcessTypeChange = (event) => {
    setProcessType(event.target.value);
  };

  useEffect(() => {
    /**
     * JS method called to retrieve token in getToken callback method
     */
    getTokenForAPI(instance, inProgress, accounts, getToken);
    getRulesByOrganization();
    callTokenForGetUser();
    // eslint-disable-next-line
  }, [instance, accounts, inProgress]);

  /**
     * 
     * JS method validate project name.
     */
  const getProjectNameValidation = () => {
    return projectNameRegex.test(projectName) || projectName.length > 64;
  };

  /**
   * 
   * @param {*} e handles the JSON file input
   */
  const handleChangejsonFile = (e) => {
    const fileReader = new FileReader();
    fileReader.readAsText(e.target.files[0], "UTF-8");
    console.log("e.target.result", e.target.files[0].type);
    // eslint-disable-next-line
    if (e.target.files[0].type == "application/json") {
      fileReader.onload = (e) => {
        console.log("Result====>", typeof e.target.result);
        console.log("Parsed Result====>", JSON.parse(e.target.result));
        const duplicateVariables = [];
        for (const variable of Object.keys(JSON.parse(e.target.result))) {
          if (Object.keys(addedVariable).includes(variable)) {
            duplicateVariables.push(variable);
          }
        }
        if (duplicateVariables.length) {
          setJsonButtonError(
            `Variables (${duplicateVariables.toString()}) already exist in variable group. Please delete previous one or modify your JSON file`
          );
        } else {
          setAddedVariable({
            ...addedVariable,
            ...JSON.parse(e.target.result),
          });
          setJsonButtonError("");
        }
      };
    } else {
      console.log("not a file type");
      setJsonButtonError(
        "Invalid file selected! Please select a valid JSON file"
      );
    }
  };
  /**
   * display information about branching modal
   */
  const BranchMessage = `Below Branching Modal is for reference purpose only`;
  const HtmlTooltip = styled(({ className, ...props }) => (
    <Tooltip {...props} classes={{ popper: className }} />
  ))(({ theme }) => ({
    [`& .${tooltipClasses.tooltip}`]: {
      backgroundColor: "#007CB9",
      border: "1px solid #dadde9",
      fontSize: "14px",
    },
  }));

  /**
   *
   * @param {*} message String value to be shown with Progress Bar
   * JS method called to make the Progress Bar visible along with the message
   */
  const showProgressBar = (message) => {
    setIsVisible(true);
    setProgressBarMessage(message);
  };

  /**
   *
   * JS method called to hide the Progress Bar
   */
  const hideProgressBar = () => {
    setIsVisible(false);
    setProgressBarMessage("");
  };

  const handleLockChange = () => {
    setIsVariableLock((prev) => !prev)
  }

  return (
    <div>
      <ProgressBar
        isVisible={isVisible}
        progressBarMessage={progressBarMessage}
      />
      <ErrorAlert
        isErrorVisible={isErrorVisible}
        callback={() => {
          setIsErrorVisible(false);
          if (
            errorAlertCallback.hasOwnProperty("navigate") &&
            errorAlertCallback.hasOwnProperty("navigateData")
          ) {
            navigate(
              errorAlertCallback.navigate,
              errorAlertCallback.navigateData
            );
          } else if (errorAlertCallback.hasOwnProperty("navigate")) {
            navigate(errorAlertCallback.navigate);
          }
        }}
        message={errorAlertCallback.message}
      />
      <Box className="createProject-box1">
        <CustomBreadCrumb routeList={state.routeList} location={location.pathname} />
      </Box>
      <Box>
        <Typography
          className="createProject-typography1"
          variant="h6"
          mb={1}
        >
          Create Project for {localStorage.getItem("organizationName")}
        </Typography>
        <Divider />

        <Stack direction={"row"} spacing={2} mt={3}>
          <Stack direction={"column"} spacing={1} width={"50%"}>
            <Box>
              <TextField
                variant="outlined"
                fullWidth
                label="Project Name"
                required
                maxRows={4}
                error={getProjectNameValidation()}
                helperText={
                  !getProjectNameValidation()
                    ? ""
                    : "Please enter valid project name"
                }
                onChange={(event) => setProjectName(event.target.value)}
              />
              <Stack direction="row" spacing={1} alignItems="center">
                <Typography variant="body1" color="grey" fontSize={13}>
                  Final Project Name:
                </Typography>
                <Typography
                  variant="body1"
                  color="grey"
                  flexWrap={"wrap"}
                  noWrap
                >
                  {organizationRules.namingStandard}
                  {projectName}
                </Typography>
              </Stack>
            </Box>

            <TextField
              variant="outlined"
              fullWidth
              label="Description"
              maxRows={4}
              onChange={(event) => setProjectDescription(event.target.value)}
            />
            <Stack
              direction={"row"}
              spacing={2}
              alignItems={"flex-end"}
              pt={1.5}
            >
              <Stack direction={"column"} spacing={1} width={"50%"}>
                <Card variant="outlined">
                  <CardContent>
                    <Typography
                      mb={1}
                      mt={-0.5}
                      variant="body1"
                      color={"#005689"}
                    >
                      Project Visibility
                    </Typography>

                    <RadioGroup
                      defaultValue="private"
                      name="radio-buttons-group"
                      onChange={handleProjectVisibilityChange}
                      value={projectVisibility}
                    >
                      <Stack direction={"column"} mt={-1} mb={-2}>
                        <FormControlLabel
                          value="public"
                          control={
                            <Radio
                              className="createProject-radioGroup" />
                          }
                          label="Public"
                          disabled
                        />

                        <FormControlLabel
                          value="private"
                          control={
                            <Radio
                              className="createProject-radioGroup" />
                          }
                          label="Private"
                        />
                      </Stack>
                    </RadioGroup>
                  </CardContent>
                </Card>
              </Stack>

              <Stack direction={"column"} width={"50%"} spacing={2}>
                <FormControl fullWidth>
                  <InputLabel id="demo-simple-select-label">
                    SCM Type
                  </InputLabel>
                  <Select
                    labelId="demo-simple-select-label"
                    id="demo-simple-select"
                    value={scmType}
                    label="Version Control"
                    onChange={handleScmTypeChange}
                  >
                    {scmTypeList.map((type) => (
                      <MenuItem value={type.name} key={type.id}>
                        {type.name}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>

                <FormControl fullWidth>
                  <InputLabel id="demo-simple-select-label">
                    Process Type
                  </InputLabel>
                  <Select
                    labelId="demo-simple-select-label"
                    id="demo-simple-select"
                    value={processType}
                    label="Version Control"
                    onChange={handleProcessTypeChange}
                  >
                    {processList.map((type) => (
                      <MenuItem value={type.id} key={type.id}>
                        {type.name}
                      </MenuItem>
                    ))}
                  </Select>
                </FormControl>
              </Stack>
            </Stack>
          </Stack>

          <Stack direction={"column"} spacing={2} width={"50%"}>
            <TextField
              variant="outlined"
              fullWidth
              label="Default Repo Name"
              disabled
              value={`${organizationRules.namingStandard}${projectName}`}
            />
            <Stack direction={"column"}>
              <Stack direction={"row"} mb={2}>
                <Typography
                  className="createProject-typography2"
                  variant="body1"
                  fontSize={20}
                >
                  Branching Modal
                </Typography>
                <HtmlTooltip title={BranchMessage} placement="right-start">
                  <InfoOutlinedIcon
                    className="createProject-infoOutlined" />
                </HtmlTooltip>
              </Stack>
              <Divider />

              <Stack
                direction={"row"}
                justifyContent={"space-between"}
                mb={2}
                mt={1}
              >
                <Stack direction={"row"} mr={2}>
                  <Typography color={"#007CB9"} fontSize={16}>
                    Model Name:
                  </Typography>
                  <Typography
                    fontWeight={"bold"}
                    color={"#005689"}
                    fontSize={16}
                  >
                    {organizationRules.branchingModel.name}
                  </Typography>
                </Stack>
                <Stack direction={"row"}>
                  <Typography color={"#007CB9"} fontSize={16}>
                    Number Of Branches:
                  </Typography>
                  <Typography
                    fontWeight={"bold"}
                    color={"#005689"}
                    fontSize={16}
                  >
                    {organizationRules.branchingModel.numberOfBranches}
                  </Typography>
                </Stack>
              </Stack>

              {organizationRules.branchingModel.branches.length > 0 ? (
                organizationRules.branchingModel.branches.map(
                  (branch, index) => (
                    <Accordion key={index}>
                      <AccordionSummary
                        expandIcon={<ExpandMoreOutlined />}
                        aria-controls="panel1a-content"
                        id="panel1a-header"
                      >
                        <Typography className="createProject-typography3" >
                          Branch {index + 1}
                        </Typography>
                        <Chip label={branch.type} />
                      </AccordionSummary>
                      <AccordionDetails>
                        <Grid container justifyContent={"space-between"}>
                          <Grid item>
                            <Stack direction={"row"} spacing={1}>
                              <Typography color={"#007CB9"} fontSize={16}>
                                Branch Name:
                              </Typography>
                              <Typography
                                fontWeight={"bold"}
                                color={"#005689"}
                                fontSize={16}
                              >
                                {branch.name}
                              </Typography>
                            </Stack>
                          </Grid>
                          <Grid item>
                            <Stack direction={"row"} spacing={1}>
                              <Typography color={"#007CB9"} fontSize={16}>
                                Reviewers:
                              </Typography>
                              <Typography
                                fontWeight={"bold"}
                                color={"#005689"}
                                fontSize={16}
                              >
                                {branch.noOfReviewers}
                              </Typography>
                            </Stack>
                          </Grid>
                          <Grid item>
                            <Stack direction={"row"} spacing={1}>
                              <Typography color={"#007CB9"} fontSize={16}>
                                Merge Type:
                              </Typography>
                              <Typography
                                fontWeight={"bold"}
                                color={"#005689"}
                                fontSize={16}
                              >
                                {branch.mergeType}
                              </Typography>
                            </Stack>
                          </Grid>
                        </Grid>
                      </AccordionDetails>
                    </Accordion>
                  )
                )
              ) : (
                <></>
              )}
            </Stack>
          </Stack>
        </Stack>

        <Divider className="createProject-divider1" />
        <Stack direction={"row"} spacing={2}>
          <Box className="createProject-box2">
            <Accordion>
              <AccordionSummary
                expandIcon={<ExpandMoreOutlined />}
                aria-controls="panel1a-content"
                id="panel1a-header"
              >
                <Typography color={"#005689"} fontWeight={"bold"}>
                  Add Variables
                </Typography>
              </AccordionSummary>
              <AccordionDetails>
                <Box className="createProject-box3">
                  <Stack direction={"row"} spacing={2}>
                    <TextField
                      variant="outlined"
                      fullWidth
                      size="small"
                      label="Variable Group Name"
                      required
                      name="variableGroupName"
                      value={variableGroupName}
                      error={!variableGroupName.length}
                      helperText={
                        variableGroupName.length
                          ? ""
                          : "Please enter variable group name"
                      }
                      onChange={(event) =>
                        setVariableGroupName(event.target.value)
                      }
                    />

                    <TextField
                      variant="outlined"
                      fullWidth
                      size="small"
                      name="description"
                      label="Variable Group Description"
                      required
                      value={variableGroupDescription}
                      error={!variableGroupDescription.length}
                      helperText={
                        variableGroupDescription.length
                          ? ""
                          : "Please enter variable group description"
                      }
                      onChange={(event) =>
                        setVariableGroupDescription(event.target.value)
                      }
                    />
                  </Stack>
                  <Stack
                    direction={"row"}
                    justifyContent={"space-between"}
                    mt={1}
                    alignItems={"center"}
                  >
                    <Typography color={"#005689"}>Variables</Typography>
                    <Stack direction={"row"} alignItems={"center"}>
                      <Switch
                        onChange={(event) => {
                          setIsJsonSelected(event.target.checked);
                        }}
                      />
                      <Typography color={"#005689"}>Upload JSON</Typography>
                    </Stack>
                  </Stack>
                  <Stack spacing={2} direction={"row"} ml={1} mt={1}>
                    <Typography
                      width={"100%"}
                      variant="body2"
                      color={"#007CB9"}
                    >
                      {"Name"}
                    </Typography>
                    <Typography
                      width={"100%"}
                      variant="body2"
                      color={"#007CB9"}
                    >
                      {"Value"}
                    </Typography>
                    <IconButton disabled>
                      <Delete className="addVariableDialog-delete" />
                    </IconButton>
                  </Stack>
                  <Divider
                    className="addVariableDialog-divider" />
                  {Object.keys(addedVariable).map((name, index) => (
                    <Stack
                      spacing={2}
                      direction={"row"}
                      ml={1}
                      flex={1}
                      alignItems={"center"}
                      key={index}
                    >
                      <Typography width={"50%"} flexWrap={"wrap"} noWrap>
                        {name}
                      </Typography>
                      <Typography width={"50%"} flexWrap={"wrap"} noWrap>
                        {addedVariable[name].isSecret ? "****" : addedVariable[name].value}
                      </Typography>
                      <IconButton
                        onClick={() => {
                          const variable = { ...addedVariable };
                          delete variable[name];
                          setAddedVariable(variable);
                        }}
                      >
                        <Delete />
                      </IconButton>
                    </Stack>
                  ))}
                  {!isJsonSelected ? (
                    <Box className="addVariableDialog-box2">
                      <Stack spacing={1} direction={"row"} mt={1} mb={1} ml={1}>
                        <TextField
                          variant="standard"
                          fullWidth
                          size="small"
                          label="Variable Name"
                          name="variableKey"
                          value={variableKey}
                          error={Object.keys(addedVariable).includes(
                            variableKey
                          )}
                          helperText={
                            Object.keys(addedVariable).includes(variableKey)
                              ? `${variableKey} already exists in variable group`
                              : ""
                          }
                          onChange={(event) =>
                            setVariableKey(event.target.value)
                          }
                        />

                        <TextField
                          variant="standard"
                          fullWidth
                          size="small"
                          type={isVariableLock ? "password" : "text"}
                          label="Variable Value"
                          name="variableValue"
                          value={variableValue}
                          onChange={(event) =>
                            setVariableValue(event.target.value)
                          }
                        />
                        <IconButton
                          disabled={
                            !(
                              variableKey.trim().length &&
                              variableValue.trim().length &&
                              variableGroupName.trim().length &&
                              variableGroupDescription.trim().length &&
                              !Object.keys(addedVariable).includes(variableKey)
                            )
                          }
                          onClick={() => {
                            const variable = { ...addedVariable };
                            variable[variableKey] = {
                              value: variableValue,
                              isSecret: isVariableLock
                            };
                            setAddedVariable(variable);
                            setVariableKey("");
                            setVariableValue("");
                            setIsVariableLock(false);
                          }}
                        >
                          <AddCircleOutlineSharpIcon
                            className="createProject-addCircleOutlined" />
                        </IconButton>
                        <IconButton
                          onClick={handleLockChange}
                        >
                          {isVariableLock ? <LockOutlined /> : <LockOpenOutlined />}
                        </IconButton>
                      </Stack>
                    </Box>
                  ) : (
                    <Box className="addVariableDialog-box2">
                      <ColorButton
                        className="addVariableDialog-colourButton"
                        backgroundcolor="#005689"
                        variant="contained"
                        fontSize="14px"
                        component="label"
                        disabled={
                          !(
                            variableGroupName.length &&
                            variableGroupDescription.length
                          )
                        }
                        onChange={handleChangejsonFile}
                      >
                        Upload JSON
                        <input hidden multiple type="file" value={""} />
                      </ColorButton>
                      <Typography
                        className={jsonButtonError.includes("Invalid") || jsonButtonError.includes("delete") ? "addVariableDialog-typography-red" : "addVariableDialog-typography-blue"}
                        variant="subtitle2"
                      >
                        {variableGroupName.length &&
                          variableGroupDescription.length
                          ? jsonButtonError
                          : "Please enter Variable Group Name & Description first"}
                      </Typography>
                    </Box>
                  )}
                </Box>
              </AccordionDetails>
            </Accordion>
          </Box>
          <Box className="createProject-box2">
            <Accordion>
              <AccordionSummary
                expandIcon={<ExpandMoreOutlined />}
                aria-controls="panel1a-content"
                id="panel1a-header"
              >
                <Typography color={"#005689"} fontWeight={"bold"}>
                  Add CI Pipeline
                </Typography>
              </AccordionSummary>
              <AccordionDetails>
                <Stack spacing={2}>
                  <TextField
                    variant="outlined"
                    fullWidth
                    label="Default Repo Name"
                    disabled
                    value={`${organizationRules.namingStandard}${projectName}`}
                  />
                  <TextField
                    variant="outlined"
                    fullWidth
                    label="Pipeline Name"
                    error={!pipelineName.length}
                    required
                    helperText={
                      !pipelineName.length ? "Please enter Pipeline Name" : ""
                    }
                    onChange={(event) => setPipelineName(event.target.value)}
                  />
                </Stack>
                <Stack spacing={2} mt={2}>
                  <FormControl required>
                    <InputLabel id="demo-simple-select-label">
                      Technology Type
                    </InputLabel>
                    <Select
                      labelId="demo-simple-select-label"
                      id="demo-simple-select"
                      value={technologyType}
                      label="Version Control"
                      error={!technologyType.length}
                      onChange={handleTechnologyTypeChange}
                    >
                      {technologyTypeList.map((type) => (
                        <MenuItem value={type.value} key={type.id}>
                          {type.name}
                        </MenuItem>
                      ))}
                    </Select>
                  </FormControl>

                  <FormControl>
                    <FormLabel id="demo-row-radio-buttons-group-label">
                      Publish Artifacts
                    </FormLabel>
                    <RadioGroup
                      row
                      aria-labelledby="demo-row-radio-buttons-group-label"
                      name="row-radio-buttons-group"
                      value={publishArtifacts}
                      onChange={handlePublishArtifactTypeChange}
                    >
                      <FormControlLabel
                        className="createCIPipeline-formControlLevel"
                        value={true}
                        control={<Radio />}
                        label="Yes"
                      />
                      <FormControlLabel
                        className="createCIPipeline-formControlLevel"
                        value={false}
                        control={<Radio />}
                        label="No"
                      />
                    </RadioGroup>
                  </FormControl>
                </Stack>

                {pipelineName.length > 0 && technologyType.length > 0 ? (
                  <Box>
                    <Stack direction={"row"} spacing={2} width={"100%"}>
                      <Box width={"50%"} mt={2}>
                        {addUserList.length > 0 ? (
                          <Paper className="createProject-paper" variant="outlined">
                            <ListSubheader>Available Reviewers</ListSubheader>
                            <Divider />
                            <List
                              className="createProject-list">
                              {addUserList
                                .filter(
                                  (user) =>
                                    // eslint-disable-next-line
                                    user.accessLevel.licenseDisplayName ==
                                    "Basic"
                                )
                                .map((user, index) => (
                                  <Box key={index}>
                                    <ButtonBase
                                      focusRipple
                                      onClick={() => {
                                        console.log(user.user.displayName);
                                        if (
                                          selectedReviewerList.filter((e) => {
                                            return (
                                              // eslint-disable-next-line
                                              e.user.mailAddress ===
                                              user.user.mailAddress
                                            );
                                          }).length > 0 ||
                                          // eslint-disable-next-line
                                          selectedReviewerList.length ==
                                          noOfReviewers
                                        ) {
                                          return;
                                        }
                                        setSelectedReviewerList([
                                          ...selectedReviewerList,
                                          user,
                                        ]);
                                      }}
                                    >
                                      <Stack
                                        direction="row"
                                        spacing={1}
                                        alignItems="center"
                                        m={1}
                                      >
                                        <Avatar
                                          {...stringAvatar(
                                            user.user.displayName
                                          )}
                                        />
                                        <Typography>
                                          {user.user.displayName}
                                        </Typography>
                                      </Stack>
                                    </ButtonBase>
                                    <Divider />
                                  </Box>
                                ))}
                            </List>
                          </Paper>
                        ) : (
                          <></>
                        )}
                      </Box>
                      <Box width={"50%"}>
                        {selectedReviewerList.length > 0 ? (
                          <Box>
                            <Typography
                              className="createProject-typography4"
                              variant="h6"
                              gutterBottom
                            >
                              Selected Reviewers
                            </Typography>
                            <Divider />
                            {selectedReviewerList.map((user, index) => (
                              <Chip
                                className="addUserDialog-chip"
                                key={index}
                                label={user.user.displayName}
                                onDelete={() => {
                                  setSelectedReviewerList(
                                    selectedReviewerList.filter(
                                      (e) =>
                                        e.user.mailAddress !==
                                        user.user.mailAddress
                                    )
                                  );
                                }}
                              />
                            ))}
                          </Box>
                        ) : (
                          <></>
                        )}
                      </Box>
                    </Stack>
                    <Typography
                      variant="body1"
                      color="#007CB9"
                      fontSize={13}
                      fontWeight={"bold"}
                      mt={1}
                    >
                      Your organization policy require to review every commit.
                      Please add {noOfReviewers} reviewers for initial pipeline
                      commit to default branch.
                    </Typography>
                  </Box>
                ) : (
                  <></>
                )}
              </AccordionDetails>
            </Accordion>
          </Box>
        </Stack>

        <Box
          className="createProject-box4"
          variant="outlined"
        >
          <Typography
            className="addUserDialog-typography"
            variant="h6"
            gutterBottom
          >
            Add Project Users
          </Typography>
          <Divider className="createProject-divider2" />

          <Stack direction={"row"} spacing={2} width={"100%"}>
            <Box width={"50%"} mt={3}>
              <TextField
                variant="outlined"
                fullWidth
                label="Search User"
                placeholder="Please enter user name to search"
                onChange={retrieveTokenSearchUserAPI}
              />
              {filteredUserList.length > 0 ? (
                <Paper className="createProject-paper" variant="outlined">
                  <ListSubheader>Available Users</ListSubheader>
                  <Divider />
                  <List
                    className="createProject-list"
                  >
                    {filteredUserList.map((user, index) => (
                      <Box key={index}>
                        <ButtonBase
                          focusRipple
                          onClick={() => {
                            console.log(user.user.displayName);
                            if (
                              selectedUserList.filter((e) => {
                                return (
                                  e.user.mailAddress === user.user.mailAddress
                                );
                              }).length > 0
                            ) {
                              return;
                            }
                            setSelectedUserList([...selectedUserList, user]);
                          }}
                        >
                          <Stack
                            direction="row"
                            spacing={1}
                            alignItems="center"
                            m={1}
                          >
                            <Avatar {...stringAvatar(user.user.displayName)} />
                            <Typography>{user.user.displayName}</Typography>
                          </Stack>
                        </ButtonBase>
                        <Divider />
                      </Box>
                    ))}
                  </List>
                </Paper>
              ) : (
                <></>
              )}
            </Box>
            <Box width={"50%"}>
              {selectedUserList.length > 0 ||
                selectedReviewerList.length > 0 ? (
                <Box>
                  <Typography
                    className="createProject-typography5"
                    variant="h6"
                    gutterBottom
                  >
                    Selected Users
                  </Typography>
                  <Divider />
                  {[
                    ...new Set([...selectedUserList, ...selectedReviewerList]),
                  ].map((user, index) => (
                    <Chip
                      className="addUserDialog-chip "
                      key={index}
                      label={user.user.displayName}
                      onDelete={() => {
                        setSelectedUserList(
                          selectedUserList.filter(
                            (e) => e.user.mailAddress !== user.user.mailAddress
                          )
                        );
                      }}
                    />
                  ))}
                </Box>
              ) : (
                <></>
              )}
            </Box>
          </Stack>
        </Box>

        <Stack direction="row" justifyContent="flex-end" padding={2}>
          <ColorButton
            backgroundcolor="#005689"
            variant="contained"
            onClick={() => navigate(-1)}
          >
            BACK
          </ColorButton>
          <ColorButton
            className="createProject-button-create"
            backgroundcolor="#005689"
            variant="contained"
            onClick={retrieveTokenForCreateProjectAPI}
            disabled={
              !(projectName.length && scmType.length && processType.length)
            }
          // onClickCapture={ () =>  setPause(!isPaused)}
          >
            CREATE PROJECT
          </ColorButton>
        </Stack>
      </Box>
    </div>
  );
}
