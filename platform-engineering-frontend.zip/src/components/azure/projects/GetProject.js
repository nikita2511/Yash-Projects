import "./projects.css";
import * as React from "react";
import Paper from "@mui/material/Paper";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableContainer from "@mui/material/TableContainer";
import TableHead from "@mui/material/TableHead";
import TablePagination from "@mui/material/TablePagination";
import TableRow from "@mui/material/TableRow";
import ProgressBar from "../../../utils/ProgressBar";
import { useNavigate } from "react-router-dom";
import {
  Avatar,
  Card,
  Divider,
  IconButton,
  Stack,
  Tooltip,
  Typography,
  Box,
} from "@mui/material";
import { useEffect } from "react";
import { useMsal } from "@azure/msal-react";
import { getTokenForAPI } from "../../../utils/RetrieveToken";
import axios from "axios";
import { constants } from "../../../utils/Constants";
import ErrorAlert from "../../error/ErrorAlert";
import { ColorButton } from "../../../utils/CustomButton";
import { stringAvatar } from "../../../utils/helper";
import CustomBreadCrumb from "../../../utils/CustomBreadCrumb";
import { useLocation } from "react-router-dom";
import azureRepo from "../../../assets/azure-repo.png";
import azureCIPipeline from "../../../assets/azure-pipeline.png";
import azureVariable from "../../../assets/azure-variable.png";
import azureUser from "../../../assets/azure-user.png";
/**
 *
 * @returns React Functional Component (GetProjects) which renders all the available projects associated with the organization.
 */
const columns = [
  { id: "name", label: "Project Name", minWidth: 100 },
  { id: "description", label: "Description", minWidth: 100 },
  {
    id: "lastUpdateTime",
    label: "Last Update Time",
    minWidth: 100,
    format: (value) => new Date(value).toLocaleString(),
  },
  {
    id: "action",
    label: "",
    minWidth: 100,
  },
];
export default function GetProject() {
  const location = useLocation();
  const { state } = location;
  console.log("GetProject=======> State", state);
  const [page, setPage] = React.useState(0);
  const [rowsPerPage, setRowsPerPage] = React.useState(10);
  const [projectList, setProjectList] = React.useState([]);
  const [placeholderMessage, setPlaceholderMessage] = React.useState(
    "Please select organization to retrieve all available projects!"
  );
  const { instance, inProgress, accounts } = useMsal();
  const [isVisible, setIsVisible] = React.useState(false);
  const [progressBarMessage, setProgressBarMessage] =
    React.useState("Please wait!");
  const [isErrorVisible, setIsErrorVisible] = React.useState(false);
  const navigate = useNavigate();

  /**
   *
   * @param {*} token Access token retrieved to call Azure REST APIs using backend endpoints
   * callback method called after token is retrieved from @azure/msal-browser dependency
   */
  const getToken = (token) => {
    getAllProjectsByOrganizationName(token);
  };

  useEffect(() => {
    /**
     * JS method called to retrieve token in getToken callback method
     */
    getTokenForAPI(instance, inProgress, accounts, getToken);
    // eslint-disable-next-line
  }, [instance, accounts, inProgress]);

  /**
   *
   * @param {*} token Access token retrieved to call Azure REST APIs using backend endpoints
   * JS method to call GET REST Endpoint for retrieving user's all projects associated with the organizations
   */
  const getAllProjectsByOrganizationName = (token) => {
    showProgressBar("Please be patient! while projects are being fetched.");
    let config = {
      headers: { authorization: "Bearer " + token },
      params: {
        organizationName: localStorage.getItem("organizationName"),
      },
    };
    axios
      .get(constants.BASE_URL + constants.GET_PROJECTS, config)
      .then((response) => {
        console.log(
          "Reponse-getAllProjectsByOrganizationName=======>",
          response.data.body.projects
        );
        hideProgressBar();
        if (response.data.body.projects.length < 1) {
          setPlaceholderMessage(
            "No projects available for selected organization!"
          );
        }
        setProjectList(response.data.body.projects);
      })
      .catch((error) => {
        console.log("Error-getAllProjectsByOrganizationName========>", error);
        setProjectList([]);
        hideProgressBar();
        if (error.response.status === 404) {
          setPlaceholderMessage(
            "Organization not found! Please select a valid organization"
          );
        } else {
          handleErrorAlert(true);
          setPlaceholderMessage("Oops! Something went wrong");
        }
      });
  };

  const handleChangePage = (event, newPage) => {
    setPage(newPage);
  };

  const handleChangeRowsPerPage = (event) => {
    setRowsPerPage(+event.target.value);
    setPage(0);
  };
  /**
   *
   * @param {*} value boolean value to change visiblity of Alert Dialog
   * JS method to update the boolean state value isErrorVisible
   */
  const handleErrorAlert = (value) => {
    setIsErrorVisible(value);
  };

  /**
   *
   * JS method to handle the data of avilable project.
   */
  const GetTableRowData = ({ column, row }) => {
    const value = row[column.id];
    if (column.format && column.id === "lastUpdateTime") {
      return <Typography variant="body2">{column.format(value)}</Typography>;
    } else if (column.id === "name") {
      return (
        <Stack direction={"row"} spacing={2} alignItems={"center"}>
          <Avatar variant="rounded" {...stringAvatar(row["name"])} />
          <Typography variant="body2">{value}</Typography>
        </Stack>
      );
    } else if (column.id === "action") {
      return (
        <Stack direction={"row"}>
          <Tooltip title="Repository" arrow>
            <IconButton
              onClick={() => {
                navigate("/azure/projectInfo", {
                  state: {
                    project: row,
                    routeList: [...state.routeList, location.pathname],
                    tabId: 0,
                  },
                });
              }}
            >
              <img
                src={azureRepo}
                alt={"Repository"}
                loading="lazy"
                className="getProject-icon-img"
              />
            </IconButton>
          </Tooltip>
          <Tooltip title="CI Pipeline" arrow>
            <IconButton
              onClick={() => {
                navigate("/azure/projectInfo", {
                  state: {
                    project: row,
                    routeList: [...state.routeList, location.pathname],
                    tabId: 1,
                  },
                });
              }}
            >
              <img
                src={azureCIPipeline}
                alt={"CI Pipeline"}
                loading="lazy"
                className="getProject-icon-img"
              />
            </IconButton>
          </Tooltip>
          <Tooltip title="Variable Groups" arrow>
            <IconButton
              onClick={() => {
                navigate("/azure/projectInfo", {
                  state: {
                    project: row,
                    routeList: [...state.routeList, location.pathname],
                    tabId: 3,
                  },
                });
              }}
            >
              <img
                src={azureVariable}
                alt={"Variable Groups"}
                loading="lazy"
                className="getProject-icon-img"
              />
            </IconButton>
          </Tooltip>
          <Tooltip title="Users" arrow>
            <IconButton
              onClick={() => {
                navigate("/azure/projectInfo", {
                  state: {
                    project: row,
                    routeList: [...state.routeList, location.pathname],
                    tabId: 4,
                  },
                });
              }}
            >
              <img
                src={azureUser}
                alt={"Users"}
                loading="lazy"
                className="getProject-icon-img"
              />
            </IconButton>
          </Tooltip>
        </Stack>
      );
    } else {
      return <Typography variant="body2">{value}</Typography>;
    }
  };

  /**
   *
   * @param {*} message String value to be shown with Progress Bar
   * JS method called to make the Progress Bar visible along with the message
   */
  const showProgressBar = (message) => {
    setIsVisible(true);
    setProgressBarMessage(message);
  };

  /**
   *
   * JS method called to hide the Progress Bar
   */
  const hideProgressBar = () => {
    setIsVisible(false);
    setProgressBarMessage("");
  };

  return (
    <div>
      <ProgressBar
        isVisible={isVisible}
        progressBarMessage={progressBarMessage}
      />
      <ErrorAlert
        isErrorVisible={isErrorVisible}
        callback={() => {
          setIsErrorVisible(false);
          navigate(-1);
        }}
        message={"Something unexpected happend! Please try again"}
      />
      <Box mr={1} mb={1}>
        <CustomBreadCrumb
          routeList={state.routeList}
          location={location.pathname}
        />
      </Box>
      <Stack
        direction={"row"}
        justifyContent={"space-between"}
        mb={1}
        alignItems={"center"}
      >
        <Typography variant="h6" color={"#005689"} fontWeight={"bold"}>
          {localStorage.getItem("organizationName")}
        </Typography>
        <ColorButton
          backgroundcolor="#005689"
          variant="contained"
          size="small"
          onClick={() =>
            navigate("/azure/createProject", {
              state: {
                routeList: [...state.routeList, location.pathname],
              },
            })
          }
        >
          Create Project
        </ColorButton>
      </Stack>
      <Card className="getProject-card-project" raised={true}>
        <Typography variant="body1" color={"#005689"}>
          Available Projects
        </Typography>
        <Divider />
        <div>
          {projectList.length > 0 ? (
            <Paper className="getProject-paper-project">
              <TableContainer className="getProject-tableContainer">
                <Table stickyHeader aria-label="sticky table">
                  <TableHead>
                    <TableRow>
                      {columns.map((column) => (
                        <TableCell
                          key={column.id}
                          align={column.align}
                          size="medium"
                        >
                          <Typography variant="body2" color={"#007CB9"}>
                            {column.label}
                          </Typography>
                        </TableCell>
                      ))}
                    </TableRow>
                  </TableHead>
                  <TableBody>
                    {projectList
                      .slice(
                        page * rowsPerPage,
                        page * rowsPerPage + rowsPerPage
                      )
                      .map((row, index) => {
                        return (
                          <TableRow
                            hover
                            role="checkbox"
                            tabIndex={-1}
                            key={index}
                          >
                            {columns.map((column) => {
                              return (
                                <TableCell
                                  key={column.id}
                                  align={column.align}
                                  size="small"
                                  onClick={() => {
                                    if (column.id === "action") {
                                      return;
                                    }
                                    navigate("/azure/projectInfo", {
                                      state: {
                                        project: row,
                                        routeList: [
                                          ...state.routeList,
                                          location.pathname,
                                        ],
                                        tabId: 0,
                                      },
                                    });
                                  }}
                                  className="getProject-tableCell"
                                >
                                  <GetTableRowData column={column} row={row} />
                                </TableCell>
                              );
                            })}
                          </TableRow>
                        );
                      })}
                  </TableBody>
                </Table>
              </TableContainer>
              <TablePagination
                rowsPerPageOptions={[5, 10, 25]}
                component="div"
                count={projectList.length}
                rowsPerPage={rowsPerPage}
                page={page}
                onPageChange={handleChangePage}
                onRowsPerPageChange={handleChangeRowsPerPage}
              />
            </Paper>
          ) : (
            <Typography
              textAlign={"center"}
              color={"#005689"}
              fontWeight={"bold"}
              mt={2}
              variant="body1"
            >
              {placeholderMessage}
            </Typography>
          )}
        </div>
      </Card>
    </div>
  );
}
