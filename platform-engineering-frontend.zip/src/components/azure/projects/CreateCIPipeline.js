import {
  Avatar,
  Button,
  ButtonBase,
  Chip,
  DialogActions,
  DialogContent,
  DialogTitle,
  Divider,
  FormControl,
  FormControlLabel,
  FormLabel,
  InputLabel,
  List,
  ListSubheader,
  MenuItem,
  Paper,
  Radio,
  RadioGroup,
  Select,
  Stack,
  TextField,
  Typography,
} from "@mui/material";
import Dialog from "@mui/material/Dialog";
import { Box } from "@mui/system";
import React from "react";
import axios from "axios";
import { constants } from "../../../utils/Constants";
import ProgressBar from "../../../utils/ProgressBar";
import ErrorAlert from "../../error/ErrorAlert";
import { useLocation, useNavigate } from "react-router-dom";
import { getTokenForAPI } from "../../../utils/RetrieveToken";
import { useMsal } from "@azure/msal-react";
import { stringAvatar } from "../../../utils/helper";
import { ColorButton } from "../../../utils/CustomButton";
import { Add } from "@mui/icons-material";

/**
 *
 * @returns React Functional Component (CreateCIPipeline) which renders a dialog by which pipeline will be created for the project.
 */
export default function CreateCIPipeline({
  onNewCIPipelineAdded,
  projectRepositories,
  eligibleUsers,
}) {
  const [open, setOpen] = React.useState(false);
  const { state } = useLocation();
  const { instance, inProgress, accounts } = useMsal();
  const [isVisible, setIsVisible] = React.useState(false);
  const [progressBarMessage, setProgressBarMessage] =
    React.useState("Please wait!");
  const [isErrorVisible, setIsErrorVisible] = React.useState(false);
  const [errorAlertCallback, setErrorAlertCallback] = React.useState({
    navigate: -1,
    navigateData: {
      state: {},
    },
    message: "Something unexpected happend! Please try again",
  });
  // eslint-disable-next-line
  const navigate = useNavigate();
  const [repoName, setRepoName] = React.useState("");
  const [technologyType, setTechnologyType] = React.useState("");
  const [isPublishArtifact, setPublishArtifact] = React.useState(false);
  // eslint-disable-next-line
  const [technologyTypeList, setTechnologyTypeList] = React.useState([
    {
      id: "0",
      name: "Java",
      value: "java",
    },
    {
      id: "1",
      name: ".Net",
      value: "dotNet",
    },
  ]);
  const [pipelineName, setPipelineName] = React.useState("");
  // eslint-disable-next-line
  const [addUserList, setAddUserList] = React.useState([...eligibleUsers]);
  const [selectedUserList, setSelectedUserList] = React.useState([]);
  const [filteredUserList, setFilteredUserList] = React.useState([
    ...eligibleUsers,
  ]);
  const [noOfReviewers, setNoOfReviewers] = React.useState("");

  React.useEffect(() => {
    setAddUserList(eligibleUsers);
    setFilteredUserList(eligibleUsers);
  }, [eligibleUsers]);

  /**
   *
   * @param {*} token Access token retrieved to call Azure REST APIs using backend endpoints
   * JS method to call GET REST Endpoint for retrieving organization rule.
   */
  const callGetOrganizationRule = (token) => {
    showProgressBar("Please be patient! while information related to existing projet are being fetched");
    let config = {
      // headers: { authorization: "Bearer " + token },
      params: {
        organizationName: localStorage.getItem("organizationName"),
        platform: "AzureDevops"
      },
    };
    axios
      .get(constants.BASE_URL + constants.GET_RULES_BY_ORGANIZTION, config)
      .then((response) => {
        hideProgressBar();
        console.log(
          "Response-getRulesByOrganization==============>",
          response.data.body.projectCreationRules
        );
        const rules = response.data.body.projectCreationRules;
        setNoOfReviewers(rules.branchingModel.branches.find(    // eslint-disable-next-line
          (branch) => branch.type == "default"
        ).noOfReviewers)
      })
      .catch((error) => {
        // handleErrorAlert(true);
        hideProgressBar();
      });
  }
  /**
   * 
    * @returns JS method callback after dialog is opened. 
   */
  const handleClickOpen = () => {
    callGetOrganizationRule();
    setOpen(true);
  };

  /**
   * 
    * @returns JS method callback after dialog is closed. 
   */
  const handleCreateCIPipelineDialogClose = () => {
    setOpen(false);
    setRepoName("");
    setTechnologyType("");
    setPublishArtifact(false);
    setSelectedUserList([]);
  };

  /**
     * JS method called to retrieve token in getToken callback method
     */
  const retrieveTokenForCreateCIPipelineAPI = () => {
    showProgressBar("Please be patient! While user is authorised");
    getTokenForAPI(instance, inProgress, accounts, callCreateCIPipelineAPI);
  };

  /**
   * 
   * @returns JS method to add users as reviewers for the pipeline.
   */
  const getReviewersToAdd = () => {
    const users = [];
    for (const user of selectedUserList) {
      const reviewer = {
        id: user.id,
        isRequired: true,
      };
      users.push(reviewer);
    }
    return users;
  };

  /**
   * 
    * @returns JS method callback after dialog is closed. 
   */
  const handleCreateCIPipeline = () => {
    retrieveTokenForCreateCIPipelineAPI();
  };

  /**
   *
   * @param {*} token Access token retrieved to call Azure REST APIs using backend endpoints
   * JS method to call POST REST Endpoint for posting inputs for CIpipeline to be created for project.
   */
  const callCreateCIPipelineAPI = (token) => {
    showProgressBar("Please be patient! While CI pipeline is being created.");
    const data = {
      organizationName: localStorage.getItem("organizationName"),
      projectName: state.project.name,
      repoName: repoName,
      applicationType: technologyType,
      publishArtifacts: isPublishArtifact,
      userNameInitials: stringAvatar(
        instance.getActiveAccount() ? instance.getActiveAccount().name : ""
      ).children,
      pipelineName: pipelineName,
      reviewers: getReviewersToAdd()
    };
    console.log("handleCreateCIPipeline============>", data);
    let config = {
      headers: { authorization: "Bearer " + token },
    };
    axios
      .post(constants.BASE_URL + constants.POST_CREATE_CI_PIPELINE, data, config)
      .then((response) => {
        hideProgressBar();
        handleCreateCIPipelineDialogClose();
        onNewCIPipelineAdded();
        console.log("Response-callCreateCIPipelineAPI========>", response);
      })
      .catch((error) => {
        hideProgressBar();  // eslint-disable-next-line
        if (error.response.status == 409) {
          setErrorAlertCallback({
            message: error.response.data.body.errorMessage
          });
        } else {
          setErrorAlertCallback({
            message:
              "Something went wrong while creating CI Pipeline in project. Please try again!",
          });
        }
        handleErrorAlert(true);
        console.log("Error-callCreateCIPipelineAPI=========>", error.response);
      });
  };


  const handleClose = (event, reason) => {
    // eslint-disable-next-line
    if (reason && reason == "backdropClick") return;
    handleCreateCIPipelineDialogClose();
  };

  /**
   *
   * @param {*} value boolean value to change visiblity of Alert Dialog
   * JS method to update the boolean state value isErrorVisible
   */
  const handleErrorAlert = (value) => {
    setIsErrorVisible(value);
  };

  /**
   *
   * @param {*} message String value to be shown with Progress Bar
   * JS method called to make the Progress Bar visible along with the message
   */
  const showProgressBar = (message) => {
    setIsVisible(true);
    setProgressBarMessage(message);
  };

  /**
   *
   * JS method called to hide the Progress Bar
   */
  const hideProgressBar = () => {
    setIsVisible(false);
    setProgressBarMessage("");
  };

  /**
   * 
   * @param {*} event method to handle repository name for pipeline.
   */
  const handleRepoNameChange = (event) => {
    setRepoName(event.target.value);
  };

  /**
  * 
  * @param {*} event method to handle technology type for pipeline.
  */
  const handleTechnologyTypeChange = (event) => {
    setTechnologyType(event.target.value);
  };

  /**
   * 
   * @param {*} event method to handle publishArtifact type for pipeline.
   */
  const handlePublishArtifactChange = (event) => {  // eslint-disable-next-line
    setPublishArtifact(event.target.value == "true");
  };

  return (
    <Box>
      <ColorButton
        backgroundcolor="#005689"
        variant="contained"
        size="small"
        onClick={handleClickOpen}
        startIcon={<Add />}
      >
        New CI Pipeline
      </ColorButton>
      <Dialog open={open} onClose={handleClose}>
        <ProgressBar
          isVisible={isVisible}
          progressBarMessage={progressBarMessage}
        />
        <ErrorAlert
          isErrorVisible={isErrorVisible}
          callback={() => {
            setIsErrorVisible(false);
            if (
              errorAlertCallback.hasOwnProperty("navigate") &&
              errorAlertCallback.hasOwnProperty("navigateData")
            ) {
              navigate(
                errorAlertCallback.navigate,
                errorAlertCallback.navigateData
              );
            } else if (errorAlertCallback.hasOwnProperty("navigate")) {
              navigate(errorAlertCallback.navigate);
            }
          }}
          message={errorAlertCallback.message}
        />
        <DialogTitle
          className="createCIPipeline-dialogTitle">
          Create CI Pipeline
        </DialogTitle>
        <Divider className="createCIPipeline-divider" />
        <DialogContent>
          <Box variant="outlined" >
            <FormControl fullWidth>
              <InputLabel id="demo-simple-select-label" required>
                Repository Name
              </InputLabel>
              <Select
                labelId="demo-simple-select-label"
                id="demo-simple-select"
                value={repoName}
                label="Repository Name"
                onChange={handleRepoNameChange}
              >
                {projectRepositories.map((repo, index) => (
                  <MenuItem value={repo.name} key={repo.name}>
                    {repo.name}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>

            <FormControl className="createCIPipeline-formControl1"
              fullWidth
            >
              <InputLabel id="demo-simple-select-label" required>
                Technology Type
              </InputLabel>
              <Select
                labelId="demo-simple-select-label"
                id="demo-simple-select"
                value={technologyType}
                label="Technology Type"
                onChange={handleTechnologyTypeChange}
              >
                {technologyTypeList.map((type) => (
                  <MenuItem value={type.value} key={type.id}>
                    {type.name}
                  </MenuItem>
                ))}
              </Select>
            </FormControl>

            <TextField
              variant="outlined"
              fullWidth
              label="Pipeline Name"
              required
              onChange={(event) => setPipelineName(event.target.value)}
            />

            <FormControl className="createCIPipeline-formControl2">
              <FormLabel id="demo-row-radio-buttons-group-label">
                Publist Artifacts
              </FormLabel>
              <RadioGroup
                className="createCIPipeline-radioGroup"
                row
                aria-labelledby="demo-row-radio-buttons-group-label"
                name="row-radio-buttons-group"
                onChange={handlePublishArtifactChange}
                value={isPublishArtifact}
              >
                <FormControlLabel
                  className="createCIPipeline-formControlLevel"
                  value={true}
                  control={<Radio />}
                  label="Yes"
                />
                <FormControlLabel
                  className="createCIPipeline-formControlLevel"
                  value={false}
                  control={<Radio />}
                  label="No"
                />
              </RadioGroup>
            </FormControl>
            <Box
              className="createCIPipeline-box1"
              variant="outlined"
            >
              {pipelineName.trim().length &&
                technologyType.trim().length &&
                repoName.trim().length ? (
                <Box>
                  <Stack direction={"row"} spacing={2}>
                    <Box>
                      {filteredUserList.length > 0 ? (
                        <Paper
                          className="createCIPipeline-paper"
                          variant="outlined"
                        >
                          <ListSubheader>Available Reviewers</ListSubheader>
                          <Divider />
                          <List
                            className="createCIPipeline-list">
                            {filteredUserList.map((user, index) => (
                              <Box key={index}>
                                <ButtonBase
                                  focusRipple
                                  onClick={() => {
                                    console.log(user.user.displayName);
                                    if (
                                      selectedUserList.filter((e) => {
                                        return (
                                          e.user.mailAddress ===
                                          user.user.mailAddress
                                        );
                                      }).length > 0 ||  // eslint-disable-next-line
                                      selectedUserList.length == noOfReviewers
                                    ) {
                                      return;
                                    }
                                    setSelectedUserList([
                                      ...selectedUserList,
                                      user,
                                    ]);
                                  }}
                                >
                                  <Stack
                                    direction="row"
                                    spacing={1}
                                    alignItems="center"
                                    m={1}
                                  >
                                    <Avatar
                                      {...stringAvatar(user.user.displayName)}
                                    />
                                    <Typography>
                                      {user.user.displayName}
                                    </Typography>
                                  </Stack>
                                </ButtonBase>
                                {// eslint-disable-next-line
                                  index != filteredUserList.length - 1 ? (
                                    <Divider />
                                  ) : (
                                    <></>
                                  )}
                              </Box>
                            ))}
                          </List>
                        </Paper>
                      ) : (
                        <></>
                      )}
                    </Box>
                    <Box>
                      {selectedUserList.length > 0 ? (
                        <Box>
                          <Typography
                            className="createCIPipeline-typography1"
                            variant="h6"
                            fontSize={14}
                          >
                            Selected Reviewers
                          </Typography>
                          <Divider />
                          <Box className="createCIPipeline-box2">
                            {selectedUserList.map((user, index) => (
                              <Chip
                                className="createCIPipeline-chip"
                                key={index}
                                label={user.user.displayName}
                                onDelete={() => {
                                  setSelectedUserList(
                                    selectedUserList.filter(
                                      (e) =>
                                        e.user.mailAddress !==
                                        user.user.mailAddress
                                    )
                                  );
                                }}
                              />
                            ))}
                          </Box>
                        </Box>
                      ) : (
                        <></>
                      )}
                    </Box>
                  </Stack>
                  <Typography
                    variant="body1"
                    color="#007CB9"
                    fontSize={13}
                    fontWeight={"bold"}
                    mt={1}
                  >
                    Your organization policy require to review every commit.
                    Please add {noOfReviewers} reviewers for initial pipeline
                    commit to default branch. Also, you need to add user in the
                    project to make them reviewer if already not present.
                  </Typography>
                  <Typography
                    variant="body1"
                    color="#007CB9"
                    fontSize={13}
                    fontWeight={"bold"}
                    mt={1}
                  >
                    Also, you need to add user in the project to make them
                    reviewer if already not present.
                  </Typography>
                </Box>
              ) : (
                <></>
              )}
            </Box>
          </Box>
        </DialogContent>
        <DialogActions>
          <Button className="createCIPipeline-button-cancel"
            onClick={handleClose}
          >
            Cancel
          </Button>
          <Button
            className="createCIPipeline-button-create"
            disabled={
              !(
                repoName.trim().length &&
                technologyType.trim().length && // eslint-disable-next-line
                selectedUserList.length == noOfReviewers &&
                pipelineName.trim().length
              )
            }
            onClick={handleCreateCIPipeline}
          >
            Create CI Pipeline
          </Button>
        </DialogActions>
      </Dialog>
    </Box>
  );
}
