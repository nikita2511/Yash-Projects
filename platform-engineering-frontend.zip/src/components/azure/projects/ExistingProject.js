import React, { useEffect, useState } from "react";
import { Box, Card, Divider, Stack, Typography } from "@mui/material";
import ProjectTabs from "./ProjectTabs";
import { useLocation } from "react-router-dom";
import Button from "@mui/material/Button";
import Dialog from "@mui/material/Dialog";
import DialogActions from "@mui/material/DialogActions";
import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogTitle from "@mui/material/DialogTitle";
import axios from "axios";
import { constants } from "../../../utils/Constants";
import { useMsal } from "@azure/msal-react";
import { getTokenForAPI } from "../../../utils/RetrieveToken";
import { useNavigate } from "react-router-dom";
import ProgressBar from "../../../utils/ProgressBar";
import ErrorAlert from "../../error/ErrorAlert";
import AddUsersDialog from "./AddUsersDialog";
import CustomBreadCrumb from "../../../utils/CustomBreadCrumb";
import CreateCIPipeline from "./CreateCIPipeline";
import CreateRepoDialog from "./CreateRepoDialog";
import AddVariablesDialog from "./AddVarialblesDialog";
import { ColorButton } from "../../../utils/CustomButton";
import { Add } from "@mui/icons-material";
import CreateReleasePipeline from "./CreateReleasePipeline";

/**
 *
 * @returns React Functional Component (ExistingProject) which renders all the available information of existing project.
 */
export default function ExistingProject() {
  const location = useLocation();
  const { state } = location;
  const { instance, inProgress, accounts } = useMsal();
  const navigate = useNavigate();
  const [isVisible, setIsVisible] = React.useState(false);
  const [progressBarMessage, setProgressBarMessage] =
    React.useState("Please wait!");
  const [isErrorVisible, setIsErrorVisible] = React.useState(false);
  const [errorAlertCallback, setErrorAlertCallback] = React.useState({
    navigate: -1,
    navigateData: {
      state: {},
    },
    message: "Something unexpected happend! Please try again",
  });
  const [projectRepositories, setProjectRepositories] = useState([]);
  const [projectPipelines, setProjectPipelines] = useState([]);
  const [projectVariableGroups, setProjectVariableGroups] = useState([]);
  const [existingProjectUsers, setExistingProjectUsers] = useState([]);
  const [variableGroupDialogIsOpen, setVariableGroupDialogIsOpen] =
    useState(false);
  const [isVariableEdit, setIsVariableEdit] = React.useState(false);
  const [variableGroupToEdit, setVariableGroupToEdit] = React.useState({});
  const [existingUserToDelete, setExistingUserToDelete] = React.useState({});
  const [isConfirmDeleteOpen, setIsConfirmDeleteOpen] = React.useState(false);
  const [releasePipeline, setReleasePipeline] = useState([]);

  /**
   * 
   * @param {*} user alredy exist in project
   * @returns set new user list
   */
  const onDeleteExistingUser = (user) => {
    console.log("onDeleteExistingUser==========>", user);
    setExistingUserToDelete(user);
    setIsConfirmDeleteOpen(true);
  };

  /**
     * JS method called to retrieve token in getTokenForAPI callback method
     */
  const callGetTokenForDeleteExistingUserAPI = () => {
    showProgressBar("Please be patient. While user is authorised");
    getTokenForAPI(
      instance,
      inProgress,
      accounts,
      onTokenForDeleteExistingUser
    );
  };

  /**
  * 
   * @returns JS method callback after retrieving token. 
  */
  const onTokenForDeleteExistingUser = (token) => {
    hideProgressBar();
    callDeleteExistingUserAPI(token);
  };

  /**
  *
  * @param {*} token Access token retrieved to call Azure REST APIs using backend endpoints
  * JS method to call DELETE REST Endpoint for deleting user from project.
  */
  const callDeleteExistingUserAPI = (token) => {
    showProgressBar("Please be patient! While user is being deleted");
    const data = {
      organizationName: localStorage.getItem("organizationName"),
      projectId: state.project.id,
      userIds: [existingUserToDelete.id],
    };
    let config = {
      headers: { authorization: "Bearer " + token },
      data,
    };
    console.log("onTokenForDeleteExistingUser==========>", config);
    axios
      .delete(constants.BASE_URL + constants.GET_ADDUSER_LIST, config)
      .then((response) => {
        console.log(
          "callDeleteExistingUserAPI-Response============>",
          response
        );
        hideProgressBar();
        setIsConfirmDeleteOpen(false);
        getTokenForExistingUsers();
      })
      .catch((error) => {
        hideProgressBar();
        console.log("callDeleteExistingUserAPI-Error============>", error);
        handleErrorAlert(true);
        setErrorAlertCallback({
          message:
            "Something went wrong while creating repository. Please try again!",
        });
      });
  };

  /**
   * 
   * @returns boolean to rendering dialog conditionally.
   */
  const handleVariableGroupDialogOpen = () =>
    setVariableGroupDialogIsOpen(true);

  /**
 *
 * @param {*} value boolean value to change visiblity of Alert Dialog
 * JS method to update the boolean state value isErrorVisible
 */
  const handleErrorAlert = (value) => {
    setIsErrorVisible(value);
  };

  /**
   *
   * @param {*} token Access token retrieved to call Azure REST APIs using backend endpoints
   * JS method to call GET REST Endpoint for retrieving variable groups.
   */
  const callGetVariableGroupsForProject = (token) => {
    showProgressBar(
      "Please be patient! while information related to existing projet are being fetched."
    );
    let config = {
      headers: { authorization: "Bearer " + token },
      params: {
        organizationName: localStorage.getItem("organizationName"),
        projectName: state.project.name,
      },
    };
    axios
      .get(constants.BASE_URL + constants.GET_VARIABLE_GROUP, config)
      .then((response) => {
        hideProgressBar();
        console.log(
          "Reponse-callGetVariableGroupsForProject=======>",
          response.data.body.getVariableGroup
        );
        setProjectVariableGroups(response.data.body.getVariableGroup);
      })
      .catch((error) => {
        hideProgressBar();
        console.log("Error-callGetVariableGroupsForProject========>", error);
        handleErrorAlert(true);
        setErrorAlertCallback({
          message:
            "Something went wrong while fetching variable groups. Please try again!",
        });
        setProjectVariableGroups([]);
      });
  };

  /**
   *
   * @param {*} token Access token retrieved to call Azure REST APIs using backend endpoints
   * JS method to call GET REST Endpoint for retrieving repositories.
   */
  const callGetRepoForProject = (token) => {
    showProgressBar(
      "Please be patient! while information related to existing projet are being fetched"
    );
    let config = {
      headers: { authorization: "Bearer " + token },
      params: {
        organizationName: localStorage.getItem("organizationName"),
        projectName: state.project.name,
      },
    };
    axios
      .get(constants.BASE_URL + constants.GET_REPOSITORIES, config)
      .then((response) => {
        hideProgressBar();
        console.log(
          "Reponse-callGetRepoForProject=======>",
          response.data.body.listRepositories
        );
        setProjectRepositories(response.data.body.listRepositories);
      })
      .catch((error) => {
        hideProgressBar();
        console.log("Error-callGetRepoForProject========>", error);
        handleErrorAlert(true);
        setErrorAlertCallback({
          message:
            "Something went wrong while fetching repositories. Please try again!",
        });
        setProjectRepositories([]);
      });
  };

  /**
  *
  * @param {*} token Access token retrieved to call Azure REST APIs using backend endpoints
  * JS method to call GET REST Endpoint for retrieving CIpipelines.
  */
  const callGetPipelineForProject = (token) => {
    showProgressBar(
      "Please be patient! while information related to existing projet is being fetched"
    );
    let config = {
      headers: { authorization: "Bearer " + token },
      params: {
        organizationName: localStorage.getItem("organizationName"),
        projectName: state.project.name,
      },
    };
    axios
      .get(constants.BASE_URL + constants.GET_PIPELINES, config)
      .then((response) => {
        hideProgressBar();
        console.log(
          "Reponse-callGetPipelineForProject=======>",
          response.data.body.listPipelines
        );
        setProjectPipelines(response.data.body.listPipelines.value);
      })
      .catch((error) => {
        hideProgressBar();
        console.log("Error-callGetPipelineForProject========>", error);
        handleErrorAlert(true);
        setErrorAlertCallback({
          message:
            "Something went wrong while fetching pipelines. Please try again!",
        });
        setProjectPipelines([]);
      });
  };

  /**
  *
  * @param {*} token Access token retrieved to call Azure REST APIs using backend endpoints
  * JS method to call GET REST Endpoint for retrieving existing users.
  */
  const callGetExistingProjectUsers = (token) => {
    console.log(
      "callGetExistingProjectUsers>>>>>>>>>>>>>>>>>>>>>>..",
      state.project.id
    );
    showProgressBar(
      "Please be patient! while information related to existing projet are being fetched"
    );
    let config = {
      headers: { authorization: "Bearer " + token },
      params: {
        organizationName: localStorage.getItem("organizationName"),
        projectId: state.project.id,
      },
    };
    axios
      .get(constants.BASE_URL + constants.GET_PROJECT_MEMBERS, config)
      .then((response) => {
        hideProgressBar();
        console.log(
          "Reponse-callGetExistingProjectUsers=======>",
          response.data.body.data.members
        );
        setExistingProjectUsers(response.data.body.data.members);
      })
      .catch((error) => {
        hideProgressBar();
        console.log("Error-callGetExistingProjectUsers========>", error);
        handleErrorAlert(true);
        setErrorAlertCallback({
          message:
            "Something went wrong while fetching variable groups. Please try again!",
        });
        setExistingProjectUsers([]);
      });
  };


  const callGetReleasePipeline = (token) => {
    console.log(
      "callGetReleasePipelines>>>>>>>>>>>>>>>>>>>>>>..",
      state.project.id
    );
    showProgressBar(
      "Please be patient! while information related to existing projet are being fetched"
    );
    let config = {
      headers: { authorization: "Bearer " + token },
      params: {
        organizationName: localStorage.getItem("organizationName"),
        projectName: state.project.name,
      },
    };
    axios
      .get(constants.BASE_URL + constants.GET_RELEASE_PIPELINE, config)
      .then((response) => {
        hideProgressBar();
        console.log(
          "Reponse-callGetReleasePipelines=======>",
          response.data.body.releasePipelines.value
        );
        setReleasePipeline(response.data.body.releasePipelines.value);
      })
      .catch((error) => {
        hideProgressBar();
        console.log("Error-callGetReleasePipeline========>", error);
        handleErrorAlert(true);
        setErrorAlertCallback({
          message:
            "Something went wrong while fetching variable groups. Please try again!",
        });
        setReleasePipeline([]);
      });
  };
  /**
    * JS method called to retrieve token in getToken.... callback method
    */
  const onTokenForRepoList = (token) => {
    callGetRepoForProject(token);
  };
  /**
    * JS method called to retrieve token in getToken.... callback method
    */
  const onTokenForReleasePipeline = (token) => {
    callGetReleasePipeline(token);
  };

  /**
    * JS method called to retrieve token in getToken.... callback method
    */
  const onTokenForPipelineList = (token) => {
    callGetPipelineForProject(token);
  };

  /**
    * JS method called to retrieve token in getToken.... callback method
    */
  const getTokenForRepoList = () => {
    getTokenForAPI(instance, inProgress, accounts, onTokenForRepoList);
  };

  /**
    * JS method called to retrieve token in getToken.... callback method
    */
  const getTokenForReleasePipeline = () => {
    getTokenForAPI(instance, inProgress, accounts, onTokenForReleasePipeline);
  };

  /**
    * JS method called to retrieve token in getToken.... callback method
    */
  const getTokenForPipelineList = () => {
    getTokenForAPI(instance, inProgress, accounts, onTokenForPipelineList);
  };

  /**
    * JS method called to retrieve token in getToken.... callback method
    */
  const onTokenForVariableGroupList = (token) => {
    callGetVariableGroupsForProject(token);
  };

  /**
    * JS method called to retrieve token in getToken.... callback method
    */
  const onTokenForExistingUsers = (token) => {
    callGetExistingProjectUsers(token);
  };

  /**
    * JS method called to retrieve token in getToken.... callback method
    */
  const getTokenForVariableGroupList = () => {
    getTokenForAPI(instance, inProgress, accounts, onTokenForVariableGroupList);
  };

  /**
    * JS method called to retrieve token in getToken.... callback method
    */
  const getTokenForExistingUsers = () => {
    getTokenForAPI(instance, inProgress, accounts, onTokenForExistingUsers);
  };

  /**
    * JS method called to retrieve token in getToken.... callback method
    */
  const onNewUserAdded = () => {
    getTokenForExistingUsers();
    setTabId(4);
  };

  /**
    * JS method called to retrieve token in getToken.... callback method
    */
  const onNewVariableGroupAdded = () => {
    getTokenForVariableGroupList();
    setTabId(3);
  };

  useEffect(() => {
    showProgressBar(
      "Please be patient! while information related to existing projet are being fetched"
    );
    /**
     * JS method called to retrieve token in getToken.... callback method
     */
    getTokenForRepoList();
    getTokenForVariableGroupList();
    getTokenForExistingUsers();
    getTokenForPipelineList();
    getTokenForReleasePipeline();
    // eslint-disable-next-line
  }, [instance, accounts, inProgress]);

  const [tabId, setTabId] = useState(0);

  useEffect(() => {
    setTabId(state.tabId);
    // eslint-disable-next-line
  }, [state.tabId]);

  const ConfirmDeleteUserAlert = () => {
    return (
      <Dialog
        open={isConfirmDeleteOpen}
        onClose={() => {
          setIsConfirmDeleteOpen(false);
        }}
      >
        <DialogTitle
          color={"#005689"}
          fontWeight={"bold"}
        >
          Alert
        </DialogTitle>
        <DialogContent>
          <DialogContentText>
            {existingUserToDelete.hasOwnProperty("user")
              ? `Are you sure you want to remove ${existingUserToDelete.user.displayName} from ${state.project.name}? `
              : ""}
            <br />
            Click Remove to confirm else click cancel.
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button
            onClick={() => {
              setIsConfirmDeleteOpen(false);
            }}
            className="existingProject-deleteUserDialog-cancel-button"
          >
            Cancel
          </Button>
          <Button
            onClick={callGetTokenForDeleteExistingUserAPI}
            className="existingProject-deleteUserDialog-remove-button"
          >
            Remove
          </Button>
        </DialogActions>
      </Dialog>
    );
  };

  /**
  * 
  * @param {*} variableGroup existing variable group
  * @returns update variable gruop
  */
  const onEditVariableGroup = (variableGroup) => {
    console.log("onEditVariableGroup=========>", variableGroup);
    setIsVariableEdit(true);
    setVariableGroupToEdit(variableGroup);
    handleVariableGroupDialogOpen();
  };

  /**
 * JS method to handle add new CIpipeline
 */
  const onNewCIPipelineAdded = () => {
    getTokenForPipelineList();
    setTabId(1);
  };

  /**
 * JS method to handle add new repository with pipeline
 */
  const onNewRepoAddedWithPipeline = () => {
    getTokenForPipelineList();
    getTokenForRepoList();
    setTabId(0);
  }
  /**
   * JS method to handle add new repository
   */
  const onNewRepoAdded = () => {
    getTokenForRepoList();
    setTabId(0);
  };

  /**
   * 
   * @param {*} id set tab id
   * to render different tab based on id
   */
  const onProjectTabChange = (id) => {
    setTabId(id);
  };

  /**
   *
   * @param {*} message String value to be shown with Progress Bar
   * JS method called to make the Progress Bar visible along with the message
   */
  const showProgressBar = (message) => {
    setIsVisible(true);
    setProgressBarMessage(message);
  };

  /**
    *
    * JS method called to hide the Progress Bar
    */
  const hideProgressBar = () => {
    setIsVisible(false);
    setProgressBarMessage("");
  };

  /**
     * JS method called just after the closing dialog, updating states of  atributes
     */
  const handleVariableGroupDialogClose = () => {
    setVariableGroupDialogIsOpen(false);
    setIsVariableEdit(false);
    setVariableGroupToEdit({});
  };

  return (
    <Box>
      <ProgressBar
        isVisible={isVisible}
        progressBarMessage={progressBarMessage}
      />
      <ErrorAlert
        isErrorVisible={isErrorVisible}
        callback={() => {
          setIsErrorVisible(false);
          if (
            errorAlertCallback.hasOwnProperty("navigate") &&
            errorAlertCallback.hasOwnProperty("navigateData")
          ) {
            navigate(
              errorAlertCallback.navigate,
              errorAlertCallback.navigateData
            );
          } else if (errorAlertCallback.hasOwnProperty("navigate")) {
            navigate(errorAlertCallback.navigate);
          }
        }}
        message={errorAlertCallback.message}
      />
      <Box mr={1} mb={1}>
        <CustomBreadCrumb
          routeList={state.routeList}
          location={location.pathname}
        />
      </Box>
      <ConfirmDeleteUserAlert />

      <Stack direction="row" justifyContent="space-between">
        <Typography
          variant="h6"
          color={"#005689"}
          fontWeight={"bold"}
        >
          {state.project.name}
        </Typography>
      </Stack>
      <ProjectTabs
        project={state.project}
        projectRepositories={projectRepositories}
        projectVariableGroups={projectVariableGroups}
        existingProjectUsers={existingProjectUsers}
        onDeleteExistingUser={onDeleteExistingUser}
        onEditVariableGroup={onEditVariableGroup}
        projectPipelines={projectPipelines}
        releasePipeline={releasePipeline}
        tabId={tabId}
        onProjectTabChange={onProjectTabChange}
      />
      <Divider />
      <Box position="fixed" bottom="0px" width={"100vw"} ml={-3}>
        <Card raised>
          <Stack direction="row" spacing={2} p={1}>
            <CreateRepoDialog
              onNewRepoAdded={onNewRepoAdded}
              eligibleUsers={existingProjectUsers.filter(
                // eslint-disable-next-line
                (user) => user.accessLevel.licenseDisplayName == "Basic"
              )}
              onNewRepoAddedWithPipeline={onNewRepoAddedWithPipeline}
            />
            <CreateCIPipeline
              project={state.project}
              onNewCIPipelineAdded={onNewCIPipelineAdded}
              projectRepositories={projectRepositories}
              eligibleUsers={existingProjectUsers.filter(
                // eslint-disable-next-line
                (user) => user.accessLevel.licenseDisplayName == "Basic"
              )}
            />
            <ColorButton
              backgroundcolor="#005689"
              variant="contained"
              size="small"
              onClick={handleVariableGroupDialogOpen}
              startIcon={<Add />}
            >
              New Variables Group
            </ColorButton>
            <AddUsersDialog
              project={state.project}
              onNewUserAdded={onNewUserAdded}
            />
            {/* <CreateReleasePipeline
              project={state.project}
              onNewUserAdded={onNewUserAdded}
              ciPipelines={projectPipelines}
            /> */}
            <ColorButton
              backgroundcolor="#005689"
              variant="contained"
              size="small"
              onClick={() => {
                navigate('/azure/createReleasePipeline', {
                  state: {
                    project: state.project,
                    routeList: [...state.routeList],
                    ciPipelines: projectPipelines
                  }
                })
              }}
              startIcon={<Add />}
            >
              New Release Pipeline
            </ColorButton>
            <AddVariablesDialog
              onNewVariableGroupAdded={onNewVariableGroupAdded}
              project={state.project}
              variableGroupToEdit={variableGroupToEdit}
              isVariableEdit={isVariableEdit}
              variableGroupDialogIsOpen={variableGroupDialogIsOpen}
              handleVariableGroupDialogClose={handleVariableGroupDialogClose}
            />
          </Stack>
        </Card>
      </Box>
    </Box>
  );
}
