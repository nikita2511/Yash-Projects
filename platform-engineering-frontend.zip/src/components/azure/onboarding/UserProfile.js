import React from "react";
import "./onboarding.css";
import LandingBar from "../../../utils/LandingBar";
import Box from "@mui/material/Box";
import TextField from "@mui/material/TextField";
import { Avatar, Divider, Typography } from "@mui/material";
import { useMsal } from "@azure/msal-react";
import { stringAvatar } from "../../../utils/helper";
/**
 * 
 * @returns React Functional Component (UserProfile) which renders logged in user's basic information
 */
export default function UserProfile() {
  const { instance } = useMsal();

  return (
    <Box>
      <LandingBar />
      <Box padding={3}>
        <Typography
          className="userProfile-typography1"
          variant="h6"
          gutterBottom
        >
          User Profile
        </Typography>
        <Divider />

        <Typography mt={2} mb={2} className="userProfile-typography2">
          Profile picture
        </Typography>

        <Avatar
          className="userProfile-avatar"
          {...stringAvatar(
            instance.getActiveAccount() ? instance.getActiveAccount().name : ""
          )}
        />
        <Typography mb={1} className="userProfile-typography2">
          Full name
        </Typography>

        <TextField
          className="userProfile-textFeild"
          disabled
          defaultValue={instance.getActiveAccount().name}
        />

        <Typography className="userProfile-typography2" mb={1} mt={2}>
          Email
        </Typography>

        <TextField className="userProfile-textFeild" disabled 
          defaultValue={instance.getActiveAccount().username} />
      </Box>
    </Box>
  );
}
