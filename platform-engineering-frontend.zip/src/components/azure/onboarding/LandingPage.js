import React from "react";
import "./onboarding.css";
import LandingBar from "../../utils/LandingBar";
import {
  AuthenticatedTemplate,
  UnauthenticatedTemplate,
} from "@azure/msal-react";
import { Card, Typography } from "@mui/material";
import ImageStepper from "./ImageStepper";
import azureLogo from "../../assets/azure-logo.png";
import { useMsal } from "@azure/msal-react";
import { msalConfig } from "../../authConfig";
import { Navigate } from "react-router-dom";
/**
 * 
 * @returns React Functional Component (LandingPage) which is rendered on home route (/)
 */
export default function LandingPage() {
  const { instance } = useMsal();
  /**
   * callback function called when user clicks on logout button
   */
  const handleLoginRedirect = () => {
    instance
      .loginRedirect({ scopes: [...msalConfig.auth.scopes] })
      .catch((error) => console.log(error));
  };

  return (
    <div className="landing-dashboard">
      <LandingBar />
      <ImageStepper />
      <div className="main-container">
        <UnauthenticatedTemplate>
          <Typography
            className="imageStepper-typography1"
            variant="h5"
            gutterBottom
          >
            Welcome to DevOps PlatForm Engineering!
          </Typography>
          <Typography
            className="imageStepper-typography2"
            variant="body2"
            gutterBottom
          >
            Login using your official credentials to access the platform.
          </Typography>
          <Card
            className="imageStepper-card imageStepper-card:hover"
            raised={true}
            onClick={handleLoginRedirect}
          >
            <img
              className="imageStepper-image"
              src={azureLogo}
              alt={"Could not load media"}
              loading="lazy"
            />
          </Card>
        </UnauthenticatedTemplate>
        <AuthenticatedTemplate>
          <Navigate to="/organization" />
        </AuthenticatedTemplate>
      </div>
    </div>
  );
}
