import { Outlet, useNavigate } from "react-router-dom";
import { MsalProvider, UnauthenticatedTemplate } from "@azure/msal-react";
import React, { useEffect, useState } from "react";
import axios from "axios";
import { constants } from "../../../utils/Constants";
import {
  EventType,
  LogLevel,
  PublicClientApplication,
} from "@azure/msal-browser";
import LandingBar from "../../../utils/LandingBar";
import { Typography } from "@mui/material";
import ImageStepper from "./ImageStepper";
import ProgressBar from "../../../utils/ProgressBar";
import ErrorAlert from "../../error/ErrorAlert";
/**
 *
 * @param {*} instance instance from useMsal hook of "@azure/msal-react" provided by calling component
 * @returns MsalProvider component which wraps RouterProvider with all the routes
 */
function AzureDevopsPlatform() {
  const navigate = useNavigate();
  const [inst, setInst] = useState(null);
  const [isVisible, setIsVisible] = React.useState(false);
  const [progressBarMessage, setProgressBarMessage] =
    React.useState("Please wait!");
  const [isErrorVisible, setIsErrorVisible] = React.useState(false);
  const [errorAlertCallback, setErrorAlertCallback] = React.useState({
    navigate: -1,
    navigateData: {
      state: {},
    },
    message: "Something unexpected happend! Please try again",
  });
  /**
   *
   * @param {*} message String value to be shown with Progress Bar
   * JS method called to make the Progress Bar visible along with the message
   */
  const showProgressBar = (message) => {
    setIsVisible(true);
    setProgressBarMessage(message);
  };
  /**
   *
   * JS method called to hide the Progress Bar
   */
  const hideProgressBar = () => {
    setIsVisible(false);
    setProgressBarMessage("");
  };
  /**
    *
    * @param {*} value boolean value to change visiblity of Alert Dialog
     JS method to update the boolean state value isErrorVisible
    */
  const handleErrorAlert = (value) => {
    setIsErrorVisible(value);
  };
  const msalConfig = {
    auth: {
      clientId: "", // This is the ONLY mandatory field that you need to supply.
      authority: "", // Defaults to "https://login.microsoftonline.com/common"
      redirectUri: "http://localhost:3000/azure", // You must register this URI on Azure Portal/App Registration. Defaults to window.location.origin
      postLogoutRedirectUri: "http://localhost:3000/azure/", // Indicates the page to navigate after logout.
      clientCapabilities: ["CP1"], // this lets the resource owner know that this client is capable of handling claims challenge.
      scopes: ["499b84ac-1321-427f-aa17-267ca6975798/user_impersonation"],
    },
    cache: {
      cacheLocation: "localStorage", // Configures cache location. "sessionStorage" is more secure, but "localStorage" gives you SSO between tabs.
      storeAuthStateInCookie: false, // Set this to "true" if you are having issues on IE11 or Edge
    },
    system: {
      loggerOptions: {
        /**
         * Below you can configure MSAL.js logs. For more information, visit:
         * https://docs.microsoft.com/azure/active-directory/develop/msal-logging-js
         */
        loggerCallback: (level, message, containsPii) => {
          if (containsPii) {
            return;
          }
          switch (level) {
            case LogLevel.Error:
              console.error(message);
              return;
            case LogLevel.Info:
              console.info(message);
              return;
            case LogLevel.Verbose:
              console.debug(message);
              return;
            case LogLevel.Warning:
              console.warn(message);
              return;
            default:
              console.log(message);
          }
        },
      },
    },
  };
  /**
   *
   * JS method to call GET REST Endpoint for retrieving availble ADs
   */
  const callGetADInfoAPI = () => {
    showProgressBar(
      "Please be patient! while Active Directories are being fetched."
    );
    axios
      .get(constants.BASE_URL + constants.GET_ACTIVE_DIRECTORY)
      .then((response) => {
        hideProgressBar();
        console.log(
          "Response-callGetActiveDirectories========>",
          response.data.body.activeDirectories
        );
        if (response.data.body.activeDirectories.length < 1) {
          handleErrorAlert(true);
          setErrorAlertCallback({
            navigate: "/createADInfo",
            message: `No active directories found! Please ask Admin to add AD Info`,
          });
        } else {
          const primaryAD = response.data.body.activeDirectories.find(
            (item) => item.isActiveDirectoryPrimary
          );
          localStorage.setItem("primaryADInfo", JSON.stringify(primaryAD));
          msalConfig.auth.clientId = primaryAD.applicationClientId;
          msalConfig.auth.authority = primaryAD.activeDirectorydomain;
          setupMsal(msalConfig);
        }
      })
      .catch((error) => {
        hideProgressBar();
        handleErrorAlert(true);
        setErrorAlertCallback({
          navigate: -1,
          message: `Something went wrong while fetching active directories! Please contact admin`,
        });
        console.log("Error-callGetActiveDirectories=========>", error);
      });
  };

  let msalInstance;
  const setupMsal = (myConfig) => {
    msalInstance = new PublicClientApplication(myConfig);
    console.log("setupmsal=======>", msalInstance.getLogger());
    // Default to using the first account if no account is active on page load
    if (
      !msalInstance.getActiveAccount() &&
      msalInstance.getAllAccounts().length > 0
    ) {
      // Account selection logic is app dependent. Adjust as needed for different use cases.
      msalInstance.setActiveAccount(msalInstance.getAllAccounts()[0]);
    }

    // Optional - This will update account state if a user signs in from another tab or window
    msalInstance.enableAccountStorageEvents();

    // Listen for sign-in event and set active account
    msalInstance.addEventCallback((event) => {
      if (
        event.eventType === EventType.LOGIN_SUCCESS &&
        event.payload.account
      ) {
        const account = event.payload.account;
        msalInstance.setActiveAccount(account);
      }
    });
    if (msalInstance) {
      console.log("if Check=======>", msalInstance);
      setInst(msalInstance);
    }
  };

  useEffect(() => {
    if (!localStorage.getItem("primaryADInfo")) {
      callGetADInfoAPI();
    } else {
      const primaryAD = JSON.parse(localStorage.getItem("primaryADInfo"));
      msalConfig.auth.clientId = primaryAD.applicationClientId;
      msalConfig.auth.authority = primaryAD.activeDirectorydomain;
      setupMsal(msalConfig);
    }
    // eslint-disable-next-line
  }, []);

  const PlaceHolderForADInfo = () => {
    return (
      <div className="landing-dashboard">
        <LandingBar />
        <ImageStepper />
        <div className="main-container">
          <Typography
            className="imageStepper-typography1"
            variant="h6"
            gutterBottom
            mt={4}
          >
            Welcome to DevOps PlatForm Engineering!
          </Typography>
          <Typography
            className="imageStepper-typography2"
            variant="body1"
            gutterBottom
          >
            Please wait while Azure DevOps is being initialised
          </Typography>
        </div>
      </div>
    );
  };

  return (
    <div>
      <ProgressBar
        isVisible={isVisible}
        progressBarMessage={progressBarMessage}
      />
      <ErrorAlert
        isErrorVisible={isErrorVisible}
        callback={() => {
          setIsErrorVisible(false);
          if (
            errorAlertCallback.hasOwnProperty("navigate") &&
            errorAlertCallback.hasOwnProperty("navigateData")
          ) {
            navigate(
              errorAlertCallback.navigate,
              errorAlertCallback.navigateData
            );
          } else if (errorAlertCallback.hasOwnProperty("navigate")) {
            navigate(errorAlertCallback.navigate);
          }
        }}
        message={errorAlertCallback.message}
      />
      {inst ? (
        <MsalProvider instance={inst}>
          <Outlet />
          <UnauthenticatedTemplate>
            <PlaceHolderForADInfo />
          </UnauthenticatedTemplate>
        </MsalProvider>
      ) : (
        <PlaceHolderForADInfo />
      )}
    </div>
  );
}

export default AzureDevopsPlatform;
