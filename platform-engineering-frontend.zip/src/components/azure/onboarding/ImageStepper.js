import * as React from "react";
import "./onboarding.css";
import { useTheme } from "@mui/material/styles";
import Box from "@mui/material/Box";
import MobileStepper from "@mui/material/MobileStepper";
import SwipeableViews from "react-swipeable-views-react-18-fix";
import { autoPlay } from "react-swipeable-views-utils";
/**
 * Component for playing slides auto play
 */
const AutoPlaySwipeableViews = autoPlay(SwipeableViews);
/**
 * Array of images for AutoPlaySwipeableViews
 */
const images = [
  {
    label: "azure-1",
    imgPath:
      "https://squareops.com/wp-content/uploads/2022/12/HEADER-AZURE.png",
  },
  {
    label: "azure-2",
    imgPath: "https://www.predicagroup.com/app/uploads/2021/08/GetImage-6.png",
  },
  {
    label: "azure-3",
    imgPath:
      "https://www.kovair.com/blog/wp-content/uploads/2022/03/Image-1-Azure-DevOps.png",
  },
  {
    label: "azure-4",
    imgPath:
      "https://www.databricks.com/wp-content/uploads/2021/09/azure-devops-blog-img-1B.png",
  },
];
/**
 * 
 * @returns React Functional Component (SwipeableTextMobileStepper) which display the given array of images on autoplay
 */
function SwipeableTextMobileStepper() {
  const theme = useTheme();
  /**
   * current active step of AutoPlaySwipeableViews
   */
  const [activeStep, setActiveStep] = React.useState(0);
  /**
   * maximum steps for MobileStepper which is length of array of images
   */
  const maxSteps = images.length;
  /**
   * 
   * @param {*} step current number of step
   * callback function called when a step is changed in AutoPlaySwipeableViews
   */
  const handleStepChange = (step) => {
    setActiveStep(step);
  };

  return (
    <Box className="imageStepper-Parent-box">
      <AutoPlaySwipeableViews
        axis={theme.direction === "rtl" ? "x-reverse" : "x"}
        index={activeStep}
        onChangeIndex={handleStepChange}
        enableMouseEvents
      >
        {images.map((step, index) => (
          <div
            className="imageStepper-div"
            key={step.label}
          >
            {Math.abs(activeStep - index) <= 2 ? (
              <Box
                className="imageStepper-box"
                component="img"
                src={step.imgPath}
                alt={step.label}
              />
            ) : null}
          </div>
        ))}
      </AutoPlaySwipeableViews>
      <MobileStepper
        steps={maxSteps}
        position="static"
        activeStep={activeStep}
      />
    </Box>
  );
}

export default SwipeableTextMobileStepper;
