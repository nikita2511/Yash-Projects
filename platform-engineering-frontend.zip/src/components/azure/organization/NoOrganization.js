import './organization.css';
import { Typography } from "@mui/material";
import React from "react";
/**
 * 
 * @returns React Functional Component (NoOrganization) which is rendered when user is not a part of any organization
 */
export default function NoOrganization() {
  return (
    <div className="noOrganization-div-parent">
      <Typography
        variant="subtitle2"
        display="block"
        gutterBottom
        color={"#005689"}
        fontSize={"20px"}
      >
        You are not a member of any organization. Organizations will be visible
        once you create or get assigned to it.
      </Typography>
    </div>
  );
}
