import './organization.css';
import React, { useEffect } from "react";
import { constants } from "../../../utils/Constants";
import axios from "axios";
import { getTokenForAPI } from "../../../utils/RetrieveToken";
import { useMsal } from "@azure/msal-react";
import Card from "@mui/material/Card";
import CardActions from "@mui/material/CardActions";
import AddCircleOutlineSharpIcon from "@mui/icons-material/AddCircleOutlineSharp";
import CardContent from "@mui/material/CardContent";
import Typography from "@mui/material/Typography";
import Box from "@mui/material/Box";
import Stack from "@mui/material/Stack";
import { Avatar, Divider, Grid, IconButton, Tab, Tabs, Tooltip, tooltipClasses } from "@mui/material";
import { stringAvatar } from "../../../utils/helper";
import LandingBar from "../../../utils/LandingBar";
import { useNavigate } from "react-router-dom";
import ProgressBar from "../../../utils/ProgressBar";
import { Add, InfoOutlined } from "@mui/icons-material";
import { MsalAuthenticationTemplate } from "@azure/msal-react";
import { InteractionType } from "@azure/msal-browser";
import ErrorAlert from "../../error/ErrorAlert";
import AlertDialog from "../../error/AlertDialog";
import { useLocation } from "react-router-dom";
import styled from '@emotion/styled';
/**
 *
 * @returns React Functional Component (AllOrganization) which renders all the available organization where logged in user is a member
 */
export default function AllOrganization() {
  const location = useLocation();
  const { state } = location;
  const [organizationList, setOrganizationList] = React.useState([]);
  const [isVisible, setIsVisible] = React.useState(false);
  const [progressBarMessage, setProgressBarMessage] =
    React.useState("Please wait!");
  const [isErrorVisible, setIsErrorVisible] = React.useState(false);
  const { instance, inProgress, accounts } = useMsal();
  const [isAlertVisible, setIsAlertVisible] = React.useState(false);
  const navigate = useNavigate();
  const [alertData, setAlertData] = React.useState({
    positiveCallback: {
      navigate: -1,
      navigateData: {
        state: {},
      },
    },
    negativeCallback: {
      navigate: -1,
      navigateData: {
        state: {},
      },
    },
    message:
      "Organization Rule is not created for the organization you are trying to access. Please create rule to proceed further.",
  });
  const [activeDirectoryList, setActiveDirectoryList] = React.useState([]);
  const [selectedAD, setSelectedAD] = React.useState(0);
  const [noOrganizationMessage, setNoOrganizationMessage] = React.useState("Please be patient! while user is being authorised by Azure DevOps.");

  /**
   *
   * JS method to call GET REST Endpoint for retrieving availble ADs
   */
  const callGetADInfoAPI = () => {
    showProgressBar(
      "Please be patient! while Active Directories are being fetched."
    );
    axios
      .get(constants.BASE_URL + constants.GET_ACTIVE_DIRECTORY)
      .then((response) => {
        hideProgressBar();
        for (const directory of response.data.body.activeDirectories) {
          directory["isActive"] = false;
        }
        console.log(
          "Response-callGetActiveDirectories========>",
          response.data.body.activeDirectories
        );
        setActiveDirectoryList(response.data.body.activeDirectories);
        setSelectedAD(
          JSON.parse(localStorage.getItem("primaryADInfo")).activeDirectoryId
        );
      })
      .catch((error) => {
        hideProgressBar();
        handleErrorAlert(true);
        console.log("Error-callGetActiveDirectories=========>", error);
      });
  };

  /**
   *
   * @param {*} token Access token retrieved to call Azure REST APIs using backend endpoints
   * callback method called after token is retrieved from @azure/msal-browser dependency
   */
  const getToken = (token) => {
    hideProgressBar();
    callAllorganizationAPI(token);
  };

  useEffect(() => {
    showProgressBar("Please be patient! While user is authorised");
    /**
     * JS method called to retrieve token in getToken callback method
     */
    getTokenForAPI(instance, inProgress, accounts, getToken);
    callGetADInfoAPI();
    // eslint-disable-next-line
  }, [instance, accounts, inProgress]);
  /**
   *
   * @param {*} token Access token retrieved to call Azure REST APIs using backend endpoints
   * JS method to call GET REST Endpoint for retrieving user's all available organizations
   */
  const callAllorganizationAPI = (token) => {
    showProgressBar(
      "Please be patient! while organizations are being fetched."
    );
    setNoOrganizationMessage("User is authorised successfully by Azure DevOps")
    let config = {
      headers: { authorization: "Bearer " + token },
      params: {
        platform: "AzureDevops"
      }
    };
    axios
      .get(constants.BASE_URL + constants.GET_ORGANIZATION, config)
      .then((response) => {
        console.log(
          "Reponse-getAllOrganization=======>",
          response.data.body.organizations.value
        );
        hideProgressBar();
        setOrganizationList(response.data.body.organizations.value);
        if (!response.data.body.organizations.value.length) {
          setNoOrganizationMessage("You are not a member of any organization. Organizations will be visible once you create or get assigned to it.")
        }
      })
      .catch((error) => {
        handleErrorAlert(true);
        hideProgressBar();
        console.log("Error-callAllorganizationAPI========>", error);
      });
  };
  /**
   *
   * @param {*} value boolean value to change visiblity of Alert Dialog
   * JS method to update the boolean state value isErrorVisible
   */
  const handleErrorAlert = (value) => {
    setIsErrorVisible(value);
  };
  /**
   *
   * @param {*} org Object of organization on which user has clicked
   * JS method called when user click on `View Organization` button inside an Organization's card component
   */
  const onClickViewOrganization = (org) => {
    if (org.isRuleExists) {
      navigate("/azure/project", {
        state: {
          organization: org.accountName,
          routeList: [location.pathname],
        },
      });
    } else {
      setAlertData({
        positiveCallback: {
          navigate: "/azure/createRule",
          navigateData: {
            state: {
              organization: localStorage.getItem("organizationName"),
              routeList: [location.pathname],
            },
          },
        },
        message:
          "Organization Rule is not created for the organization you are trying to access. Please proceed to create rule before accessing the organization.",
      });
      setIsAlertVisible(true);
    }
  };
  /**
   * JSON object authRequest used in MsalAuthenticationTemplate component to validate user
   */
  const authRequest = {
    ...["499b84ac-1321-427f-aa17-267ca6975798/user_impersonation"],
  };
  /**
   *
   * @param {*} message String value to be shown with Progress Bar
   * JS method called to make the Progress Bar visible along with the message
   */
  const showProgressBar = (message) => {
    setIsVisible(true);
    setProgressBarMessage(message);
  };
  /**
   *
   * JS method called to hide the Progress Bar
   */
  const hideProgressBar = () => {
    setIsVisible(false);
    setProgressBarMessage("");
  };

  /**
 * display information about branching modal
 */
  const addADInfo = `Add New AD`;
  const BranchMessage = `Available active directories`;
  const HtmlTooltip = styled(({ className, ...props }) => (
    <Tooltip {...props} classes={{ popper: className }} placement='bottom' />
  ))(({ theme }) => ({
    [`& .${tooltipClasses.tooltip}`]: {
      backgroundColor: "#007CB9",
      border: "1px solid #dadde9",
      fontSize: "14px",
    },
  }));
  return (
    <MsalAuthenticationTemplate
      interactionType={InteractionType.Redirect}
      authenticationRequest={authRequest}
    >
      <Box>
        <ProgressBar
          isVisible={isVisible}
          progressBarMessage={progressBarMessage}
        />

        <ErrorAlert
          isErrorVisible={isErrorVisible}
          callback={() => {
            setIsErrorVisible(false);
            navigate(-1);
          }}
          message={"Something unexpected happend! Please try again"}
        />

        <AlertDialog
          isDialogVisible={isAlertVisible}
          message={alertData.message}
          negativeCallback={() => {
            setIsAlertVisible(false);
            if (
              alertData.hasOwnProperty("negativeCallback") &&
              alertData.negativeCallback.hasOwnProperty("navigate") &&
              alertData.negativeCallback.hasOwnProperty("navigateData")
            ) {
              navigate(
                alertData.negativeCallback.navigate,
                alertData.negativeCallback.navigateData
              );
            } else if (
              alertData.hasOwnProperty("negativeCallback") &&
              alertData.negativeCallback.hasOwnProperty("navigate")
            ) {
              navigate(alertData.negativeCallback.navigate);
            }
          }}
          positiveCallback={() => {
            setIsErrorVisible(false);
            if (
              alertData.hasOwnProperty("positiveCallback") &&
              alertData.positiveCallback.hasOwnProperty("navigate") &&
              alertData.positiveCallback.hasOwnProperty("navigateData")
            ) {
              navigate(
                alertData.positiveCallback.navigate,
                alertData.positiveCallback.navigateData
              );
            } else if (
              alertData.hasOwnProperty("positiveCallback") &&
              alertData.positiveCallback.hasOwnProperty("navigate")
            ) {
              navigate(alertData.positiveCallback.navigate);
            }
          }}
        />

        <LandingBar />
        <Box sx={{ borderBottom: 1, borderColor: "divider" }} mb={1}>
          <Tabs value={selectedAD}>
            <HtmlTooltip title={BranchMessage} placement="right-start">
              <InfoOutlined
                sx={{
                  color: "#005689",
                  display: "flex",
                  alignSelf: "center",
                  m: 1,
                }}
              />
            </HtmlTooltip>
            <Divider orientation="vertical" flexItem />
            {activeDirectoryList.map((info, index) => (
              <Tab
                label={info.activeDirectoryName}
                key={info.activeDirectoryId}
                value={info.activeDirectoryId}
                className={
                  JSON.parse(localStorage.getItem("primaryADInfo"))
                    .activeDirectoryId === info.activeDirectoryId
                    ? "allOrganization-selected-ad-button"
                    : "allOrganization-ad-button"
                }
                disabled={
                  JSON.parse(localStorage.getItem("primaryADInfo"))
                    .activeDirectoryId === info.activeDirectoryId
                }
                onClick={() => {
                  localStorage.setItem("primaryADInfo", JSON.stringify(info));
                  navigate(0);
                }}
              />
            ))}
            <HtmlTooltip title={addADInfo} placement="right-start">
              <IconButton
                backgroundcolor="#005689"
                variant="contained"
                size="small"
                sx={{
                  height: "50px",
                  margin: "3px",
                }}
                startIcon={
                  <Add
                    fontSize="30px"
                  />
                }
                onClick={() => {
                  navigate("/azure/updateAdInfo", {
                    state: {
                      routeList: ["/azure"],
                    },
                  });
                }}
              >
                <Add fontSize='large' className="addVariableDialog-addCircleOutlined" />
              </IconButton>
            </HtmlTooltip>

          </Tabs>
        </Box>
        <Stack direction="row" justifyContent="space-between" ml={3} mr={3}>
          <Typography
            variant="h6"
            color={"#005689"}
            fontWeight={"bold"}
            p={"2px"}
          >
            Organizations
          </Typography>
        </Stack>

        {organizationList.length > 0 ? (
          <Card
            variant="outlined"
            className="allOrganization-card-organizationList"
          >
            <Grid container>
              {organizationList.map((org, index) => (
                <Grid item xs={6} md={3} key={index}>
                  <Card
                    raised={true}
                    onClick={() => {
                      localStorage.setItem("organizationName", org.accountName);
                      onClickViewOrganization(org);
                    }}
                    className="allOrganization-card-organization allOrganization-button-viewOrganization"
                  >
                    <CardContent>
                      <Stack direction="row" spacing={2}>
                        <Avatar
                          {...stringAvatar(org.accountName)}
                          variant="square"
                        />
                        <Typography
                          variant="h7"
                          component="div"
                          color={"#005689"}
                          fontWeight={"bold"}
                        >
                          {org.accountName}
                        </Typography>
                      </Stack>
                    </CardContent>
                    <CardActions></CardActions>
                  </Card>
                </Grid>
              ))}
            </Grid>
          </Card>
        ) : (
          <Typography
            variant="subtitle2"
            display="block"
            gutterBottom
            textAlign={"center"}
            mt={4}
            color={"#005689"}
            fontSize={"20px"}
          >
            {noOrganizationMessage}
          </Typography>
        )}
      </Box>
    </MsalAuthenticationTemplate>
  );
}
