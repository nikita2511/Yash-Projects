import './rules.css'
import React, { useEffect, useState } from "react";
import Box from "@mui/material/Box";
import TextField from "@mui/material/TextField";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import { useLocation, useNavigate } from "react-router-dom";
import CardContent from "@mui/material/CardContent";
import Stack from "@mui/material/Stack";
import Card from "@mui/material/Card";
import { Chip, Divider, Grid, Typography } from "@mui/material";
import axios from "axios";
import { constants } from "../../../../utils/Constants";
import ProgressBar from "../../../../utils/ProgressBar";
import ErrorAlert from "../../../error/ErrorAlert";
import { ColorButton } from "../../../../utils/CustomButton";
import { useMsal } from "@azure/msal-react";
import AlertDialog from "../../../error/AlertDialog";
import CustomBreadCrumb from "../../../../utils/CustomBreadCrumb";
import { getTokenForAPI } from "../../../../utils/RetrieveToken";
/**
 *
 * @returns React Functional Component (UpdateRules) which renders a form to update organization rules for a particular organization
 */
export default function UpdateRules() {
  const { instance, inProgress, accounts } = useMsal();
  const navigate = useNavigate();
  const location = useLocation();
  const { state } = location;
  const [organization, setOrganization] = useState("");
  const [versionName, setVersionName] = useState("");
  const [namingConvention, setNamingConvention] = useState("");
  const [selectedBranchingModel, setSelectedBranchingModel] = useState({});
  const [availableMergeTypes, setAvailableMergeTypes] = useState([]);
  const [branchingModels, setBranchingModels] = useState([]);
  const [isVisible, setIsVisible] = React.useState(false);
  const [progressBarMessage, setProgressBarMessage] =
    React.useState("Please wait!");
  const [isErrorVisible, setIsErrorVisible] = React.useState(false);
  // eslint-disable-next-line
  const [organizationRules, setOrganizationRules] = useState({});
  const [errorAlertCallback, setErrorAlertCallback] = React.useState({
    navigate: -1,
    navigateData: {
      state: {},
    },
    message: "Something unexpected happend! Please try again",
  });
  const [isFieldDisable, setIsFieldDisable] = React.useState(true);
  const [isAlertVisible, setIsAlertVisible] = React.useState(false);
  const [alertData, setAlertData] = React.useState({
    positiveCallback: {
      navigate: -1,
      navigateData: {
        state: {},
      },
    },
    negativeCallback: {
      navigate: -1,
      navigateData: {
        state: {},
      },
    },
    message:
      "Organization Rule is not created for the organization you are trying to access. Please create rule to proceed further.",
  });
  const [isUserProjectCollectionAdministrators, setIsUserProjectCollectionAdministrators] = useState(false);
  /**
   *
   * @param {*} value boolean value to change visiblity of Alert Dialog
   * JS method to update the boolean state value isErrorVisible
   */
  const handleErrorAlert = (value) => {
    setIsErrorVisible(value);
  };
  /**
   *
   * @returns JSON object for create rule API params
   */
  const getDataForCreateRuleAPI = () => {
    return {
      organizationName: organization,
      namingStandard: namingConvention,
      branchingModel: selectedBranchingModel,
      createdBy: accounts[0].name,
      platform: "AzureDevops"
    };
  };
  /**
   *
   * JS method to validate information of branches in
   */
  const validateBranches = () => {
    console.log("validateBranches");
    for (const model of selectedBranchingModel.branches) {
      if (!(model.name.trim().length && model.name.length)) {
        handleErrorAlert(true);
        setErrorAlertCallback({
          message: `Branch name is mandatory field. Please enter ${model.type} branch name`,
        });
        return;
      } else if (
        !(model.noOfReviewers.trim().length && model.noOfReviewers.length)
      ) {
        handleErrorAlert(true);
        setErrorAlertCallback({
          message: `No. of reviewers is mandatory field. Please enter No. of reviewers for ${model.type} branch`,
        });
        return;
      } else if (
        !(model.noOfReviewers.trim().length && model.mergeType.length)
      ) {
        handleErrorAlert(true);
        setErrorAlertCallback({
          message: `Merge type is mandatory field. Please enter Merge type for ${model.type} branch`,
        });
        return;
      }
    }
    if (!(namingConvention.trim().length && namingConvention.length)) {
      handleErrorAlert(true);
      setErrorAlertCallback({
        message: `Naming convention is mandatory field. Please enter naming convention`,
      });
      return;
    }
    callUpdateRuleAPI();
  };
  /**
   *
   * JS method to call GET REST Endpoint for retrieving all branching models
   */
  const getAllBranchingModels = () => {
    showProgressBar(
      "Please be patient! while branching model are being fetched."
    );
    axios
      .get(constants.BASE_URL + constants.GET_BRANCHING_MODELS)
      .then((response) => {
        hideProgressBar();
        const branchModels = response.data.body.branchingModels;
        setBranchingModels(branchModels);
        if (
          branchModels.length &&
          branchModels[0].hasOwnProperty("branches") &&
          branchModels[0].branches.length &&
          branchModels[0].branches[0].hasOwnProperty("availableMergeTypes")
        ) {
          setAvailableMergeTypes(
            branchModels[0].branches[0].availableMergeTypes
          );
        }
      })
      .catch((error) => {
        handleErrorAlert(true);
        hideProgressBar();
      });
  };
  /**
   *
   * JS method to call PUT REST Endpoint for updating the rule for organization
   */
  const callUpdateRuleAPI = () => {
    showProgressBar("Please be patient! while rule is being updated.");
    axios
      .put(
        constants.BASE_URL + constants.PUT_ORGANIZATION_RULES,
        getDataForCreateRuleAPI()
      )
      .then((response) => {
        hideProgressBar();
        setIsFieldDisable(true);
        handleErrorAlert(true);
        setErrorAlertCallback({
          message: "Organization rule updated successfully!",
        });
      })
      .catch((error) => {
        hideProgressBar();
        handleErrorAlert(true);
        setErrorAlertCallback({
          message:
            "Something went wrong while creating organization rule. Please try again!",
        });
      });
  };
  /**
   * JS method to call GET REST Endpoint for retreiving the organization rule
   */
  const getRulesByOrganization = () => {
    showProgressBar(
      "Please be patient! while organization rule is being fetched."
    );
    let config = {
      // headers: { authorization: "Bearer " + token },
      params: {
        organizationName: localStorage.getItem("organizationName"),
        platform:"AzureDevops"
      },
    };
    axios
      .get(constants.BASE_URL + constants.GET_RULES_BY_ORGANIZTION, config)
      .then((response) => {
        hideProgressBar();
        console.log(
          "Response-getRulesByOrganization==============>",
          response.data.body.projectCreationRules
        );
        const rules = response.data.body.projectCreationRules;
        setVersionName(rules.branchingModel.name);
        setSelectedBranchingModel(rules.branchingModel);
        setNamingConvention(rules.namingStandard);
        setOrganizationRules(rules);
      })
      .catch((error) => {
        handleErrorAlert(true);
        hideProgressBar();
      });
  };

  const getProjectCollectionAdministrator = (token)=>{
    showProgressBar(
      "Please be patient! while project collection administrators are being fetched."
    );
    let config = {
      headers: { authorization: "Bearer " + token },
      params: {
        organizationName: localStorage.getItem("organizationName"),
      },
    };
    axios
      .get(
        constants.BASE_URL + constants.GET_PROJECT_COLLECTION_ADMINISTRATORS,
        config
      )
      .then((response) => {
        hideProgressBar();
        console.log(
          "Response-getProjectCollectionAdministrator==============>",
          response.data.body.projectCollectionAdministrators
        );
        const admins = response.data.body.projectCollectionAdministrators;
        const loggedInUsername = instance.getActiveAccount().username;
        setIsUserProjectCollectionAdministrators(
          admins.filter((user) => {
            return user.user.mailAddress === loggedInUsername;
          }).length
        );
      })
      .catch((error) => {
        hideProgressBar();
        console.log(
          "Response-getProjectCollectionAdministrator==============>",
          error.response
        );
      });
  };

  const getTokenForProjectCollectionAdministratorAPI = () =>{
    getTokenForAPI(instance, inProgress, accounts, getProjectCollectionAdministrator);
  };

  useEffect(() => {
    setOrganization(localStorage.getItem("organizationName"));
    getTokenForProjectCollectionAdministratorAPI();
    getAllBranchingModels();
    getRulesByOrganization();
    // eslint-disable-next-line
  }, []);
  /**
   *
   * @param {*} event JS event returned by event listener
   * callback method called when user changes Version Control field
   */
  const handleChangeVersionControlChange = (event) => {
    setVersionName(event.target.value);
    setSelectedBranchingModel(
      branchingModels.find((m) => m.name === event.target.value)
    );
  };
  /**
   *
   * @param {*} e JS event returned by event listener
   * @param {*} id ID of a branch from selected branching model to update its value
   * callback method called when user changes details of a branch from selected branching model
   */
  const onBranchModelChange = (e, id) => {
    const branchingModel = { ...selectedBranchingModel };
    const branchToChange = branchingModel.branches.find((m) => m._id === id);
    // console.log("branchToChange==============>", branchToChange)
    branchToChange[e.target.name] = e.target.value;
    // console.log("changedBranch==============>", branchToChange)
    // console.log("branchAfterUpdate==============>",branchingModel.branches)
    setSelectedBranchingModel(branchingModel);
  };
  /**
   *
   * @param {*} message String value to be shown with Progress Bar
   * JS method called to make the Progress Bar visible along with the message
   */
  const showProgressBar = (message) => {
    setIsVisible(true);
    setProgressBarMessage(message);
  };
  /**
   *
   * JS method called to hide the Progress Bar
   */
  const hideProgressBar = () => {
    setIsVisible(false);
    setProgressBarMessage("");
  };

  return (
    <div>
      <ProgressBar
        isVisible={isVisible}
        progressBarMessage={progressBarMessage}
      />
      <ErrorAlert
        isErrorVisible={isErrorVisible}
        callback={() => {
          setIsErrorVisible(false);
          if (
            errorAlertCallback.hasOwnProperty("navigate") &&
            errorAlertCallback.hasOwnProperty("navigateData")
          ) {
            navigate(
              errorAlertCallback.navigate,
              errorAlertCallback.navigateData
            );
          } else if (errorAlertCallback.hasOwnProperty("navigate")) {
            navigate(errorAlertCallback.navigate);
          }
        }}
        message={errorAlertCallback.message}
      />

      <AlertDialog
        isDialogVisible={isAlertVisible}
        message={alertData.message}
        negativeCallback={() => {
          setIsAlertVisible(false);
          if (
            alertData.hasOwnProperty("negativeCallback") &&
            alertData.negativeCallback.hasOwnProperty("navigate") &&
            alertData.negativeCallback.hasOwnProperty("navigateData")
          ) {
            navigate(
              alertData.negativeCallback.navigate,
              alertData.negativeCallback.navigateData
            );
          } else if (
            alertData.hasOwnProperty("negativeCallback") &&
            alertData.negativeCallback.hasOwnProperty("navigate")
          ) {
            navigate(alertData.negativeCallback.navigate);
          }
        }}
        positiveCallback={() => {
          setIsFieldDisable(false);
          setIsAlertVisible(false);
          if (
            alertData.hasOwnProperty("positiveCallback") &&
            alertData.positiveCallback.hasOwnProperty("navigate") &&
            alertData.positiveCallback.hasOwnProperty("navigateData")
          ) {
            navigate(
              alertData.positiveCallback.navigate,
              alertData.positiveCallback.navigateData
            );
          } else if (
            alertData.hasOwnProperty("positiveCallback") &&
            alertData.positiveCallback.hasOwnProperty("navigate")
          ) {
            navigate(alertData.positiveCallback.navigate);
          }
        }}
      />
      <Box mr={1} mb={1}>
        <CustomBreadCrumb
          routeList={state.routeList}
          location={location.pathname}
        />
      </Box>
      <Box display={"flex"} flexDirection={"column"}>
        <Stack
          justifyContent="space-between"
          direction="row"
          alignItems="center"
          mb={1}
        >
          <Typography variant="h6" color={"#005689"} fontWeight={"bold"}>
            {organization} Rules
          </Typography>

          <ColorButton
            backgroundcolor="#005689"
            variant="contained"
            size="small"
            onClick={() => {
              if (!isUserProjectCollectionAdministrators) {
                handleErrorAlert(true);
                setErrorAlertCallback({
                  message:
                    "Due to lack of sufficient access rights, You can not edit the organization rule",
                });
              } else {
                setIsAlertVisible(true);
                setAlertData({
                  message:
                    "Updated Organization Rule will only be applicable on branches created now afterwards. Branches created in past will remain unchanged. Would you like to proceed?",
                });
              }
            }}
            disabled={!isFieldDisable}
          >
            Edit Rule
          </ColorButton>
        </Stack>

        <Divider />

        <Stack direction={"row"} spacing={2}>
          <TextField
            variant="outlined"
            fullWidth
            disabled
            defaultValue={organization}
            label="Organization Name"
            multiline
            maxRows={4}
            className="create-update-rules-textField"
          />

          <TextField
            variant="outlined"
            fullWidth
            label="Naming Convention"
            value={namingConvention}
            required
            disabled={isFieldDisable}
            helperText={
              namingConvention.length ? "" : "Please enter naming convention"
            }
            error={!namingConvention.length}
            maxRows={4}
            onChange={(event) => setNamingConvention(event.target.value)}
            className="create-update-rules-textField"
          />
        </Stack>
        <Typography variant="h6" mt={2} color={"#005689"}>
          Branching Model
        </Typography>
        <Divider  className='divider2'/>

        <FormControl
          fullWidth
          className="create-update-rules-commom-margingTop"
        >
          <InputLabel id="versionName-select-label">Version Control</InputLabel>
          <Select
            labelId="versionName-select-label"
            id="demo-simple-select"
            value={versionName}
            disabled={isFieldDisable}
            label="Version Control"
            onChange={handleChangeVersionControlChange}
            className="create-update-rules-select-versionName"
          >
            {branchingModels.map((model) => (
              <MenuItem value={model.name} key={model.name}>
                {model.name}
              </MenuItem>
            ))}
          </Select>
        </FormControl>

        <Grid container rowSpacing={1}>
          {selectedBranchingModel.hasOwnProperty("branches") ? (
            selectedBranchingModel.branches.map((model, index) => (
              <Grid item xs={6} md={4} key={index}>
                <Card
                  raised={true}
                  className="create-update-rules-card-branches"
                >
                  <CardContent>
                    <Stack direction="column" spacing={2}>
                      <Stack
                        direction="row"
                        justifyContent="space-between"
                        spacing={2}
                      >
                        <Typography>Branch {index + 1}</Typography>
                        <Chip label={model.type} />
                      </Stack>
                      <TextField
                        variant="outlined"
                        fullWidth
                        label="Branch Name"
                        size="small"
                        disabled={isFieldDisable}
                        required
                        error={!model.name.length}
                        helperText={
                          model.name.length ? "" : "Please enter branch name"
                        }
                        type="text"
                        value={model.name}
                        name="name"
                        maxRows={2}
                        onChange={(event) => {
                          onBranchModelChange(event, model._id);
                        }}
                        className="create-update-rules-commom-margingTop"
                      />
                      <TextField
                        variant="outlined"
                        fullWidth
                        disabled={isFieldDisable}
                        size="small"
                        type="number"
                        InputProps={{ inputProps: { min: 1 } }}
                        required
                        onChange={(event) => {
                          onBranchModelChange(event, model._id);
                        }}
                        name="noOfReviewers"
                        label="No. of Reviewers"
                        value={model.noOfReviewers}
                        inputProps={{
                          inputMode: "numeric",
                          pattern: "[0-9]*",
                        }}
                        className="create-update-rules-commom-margingTop"
                      />

                      <FormControl
                        fullWidth
                        className="create-update-rules-commom-margingTop"
                      >
                        <InputLabel id="mergeType-select-label" size='small'>
                          Merge Type
                        </InputLabel>
                        <Select
                          labelId="mergeType-select-label"
                          id="demo-simple-select"
                          size='small'
                          value={model.mergeType}
                          name="mergeType"
                          label="Merge Type"
                          disabled={isFieldDisable}
                          onChange={(event) => {
                            onBranchModelChange(event, model._id);
                          }}
                        >
                          {availableMergeTypes.map((model) => (
                            <MenuItem value={model.key} key={model.key}>
                              {model.displayName}
                            </MenuItem>
                          ))}
                        </Select>
                      </FormControl>
                    </Stack>
                  </CardContent>
                </Card>
              </Grid>
            ))
          ) : (
            <></>
          )}
        </Grid>
        <Stack
          direction="row"
          justifyContent="flex-end"
          padding={2}
          spacing={2}
        >
          <ColorButton
            backgroundcolor="#005689"
            variant="contained"
            size='small'
            onClick={() => navigate(-1)}
          >
            BACK
          </ColorButton>
          <ColorButton
            backgroundcolor="#005689"
            variant="contained"
            size='small'
            onClick={validateBranches}
            disabled={
              !(versionName.length && namingConvention.length) || isFieldDisable
            }
          >
            UPDATE RULE
          </ColorButton>
        </Stack>
      </Box>
    </div>
  );
}
