import './rules.css'
import React, { useEffect, useState } from "react";
import Box from "@mui/material/Box";
import TextField from "@mui/material/TextField";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import { useLocation, useNavigate } from "react-router-dom";
import CardContent from "@mui/material/CardContent";
import Stack from "@mui/material/Stack";
import Card from "@mui/material/Card";
import { Chip, Divider, Grid, Typography } from "@mui/material";
import axios from "axios";
import { constants } from "../../../../utils/Constants";
import LandingBar from "../../../../utils/LandingBar";
import ProgressBar from "../../../../utils/ProgressBar";
import ErrorAlert from "../../../error/ErrorAlert";
import { ColorButton } from "../../../../utils/CustomButton";
import { useMsal } from "@azure/msal-react";
import CustomBreadCrumb from "../../../../utils/CustomBreadCrumb";
/**
 *
 * @returns React Functional Component (CreateRules) which renders a form to create organization rules for a particular organization
 */
export default function CreateRules() {
  const { accounts } = useMsal();
  const location = useLocation();
  const { state } = location;
  const navigate = useNavigate();
  const { organization, routeList } = state;
  const [versionName, setVersionName] = useState("");
  const [namingConvention, setNamingConvention] = useState("");
  const [selectedBranchingModel, setSelectedBranchingModel] = useState({});
  const [branchingModels, setBranchingModels] = useState([]);
  const [isVisible, setIsVisible] = React.useState(false);
  const [progressBarMessage, setProgressBarMessage] =
    React.useState("Please wait!");
  const [isErrorVisible, setIsErrorVisible] = React.useState(false);
  const [errorAlertCallback, setErrorAlertCallback] = React.useState({
    navigate: -1,
    navigateData: {
      state: {},
    },
    message: "Something unexpected happend! Please try again",
  });
  /**
   *
   * @param {*} value boolean value to change visiblity of Alert Dialog
   * JS method to update the boolean state value isErrorVisible
   */
  const handleErrorAlert = (value) => {
    setIsErrorVisible(value);
  };
  /**
   *
   * JS method to call GET REST Endpoint for retrieving all branching models
   */
  const getAllBranchingModels = () => {
    showProgressBar(
      "Please be patient! while branching model are being fetched."
    );
    axios
      .get(constants.BASE_URL + constants.GET_BRANCHING_MODELS)
      .then((response) => {
        hideProgressBar();
        setBranchingModels(response.data.body.branchingModels);
      })
      .catch((error) => {
        handleErrorAlert(true);
        hideProgressBar();
      });
  };
  /**
   *
   * @returns JSON object for create rule API params
   */
  const getDataForCreateRuleAPI = () => {
    return {
      organizationName: organization,
      namingStandard: namingConvention,
      branchingModel: selectedBranchingModel,
      createdBy: accounts[0].name,
      platform: "AzureDevops",
    };
  };
  /**
   *
   * JS method to validate information of branches in
   */
  const validateBranches = () => {
    for (const model of selectedBranchingModel.branches) {
      if (!(model.name.trim().length && model.name.length)) {
        handleErrorAlert(true);
        setErrorAlertCallback({
          message: `Branch name is mandatory field. Please enter ${model.type} branch name`,
        });
        return;
      } else if (
        !(model.noOfReviewers.trim().length && model.noOfReviewers.length)
      ) {
        handleErrorAlert(true);
        setErrorAlertCallback({
          message: `No. of reviewers is mandatory field. Please enter No. of reviewers for ${model.type} branch`,
        });
        return;
      } else if (
        !(model.noOfReviewers.trim().length && model.mergeType.length)
      ) {
        handleErrorAlert(true);
        setErrorAlertCallback({
          message: `Merge type is mandatory field. Please enter Merge type for ${model.type} branch`,
        });
        return;
      }
    }
    if (!(namingConvention.trim().length && namingConvention.length)) {
      handleErrorAlert(true);
      setErrorAlertCallback({
        message: `Naming convention is mandatory field. Please enter naming convention`,
      });
      return;
    }
    console.log(
      "getDataForCreateRuleAPI()========>",
      getDataForCreateRuleAPI()
    );
    callCreateRuleAPI();
  };
  /**
   *
   * JS method to call POST REST Endpoint for creating the rule for organization
   */
  const callCreateRuleAPI = () => {
    showProgressBar("Please be patient! while rule is being created.");
    axios
      .post(
        constants.BASE_URL + constants.POST_ORGANIZATION_RULES,
        getDataForCreateRuleAPI()
      )
      .then((response) => {
        hideProgressBar();
        handleErrorAlert(true);
        setErrorAlertCallback({
          navigate: "/azure/project",
          navigateData: {
            state: {
              organization,
              routeList: ["/azure"]
            },
          },
          message: "Organization rule created successfully!",
        });
      })
      .catch((error) => {
        hideProgressBar();
        handleErrorAlert(true);
        setErrorAlertCallback({
          message:
            "Something went wrong while creating organization rule. Please try again!",
        });
      });
  };

  useEffect(() => {
    getAllBranchingModels();
    // eslint-disable-next-line
  }, []);
  /**
   *
   * @param {*} event JS event returned by event listener
   * callback method called when user changes Version Control field
   */
  const handleChangeVersionControlChange = (event) => {
    setVersionName(event.target.value);
    setSelectedBranchingModel(
      branchingModels.find((m) => m.name === event.target.value)
    );
  };
  /**
   *
   * @param {*} e JS event returned by event listener
   * @param {*} id ID of a branch from selected branching model to update its value
   * callback method called when user changes details of a branch from selected branching model
   */
  const onBranchModelChange = (e, id) => {
    const branchingModel = { ...selectedBranchingModel };
    const branchToChange = branchingModel.branches.find((m) => m._id === id);
    // console.log("branchToChange==============>", branchToChange)
    branchToChange[e.target.name] = e.target.value;
    // console.log("changedBranch==============>", branchToChange)
    // console.log("branchAfterUpdate==============>",branchingModel.branches)
    setSelectedBranchingModel(branchingModel);
  };
  /**
   *
   * @param {*} message String value to be shown with Progress Bar
   * JS method called to make the Progress Bar visible along with the message
   */
  const showProgressBar = (message) => {
    setIsVisible(true);
    setProgressBarMessage(message);
  };
  /**
   *
   * JS method called to hide the Progress Bar
   */
  const hideProgressBar = () => {
    setIsVisible(false);
    setProgressBarMessage("");
  };

  return (
    <div>
      <ProgressBar
        isVisible={isVisible}
        progressBarMessage={progressBarMessage}
      />
      <ErrorAlert
        isErrorVisible={isErrorVisible}
        callback={() => {
          setIsErrorVisible(false);
          if (
            errorAlertCallback.hasOwnProperty("navigate") &&
            errorAlertCallback.hasOwnProperty("navigateData")
          ) {
            navigate(
              errorAlertCallback.navigate,
              errorAlertCallback.navigateData
            );
          } else if (errorAlertCallback.hasOwnProperty("navigate")) {
            navigate(errorAlertCallback.navigate);
          }
        }}
        message={errorAlertCallback.message}
      />
      <LandingBar />
      <Box pl={3} pr={3} display={"flex"} flexDirection={"column"}>
        <Box mr={1} mb={1} mt={3}>
          <CustomBreadCrumb
            routeList={routeList}
            location={location.pathname}
          />
        </Box>
        <Typography
          variant="h6"
          gutterBottom
          color={"#005689"}
          fontWeight={"bold"}
        >
          {organization} Rules
        </Typography>
        <Divider />

        <Stack direction={"row"} spacing={2}>
          <TextField
            variant="outlined"
            fullWidth
            disabled
            defaultValue={organization}
            label="Organization Name"
            multiline
            maxRows={4}
            className="create-update-rules-textField"
          />

          <TextField
            variant="outlined"
            fullWidth
            label="Naming Convention"
            value={namingConvention}
            required
            helperText={
              namingConvention.length ? "" : "Please enter naming convention"
            }
            error={!namingConvention.length}
            maxRows={4}
            onChange={(event) => setNamingConvention(event.target.value)}
            className="create-update-rules-textField"
          />
        </Stack>
        <Typography
          variant="h6"
          color={"#005689"}
          mt={1}
        >
          Branching Model
        </Typography>
        <Divider className='divider2' />

        <FormControl fullWidth className="create-update-rules-commom-margingTop">
          <InputLabel id="version-name-select-label">
            Version Control
          </InputLabel>
          <Select
            labelId="version-name-select-label"
            id="demo-simple-select"
            value={versionName}
            label="Version Control"
            onChange={handleChangeVersionControlChange}
            className="create-update-rules-select-versionName"
          >
            {branchingModels.map((model) => (
              <MenuItem value={model.name} key={model.name}>
                {model.name}
              </MenuItem>
            ))}
          </Select>
        </FormControl>

        <Grid container rowSpacing={1}>
          {selectedBranchingModel.hasOwnProperty("branches") ? (
            selectedBranchingModel.branches.map((model, index) => (
              <Grid item xs={6} md={4} key={index}>
                <Card
                  raised={true}
                  className='create-update-rules-card-branches'
                >
                  <CardContent>
                    <Stack direction="column" spacing={2}>
                      <Stack
                        direction="row"
                        justifyContent="space-between"
                        spacing={2}
                      >
                        <Typography>Branch {index + 1}</Typography>
                        <Chip label={model.type} />
                      </Stack>
                      <TextField
                        variant="outlined"
                        fullWidth
                        label="Branch Name"
                        size="small"
                        required
                        error={!model.name.length}
                        helperText={
                          model.name.length ? "" : "Please enter branch name"
                        }
                        type="text"
                        value={model.name}
                        name="name"
                        maxRows={2}
                        onChange={(event) => {
                          onBranchModelChange(event, model._id);
                        }}
                        className='create-update-rules-commom-margingTop'
                      />
                      <TextField
                        variant="outlined"
                        fullWidth
                        size="small"
                        type="number"
                        InputProps={{ inputProps: { min: 1 } }}
                        required
                        onChange={(event) => {
                          onBranchModelChange(event, model._id);
                        }}
                        name="noOfReviewers"
                        label="No. of Reviewers"
                        value={model.noOfReviewers}
                        inputProps={{
                          inputMode: "numeric",
                          pattern: "[0-9]*",
                        }}
                        className='create-update-rules-commom-margingTop'
                      />

                      <FormControl
                        fullWidth
                        className='create-update-rules-commom-margingTop'
                      >
                        <InputLabel id="merge-type-select-label" size='small'>
                          Merge Type
                        </InputLabel>
                        <Select
                          labelId="merge-type-select-label"
                          id="demo-simple-select"
                          size='small'
                          value={model.mergeType}
                          name="mergeType"
                          label="Merge Type"
                          onChange={(event) => {
                            onBranchModelChange(event, model._id);
                          }}
                        >
                          {model.availableMergeTypes.map((model) => (
                            <MenuItem value={model.key} key={model.key}>
                              {model.displayName}
                            </MenuItem>
                          ))}
                        </Select>
                      </FormControl>
                    </Stack>
                  </CardContent>
                </Card>
              </Grid>
            ))
          ) : (
            <></>
          )}
        </Grid>
        <Stack direction="row" justifyContent="flex-end" padding={2} spacing={2}>
          <ColorButton
            backgroundcolor="#005689"
            variant="contained"
            size='small'
            onClick={() => navigate(-1)}
          >
            BACK
          </ColorButton>
          <ColorButton
            backgroundcolor="#005689"
            size='small'
            variant="contained"
            onClick={validateBranches}
            disabled={!(versionName.length && namingConvention.length)}
          >
            CREATE RULE
          </ColorButton>
        </Stack>
      </Box>
    </div>
  );
}
