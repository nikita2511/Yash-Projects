import React from "react";
import Box from "@mui/material/Box";
import {
  Accordion,
  AccordionDetails,
  AccordionSummary,
  Button,
  Chip,
  Divider,
  Grid,
  Switch,
  Typography,
} from "@mui/material";
import ProgressBar from "../../../utils/ProgressBar";
import TextField from "@mui/material/TextField";
import Stack from "@mui/material/Stack";
import { ColorButton } from "../../../utils/CustomButton";
import { useLocation, useNavigate } from "react-router-dom";
import { getTokenForAPI } from "../../../utils/RetrieveToken";
import { useMsal } from "@azure/msal-react";
import CustomBreadCrumb from "../../../utils/CustomBreadCrumb";
import { ExpandMoreOutlined } from "@mui/icons-material";
import { constants } from "../../../utils/Constants";
import axios from "axios";
import ErrorAlert from "../../error/ErrorAlert";
import { useEffect } from "react";
/**
 *
 * @returns React Functional Component (UpdateADInfo) which renders a form to create AD Information for a particular user
 */
export default function UpdateADInfo() {
  const location = useLocation();
  const { state } = location;
  const { routeList } = state;
  const navigate = useNavigate();
  const { instance, inProgress, accounts } = useMsal();
  const [isVisible, setIsVisible] = React.useState(false);
  const [progressBarMessage, setProgressBarMessage] =
    React.useState("Please wait!");
  const [isErrorVisible, setIsErrorVisible] = React.useState(false);
  const [errorAlertCallback, setErrorAlertCallback] = React.useState({
    navigate: -1,
    navigateData: {
      state: {},
    },
    message: "Something unexpected happend! Please try again",
  });
  const [companyName, setCompanyName] = React.useState("");
  const [domainName, setDomainName] = React.useState("");
  const [tenantId, setTenantId] = React.useState("");
  const [applicationName, setApplicationName] = React.useState("");
  const [clientId, setClientId] = React.useState("");
  const [scope, setScope] = React.useState("");
  const [activeDirectoryName, setActiveDirectoryName] = React.useState("");
  const [isActiveDirectoryPrimary, setIsActiveDirectoryPrimary] =
    React.useState(false);
  const [activeDirectoryList, SetActiveDirectoryList] = React.useState([]);
  const [
    isUserProjectCollectionAdministrators,
    setIsUserProjectCollectionAdministrators,
  ] = React.useState(false);
  /**
   *
   * @param {*} message String value to be shown with Progress Bar
   * JS method called to make the Progress Bar visible along with the message
   */
  const showProgressBar = (message) => {
    setIsVisible(true);
    setProgressBarMessage(message);
  };
  /**
   *
   * JS method called to hide the Progress Bar
   */
  const hideProgressBar = () => {
    setIsVisible(false);
    setProgressBarMessage("");
  };
  /**
      *
      * @param {*} value boolean value to change visiblity of Alert Dialog
       JS method to update the boolean state value isErrorVisible
      */
  const handleErrorAlert = (value) => {
    setIsErrorVisible(value);
  };

  /**
   *
   * JS method to call DELETE REST Endpoint for deleting AD info.
   */
  const callDeleteADInfoAPI = (directory) => {
    showProgressBar("Please be patient! While AD info is being removed");
    const data = {
      activeDirectoryId: directory.activeDirectoryId,
    };
    axios
      .delete(constants.BASE_URL + constants.DELETE_ACTIVE_DIRECTORY, {
        data,
      })
      .then((response) => {
        console.log("callDeleteADInfoAPI-Response============>", response);
        hideProgressBar();
        handleErrorAlert(true);
        setErrorAlertCallback({
          message: `Active Directory ${directory.activeDirectoryName} removed successfully!`,
        });
        callGetADInfoAPI();
      })
      .catch((error) => {
        hideProgressBar();
        console.log("callDeleteADInfoAPI-Error============>", error);
        handleErrorAlert(true);
        setErrorAlertCallback({
          message:
            "Something went wrong while creating repository. Please try again!",
        });
      });
  };

  const clearAllADInfoFields = () => {
    setCompanyName("");
    setApplicationName("");
    setDomainName("");
    setClientId("");
    setTenantId("");
    setActiveDirectoryName("");
    setScope("");
    setIsActiveDirectoryPrimary(false);
  };

  /**
   *
   * @param {*} token Access token retrieved to call Azure REST APIs using backend endpoints
   * JS method to call POST REST Endpoint for POST inputs AD to be created
   */
  const callCreateADInfoAPI = () => {
    showProgressBar(
      "Please be patient! While Active Directory is being created."
    );
    const data = {
      companyName: companyName,
      applicationName: applicationName,
      activeDirectorydomain: domainName,
      applicationClientId: clientId,
      activeDirectoryId: tenantId,
      activeDirectoryName: activeDirectoryName,
      scope: scope,
      isActiveDirectoryPrimary: isActiveDirectoryPrimary,
    };
    axios
      .post(constants.BASE_URL + constants.POST_ACTIVE_DIRECTORY, data)
      .then((response) => {
        hideProgressBar();
        console.log("Response-callCreateADInfoAPI========>", response);
        handleErrorAlert(true);
        setErrorAlertCallback({
          message: `Active Directory ${activeDirectoryName} saved successfully!`,
        });
        clearAllADInfoFields();
        callGetADInfoAPI();
      })
      .catch((error) => {
        hideProgressBar();
        handleErrorAlert(true);
        setErrorAlertCallback({
          message: error.response.data.body.message,
        });
        console.log("Error-callCreateADInfoAPI=========>", error);
      });
  };

  /**
   *
   * JS method to call GET REST Endpoint for retrieving availble ADs
   */
  const callGetADInfoAPI = () => {
    showProgressBar(
      "Please be patient! while Active Directories are being fetched."
    );
    axios
      .get(constants.BASE_URL + constants.GET_ACTIVE_DIRECTORY)
      .then((response) => {
        hideProgressBar();
        for (const directory of response.data.body.activeDirectories) {
          directory["isActive"] = false;
        }
        console.log(
          "Response-callGetActiveDirectories========>",
          response.data.body.activeDirectories
        );
        SetActiveDirectoryList(response.data.body.activeDirectories);
      })
      .catch((error) => {
        hideProgressBar();
        handleErrorAlert(true);
        console.log("Error-callGetActiveDirectories=========>", error);
      });
  };

  const getProjectCollectionAdministrator = (token) => {
    showProgressBar(
      "Please be patient! while project collection administrators are being fetched."
    );
    let config = {
      headers: { authorization: "Bearer " + token },
      params: {
        organizationName: localStorage.getItem("organizationName"),
      },
    };
    axios
      .get(
        constants.BASE_URL + constants.GET_PROJECT_COLLECTION_ADMINISTRATORS,
        config
      )
      .then((response) => {
        hideProgressBar();
        console.log(
          "Response-getProjectCollectionAdministrator==============>",
          response.data.body.projectCollectionAdministrators
        );
        const admins = response.data.body.projectCollectionAdministrators;
        const loggedInUsername = instance.getActiveAccount().username;
        const isUserAdmin = admins.filter((user) => {
          return user.user.mailAddress === loggedInUsername;
        }).length;
        setIsUserProjectCollectionAdministrators(isUserAdmin);
        if (!isUserAdmin) {
          handleErrorAlert(true);
          setErrorAlertCallback({
            navigate: -1,
            message:
              "Due to lack of sufficient access rights, You can not add AD information. Kindly contact organization admin",
          });
        }
      })
      .catch((error) => {
        hideProgressBar();
        console.log(
          "Response-getProjectCollectionAdministrator==============>",
          error.response
        );
      });
  };

  const getTokenForProjectCollectionAdministratorAPI = () => {
    getTokenForAPI(
      instance,
      inProgress,
      accounts,
      getProjectCollectionAdministrator
    );
  };

  useEffect(() => {
    callGetADInfoAPI();
    getTokenForProjectCollectionAdministratorAPI();
    // eslint-disable-next-line
  }, [instance, accounts, inProgress]);

  const handleOnADInfoEditClick = (directoryId) => {
    const directories = [...activeDirectoryList];
    const directoryToEdit = directories.find(
      (item) => item._id === directoryId
    );
    directoryToEdit["isActive"] = !directoryToEdit.isActive;
    SetActiveDirectoryList(directories);
  };

  return (
    <div>
      <ProgressBar
        isVisible={isVisible}
        progressBarMessage={progressBarMessage}
      />
      <ErrorAlert
        isErrorVisible={isErrorVisible}
        callback={() => {
          setIsErrorVisible(false);
          if (
            errorAlertCallback.hasOwnProperty("navigate") &&
            errorAlertCallback.hasOwnProperty("navigateData")
          ) {
            navigate(
              errorAlertCallback.navigate,
              errorAlertCallback.navigateData
            );
          } else if (errorAlertCallback.hasOwnProperty("navigate")) {
            navigate(errorAlertCallback.navigate);
          }
        }}
        message={errorAlertCallback.message}
      />
      <Box>
        <Box mr={1} mb={1}>
          <CustomBreadCrumb
            routeList={routeList}
            location={location.pathname}
          />
        </Box>
        <Typography
          variant="h6"
          color={"#005689"}
          fontWeight={"bold"}
          mt={1.4}
          gutterBottom
        >
          Active Directory Information
        </Typography>
        <Divider />

        <Stack direction={"row"} spacing={2} mt={4}>
          <Stack direction={"column"} spacing={1.5} width={"50%"}>
            <TextField
              variant="outlined"
              fullWidth
              label="Company Name"
              size="medium"
              value={companyName}
              required
              helperText={
                companyName.trim().length ? "" : "Please enter company name"
              }
              //   error={!companyName.trim().length}
              onChange={(event) => setCompanyName(event.target.value)}
            />
            <TextField
              variant="outlined"
              fullWidth
              label="Domain Name"
              size="medium"
              value={domainName}
              required
              helperText={
                domainName.trim().length
                  ? ""
                  : "Please enter domain for your Active Directory"
              }
              //   error={!domainName.trim().length}
              onChange={(event) => setDomainName(event.target.value)}
            />
            <TextField
              variant="outlined"
              fullWidth
              label="Tenant ID/ Directory ID"
              size="medium"
              value={tenantId}
              required
              helperText={
                tenantId.trim().length
                  ? ""
                  : "Please enter Tenant ID/ Directory ID"
              }
              //   error={!tenantId.trim().length}
              onChange={(event) => setTenantId(event.target.value)}
            />
            <TextField
              variant="outlined"
              fullWidth
              label="Registered Application Name in Active Directory"
              disabled
              size="medium"
              value={applicationName}
              required
              // helperText={
              //   applicationName.trim().length
              //     ? ""
              //     : "Please enter Registered Application Name"
              // }
              //   error={!applicationName.trim().length}
              onChange={(event) => setApplicationName(event.target.value)}
            />
          </Stack>

          <Stack direction={"column"} spacing={1.5} width={"50%"}>
            <TextField
              variant="outlined"
              fullWidth
              label="Active Directory Name"
              size="medium"
              value={activeDirectoryName}
              required
              helperText={
                activeDirectoryName.trim().length
                  ? ""
                  : "Please enter Active Directory Name"
              }
              //   error={!activeDirectoryName.trim().length}
              onChange={(event) => setActiveDirectoryName(event.target.value)}
            />
            <TextField
              variant="outlined"
              fullWidth
              label="Registered Application Id/ Client Id"
              size="medium"
              value={clientId}
              required
              helperText={
                clientId.trim().length
                  ? ""
                  : "Please enter ApplicationId / ClientId"
              }
              //   error={!clientId.trim().length}
              onChange={(event) => setClientId(event.target.value)}
            />
            <TextField
              variant="outlined"
              fullWidth
              label="Scope for Application"
              disabled
              size="medium"
              value={scope}
              required
              // helperText={scope.trim().length ? "" : "Please enter Scope "}
              //   error={!scope.trim().length}
              onChange={(event) => setScope(event.target.value)}
            />
            <Box pl={2}>
              <Typography
                color={"#007CB9"}
                fontWeight={"bold"}
                fontSize={"14px"}
              >
                Set AD as Primary
              </Typography>
              <Stack direction={"row"} alignItems={"center"} mt={0.5}>
                <Typography
                  color={"#007CB9"}
                  fontWeight={"bold"}
                  fontSize={"18px"}
                >
                  No
                </Typography>
                <Switch
                  sx={{
                    "& .MuiSwitch-switchBase.Mui-checked": {
                      color: "#005689",
                    },
                    "& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track": {
                      backgroundColor: "#005689",
                    },
                  }}
                  checked={isActiveDirectoryPrimary}
                  onChange={(event) => {
                    setIsActiveDirectoryPrimary(event.target.checked);
                  }}
                />
                <Typography
                  color={"#007CB9"}
                  fontWeight={"bold"}
                  fontSize={"18px"}
                >
                  Yes
                </Typography>
              </Stack>
            </Box>
          </Stack>
        </Stack>

        <Stack direction="row" justifyContent="flex-end" mt={2} spacing={2}>
          <ColorButton
            backgroundcolor="#005689"
            variant="contained"
            size="small"
            onClick={() => navigate(-1)}
          >
            BACK
          </ColorButton>
          <ColorButton
            backgroundcolor="#005689"
            variant="contained"
            size="small"
            onClick={callCreateADInfoAPI}
            disabled={
              !(
                companyName.trim().length &&
                domainName.trim().length &&
                clientId.trim().length &&
                tenantId.trim().length &&
                activeDirectoryName.trim().length
              )
            }
          >
            Save AD Information
          </ColorButton>
        </Stack>
        <Typography
          variant="h6"
          color={"#005689"}
          fontWeight={"bold"}
          mt={1.4}
          gutterBottom
        >
          Saved Active Directory
        </Typography>
        <Divider />

        {activeDirectoryList.length > 0 ? (
          <Grid container spacing={2} mt={1}>
            {activeDirectoryList.map((info, index) => (
              <Grid item xs={12} md={6} key={index}>
                <Accordion>
                  <AccordionSummary
                    expandIcon={<ExpandMoreOutlined />}
                    aria-controls="panel1a-content"
                    id="panel1a-header"
                  >
                    <Typography
                      variant="subtitle1"
                      color={"#005689"}
                      fontWeight={"bold"}
                      mr={3}
                    >
                      {info.activeDirectoryName}
                    </Typography>
                    {info.isActiveDirectoryPrimary ? (
                      <Chip label={"Primary"} />
                    ) : (
                      <></>
                    )}
                  </AccordionSummary>
                  <AccordionDetails>
                    <Stack direction={"row"} spacing={2}>
                      <Stack direction={"column"} spacing={1.5} width={"50%"}>
                        <TextField
                          className="ADInfo-Text"
                          variant="outlined"
                          fullWidth
                          label="Company Name"
                          size="medium"
                          value={info.companyName}
                          required
                          disabled={!info.isActive}
                        />
                        <TextField
                          variant="outlined"
                          fullWidth
                          label="Domain Name"
                          size="medium"
                          value={info.activeDirectorydomain}
                          required
                          disabled={!info.isActive}
                        />
                        <TextField
                          variant="outlined"
                          fullWidth
                          label="Tenant ID/ Directory ID"
                          size="medium"
                          value={info.activeDirectoryId}
                          required
                          disabled={!info.isActive}
                        />
                        <TextField
                          variant="outlined"
                          fullWidth
                          label="Registered Application Name in Active Directory"
                          size="medium"
                          value={info.applicationName}
                          required
                          disabled={!info.isActive}
                        />
                      </Stack>

                      <Stack direction={"column"} spacing={1.5} width={"50%"}>
                        <TextField
                          variant="outlined"
                          fullWidth
                          label="Active Directory Name"
                          size="medium"
                          value={info.activeDirectoryName}
                          required
                          disabled={!info.isActive}
                        />
                        <TextField
                          variant="outlined"
                          fullWidth
                          label="Registered Application Id/ Client Id"
                          size="medium"
                          value={info.applicationClientId}
                          required
                          disabled={!info.isActive}
                        />
                        <TextField
                          variant="outlined"
                          fullWidth
                          label="Scope for Application"
                          size="medium"
                          value={info.scope}
                          required
                          disabled={!info.isActive}
                        />
                        <Box
                          pl={2}
                          color={!info.isActive ? "lightgrey" : "#007CB9"}
                        >
                          <Typography
                            // color={!info.isActive?"lightgrey":"#007CB9"}
                            color={"inherit"}
                            fontWeight={"bold"}
                            fontSize={"14px"}
                          >
                            Set AD as Primary
                          </Typography>
                          <Stack
                            direction={"row"}
                            alignItems={"center"}
                            mt={0.5}
                          >
                            <Typography
                              color={"inherit"}
                              fontWeight={"bold"}
                              fontSize={"18px"}
                            >
                              No
                            </Typography>
                            <Switch
                              sx={{
                                "& .MuiSwitch-switchBase.Mui-checked": {
                                  color: "#005689",
                                },
                                "& .MuiSwitch-switchBase.Mui-checked + .MuiSwitch-track":
                                  {
                                    backgroundColor: "#005689",
                                  },
                              }}
                              checked={info.isActiveDirectoryPrimary}
                              disabled={!info.isActive}
                            />
                            <Typography
                              color={"inherit"}
                              fontWeight={"bold"}
                              fontSize={"18px"}
                            >
                              Yes
                            </Typography>
                          </Stack>
                        </Box>
                      </Stack>
                    </Stack>
                    <Stack
                      justifyContent={"flex-end"}
                      display={"flex"}
                      direction={"row"}
                      mt={2}
                      spacing={2}
                    >
                      <Button
                        variant="outlined"
                        disabled
                        onClick={() => {
                          if (!isUserProjectCollectionAdministrators) {
                            handleErrorAlert(true);
                            setErrorAlertCallback({
                              navigate: -1,
                              message:
                                "Due to lack of sufficient access rights, You can not add AD information. Kindly contact organization admin",
                            });
                          } else {
                            handleOnADInfoEditClick(info._id);
                          }
                        }}
                      >
                        {!info.isActive ? "Edit" : "Save"} AD Info
                      </Button>
                      <Button
                        variant="outlined"
                        color="error"
                        onClick={() => {
                          callDeleteADInfoAPI(info);
                        }}
                      >
                        Delete AD Info
                      </Button>
                    </Stack>
                  </AccordionDetails>
                </Accordion>
              </Grid>
            ))}
          </Grid>
        ) : (
          <Typography
            variant="h6"
            gutterBottom
            color={"#005689"}
            textAlign={"center"}
            mt={2}
          >
            {`Active Directories are not saved yet!`}
          </Typography>
        )}
      </Box>
    </div>
  );
}
