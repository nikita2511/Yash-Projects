import React from "react";
import Header from "./Header";
import { MsalAuthenticationTemplate } from "@azure/msal-react";
import { InteractionType } from "@azure/msal-browser";
import { useLocation } from "react-router-dom";
import GetProject from "../projects/GetProject";
import SomethingWrong from "../../error/SomethingWrong";
import UpdateRules from "../organization/rules/UpdateRules";
import ExistingProject from "../projects/ExistingProject";
import CreateProject from "../projects/CreateProject";
import CreateADInfo from "../ActiveDirectoryInfo/CreateADInfo";
import UpdateADInfo from "../ActiveDirectoryInfo/UpdateADInfo";
import CreateReleasePipeline from "../projects/CreateReleasePipeline";
/**
 *
 * @returns React Functional Component (Dashboard) which hosts all other components in the flow
 */
export default function Dashboard() {
  let location = useLocation();
  /**
   *
   * @param {*} route current pathname or route name
   * @returns the component as per current pathname or route name
   */
  const GetComponentToRender = ({ route }) => {
    switch (route) {
      case "/azure/project":
        return <GetProject />;
      case "/azure/updateRule":
        return <UpdateRules />;
      case "/azure/projectInfo":
        return <ExistingProject />;
      case "/azure/createProject":
        return <CreateProject />;
      case "/createADInfo":
        return <CreateADInfo />;
      case "/azure/updateAdInfo":
        return <UpdateADInfo />;
      case "/azure/createReleasePipeline":
        return <CreateReleasePipeline />;
      default:
        return <SomethingWrong />;
    }
  };
  /**
   * JSON object used as value for authenticationRequest prop in MSALAuthenticationTemplate
   */
  const authRequest = {
    ...["499b84ac-1321-427f-aa17-267ca6975798/user_impersonation"],
  };
  return (
    <MsalAuthenticationTemplate
      interactionType={InteractionType.Redirect}
      authenticationRequest={authRequest}
    >
      <Header>
        <GetComponentToRender route={location.pathname} />
      </Header>
    </MsalAuthenticationTemplate>
  );
}
