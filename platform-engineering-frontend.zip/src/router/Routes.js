import { createBrowserRouter } from "react-router-dom";
import Dashboard from "../components/dashboard/Dashboard";
import NotFound from "../components/error/NotFound";
import SomethingWrong from "../components/error/SomethingWrong";
import UserProfile from "../components/onboarding/UserProfile";
import AllOrganization from "../components/organization/AllOrganization";
import CreateRules from "../components/organization/rules/CreateRules"; 
import DevOpsPlatformSelector from "../DevOpsPlatformSelector";
import AzureDevopsPlatform from "../AzureDevopsPlatform";
/**
 * constant named router assigned value returned from createBrowserRouter method of react-router-dom which accepts array of JSON objects of routes.
 */
export const router = createBrowserRouter([
  {
    path: "/",
    element: <DevOpsPlatformSelector />,
    
    //   loader: rootLoader,
    //   children: [
    //     {
    //       path: "team",
    //       element: <Team />,
    //       loader: teamLoader,
    //     },
    //   ],
    errorElement:<SomethingWrong/>
  },
  {
    path: "/azure",
    element: <AzureDevopsPlatform />,
    errorElement:<SomethingWrong/>
  },
  {
    path: "/organization",
    element: <AllOrganization />,
    errorElement:<SomethingWrong/>
  },
  // {
  //   path: "/project",
  //   element: <Dashboard />,
  //   errorElement:<SomethingWrong/>
  // },
  {
    path: "/createRule",
    element: <CreateRules />,
    errorElement:<SomethingWrong/>
  },
  {
    path: "/updateRule",
    element: <Dashboard/>,
    errorElement:<SomethingWrong/>
  },
  {
    path: "/createADInfo",
    element: <Dashboard />,
    errorElement: <SomethingWrong />
  },
  {
    path: "/projectInfo",
    element: <Dashboard/>,
    errorElement:<SomethingWrong/>
  },
  {
    path: "/createProject",
    element: <Dashboard/>,
    errorElement:<SomethingWrong/>
  },
  {
    path: "*",
    element:<NotFound/>
  },
  {
    path: "profile",
    element: <UserProfile />,
  },
]);
