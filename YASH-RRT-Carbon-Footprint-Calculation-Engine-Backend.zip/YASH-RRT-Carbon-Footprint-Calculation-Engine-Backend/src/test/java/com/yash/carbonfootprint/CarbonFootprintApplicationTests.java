package com.yash.carbonfootprint;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CarbonFootprintApplicationTests {

	@Test
	void contextLoads() {
	}

}
