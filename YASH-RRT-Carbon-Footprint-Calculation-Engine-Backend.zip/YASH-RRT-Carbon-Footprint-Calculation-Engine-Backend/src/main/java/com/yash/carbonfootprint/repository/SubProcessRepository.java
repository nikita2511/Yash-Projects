package com.yash.carbonfootprint.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.yash.carbonfootprint.model.Process;
import com.yash.carbonfootprint.model.SubProcess;

@Repository
public interface SubProcessRepository extends JpaRepository<SubProcess, Long> {
	public List<SubProcess> findByName(String name);
  
}
