package com.yash.carbonfootprint.repository;

// import org.hibernate.mapping.List;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.yash.carbonfootprint.model.Process;

@Repository
public interface ProcessRepository extends JpaRepository<Process, Long> {
    public List<Process> findAllByOrderByUpdatedAtDesc();
    public List<Process> findByName(String name);
//    public Process findBy
}
