package com.yash.carbonfootprint.exceptions;

import org.springframework.http.HttpStatus;

//import org.springframework.http.HttpStatus;
//
//import com.yash.carbonfootprint.service.ResourceAlreadyExistsException;

public class ResourceAlreadyExistsException extends RuntimeException {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private final HttpStatus statusCode;
    private final String resource;

    public ResourceAlreadyExistsException(String resource, HttpStatus statusCode) {
        super("resource '" + resource + "' already exists.");
        this.resource = resource;
        this.statusCode = statusCode;
    }

    public HttpStatus getStatusCode() {
        return statusCode;
    }

    public String getUserEmail() {
        return resource;
    }
}
