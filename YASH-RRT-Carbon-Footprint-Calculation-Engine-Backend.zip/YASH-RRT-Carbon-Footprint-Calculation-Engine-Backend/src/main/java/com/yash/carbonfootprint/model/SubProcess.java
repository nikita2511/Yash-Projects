package com.yash.carbonfootprint.model;
import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.*;

@Entity
@Table(name = "sub_process_master_data", schema = "carbon_footprint")
public class SubProcess {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private Double emission_factor;
    private String unit;

    @ManyToOne
    @JoinColumn(name = "process_id")
    @JsonBackReference
    private Process process;

    // Getters and Setters

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Double getEmissionFactor() {
        return emission_factor;
    }

    public void setEmissionFactor(Double emission_factor) {
        this.emission_factor = emission_factor;
    }

    public String getUnit() {
        return unit;
    }

    public void setUnit(String unit) {
        this.unit = unit;
    }

    public Double getEmission_factor() {
        return emission_factor;
    }

    public void setEmission_factor(Double emission_factor) {
        this.emission_factor = emission_factor;
    }

    public Process getProcess() {
        return process;
    }

    public void setProcess(Process process) {
        this.process = process;
    }
    @Override
    public String toString() {
        return "SubProcess [id=" + id + ", name=" + name + ", emission_factor=" + emission_factor + ", unit=" + unit
                 + "]";
    }

}
