package com.yash.carbonfootprint.dao;

public class ProcessDao {
    
}
