package com.yash.carbonfootprint.model;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonManagedReference;

import jakarta.persistence.*;

@Entity
@Table(name = "supply_chain", schema = "carbon_footprint")
public class SupplyChain {

    public SupplyChain(Long id, Long user_id, Double total_carbon_emission, String name,
            SupplyChainCategoryMasterData supplyChainCategoryMasterData) {
        this.id = id;
        this.user_id = user_id;
        this.total_carbon_emission = total_carbon_emission;
        this.name = name;
        this.supplyChainCategoryMasterData = supplyChainCategoryMasterData;
    }

    @Override
    public String toString() {
        return "SupplyChain [id=" + id + ", user_id=" + user_id + ", total_carbon_emission=" + total_carbon_emission
                + ", name=" + name + ", supplyChainCategoryMasterData=" + supplyChainCategoryMasterData
                + ", supplyChainMappings=" + supplyChainMappings + "]";
    }

    public SupplyChain(Long id,Long user_id,String name,
            SupplyChainCategoryMasterData supplyChainCategoryMasterData) {
        this.id = id;
        this.user_id = user_id;
        this.name = name;
        this.supplyChainCategoryMasterData = supplyChainCategoryMasterData;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "supply_chain_id_seq")
    @SequenceGenerator(name = "supply_chain_id_seq", sequenceName = "carbon_footprint.supply_chain_id_seq", allocationSize = 1)
    private Long id;

    @Column(name = "user_id")
    private Long user_id;

    @Column(name = "total_carbon_emission")
    private Double total_carbon_emission=10.0;

    @Column(name = "name")
    private String name;

    @ManyToOne
    @JoinColumn(name = "category_id")
    private SupplyChainCategoryMasterData supplyChainCategoryMasterData;

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "supplyChain", fetch = FetchType.EAGER)
    @JsonManagedReference
    private List<SupplyChainMapping> supplyChainMappings = new ArrayList<>();

    public List<SupplyChainMapping> getSupplyChainMappings() {
        return supplyChainMappings;
    }

    public void setSupplyChainMappings(List<SupplyChainMapping> supplyChainMappings) {
        this.supplyChainMappings = supplyChainMappings;
    }

    public SupplyChain(Long user_id, String name, SupplyChainCategoryMasterData supplyChainCategoryMasterData) {
        this.user_id = user_id;
        this.name = name;
        this.supplyChainCategoryMasterData = supplyChainCategoryMasterData;
    }

    public SupplyChain() {
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getUserId() {
        return user_id;
    }

    public void setUserId(Long user_id) {
        this.user_id = user_id;
    }

    public Double getTotalCarbonEmission() {
        return total_carbon_emission;
    }

    public void setTotalCarbonEmission(Double total_carbon_emission) {
        this.total_carbon_emission = total_carbon_emission;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public SupplyChainCategoryMasterData getSupplyChainCategoryMasterData() {
        return supplyChainCategoryMasterData;
    }

    public void setSupplyChainCategoryMasterData(SupplyChainCategoryMasterData supplyChainCategoryMasterData) {
        this.supplyChainCategoryMasterData = supplyChainCategoryMasterData;
    }

}
