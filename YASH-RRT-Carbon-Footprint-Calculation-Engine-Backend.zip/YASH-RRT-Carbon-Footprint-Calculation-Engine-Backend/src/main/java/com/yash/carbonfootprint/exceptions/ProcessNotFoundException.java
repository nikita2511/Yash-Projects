package com.yash.carbonfootprint.exceptions;

import org.springframework.http.HttpStatus;

public class ProcessNotFoundException extends ProcessException {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public ProcessNotFoundException(Long id) {
        super("PROCESS_NOT_FOUND", HttpStatus.NOT_FOUND,
            "Process with ID " + id + " not found.");
    }
}
