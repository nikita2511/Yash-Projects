package com.yash.carbonfootprint.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.yash.carbonfootprint.dto.SupplyChainMappingRequestDTO;
import com.yash.carbonfootprint.dto.SupplyChainRequestDTO;
import com.yash.carbonfootprint.exceptions.ResourceAlreadyExistsException;
import com.yash.carbonfootprint.model.Process;
import com.yash.carbonfootprint.model.SubProcess;
import com.yash.carbonfootprint.model.SupplyChain;
import com.yash.carbonfootprint.model.SupplyChainCategoryMasterData;
import com.yash.carbonfootprint.model.SupplyChainMapping;
import com.yash.carbonfootprint.repository.ProcessRepository;
import com.yash.carbonfootprint.repository.SubProcessRepository;
import com.yash.carbonfootprint.repository.SupplyChainCategoryMasterDataRepository;
import com.yash.carbonfootprint.repository.SupplyChainMappingRepository;
import com.yash.carbonfootprint.repository.SupplyChainRepository;

@Service
public class SupplyChainService {
    @Autowired
    SupplyChainRepository supplyChainRepository;

    @Autowired
    SupplyChainCategoryMasterDataRepository supplyChainCategoryMasterDataRepository;

    @Autowired
    ProcessRepository processRepository;

    @Autowired
    SubProcessRepository subProcessRepository;

    @Autowired
    SupplyChainMappingRepository supplyChainMappingRepository;

    public SupplyChain getSupplyChainById(Long id) {
        return supplyChainRepository.findById(id).get();
    }

    public SupplyChain createSupplyChain(SupplyChainRequestDTO dto) {
    	 List<SupplyChain> existingSupplyChain = supplyChainRepository.findByName(dto.getName());
   	     System.out.println("existingSupplyChain"+existingSupplyChain);
         if (!existingSupplyChain.isEmpty()) {
         	  throw new ResourceAlreadyExistsException( dto.getName() ,HttpStatus.CONFLICT);
         }
        SupplyChainCategoryMasterData supplyChainCategoryMasterData = supplyChainCategoryMasterDataRepository
                .findById(dto.getCategory_id()).get();
        System.out.println("supplyChainCategoryMasterData" + supplyChainCategoryMasterData);
        SupplyChain supplyChain = new SupplyChain(
                dto.getUser_id(),
                dto.getName(),
                supplyChainCategoryMasterData);
        // supplyChain.setUserId(dto.getUserId());
        System.out.println("supplyChain" + supplyChain);
        System.out.println("47 ------------------- " + dto);
        List<SupplyChainMapping> mappings = new ArrayList<>();
        Double total_carbon_emission = 0.0;
        for (SupplyChainMappingRequestDTO mappingDTO : dto.getSupply_chain_mapping()) {
            Process process = processRepository.findById(mappingDTO.getProcess_id()).get();
            SubProcess subProcess = subProcessRepository.findById(mappingDTO.getSub_process_id()).get();
            Double processFootprint = mappingDTO.getQuantity() * subProcess.getEmissionFactor();
            total_carbon_emission = processFootprint + total_carbon_emission;
            SupplyChainMapping mapping = new SupplyChainMapping(
                    mappingDTO.getQuantity(),
                    mappingDTO.getSequence(),
                    processFootprint,
                    process,
                    subProcess,
                    supplyChain);
            mappings.add(mapping);
        }
        supplyChain.setSupplyChainMappings(mappings);
        supplyChain.setTotalCarbonEmission(total_carbon_emission);
        System.out.println("total_carbon_emission" + total_carbon_emission);
        supplyChainRepository.save(supplyChain);
        SupplyChain createdSupplyChain = supplyChainRepository.save(supplyChain);
        return createdSupplyChain;

    }

    public void updateSupplyChain(SupplyChainRequestDTO dto) {
        SupplyChainCategoryMasterData supplyChainCategoryMasterData = supplyChainCategoryMasterDataRepository
                .findById(dto.getCategory_id()).get();
        SupplyChain supplyChain = new SupplyChain(
                dto.getId(),
                dto.getUser_id(),
                dto.getName(),
                supplyChainCategoryMasterData);
        // supplyChain.setUserId(dto.getUserId());
        List<SupplyChainMapping> mappings = new ArrayList<>();
        Double total_carbon_emission = 0.0;
        for (SupplyChainMappingRequestDTO mappingDTO : dto.getSupply_chain_mapping()) {
            Process process = processRepository.findById(mappingDTO.getProcess_id()).get();
            SubProcess subProcess = subProcessRepository.findById(mappingDTO.getSub_process_id()).get();
            Double processFootprint = mappingDTO.getQuantity() * subProcess.getEmissionFactor();
            SupplyChainMapping mapping = new SupplyChainMapping(
                    mappingDTO.getId(),
                    mappingDTO.getQuantity(),
                    mappingDTO.getSequence(),
                    processFootprint,
                    process,
                    subProcess,
                    supplyChain);
            mappings.add(mapping);
            total_carbon_emission = total_carbon_emission + processFootprint;
        }
        supplyChain.setSupplyChainMappings(mappings);
        supplyChain.setTotalCarbonEmission(total_carbon_emission);
        System.out.println("total_carbon_emission" + total_carbon_emission);
        System.out.println("supplyChain" + supplyChain);
        SupplyChain createdSupplyChain = supplyChainRepository.save(supplyChain);
        System.out.println("createdSupplyChain" + createdSupplyChain);
    }

    public List<SupplyChain> getAllSupplyChains() {
        List<SupplyChain> supplyChains = new ArrayList<SupplyChain>();
        supplyChains = supplyChainRepository.findAll();
        System.out.println("supply chains" + supplyChains);
        return supplyChains;
    }

    public void deleteById(Long id) {
        System.out.println("id for deletinh" + id);
        try {
            System.out.println(supplyChainRepository.findById(9L));
            Optional<SupplyChain> category = supplyChainRepository.findById(id);
            supplyChainRepository.delete(category.get());
            System.out.println("after");
        } catch (Exception e) {
            System.out.println(e.getMessage());
        }
    }

    public void deleteSupplyChainMapping(Long supplyChainId, Long supplyChainMappingId) {
        SupplyChain supplyChain = supplyChainRepository.findById(supplyChainId).get();
        SupplyChainMapping supplyChainMapping = supplyChainMappingRepository.findById(supplyChainMappingId).get();
        supplyChain.getSupplyChainMappings().remove(supplyChainMapping);
        supplyChainRepository.save(supplyChain);
        supplyChainMappingRepository.delete(supplyChainMapping);
    }
}
