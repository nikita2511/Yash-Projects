package com.yash.carbonfootprint.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import com.yash.carbonfootprint.repository.ProcessRepository;
import com.yash.carbonfootprint.exceptions.ProcessNotFoundException;
import com.yash.carbonfootprint.exceptions.ResourceAlreadyExistsException;
import com.yash.carbonfootprint.model.Process;


@Service
public class ProcessService {

    @Autowired
    ProcessRepository processRepository;

    // getting all books record by using the method findaAll() of CrudRepository
    public List<Process> getAllProcesses() {
        List<Process> processes = new ArrayList<Process>();
        processes = processRepository.findAllByOrderByUpdatedAtDesc();
        return processes;
    }

    public void saveOrUpdate(Process process) {
        
    	  List<Process> existingProcess = processRepository.findByName(process.getName());
          if (!existingProcess.isEmpty()) {
          	  throw new ResourceAlreadyExistsException( process.getName() ,HttpStatus.CONFLICT);
          }
        processRepository.save(process);
    }

    public Process getProcessById(long id) {
        return processRepository.findById(id).get();
    }

    public void deleteById(Long id) {
        System.out.println("id for deletinh" + id);
        try {
        Optional<Process> process = processRepository.findById(id);
        if (!process.isPresent()) {
            throw new ProcessNotFoundException(id);
        }
        processRepository.deleteById(id);
            System.out.println("after");
        } catch (Exception e) {
            System.out.println("-----e in service"+e);
            throw e;
        }
    }
}
