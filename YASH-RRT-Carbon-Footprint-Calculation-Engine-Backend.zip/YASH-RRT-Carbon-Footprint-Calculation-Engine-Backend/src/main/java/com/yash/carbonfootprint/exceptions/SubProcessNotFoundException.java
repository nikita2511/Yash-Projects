package com.yash.carbonfootprint.exceptions;

import org.springframework.http.HttpStatus;

public class SubProcessNotFoundException extends ProcessException {

    public SubProcessNotFoundException(Long id) {
        super("PROCESS_NOT_FOUND", HttpStatus.NOT_FOUND,
            "Process with ID " + id + " not found.");
    }
}
