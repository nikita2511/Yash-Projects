package com.yash.carbonfootprint.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

import com.yash.carbonfootprint.exceptions.ResourceAlreadyExistsException;
import com.yash.carbonfootprint.model.SupplyChainCategoryMasterData;
import com.yash.carbonfootprint.model.User;
import com.yash.carbonfootprint.repository.SupplyChainCategoryMasterDataRepository;

@Service
public class SupplyChainCategoryMasterDataService {
    
@Autowired
SupplyChainCategoryMasterDataRepository supplyChainCategoryMasterDataRepository;

public void saveOrUpdate(SupplyChainCategoryMasterData supplyChainCategoryMasterData) {
    try {
    	List<SupplyChainCategoryMasterData> existingCategory = supplyChainCategoryMasterDataRepository.findByName(supplyChainCategoryMasterData.getName());
        if (!existingCategory.isEmpty()) {
        	  throw new ResourceAlreadyExistsException( supplyChainCategoryMasterData.getName() ,HttpStatus.CONFLICT);
        }
        supplyChainCategoryMasterDataRepository.save(supplyChainCategoryMasterData);  
    } catch (Exception e) {
    }

}

public List<SupplyChainCategoryMasterData> getAllCategories()   
	{  
	List<SupplyChainCategoryMasterData> categories = new ArrayList<SupplyChainCategoryMasterData>();  
	categories = supplyChainCategoryMasterDataRepository.findAll();
    System.out.println("categories in service" + categories);
    return categories;  
	}

public  SupplyChainCategoryMasterData getCategoryById(long id) {
		return supplyChainCategoryMasterDataRepository.findById(id).get();
	}  

public void deleteById(Long id) {
    System.out.println("id for deletinh" +id);
    try {
    System.out.println(supplyChainCategoryMasterDataRepository.findById(9L));
    Optional<SupplyChainCategoryMasterData> category = supplyChainCategoryMasterDataRepository.findById(id);    
    supplyChainCategoryMasterDataRepository.delete(category.get());
    System.out.println("after");  
    } catch (Exception e) {
       System.out.println(e.getMessage());
    }
}
}