package com.yash.carbonfootprint.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.yash.carbonfootprint.exceptions.ProcessNotFoundException;
import com.yash.carbonfootprint.exceptions.ResourceAlreadyExistsException;
import com.yash.carbonfootprint.model.SubProcess;
import com.yash.carbonfootprint.service.SubProcessService;

@RestController
@RequestMapping("/api/v1")
@CrossOrigin(origins = "http://localhost:3000")
public class SubProcessController {

    @Autowired
    SubProcessService subProcessService;

    @PostMapping("/process/{process_id}/subProcess")
    public ResponseEntity<?> save(@PathVariable("process_id") Long process_id,
            @RequestBody List<SubProcess> subProcesses) {
    	   Map<String, Object> response = new HashMap<>();
        try {
            System.out.print(process_id);
            System.out.println(subProcesses);
            subProcessService.saveAllObjects(process_id, subProcesses);
            response.put("message", "Subprocesses saved successfully");
            response.put("status", 200); // Optional inclusion
            return ResponseEntity.ok(response);
        } catch (ProcessNotFoundException e) {
            response.put("message", e.getMessage());
            response.put("status", HttpStatus.NOT_FOUND);
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
    	}
        catch (ResourceAlreadyExistsException e) {
            response.put("message", e.getMessage());
            response.put("status", HttpStatus.CONFLICT);
            return ResponseEntity.status(HttpStatus.CONFLICT).body(response);
    	}
    }

    @PutMapping("/process/{process_id}/subProcess")
    public ResponseEntity<?> update(@PathVariable("process_id") Long process_id, @RequestBody SubProcess subProcess) {
        try {
            Map<String, Object> response = new HashMap<>();
            subProcessService.update(process_id, subProcess);
            response.put("message", "sub process updated successfully");
            response.put("status", 200); // Optional inclusion 
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }

    }

    @DeleteMapping("process/{processId}/subProcess/{subProcessId}")
    public ResponseEntity<?> deleteById(@PathVariable Long processId, @PathVariable Long subProcessId) {
        Map<String, Object> response = new HashMap<>();
        try {
            subProcessService.deleteById(processId, subProcessId);
            response.put("message", "process deleted successfully");
            response.put("status", 204); // Optional inclusion
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("message", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }
}
