package com.yash.carbonfootprint.exceptions;

import org.springframework.http.HttpStatus;

public class SubProcessException extends RuntimeException {

    private final String code;
    private final HttpStatus httpStatus;

    public SubProcessException(String code, HttpStatus httpStatus, String message) {
        super(message);
        this.code = code;
        this.httpStatus = httpStatus;
    }

    public String getCode() {
        return code;
    }

    public HttpStatus getHttpStatus() {
        return httpStatus;
    }
}
