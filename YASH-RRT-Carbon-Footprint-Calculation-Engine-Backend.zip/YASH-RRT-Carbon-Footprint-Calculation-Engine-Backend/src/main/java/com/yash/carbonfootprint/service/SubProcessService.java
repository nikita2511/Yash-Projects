package com.yash.carbonfootprint.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import com.yash.carbonfootprint.model.SubProcess;
import com.yash.carbonfootprint.exceptions.ProcessNotFoundException;
import com.yash.carbonfootprint.exceptions.ResourceAlreadyExistsException;
import com.yash.carbonfootprint.model.Process;
import com.yash.carbonfootprint.repository.ProcessRepository;
import com.yash.carbonfootprint.repository.SubProcessRepository;
import java.util.List;
import java.util.Optional;

@Service
public class SubProcessService {

    @Autowired
    SubProcessRepository subProcessRepository; // Inject the appropriate repository

    @Autowired
    ProcessRepository processRepository;

    public void saveAllObjects(Long process_id, List<SubProcess> subProcesses) {
    	
        Optional<Process> optionalProcess = processRepository.findById(process_id);
        System.out.println("optionalProcess" + optionalProcess);
        if (optionalProcess.isPresent()) {
            Process process = optionalProcess.get();
            for (SubProcess subProcess : subProcesses) {
                subProcess.setProcess(process);
                List<SubProcess> existingSubProcess = subProcessRepository.findByName(subProcess.getName());
                System.out.println("existingSubProcess" +existingSubProcess);
                if (!existingSubProcess.isEmpty()) {
                	  throw new ResourceAlreadyExistsException( subProcess.getName() ,HttpStatus.CONFLICT);
                }
                subProcessRepository.save(subProcess);
            }
        }
        else {
        	  throw new ProcessNotFoundException(process_id);
        }
    }

    public void update(Long processId, SubProcess subProcess) {
        Optional<Process> optionalProcess = processRepository.findById(processId);
        System.out.println("optionalProcess" + optionalProcess);
        Process process = optionalProcess.get();
        System.out.println("process" + process);
        subProcess.setProcess(process);
        subProcessRepository.save(subProcess);

    }

    public void deleteById(Long processId, Long subProcessId) {
        try {
            Process process = processRepository.findById(processId).get();
            SubProcess subProcess = subProcessRepository.findById(subProcessId).get();
            process.getSubProcesses().remove(subProcess);
            processRepository.save(process);
            subProcessRepository.delete(subProcess);
        } catch (Exception e) {
          throw e;
        }
      
    }

}
