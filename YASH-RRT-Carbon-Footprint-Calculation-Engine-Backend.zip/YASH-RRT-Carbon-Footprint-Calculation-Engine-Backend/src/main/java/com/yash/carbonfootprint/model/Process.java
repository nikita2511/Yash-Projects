package com.yash.carbonfootprint.model;

import jakarta.persistence.*;

// import java.sql.Date;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Date;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

// import com.fasterxml.jackson.annotation.JsonManagedReference;

@Entity
@Table(name = "process_master_data", schema = "carbon_footprint")
public class Process {


	// Date date = new Date();
	// public Process(long id, List<SubProcess> subProcesses, String name, String created_by, String updated_by) {
	// 	this.id = id;
	// 	this.subProcesses = subProcesses;
	// 	this.name = name;
	// 	this.created_by = created_by;
	// 	this.updated_by = updated_by;
	// 	// this.updatedAt = updatedAt;
	// 	// this.createdAt = createdAt;
	// }

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long id;

	@OneToMany(cascade = CascadeType.ALL, mappedBy = "process", fetch = FetchType.EAGER)
	// @JsonManagedReference
	private List<SubProcess> subProcesses = new ArrayList<>();

	@Column(name = "name")
	private String name;

	@Column(name = "created_by")
	private String created_by;

	@Column(name = "updated_by")
	private String updated_by;

	@Column(name = "updated_at")
	private Date updatedAt= new Date();

	@Column(name = "created_at")
	private Date createdAt=new Date();
	public Process() {
	}

	public Process(String name, String created_by, String updated_by) {
		this.name = name;
		this.created_by = created_by;
		this.updated_by = updated_by;
	}

	
	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public List<SubProcess> getSubProcesses() {
		return subProcesses;
	}

	public void setSubProcesses(List<SubProcess> subProcesses) {
		this.subProcesses = subProcesses;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCreated_by() {
		return created_by;
	}

	public void setCreated_by(String created_by) {
		this.created_by = created_by;
	}

	public String getUpdated_by() {
		return updated_by;
	}

	public void setUpdated_by(String updated_by) {
		this.updated_by = updated_by;
	}

	// public Date getUpdatedAt() {
	// 	return updatedAt;
	// }

	// public void setUpdatedAt(Date updatedAt) {
	// 	this.updatedAt = updatedAt;
	// }



	// public Date getCreatedAt() {
	// 	return createdAt;
	// }

	// public void setCreatedAt(Date createdAt) {
	// 	this.createdAt = createdAt;
	// }

	@Override
	public String toString() {
		return "Process [id=" + id + ", subProcesses=" + subProcesses + ", name=" + name + ", created_by=" + created_by
				+ ", updated_by=" + updated_by + "]";
	}

}
