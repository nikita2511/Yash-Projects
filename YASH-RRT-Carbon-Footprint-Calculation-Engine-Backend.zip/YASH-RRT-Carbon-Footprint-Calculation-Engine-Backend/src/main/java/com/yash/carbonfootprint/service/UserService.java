package com.yash.carbonfootprint.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;

//import com.yash.carbonfootprint.exceptions.AlreadyExistsException;
import com.yash.carbonfootprint.exceptions.ResourceAlreadyExistsException;
//import com.yash.carbonfootprint.exceptions.UserAlreadyExistsException;
import com.yash.carbonfootprint.model.User;
import com.yash.carbonfootprint.repository.UserRepository;
import com.yash.carbonfootprint.utility.SecurityConfig;

@Service
public class UserService {
    @Autowired
    UserRepository userRepository;

    SecurityConfig securityConfig = new SecurityConfig();

    public User saveOrUpdate(User user) {
    	
        user.setPassword(securityConfig.passwordEncoder().encode(user.getPassword()));
        List<User> existingUser = userRepository.findByEmail(user.getEmail());
        if (!existingUser.isEmpty()) {
        	  throw new ResourceAlreadyExistsException( user.getEmail() ,HttpStatus.CONFLICT);
        }
        return userRepository.save(user);
    }

    public User login(User user) throws Exception {
        List<User> userObj = userRepository.findByEmail(user.getEmail());
        if (userObj.isEmpty()) {
            throw new Exception("Invalid User name or password");
        }
        Boolean isValid = securityConfig.passwordEncoder().matches(user.getPassword(), userObj.get(0).getPassword());
        if (isValid) {
            return userObj.get(0);
        } else {
            throw new Exception("Invalid User name or password");
        }
    }

}
