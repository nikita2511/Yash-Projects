package com.yash.carbonfootprint.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.yash.carbonfootprint.model.SupplyChain;
//import com.yash.carbonfootprint.model.SupplyChainMapping;

@Repository
public interface SupplyChainRepository
        extends JpaRepository<SupplyChain, Long> {
	public List<SupplyChain> findByName(String name);
}
