package com.yash.carbonfootprint.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;
import com.yash.carbonfootprint.dto.SupplyChainRequestDTO;
import com.yash.carbonfootprint.exceptions.ResourceAlreadyExistsException;
import com.yash.carbonfootprint.model.SupplyChain;
import com.yash.carbonfootprint.service.SupplyChainService;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

@RestController
@RequestMapping("/api/v1")
@CrossOrigin(origins = "http://localhost:3000")
public class SupplyChainController {
    @Autowired
    SupplyChainService supplyChainService;

    @GetMapping("/supply-chain/{id}")
    public SupplyChain getSupplyChainById(@PathVariable("id") Long id) {
        return supplyChainService.getSupplyChainById(id);
    }

    @PostMapping("/supply-chain")
    public ResponseEntity<?> createSupplyChain(@RequestBody SupplyChainRequestDTO supplyChainRequestDTO) {
        Map<String, Object> response = new HashMap<>();
        try {
        System.out.print("supplyChainRequestDTO in controller"+supplyChainRequestDTO);
        SupplyChain createdSupplyChain = supplyChainService.createSupplyChain(supplyChainRequestDTO);
        response.put("data",createdSupplyChain);
        response.put("message", "supply chain created successfully!");
        response.put("status", 200);
        return ResponseEntity.ok(response);
        } 
        catch (ResourceAlreadyExistsException e) {
            response.put("message", e.getMessage());
            response.put("status", HttpStatus.CONFLICT);
            return ResponseEntity.status(HttpStatus.CONFLICT).body(response);
    	}
        catch (Exception e) {
            response.put("message", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }

    }

    @GetMapping("/supply-chain")
    private ResponseEntity<List<SupplyChain>> getAllSupplyChain() {
        return new ResponseEntity<>(supplyChainService.getAllSupplyChains(), HttpStatus.OK);
    }

    @PutMapping("/supply-chain")
    private ResponseEntity<Map<String, Object>> update(@RequestBody SupplyChainRequestDTO supplyChainRequestDTO) {
        Map<String, Object> response = new HashMap<>();
        supplyChainService.updateSupplyChain(supplyChainRequestDTO);
        response.put("message", "supply chain updated successfully!");
        response.put("status",200);
        return ResponseEntity.ok(response);
    }

    @DeleteMapping("/supply-chain/{id}")
    public ResponseEntity<?> deleteById(@PathVariable Long id) {
        try {
            supplyChainService.deleteById(id);
            return ResponseEntity.noContent().build();
        } catch (Exception e) {
            return ResponseEntity.badRequest().body(e.getMessage());
        }
    }

    @DeleteMapping("/supply-chain/{supplyChainId}/supply-chain-mapping/{supplyChainMappingId}")
    public ResponseEntity<?> deleteSupplyChainProcessMapping(@PathVariable Long supplyChainId,
            @PathVariable Long supplyChainMappingId) {
        Map<String, String> response = new HashMap<>();
        try {
            supplyChainService.deleteSupplyChainMapping(supplyChainId, supplyChainMappingId);
            response.put("message", "Successfully deleted");
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("errorMessage", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }

}
