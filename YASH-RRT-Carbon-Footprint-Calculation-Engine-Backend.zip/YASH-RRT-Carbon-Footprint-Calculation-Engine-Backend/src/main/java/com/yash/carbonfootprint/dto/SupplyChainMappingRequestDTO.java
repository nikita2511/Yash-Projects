package com.yash.carbonfootprint.dto;

public class SupplyChainMappingRequestDTO {
   
    public SupplyChainMappingRequestDTO(Long id, Long process_id, Long sub_process_id, Double quantity,
            Integer sequence) {
        this.id = id;
        this.process_id = process_id;
        this.sub_process_id = sub_process_id;
        this.quantity = quantity;
        this.sequence = sequence;
    }
    public SupplyChainMappingRequestDTO(Long process_id, Long sub_process_id, Double quantity, Integer sequence) {
        this.process_id = process_id;
        this.sub_process_id = sub_process_id;
        this.quantity = quantity;
        this.sequence = sequence;
    }
    public SupplyChainMappingRequestDTO() {
    }
    private Long id;
    public Long getId() {
        return id;
    }
    private Long process_id;
    private Long sub_process_id;
    private Double quantity; // Use Integer for optional quantity
    private Integer sequence;
    public Long getProcess_id() {
        return process_id;
    }
    public void setProcess_id(Long process_id) {
        this.process_id = process_id;
    }
    public Long getSub_process_id() {
        return sub_process_id;
    }
    public void setSub_process_id(Long sub_process_id) {
        this.sub_process_id = sub_process_id;
    }
    public Double getQuantity() {
        return quantity;
    }
    public void setQuantity(Double quantity) {
        this.quantity = quantity;
    }
    public Integer getSequence() {
        return sequence;
    }
    public void setSequence(Integer sequence) {
        this.sequence = sequence;
    }
    @Override
    public String toString() {
        return "SupplyChainMappingRequestDTO [process_id=" + process_id + ", sub_process_id=" + sub_process_id
                + ", quantity=" + quantity + ", sequence=" + sequence + "]";
    }
}
