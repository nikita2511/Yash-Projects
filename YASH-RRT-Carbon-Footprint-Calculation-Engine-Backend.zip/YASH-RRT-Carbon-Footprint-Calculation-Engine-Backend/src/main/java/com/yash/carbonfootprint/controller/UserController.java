package com.yash.carbonfootprint.controller;

import java.util.HashMap;
//import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.yash.carbonfootprint.exceptions.ResourceAlreadyExistsException;
//import com.yash.carbonfootprint.exceptions.UserAlreadyExistsException;
import com.yash.carbonfootprint.model.User;
import com.yash.carbonfootprint.service.UserService;

import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@RestController
@RequestMapping("/api/v1")
@CrossOrigin(origins = "http://localhost:3000", methods = { RequestMethod.GET, RequestMethod.POST })
public class UserController {

    @Autowired
    UserService userService;

    @PostMapping("/user")
    private ResponseEntity<?> saveUser(@RequestBody User user) {
        Map<String, Object> response = new HashMap<>();
        try {
            userService.saveOrUpdate(user);
            return ResponseEntity.ok(user);
        } catch (ResourceAlreadyExistsException e) {
        	System.out.println("-----------e----------" + e.getMessage());
        	System.out.println("-----------e----------" + e.getStatusCode());
            response.put("message", e.getMessage());
            response.put("status", HttpStatus.CONFLICT);
            return ResponseEntity.status(HttpStatus.CONFLICT).body(response);
        }
    }

    @PostMapping("/login")
    private ResponseEntity<?> login(@RequestBody User user) {
        Map<String, Object> response = new HashMap<>();
        try {
            System.out.println("inside login" + user);
            User userObj = userService.login(user);
            return ResponseEntity.ok(userObj);
        } catch (Exception e) {
            response.put("Message", e.getMessage());
            return ResponseEntity.badRequest().body(response);
        }
    }

}
