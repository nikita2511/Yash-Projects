package com.yash.carbonfootprint.model;

import jakarta.persistence.*;

@Entity
@Table(name = "supply_chain_category_master_data", schema = "carbon_footprint")
public class SupplyChainCategoryMasterData {

    public SupplyChainCategoryMasterData() {
    }

    // constructor
    public SupplyChainCategoryMasterData(String name, String created_by, String updated_by) {
        this.name = name;
        this.created_by = created_by;
        this.updated_by= updated_by;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "name", nullable = false)
    private String name;

    @Column(name = "created_by", nullable = false)
    private String created_by;

    @Column(name = "updated_by", nullable = false)
    private String updated_by;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

 
    @Override
    public String toString() {
        return "SupplyChainCategoryMasterData [id=" + id + ", name=" + name + ", createdBy=" + created_by
                + ", updatedBy=" + updated_by + "]";
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCreated_by() {
        return created_by;
    }

    public void setCreated_by(String created_by) {
        this.created_by = created_by;
    }

    public String getUpdated_by() {
        return updated_by;
    }

    public void setUpdated_by(String updated_by) {
        this.updated_by = updated_by;
    }

}
