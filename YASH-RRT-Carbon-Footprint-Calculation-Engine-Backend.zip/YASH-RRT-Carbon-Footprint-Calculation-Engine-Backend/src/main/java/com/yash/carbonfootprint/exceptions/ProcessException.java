package com.yash.carbonfootprint.exceptions;

import org.springframework.http.HttpStatus;

public class ProcessException extends RuntimeException {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private final String code;
    private final HttpStatus httpStatus;

    public ProcessException(String code, HttpStatus httpStatus, String message) {
        super(message);
        this.code = code;
        this.httpStatus = httpStatus;
    }

    public String getCode() {
        return code;
    }

    public HttpStatus getHttpStatus() {
        return httpStatus;
    }
}
