package com.yash.carbonfootprint.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.yash.carbonfootprint.service.ProcessService;
import com.yash.carbonfootprint.exceptions.ResourceAlreadyExistsException;
import com.yash.carbonfootprint.model.Process;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
@RestController
@RequestMapping("/api/v1")
@CrossOrigin(origins = "http://localhost:3000",
methods = {RequestMethod.GET, RequestMethod.POST,RequestMethod.DELETE,RequestMethod.PUT})
public class ProcessController {
    
    @Autowired
    ProcessService processService;

    @GetMapping("/process")  
	private  ResponseEntity<?> getAllProcesses()   
	{   
       Map<String, Object> response = new HashMap<>();
    try {
       System.out.println(processService.getAllProcesses());
       return new ResponseEntity<>(processService.getAllProcesses(), HttpStatus.OK);
	  } catch (Exception e) {
	   response.put("message", e.getMessage());
	   response.put("status", HttpStatus.INTERNAL_SERVER_ERROR);
	   return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(response);
	}
  
	}  

    
	@PostMapping("/process")  
	private ResponseEntity<?> saveProcess(@RequestBody Process process)   
	{  
		Map<String, Object> response = new HashMap<>();
	try {
	   	processService.saveOrUpdate(process);  
	    response.put("message", "process saved successfully");
	    response.put("status",200);
	    return ResponseEntity.status(HttpStatus.OK).body(response);
	} catch (ResourceAlreadyExistsException e) {
        response.put("message", e.getMessage());
        response.put("status", HttpStatus.CONFLICT);
        return ResponseEntity.status(HttpStatus.CONFLICT).body(response);
	}
 
	}  

	
	@GetMapping("/process/{id}")  
	private ResponseEntity<?> getUser(@PathVariable("id") int id)   
	{  
		Map<String, Object> response = new HashMap<>();
	try {  
		return new ResponseEntity<>(processService.getProcessById(id), HttpStatus.OK);
	} catch (Exception e) {
		response.put("message", e.getMessage());
	    response.put("status", 500); // Optional inclusion  
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
    }
	
	}  
	
	@PutMapping("/process")  
	private ResponseEntity<Map<String, Object>> update(@RequestBody Process process)   
	{  
		Map<String, Object> response = new HashMap<>();
	try {
		processService.saveOrUpdate(process); 
		response.put("message", "process updated successfully");
		response.put("status",200);
	    return ResponseEntity.status(HttpStatus.OK).body(response);
	} catch (Exception e) {
		response.put("message", e.getMessage());
	    response.put("status", 500); // Optional inclusion 
		return ResponseEntity.ok(response); 
	}

	} 

	@DeleteMapping("/process/{id}")
    public ResponseEntity<?> deleteById(@PathVariable Long id) {
		Map<String, Object> response = new HashMap<>();
        try {
            processService.deleteById(id);
            response.put("message", "process deleted successfully");
            response.put("status",200);
		    return ResponseEntity.status(HttpStatus.OK).body(response);
        } catch (Exception e) {
        	response.put("message", e.getMessage());
    	    response.put("status", 500); // Optional inclusion  
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(e.getMessage());
        }
    }
}
