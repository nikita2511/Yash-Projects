package com.yash.carbonfootprint.model;

import com.fasterxml.jackson.annotation.JsonBackReference;

import jakarta.persistence.*;

@Entity
@Table(name = "supply_chain_mapping", schema = "carbon_footprint")
public class SupplyChainMapping {

    public SupplyChainMapping() {
    }

    public SupplyChainMapping(Double quantity, Integer sequence, Double processFootprint, Process process,
            SubProcess subProcess, SupplyChain supplyChain) {
        this.quantity = quantity;
        this.sequence = sequence;
        this.processFootprint = processFootprint;
        this.process = process;
        this.subProcess = subProcess;
        this.supplyChain = supplyChain;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY) // Assuming auto-increment
    private Long id;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Column(name = "quantity", nullable = false)
    private Double quantity;

    @Column(name = "sequence", nullable = false)
    private Integer sequence;

    @Column(name = "process_footprint")
    private Double processFootprint;

    // @ManyToOne
    // @JoinColumn(name = "process_id", nullable = false)
    // private Long process_id;

    // public Long getProcess_id() {
    // return process_id;
    // }

    // public void setProcess_id(Long process_id) {
    // this.process_id = process_id;
    // }

    @ManyToOne
    @JoinColumn(name = "sub_process_id")
    private SubProcess subProcess;

    @ManyToOne
    @JoinColumn(name = "supply_chain_id", nullable = false)
    @JsonBackReference
    private SupplyChain supplyChain;

    public Double getQuantity() {
        return quantity;
    }

    public void setQuantity(Double quantity) {
        this.quantity = quantity;
    }

    public Integer getSequence() {
        return sequence;
    }

    public void setSequence(Integer sequence) {
        this.sequence = sequence;
    }

    public Double getProcessFootprint() {
        return processFootprint;
    }

    public void setProcessFootprint(Double processFootprint) {
        this.processFootprint = processFootprint;
    }

    @ManyToOne
    @JoinColumn(name = "process_id", nullable = false)
    private Process process;

    public SupplyChainMapping(Long id, Double quantity, Integer sequence, Double processFootprint, Process process,
            SubProcess subProcess, SupplyChain supplyChain) {
        this.id = id;
        this.quantity = quantity;
        this.sequence = sequence;
        this.processFootprint = processFootprint;
        this.process = process;
        this.subProcess = subProcess;
        this.supplyChain = supplyChain;
       
    }

    public Process getProcess() {
        return process;
    }

    public void setProcess(Process process) {
        this.process = process;
    }

    public SubProcess getSubProcess() {
        return subProcess;
    }

    public void setSubProcess(SubProcess subProcess) {
        this.subProcess = subProcess;
    }

    public SupplyChain getSupplyChain() {
        return supplyChain;
    }

    public void setSupplyChain(SupplyChain supplyChain) {
        this.supplyChain = supplyChain;
    }

}
